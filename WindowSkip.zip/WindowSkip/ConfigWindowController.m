//
//  ConfigWindowController.m
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016 108. All rights reserved.
//  adpbG147.

#import "ConfigWindowController.h"
#import "MainWindowController.h"
#import "PlistTool.h"
#import "UMWindowController.h"
#import "Person.h"
#import "QcrPerson.h"
#import "fdrPerson.h"


@interface ConfigWindowController ()

@property (strong) UMWindowController *UMWindow;

@end

@implementation ConfigWindowController{
    
    PlistTool *plistHandler;
}

//NSTextView *txtScrollView ;

//NSMutableDictionary *ConfigDic;
NSString *filePath;
NSDictionary *Mutabledic;
NSDictionary *secondDic;
NSMutableDictionary *configDic;
NSMutableArray *radarDic;
NSMutableArray *qcrDict;
NSMutableDictionary *fdrDict;

NSString *confKeyConfig;
NSString *confValueConfig;
NSString *bundlePath;
NSString *bundlePathConfig;


- (void)windowDidLoad {
    [super windowDidLoad];

//    NSFileManager *fm = [NSFileManager defaultManager];
//    NSString *cuDir = [fm currentDirectoryPath];
//
//    filePath = [cuDir stringByAppendingPathComponent:@"config.plist"];
    
    
    [self.leftBn setButtonType: NSMomentaryPushInButton];
    [self.leftBn setBezelStyle: NSRoundedBezelStyle];
    [self.leftBn setBordered: NO];
    [self.leftBn setImage: [NSImage imageNamed: @"left_highlighted"]];
    [self.leftBn setImagePosition: NSImageOnly];
    [self.leftBn setTarget: self];

    
    plistHandler = [PlistTool instance];
    
    NSString *bundle = [[NSBundle mainBundle] pathForResource:@"config" ofType:@"plist"];
    
    configDic = [NSMutableDictionary dictionaryWithContentsOfFile:bundle];

    NSLog(@"configDic: %@", configDic);
    
    /*
    secondDic = [plistHandler valueForKey:@"Radar" inDictionary:configDic recursion:YES];

    NSEnumerator *enumerator = [secondDic keyEnumerator];
    confKeyConfig = [enumerator nextObject];
    
    confValueConfig = [secondDic objectForKey:confKeyConfig];
    */
    
    
    
    [self.radarPlusBn setButtonType: NSMomentaryPushInButton];
    [self.radarPlusBn setBezelStyle: NSRoundedBezelStyle];
    [self.radarPlusBn setBordered: YES];
    [self.radarPlusBn setImage: [NSImage imageNamed: @"plus.png"]];
    [self.radarPlusBn setImagePosition: NSImageOnly];
    [self.radarPlusBn setTarget: self];
    
    [self.qcrPlusBn setButtonType: NSMomentaryPushInButton];
    [self.qcrPlusBn setBezelStyle: NSRoundedBezelStyle];
    [self.qcrPlusBn setBordered: YES];
    [self.qcrPlusBn setImage: [NSImage imageNamed: @"plus.png"]];
    [self.qcrPlusBn setImagePosition: NSImageOnly];
    [self.qcrPlusBn setTarget: self];
    
    [self.fdrPlusBn setButtonType: NSMomentaryPushInButton];
    [self.fdrPlusBn setBezelStyle: NSRoundedBezelStyle];
    [self.fdrPlusBn setBordered: YES];
    [self.fdrPlusBn setImage: [NSImage imageNamed: @"plus.png"]];
    [self.fdrPlusBn setImagePosition: NSImageOnly];
    [self.fdrPlusBn setTarget: self];
    
    
    [self.radarMinusBn setButtonType: NSMomentaryPushInButton];
    [self.radarMinusBn setBezelStyle: NSRoundedBezelStyle];
    [self.radarMinusBn setBordered: YES];
    [self.radarMinusBn setImage: [NSImage imageNamed: @"minus.png"]];
    [self.radarMinusBn setImagePosition: NSImageOnly];
    [self.radarMinusBn setTarget: self];
    
    [self.qcrMinusBn setButtonType: NSMomentaryPushInButton];
    [self.qcrMinusBn setBezelStyle: NSRoundedBezelStyle];
    [self.qcrMinusBn setBordered: YES];
    [self.qcrMinusBn setImage: [NSImage imageNamed: @"minus.png"]];
    [self.qcrMinusBn setImagePosition: NSImageOnly];
    [self.qcrMinusBn setTarget: self];
    
    [self.fdrMinusBn setButtonType: NSMomentaryPushInButton];
    [self.fdrMinusBn setBezelStyle: NSRoundedBezelStyle];
    [self.fdrMinusBn setBordered: YES];
    [self.fdrMinusBn setImage: [NSImage imageNamed: @"minus.png"]];
    [self.fdrMinusBn setImagePosition: NSImageOnly];
    [self.fdrMinusBn setTarget: self];
    
    
    //初始化控件
    self.radarBorderedScro.hidden =YES;
    self.radarPlusBn.hidden = YES;
    self.radarMinusBn.hidden = YES;
    
    self.qcrBorderedScro.hidden = NO;
    self.qcrPlusBn.hidden = NO;
    self.qcrMinusBn.hidden = NO;
    
    self.fdrBorderedScro.hidden = YES;
    self.fdrPlusBn.hidden = YES;
    self.fdrMinusBn.hidden = YES;
    
}


- (IBAction)backToUM:(id)sender {
    _UMWindow = [[UMWindowController alloc] initWithWindowNibName:@"UMWindowController"];
    [_UMWindow.window orderFront:nil];
    [_UMWindow.window center];
    [self.window orderOut:nil];
}


#pragma mark -- add, delete, modify the radar plist
- (IBAction)addItem:(id)sender {
    
    Person *newPerson = [[Person alloc] init];
    
    [_personArr addObject:newPerson.personName];
    
    [_passwdArr addObject:newPerson.passWord];
    
    [_checkArr addObject:newPerson.checkState];
    
    [tableViewTest reloadData];
    
    NSLog(@"radarDic: %lu", (unsigned long)radarDic.count);
    
    //将新建newPerson数据写入MutableDic
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];

    [plistHandler setValue:_checkArr[radarDic.count] forKey:@"Check" inDictionary:dict recursion:NO];

    [plistHandler setValue:_passwdArr[radarDic.count] forKey:@"Password" inDictionary:dict recursion:NO];

    [plistHandler setValue:_personArr[radarDic.count] forKey:@"UserName" inDictionary:dict recursion:NO];

    [radarDic addObject:dict];

    [plistHandler write:Mutabledic toFile:bundlePathConfig];
    
    NSLog(@"radarDic: %@", radarDic);

    
    id RadarDic = [plistHandler valueForKey:@"Radar" inDictionary:configDic recursion:YES];
    
    NSLog(@"RadarDic: %@", RadarDic);
}


- (IBAction)deleteItem:(id)sender {
    
    NSIndexSet *rows = [tableViewTest selectedRowIndexes];
    
    NSInteger row = [tableViewTest selectedRow];
    
    
    if([rows count] == 0){
        
        NSBeep();
        
        return;
    }
    
    [_personArr removeObjectsAtIndexes:rows];
    [_passwdArr removeObjectsAtIndexes:rows];
    [_checkArr removeObjectsAtIndexes:rows];

    NSLog(@"rows.count: %lu", (unsigned long)rows.count);
    
    NSLog(@"rows.count: %lu", (unsigned long)row);
    
    [radarDic removeObjectAtIndex:row];
    
    
    NSLog(@"radarDic: %@", radarDic);
    
    [plistHandler write:Mutabledic toFile:bundlePathConfig];
    
    [tableViewTest reloadData];
}



#pragma mark - add, delete, modify the QCR plist
- (IBAction)addQcrItem:(id)sender {
    
    QcrPerson *newPerson = [[QcrPerson alloc] init];
    
    [_qcrPersonArr addObject:newPerson.qcrPersonName];
    
    [_qcrPasswdArr addObject:newPerson.qcrPassWord];
    
    [_qcrCheckArr addObject:newPerson.qcrCheckState];
    
    [qcrTableView reloadData];
    
    NSLog(@"radarDic: %lu", (unsigned long)qcrDict.count);
    
    
    //将新建newPerson数据写入MutableDic
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    
    [plistHandler setValue:_qcrCheckArr[qcrDict.count] forKey:@"qcrCheck" inDictionary:dict recursion:NO];
    
    [plistHandler setValue:_qcrPasswdArr[qcrDict.count] forKey:@"qcrPassword" inDictionary:dict recursion:NO];
    
    [plistHandler setValue:_qcrPersonArr[qcrDict.count] forKey:@"qcrUserName" inDictionary:dict recursion:NO];
    
    [qcrDict addObject:dict];
    
    [plistHandler write:Mutabledic toFile:bundlePathConfig];
    
    NSLog(@"radarDic: %@", qcrDict);
    
    
    id RadarDic = [plistHandler valueForKey:@"qcrRadar" inDictionary:configDic recursion:YES];
    
    NSLog(@"RadarDic: %@", RadarDic);
}


- (IBAction)deleteQcrItem:(id)sender {
    
    NSIndexSet *rows = [qcrTableView selectedRowIndexes];
    
    NSInteger row = [qcrTableView selectedRow];
    
    
    if([rows count] == 0){
        
        NSBeep();
        
        return;
    }
    
    [_qcrPersonArr removeObjectsAtIndexes:rows];
    
    [_qcrPasswdArr removeObjectsAtIndexes:rows];
    
    [_qcrCheckArr removeObjectsAtIndexes:rows];
    
    
    NSLog(@"rows.count: %lu", (unsigned long)rows.count);
    
    NSLog(@"rows.count: %lu", (unsigned long)row);
    
    [qcrDict removeObjectAtIndex:row];
    
    NSLog(@"radarDic: %@", qcrDict);
    
    [plistHandler write:Mutabledic toFile:bundlePathConfig];
    
    [qcrTableView reloadData];
}

- (IBAction)addFdrItem:(id)sender {
    
    fdrPerson *newPerson = [[fdrPerson alloc] init];
    
    [_fdrPersonArr addObject:newPerson.fdrPersonName];
    
    [_fdrPasswdArr addObject:newPerson.fdrPassWord];
    
    [fdrTableView reloadData];
    
    NSLog(@"radarDic: %lu", (unsigned long)qcrDict.count);
    
}

- (IBAction)deleteFdrItem:(id)sender {
    
    NSIndexSet *rows = [fdrTableView selectedRowIndexes];
    
    NSInteger row = [fdrTableView selectedRow];

    if([rows count] == 0){
        
        NSBeep();
        
        return;
    }
    
    NSLog(@"_fdrPersonArr: %@", _fdrPersonArr);
    
    NSLog(@"row: %ld", (long)row);
    
    
    
    id name = [_fdrPersonArr objectAtIndex:row];

    NSLog(@"name: %@", name);
    
    [plistHandler removeKey:name inDictionary:Mutabledic recursion:YES];
    
    [plistHandler write:Mutabledic toFile:bundlePathConfig];
    
    [fdrTableView reloadData];
    
}




#pragma mark -- select diffirent table

- (IBAction)selecteSeg:(id)sender {
    
    NSInteger segmentNum = self.segment.selectedSegment;
    
    switch (segmentNum) {
            
        case 0:
            self.radarBorderedScro.hidden =NO;
            self.radarPlusBn.hidden = NO;
            self.radarMinusBn.hidden = NO;
            self.qcrBorderedScro.hidden = YES;
            self.qcrPlusBn.hidden = YES;
            self.qcrMinusBn.hidden = YES;
            self.fdrBorderedScro.hidden = YES;
            self.fdrPlusBn.hidden = YES;
            self.fdrMinusBn.hidden = YES;
            break;
        case 1:
            self.radarBorderedScro.hidden =YES;
            self.radarPlusBn.hidden = YES;
            self.radarMinusBn.hidden = YES;
            self.qcrBorderedScro.hidden = NO;
            self.qcrPlusBn.hidden = NO;
            self.qcrMinusBn.hidden = NO;
            self.fdrBorderedScro.hidden = YES;
            self.fdrPlusBn.hidden = YES;
            self.fdrMinusBn.hidden = YES;
            break;
            
        case 2:
            self.radarBorderedScro.hidden =YES;
            self.radarPlusBn.hidden = YES;
            self.radarMinusBn.hidden = YES;
            self.qcrBorderedScro.hidden = YES;
            self.qcrPlusBn.hidden = YES;
            self.qcrMinusBn.hidden = YES;
            self.fdrBorderedScro.hidden = NO;
            self.fdrPlusBn.hidden = NO;
            self.fdrMinusBn.hidden = NO;
            
            break;
            
        case 3:
            
            break;
        default:
            break;
    }
    
}

#pragma mark - NSTableViewDataSource
-(void) awakeFromNib{

    plistHandler = [PlistTool instance];
    
    bundlePath = [[NSBundle mainBundle] resourcePath];
    bundlePathConfig = [bundlePath stringByAppendingPathComponent:@"config.plist"];
    
    NSLog(@"bundlePathConfig: %@", bundlePathConfig);
    
    
    //RadarMutableDic
    NSString *bundle = [[NSBundle mainBundle] pathForResource:@"config" ofType:@"plist"];
    Mutabledic = [[NSMutableDictionary alloc] initWithContentsOfFile:bundle];
    
    radarDic = [plistHandler valueForKey:@"Radar" inDictionary:Mutabledic recursion:YES];
    _personArr = [NSMutableArray array];
    _passwdArr = [NSMutableArray array];
    _checkArr=[NSMutableArray array];
    
    if([radarDic respondsToSelector:@selector(objectAtIndex:)]){
        for(int i = 0; i< radarDic.count; i++){
            [_personArr addObject:[radarDic[i] objectForKey:@"UserName"]];
            [_passwdArr addObject:[radarDic[i] objectForKey:@"Password"]];
            [_checkArr addObject:[radarDic[i] objectForKey:@"Check"]];
        }
    }

    //QCRMutableDic
    qcrDict = [plistHandler valueForKey:@"QCR" inDictionary:Mutabledic recursion:YES];
   // NSLog(@"qcrDict: %@", qcrDict);
    
    _qcrPersonArr = [NSMutableArray array];
    _qcrPasswdArr = [NSMutableArray array];
    _qcrCheckArr=[NSMutableArray array];

    if([qcrDict respondsToSelector:@selector(objectAtIndex:)]){
        for(int i = 0; i< qcrDict.count; i++){
            NSLog(@"%d: %lu: ",i , (unsigned long)qcrDict.count);
            [_qcrPersonArr addObject:[qcrDict[i] objectForKey:@"qcrUserName"]];
            [_qcrPasswdArr addObject:[qcrDict[i] objectForKey:@"qcrPassword"]];
            [_qcrCheckArr addObject:[qcrDict[i] objectForKey:@"qcrCheck"]];
        }
    }
    
    //fdrMutableDic
    fdrDict = [plistHandler valueForKey:@"FDRSeal" inDictionary:Mutabledic recursion:YES];
    _fdrPersonArr = [NSMutableArray array];
    _fdrPasswdArr = [NSMutableArray array];
    
    
    if([fdrDict respondsToSelector:@selector(objectForKey:)]){
        
        id temp = [fdrDict  keyEnumerator];
        
        NSString* str;
        
        while (str =  [temp nextObject]) {
            [_fdrPersonArr addObject:str];
        }
        
        NSLog(@"_fdrPersonArr: %@", _fdrPersonArr);
        
        for (int i = 0 ; i<_fdrPersonArr.count; i++) {
            [_fdrPasswdArr addObject:[fdrDict objectForKey:_fdrPersonArr[i]]];
        }
        NSLog(@"valueArray: %@", _fdrPasswdArr);
    }
}

#pragma mark - Table View Data Source
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
//    NSLog(@"self.numberCodes.count:%lu", (unsigned long)self.personArr.count);
    if([tableView isEqual:tableViewTest]){
        
        return self.personArr.count;
    }else if([tableView isEqual:qcrTableView]){
        
        return self.qcrPasswdArr.count;
    }else if([tableView isEqual:fdrTableView]){
        
       return self.fdrPasswdArr.count;
    }
    
    return 0;
}

- (id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
    if([tableView isEqual:tableViewTest]){
       
        if ([tableColumn.identifier isEqualToString:@"people"]) {
            NSString *personIdt = (NSString*)[self.personArr objectAtIndex:row];
            return personIdt;
        }else if([tableColumn.identifier isEqualToString:@"password"]){
            NSString *passWdIdt = (NSString*)[self.passwdArr objectAtIndex:row];
            return passWdIdt;
        }else if([tableColumn.identifier isEqualToString:@"check"]){
            NSButtonCell* cell = [tableColumn dataCellForRow:row];
            [cell setTag:row];
            [cell setAction:@selector(CellClick:)];
            [cell setTarget:self];
    
            NSInteger nTemp;
            NSString *nsTemp=(NSString*)[_checkArr objectAtIndex:row];
            nTemp=[nsTemp intValue];
            [cell setState:nTemp];
            return cell;
        }
    }else if([tableView isEqual:qcrTableView]){
        
        if ([tableColumn.identifier isEqualToString:@"qcrPeople"]) {
            // first colum (numbers)
            NSString *personIdt = (NSString*)[self.qcrPersonArr objectAtIndex:row];
            return personIdt;
        }else if([tableColumn.identifier isEqualToString:@"qcrPassword"]){
            return (NSString*)[self.qcrPasswdArr objectAtIndex:row];
            
        }else if([tableColumn.identifier isEqualToString:@"qcrCheck"]){
            
            NSButtonCell* cell = [tableColumn dataCellForRow:row];
            [cell setTag:row];
            [cell setAction:@selector(CellClick:)];
            [cell setTarget:self];

            NSInteger nTemp;
            NSString *nsTemp=(NSString*)[_qcrCheckArr objectAtIndex:row];
            nTemp=[nsTemp intValue];
            [cell setState:nTemp];
            
            return cell;
        }
    }else if([tableView isEqual:fdrTableView]){
        
        if ([tableColumn.identifier isEqualToString:@"fdrPeople"]) {
            // first colum (numbers)
            
            NSString *personIdt = (NSString*)[self.fdrPersonArr objectAtIndex:row];
            return personIdt;
        }else if([tableColumn.identifier isEqualToString:@"fdrPassword"]){
            
            return (NSString*)[self.fdrPasswdArr objectAtIndex:row];
        }
    }
    return 0;
}



-(void)tableView:(NSTableView *)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    if([tableView isEqual:tableViewTest]){
        NSString *strIdt = [tableColumn identifier];
        if([strIdt isEqualToString:@"people"]){
            NSString *nsT = (NSString*)object;
            //NSLog(@"*******%@",nsT);
            [self.personArr replaceObjectAtIndex:row withObject:nsT];
           // NSLog(@"radarDic1: %@", radarDic);
            [self setDicValue:row];
            [tableViewTest reloadData];
        }else if([strIdt isEqualToString:@"password"]){
            NSString *ns = (NSString*)object;
            //NSLog(@"*******%@",ns);
            [self.passwdArr replaceObjectAtIndex:row withObject:ns];
            [self setDicValue:row];
            [tableViewTest reloadData];
        }else if([strIdt isEqualToString:@"check"]){
            id nsCheck = [_checkArr objectAtIndex:row];
            NSLog(@"nsCheck: %@", nsCheck);
            if([nsCheck isEqualTo:@"1"]){
                nsCheck = @"0";
            }else{
                nsCheck = @"1";
            }
            [self.checkArr replaceObjectAtIndex:row withObject:nsCheck];
            
     //       [radarDic removeObjectAtIndex:row];
            
     //       [plistHandler write:Mutabledic toFile:filePath];
            
      //      NSLog(@"radarDic1: %@", radarDic);
            
            [self setDicValue:row];
            [tableViewTest reloadData];
        }
    }else if([tableView isEqual:qcrTableView]){
        NSString *qcrIdt = [tableColumn identifier];
        if([qcrIdt isEqualToString:@"qcrPeople"]){
            NSString *nsT = (NSString*)object;
            //NSLog(@"*******%@",nsT);
            
            [self.qcrPersonArr replaceObjectAtIndex:row withObject:nsT];
            NSLog(@"radarDic1: %@", qcrDict);
            [self setQcrDicValue:row];
            [qcrTableView reloadData];
        }else if([qcrIdt isEqualToString:@"qcrPassword"]){
            NSString *ns = (NSString*)object;
            //NSLog(@"*******%@",ns);
            
            [self.qcrPasswdArr replaceObjectAtIndex:row withObject:ns];
            [self setQcrDicValue:row];
            [qcrTableView reloadData];
        }else if([qcrIdt isEqualToString:@"qcrCheck"]){
            
            id nsCheck = [_qcrCheckArr objectAtIndex:row];
            
    //        NSLog(@"nsCheck: %@", nsCheck);
            if([nsCheck isEqualTo:@"1"]){
                nsCheck = @"0";
            }else{
                nsCheck = @"1";
            }
            
            [self.qcrCheckArr replaceObjectAtIndex:row withObject:nsCheck];
            
            //       [radarDic removeObjectAtIndex:row];
            //       [plistHandler write:Mutabledic toFile:filePath];
            
            NSLog(@"radarDic1: %@", radarDic);
            [self setQcrDicValue:row];
            [qcrTableView reloadData];
        }
    }else if([tableView isEqual:fdrTableView]){
        NSString *qcrIdt = [tableColumn identifier];
        if([qcrIdt isEqualToString:@"fdrPeople"]){
            NSString *nsT = (NSString*)object;
            //NSLog(@"*******%@",nsT);
            
            [self.fdrPersonArr replaceObjectAtIndex:row withObject:nsT];
            
            [self setFdrDicValue:row];
            [fdrTableView reloadData];
        }else if([qcrIdt isEqualToString:@"fdrPassword"]){
            NSString *ns = (NSString*)object;
            //NSLog(@"*******%@",ns);
            
            [self.fdrPasswdArr replaceObjectAtIndex:row withObject:ns];
            [self setFdrDicValue:row];
            [fdrTableView reloadData];
        }
    }
}

-(void)setFdrDicValue:(NSInteger)row{
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    
    for (int i = 0; i<_fdrPasswdArr.count; i++) {
        [plistHandler setValue:_fdrPasswdArr[i] forKey:_fdrPersonArr[i] inDictionary:dict recursion:NO];
    }
    
    [plistHandler removeKey:@"FDRSeal" inDictionary:Mutabledic recursion:YES];
    id permissionDic = [plistHandler valueForKey:@"Permission" inDictionary:Mutabledic recursion:YES];
    [plistHandler insertKey:@"FDRSeal" withValue:dict inDictionary:permissionDic atKey:@"Radar" recursion:YES];
    [plistHandler write:Mutabledic toFile:bundlePathConfig];
}


-(void)setDicValue:(NSInteger)row{
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];

    [plistHandler setValue:_checkArr[row] forKey:@"Check" inDictionary:dict recursion:NO];
    [plistHandler setValue:_passwdArr[row] forKey:@"Password" inDictionary:dict recursion:NO];
    [plistHandler setValue:_personArr[row] forKey:@"UserName" inDictionary:dict recursion:NO];
    NSLog(@"radarDict:%@", dict);
    
    [radarDic replaceObjectAtIndex:row withObject:dict];
    [plistHandler write:Mutabledic toFile:bundlePathConfig];
}

-(void)setQcrDicValue:(NSInteger)row{
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    
    [plistHandler setValue:_qcrCheckArr[row] forKey:@"qcrCheck" inDictionary:dict recursion:NO];
    [plistHandler setValue:_qcrPasswdArr[row] forKey:@"qcrPassword" inDictionary:dict recursion:NO];
    [plistHandler setValue:_qcrPersonArr[row] forKey:@"qcrUserName" inDictionary:dict recursion:NO];
    
    [qcrDict replaceObjectAtIndex:row withObject:dict];
    [plistHandler write:Mutabledic toFile:bundlePathConfig];
}



-(void)CellClick:(id)sender{
    
    NSButtonCell* cell=(NSButtonCell *)[tableViewTest selectedCell];
    if([cell state]==1)
        [cell setState:0];
    else {
        [cell setState:1];
    }
    
    NSLog(@"CellClick=%ld",[[tableViewTest selectedCell] tag]);
}

#pragma mark - Table View Delegate

- (void)tableViewSelectionDidChange:(NSNotification *)notification {
    
    NSTableView *tableView = notification.object;
    NSLog(@"User has selected row %ld", (long)tableView.selectedRow);
}


@end
