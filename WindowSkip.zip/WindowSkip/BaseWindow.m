//
//  BaseWindow.m
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016年 108. All rights reserved.
//

#import "BaseWindow.h"

@implementation BaseWindow

@end
