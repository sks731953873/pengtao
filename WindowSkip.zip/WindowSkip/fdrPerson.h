//
//  fdrPerson.h
//  WindowSkip
//
//  Created by gdadmin on 4/17/17.
//  Copyright © 2017 108. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface fdrPerson : NSObject{
    
    NSString *fdrPersonName;
    NSString *fdrPassWord;
    
}

@property (readwrite, copy) NSString* fdrPersonName;
@property (readwrite, copy) NSString* fdrPassWord;


@end
