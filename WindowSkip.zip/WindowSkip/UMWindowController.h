//
//  NewsWindowController.h
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016年 108. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface UMWindowController : NSWindowController
@property (strong) IBOutlet NSView *bgView;

@property (strong) IBOutlet NSButton *radarBn;
@property (nonatomic, copy) NSArray *umArr;

- (IBAction)backToMainWindow:(id)sender;

- (IBAction)nextToRadar:(id)sender;

- (IBAction)nextToQCR:(id)sender;

- (IBAction)nextToFDR:(id)sender;

- (IBAction)nextToConfig:(id)sender;





@end
