//
//  FDRSealWindowController.m
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016 108. All rights reserved.
// C39SL01GHNW0

#import <sqlite3.h>
#import "FDRSealWindowController.h"
#import "UMWindowController.h"
#import "PlistTool.h"
#import "AppDelegate.h"

#import "FileTool.h"


#define DBNAME @"myDataBase.db"

static NSString *temCSV = @"fdr.csv";

@interface FDRSealWindowController ()

@property(strong) UMWindowController *UMWindow;

@property(strong) UploadRadarWindowController *UploadRadarWindow;

@end

@implementation FDRSealWindowController
{
    PlistTool *plistHandler;
    FileTool *fileTool;
    
    NSArray *qcrSecondDic;
    
    
}


NSTextView *QCRInfo;
NSString *FDRKeyConfig;
NSString *FDRValueConfig;
NSString *FDRAccount;

NSString *currentDirectory;


NSFileManager *fileManager;



NSTextView *fdrView;
NSTextStorage *ts;


- (void)windowDidLoad {
    [super windowDidLoad];
    
    //FDRSeal background color
    _FDRSealView.wantsLayer = YES;
    _FDRSealView.layer.backgroundColor = CGColorCreateGenericRGB(1.0f, 0.9f, 0.9f, 0.9f);
    
    //leftBn
    [self.fdrLeftBn setButtonType: NSMomentaryPushInButton];
    [self.fdrLeftBn setBezelStyle: NSRoundedBezelStyle];
    [self.fdrLeftBn setBordered: NO];
    [self.fdrLeftBn setImage: [NSImage imageNamed: @"left_highlighted"]];
    [self.fdrLeftBn setImagePosition: NSImageOnly];
    [self.fdrLeftBn setTarget: self];
    
    
    fileManager = [NSFileManager defaultManager];
    currentDirectory = [fileManager currentDirectoryPath];
    //NSLog(@"currentDirectory: %@", currentDirectory);
    
    plistHandler = [PlistTool instance];
    
    NSDictionary *configDic = [NSDictionary dictionaryWithContentsOfFile:@"config.plist"];
    
    qcrSecondDic = [plistHandler valueForKey:@"QCR" inDictionary:configDic recursion:YES];
    
    //NSLog(@"secondDic: %@", qcrSecondDic);
    
    if([qcrSecondDic respondsToSelector:@selector(objectAtIndex:)]){
        
        for(int i = 0 ; i< qcrSecondDic.count; i++){
            
            //NSLog(@"check: %@", [qcrSecondDic[i] objectForKey:@"qcrCheck"]);
            
            id temp = [qcrSecondDic[i] objectForKey:@"qcrCheck"];
            
            if([temp isEqual:@"1"]){
                
                
                
                FDRKeyConfig = [qcrSecondDic[i] objectForKey:@"qcrUserName"];
                
                FDRAccount = [qcrSecondDic[i] objectForKey:@"qcrPassword"];
                
            }else{
                
                
            }
        }
    }
    
    FDRAccount = [[NSString alloc] initWithFormat:@"%@:%@", FDRKeyConfig,FDRAccount];
    NSLog(@"FDRAccount: %@", FDRAccount);

    
    
//    NSEnumerator *enumerator = [secondDic keyEnumerator];
//    
//    FDRKeyConfig = [enumerator nextObject];
//    
//    FDRValueConfig = [secondDic objectForKey:FDRKeyConfig];
//    
//    FDRAccount = [[NSString alloc] initWithFormat:@"%@:%@", FDRKeyConfig,FDRValueConfig];
    
    //初始化SNField
    
    self.submitBn.title = @"ChcekIn";
    
    //創建csv文件
    NSString *filePath = [currentDirectory stringByAppendingPathComponent:@"2.txt"];
    NSLog(@"filePath: %@", filePath);
    
    if([fileManager fileExistsAtPath:@"2.txt"]){
        
        NSLog(@"yes");
        
    }

    
    
    //fdrView
    
    fdrView =[[NSTextView alloc]initWithFrame:CGRectMake(47, 0, 580, 98)];

    [self.fdrDisplay  setDocumentView:fdrView];
    [self.window.contentView addSubview:self.fdrDisplay ];
    
    fdrView.editable = NO;
    
    [fdrView setMinSize:NSMakeSize(0.0, 98)];
    [fdrView setMaxSize:NSMakeSize(FLT_MAX, FLT_MAX)];
    [fdrView setVerticallyResizable:YES];
    [fdrView setHorizontallyResizable:NO];
    [fdrView setAutoresizingMask:NSViewWidthSizable];
    [[fdrView textContainer] setContainerSize:NSMakeSize(60000, FLT_MAX)];
    [[fdrView textContainer] setWidthTracksTextView:YES];
    
    [fdrView setFont:[NSFont fontWithName:@"Helvetica" size:13.0]];
    fdrView.textColor = [NSColor blackColor];
    
//    fdrView.hidden =YES;
//    self.fdrDisplay.hidden = YES;
    
}


- (IBAction)backToUMWindow:(id)sender {
    
    _UMWindow = [[UMWindowController alloc] initWithWindowNibName:@"UMWindowController"];
    
    [_UMWindow.window orderFront:nil];
    
    [_UMWindow.window center];
    
    [self.window orderOut:nil];
}


- (IBAction)checkIn:(id)sender {
    
    if([self.SNField.stringValue isEqualToString:@""]){
        return;
    }else{
        FDRTask = [[NSTask alloc] init];
        NSString *cmd = @"checkQCR";
        [FDRTask setLaunchPath:@"/bin/bash"];
        NSArray *arguments = [NSArray arrayWithObjects:cmd, FDRAccount,@"info",self.SNField.stringValue, nil];
        
        NSLog(@"arguments:%@", arguments);
        
        [self observerChange:arguments];
        
    }
}
        
        
//        _MLBSNField.stringValue = patternArr[0];
//        _BBSum.stringValue = patternArr[1];
//        _chipId.stringValue = patternArr[2];
//        _chipVer.stringValue = patternArr[3];
//        _ecid.stringValue = patternArr[4];
//        _nandcs.stringValue = patternArr[5];
//        _WIFI_MAC_ADDR.stringValue = patternArr[6];
//        _BT_MAC_ADDR.stringValue = patternArr[7];
//        _eousbMacAddr.stringValue = patternArr[8];
//        _UDID.stringValue = patternArr[9];
//        _imei.stringValue = patternArr[10];
//        _BuildStage.stringValue = patternArr[11];
//        _Config.stringValue = patternArr[12];
//        _S_BUILD.stringValue =patternArr[13];
//        _CG_SN.stringValue = patternArr[14];
//        _MESA_MODULE_SN.stringValue = patternArr[15];
//        _MPN.stringValue = patternArr[16];
//        _regionCode.stringValue = patternArr[17];
//        _UnitNo.stringValue = patternArr[18];
//        _RomeoSN.stringValue = patternArr[19];
//        _RosalineSN.stringValue = patternArr[20];
//        _savageSN.stringValue = patternArr[21];
//        _julietSN.stringValue = patternArr[22];
//        _PRODUCTION_SOC.stringValue  = patternArr[23];

//        [self observerChange:arguments];
//        
//        [self performSelector:@selector(delayEexTerminate) withObject:nil afterDelay:4.5];
        
    
    
//        NSLog(@"observerChange");
//        
//        [NSThread sleepForTimeInterval:2.0f];
//        
//        [self delayMethod];
    
    // C39SL01GHNW0/C39SX03JHNVR/C39T100KHWHN/C39S60KDHLN3/C39S408NHJ08/C39S2020HJ07/C39S200SHJ07/C39S9038HLN4
    

 
 
-(void)observerChange:(id)arguments{
    
    //create a new pipe
    
    [FDRTask setArguments:arguments];
    
    FDRPipe = [[NSPipe alloc] init];
    
    [FDRTask setStandardOutput:FDRPipe];
    
    NSFileHandle *fh = [FDRPipe fileHandleForReading];
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    
    [nc removeObserver: self];
    
    [nc addObserver:self
           selector:@selector(taskTerminated:)
               name:NSFileHandleReadCompletionNotification
             object:FDRTask];
    
    [nc addObserver:self
           selector:@selector(dataReady:)
               name:NSFileHandleReadCompletionNotification
             object:fh];
    
    [FDRTask launch];
    
    NSLog(@"4");
    
    [fdrView setString:@""];
    
    [fh readInBackgroundAndNotify];
    
}

-(void)dataReady:(NSNotification *) n{
    
    NSData *data;
    
    data = [[n userInfo] valueForKey:NSFileHandleNotificationDataItem];
    
    NSLog(@"5");
    
    NSLog(@"dataReady:%ld bytes", [data length]);
    
    if([data length]){
        
        NSLog(@"6");
        
        [self appendData:data];
    }else{
        
        NSLog(@"HH");
        
        [self setFDRTaskNil];
        
        NSString *MLBSN = @"\\n\\s*MLBSN\\s=((\\s*)||(.*))\\s*\\n";
        NSString *BB_SNUM = @"\\s*BB_SNUM\\s=((\\s*)||(.*))\\s*\\n";
        NSString *CHIPID = @"\\s*CHIPID\\s=((\\s*)||(.*))\\s*\\n";
        NSString *CHIPVER = @"\\s*CHIPVER\\s=((\\s*)||(.*))\\s*\\n";
        NSString *ECID = @"\\s*ECID\\s=((\\s*)||(.*))\\s*\\n";
        NSString *NANDCS = @"\\s*NANDCS\\s=((\\s*)||(.*))\\s*\\n";
        NSString *WIFI = @"\\s*WIFI_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
        NSString *BT = @"\\s*BT_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
        NSString *EOUSB = @"\\s*EOUSB_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
        NSString *UDID = @"\\s*UDID\\s=((\\s*)||(.*))\\s*\\n";
        NSString *IMEI = @"\\s*IMEI\\s=((\\s*)||(.*))\\s*\\n";
        NSString *BUILD_EVENT = @"\\s*BUILD_EVENT\\s=((\\s*)||(.*))\\s*\\n";
        NSString *BUILD_MATRIX_CONFIG = @"\\s*BUILD_MATRIX_CONFIG\\s=((\\s*)||(.*))\\s*\\n";
        NSString *S_BUILD = @"\\s*S_BUILD\\s=((\\s*)||(.*))\\s*\\n";
        NSString *CG_SN = @"\\s*CG_SN\\s=((\\s*)||(.*))\\s*\\n";
        NSString *MESA_MODULE_SN = @"\\s*MESA_MODULE_SN\\s=((\\s*)||(.*))\\s*\\n";
        NSString *MPN = @"\\s*MPN\\s=((\\s*)||(.*))\\s*\\n";
        NSString *REGION_CODE = @"\\s*REGION_CODE\\s=((\\s*)||(.*))\\s*\\n";
        NSString *UNIT = @"\\s*UNIT#\\s=((\\s*)||(.*))\\s*\\n";
        NSString *ROMEO_SN = @"\\s*ROMEO_SN\\s=((\\s*)||(.*))\\n";
        NSString *ROSALINE_SN = @"\\s*ROSALINE_SN\\s=((\\s*)||(.*))\\n";
        NSString *SAVAGE_SN = @"\\s*SAVAGE_SN\\s=((\\s*)||(.*))\\n";
        NSString *JULIET_SN = @"\\s*JULIET_SN\\s=((\\s*)||(.*))\\n";
        NSString *PRODUCTION_SOC = @"\\s*PRODUCTION_SOC\\s=((\\s*)||(.*))\\s*\\n";
        
        
        // NSString *pattern_sum = [NSString stringWithFormat:@"%@|%@|%@|%@|%@|%@|%@|%@|%@|%@",MLBSN, BB_SNUM, CHIPID, CHIPVER, ECID, NANDCS, WIFI, BT, EOUSB, UDID];
        
        // C39SL01GHNW0/C39SX03JHNVR/C39T100KHWHN
        NSString *pattern_sum = [NSString stringWithFormat:@"%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@",MLBSN, BB_SNUM, CHIPID, CHIPVER, ECID, NANDCS, WIFI, BT, EOUSB, UDID, IMEI, BUILD_EVENT, BUILD_MATRIX_CONFIG, S_BUILD, CG_SN,MESA_MODULE_SN, MPN, REGION_CODE, UNIT, ROMEO_SN, ROSALINE_SN, SAVAGE_SN, JULIET_SN, PRODUCTION_SOC];
        
        NSRegularExpression *regex = [[NSRegularExpression alloc] initWithPattern:pattern_sum options:NSRegularExpressionCaseInsensitive error:nil];
        NSArray *results = [regex matchesInString:fdrView.string options:0 range:NSMakeRange(0, fdrView.string.length)];
        
        _patternArr = [[NSMutableArray alloc] init];
        [_patternArr removeAllObjects];
        
        
        for (NSTextCheckingResult *result in results){
            
            // NSLog(@"%@ %@", NSStringFromRange(result.range), [QCRInfo substringWithRange:result.range]);
            
            NSRange range = {(int)(result.range.location + 23), (int)(result.range.length -23)};
            NSString* temp = [fdrView.string substringWithRange:range];
            
            //[patternArr addObject:[temp stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
            
            [_patternArr addObject:[temp stringByReplacingOccurrencesOfString:@"\n" withString:@""]];
            
        }
        
        
        NSLog(@"patternArr: %@", _patternArr);
        
    }
    
    NSLog(@"9");
    
    if (FDRTask){
        NSLog(@"11");
        [[FDRPipe fileHandleForReading] readInBackgroundAndNotify];
    }
    
    //跳转到填写参数界面
    
    if(_patternArr){
    
        _UploadRadarWindow = [[UploadRadarWindowController alloc] initWithWindowNibName:@"UploadRadarWindowController"];
        
        _UploadRadarWindow.SNArgu = _patternArr;
        
        _UploadRadarWindow.SN = self.SNField.stringValue;
        
        NSLog(@"_SearchWindow.SNArgu: %@", _UploadRadarWindow.SNArgu);
        
        [_UploadRadarWindow.window orderFront:nil];
        
        [_UploadRadarWindow.window center];
        
        [self.window orderOut:nil];
    }
}

-(void)appendData:(NSData *)d{
    
    NSString *s = [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding];
    
    ts = [fdrView textStorage];

    NSLog(@"7");
    
    [ts replaceCharactersInRange:NSMakeRange([ts length], 0) withString:s];

    NSLog(@"8");
}


- (void)taskTerminated:(NSNotification *)note
{
    NSLog(@"Terminated");
    
    FDRTask = nil;
}


-(void)setFDRTaskNil{
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    
    [nc removeObserver: self];
    
    [nc addObserver:self
           selector:@selector(taskTerminated:)
               name:NSFileHandleReadCompletionNotification
             object:FDRTask];
}



- (IBAction)search:(id)sender {
    
    
    //    SearchWindowController *search = [[SearchWindowController alloc] init];
    //
    //    search.SNArgu = self.searchField.stringValue;
    //
    //    NSLog(@"search.SNArgu: %@", search.SNArgu);
    
    
    fileManager = [NSFileManager defaultManager];
    
    currentDirectory = [fileManager currentDirectoryPath];
    
    
    if(![_searchField.stringValue isEqualToString:@""] && _searchField.stringValue.length >0){
        
        NSLog(@"1");
        
        sqlite3* database;
        
        int temp = sqlite3_open([[self dbPath] UTF8String], &database);
        
        NSLog(@"temp : %d", temp);
        
        //        const char it = *[[self dbPath] UTF8String];
        
        NSString* str = @"select * from word_inf where word like ?";
        
        const char *selectSQL = [str UTF8String];
        
        sqlite3_stmt *stmt = nil;
        
        int queryResult = sqlite3_prepare_v2(database, selectSQL , -1, &stmt, nil);
        
        NSLog(@"Result: %d", queryResult);
        
        _result = [[NSMutableArray alloc] init];
        
        if(queryResult == SQLITE_OK){
            
            NSLog(@"编译成功");
            
            sqlite3_bind_text(stmt, 1, [[NSString stringWithFormat:@"%%%@%%", _searchField.stringValue] UTF8String], -1, NULL);
            
            while(sqlite3_step(stmt) == SQLITE_ROW){
                
                NSLog(@"3");
                
                //SN,MLBSN,BB_SNUM,CHIPID,CHIPVER,ECID,NANDCS,WIFI,BT,EOUSB,UDID,IMEI,BUILD_EVENT,BUILD_MATRIX_CONFIG,S_BUILD,CG_SN,MESA_MODULE_SN,MPN,REGION_CODE,UNIT,ROMEO_SN,ROSALINE_SN,SAVAGE_SN,JULIET_SN,PRODUCTION_SOC\
                
                int word_id = sqlite3_column_int(stmt, 0);
                char* SN = (char *)sqlite3_column_text(stmt, 1);
                char* MLBSN = (char *)sqlite3_column_text(stmt, 2);
                char* BB_SNUM = (char *)sqlite3_column_text(stmt, 3);
                char* CHIPID = (char *)sqlite3_column_text(stmt, 4);
                char* CHIPVER = (char *)sqlite3_column_text(stmt, 5);
                char* ECID = (char *)sqlite3_column_text(stmt, 6);
                char* NANDCS = (char *)sqlite3_column_text(stmt, 7);
                char* WIFI = (char *)sqlite3_column_text(stmt, 8);
                char* BT = (char *)sqlite3_column_text(stmt, 9);
                char* EOUSB = (char *)sqlite3_column_text(stmt, 10);
                char* UDID = (char *)sqlite3_column_text(stmt, 11);
                char* IMEI = (char *)sqlite3_column_text(stmt, 12);
                char* BUILD_EVENT = (char *)sqlite3_column_text(stmt, 13);
                char* BUILD_MATRIX_CONFIG = (char *)sqlite3_column_text(stmt, 14);
                char* S_BUILD = (char *)sqlite3_column_text(stmt, 15);
                char* CG_SN = (char *)sqlite3_column_text(stmt, 16);
                char* MESA_MODULE_SN = (char *)sqlite3_column_text(stmt, 17);
                char* MPN = (char *)sqlite3_column_text(stmt, 18);
                char* REGION_CODE = (char *)sqlite3_column_text(stmt, 19);
                char* UNIT = (char *)sqlite3_column_text(stmt, 20);
                char* ROMEO_SN = (char *)sqlite3_column_text(stmt, 21);
                char* ROSALINE_SN = (char *)sqlite3_column_text(stmt, 22);
                char* SAVAGE_SN = (char *)sqlite3_column_text(stmt, 23);
                char* JULIET_SN = (char *)sqlite3_column_text(stmt, 24);
                char* PRODUCTION_SOC = (char *)sqlite3_column_text(stmt, 25);
                
                [_result addObject:[NSString stringWithUTF8String:SN]];
                [_result addObject:[NSString stringWithUTF8String:MLBSN]];
                [_result addObject:[NSString stringWithUTF8String:BB_SNUM]];
                [_result addObject:[NSString stringWithUTF8String:CHIPID]];
                [_result addObject:[NSString stringWithUTF8String:CHIPVER]];
                [_result addObject:[NSString stringWithUTF8String:ECID]];
                [_result addObject:[NSString stringWithUTF8String:NANDCS]];
                [_result addObject:[NSString stringWithUTF8String:WIFI]];
                [_result addObject:[NSString stringWithUTF8String:BT]];
                [_result addObject:[NSString stringWithUTF8String:EOUSB]];
                [_result addObject:[NSString stringWithUTF8String:UDID]];
                [_result addObject:[NSString stringWithUTF8String:IMEI]];
                [_result addObject:[NSString stringWithUTF8String:BUILD_EVENT]];
                [_result addObject:[NSString stringWithUTF8String:BUILD_MATRIX_CONFIG]];
                [_result addObject:[NSString stringWithUTF8String:S_BUILD]];
                [_result addObject:[NSString stringWithUTF8String:CG_SN]];
                [_result addObject:[NSString stringWithUTF8String:MESA_MODULE_SN]];
                [_result addObject:[NSString stringWithUTF8String:MPN]];
                [_result addObject:[NSString stringWithUTF8String:REGION_CODE]];
                [_result addObject:[NSString stringWithUTF8String:UNIT]];
                [_result addObject:[NSString stringWithUTF8String:ROMEO_SN]];
                
                [_result addObject:[NSString stringWithUTF8String:ROSALINE_SN]];
                [_result addObject:[NSString stringWithUTF8String:SAVAGE_SN]];
                [_result addObject:[NSString stringWithUTF8String:JULIET_SN]];
                [_result addObject:[NSString stringWithUTF8String:PRODUCTION_SOC]];
                
                
                // C39SL01GHNW0/C39SX03JHNVR/C39T100KHWHN
                
                
                /*
                 FDRArgu *argument = [[FDRArgu alloc] initWithId:word_id SN:[NSString stringWithUTF8String:SN] MLBSN:[NSString stringWithUTF8String:MLBSN] BB_SNUM:[NSString stringWithUTF8String:BB_SNUM] CHIPID:[NSString stringWithUTF8String:CHIPID] CHIPVER:[NSString stringWithUTF8String:CHIPVER] ECID:[NSString stringWithUTF8String:ECID] NANDCS:[NSString stringWithUTF8String:NANDCS] WIFI:[NSString stringWithUTF8String:WIFI] BT:[NSString stringWithUTF8String:BT] EOUSB:[NSString stringWithUTF8String:EOUSB] UDID:[NSString stringWithUTF8String:UDID] IMEI:[NSString stringWithUTF8String:IMEI] BUILD_EVENT:[NSString stringWithUTF8String:BUILD_EVENT] BUILD_MATRIX_CONFIG:[NSString stringWithUTF8String:BUILD_MATRIX_CONFIG] S_BUILD:[NSString stringWithUTF8String:S_BUILD] CG_SN:[NSString stringWithUTF8String:CG_SN] MESA_MODULE_SN:[NSString stringWithUTF8String:MESA_MODULE_SN] MPN:[NSString stringWithUTF8String:MPN] REGION_CODE:[NSString stringWithUTF8String:REGION_CODE] UNIT:[NSString stringWithUTF8String:UNIT] ROMEO_SN:[NSString stringWithUTF8String:ROMEO_SN] ROSALINE_SN:[NSString stringWithUTF8String:ROSALINE_SN] SAVAGE_SN:[NSString stringWithUTF8String:SAVAGE_SN] JULIET_SN:[NSString stringWithUTF8String:JULIET_SN] PRODUCTION_SOC:[NSString stringWithUTF8String:PRODUCTION_SOC]];
                 */
                
            }
            
        }
        NSLog(@"5");
        sqlite3_close(database);
    }
    
//    _SearchWindow = [[UploadRadarWindowController alloc] initWithWindowNibName:@"SearchWindowController"];
//    
//    _SearchWindow.SNArgu = self.searchField.stringValue;
//    
//    NSLog(@"_SearchWindow.SNArgu: %@", _SearchWindow.SNArgu);
//    
//    [_SearchWindow.window orderFront:nil];
//    
//    [_SearchWindow.window center];
//    
//    [self.window orderOut:nil];
}


-(NSString *)dbPath{
    
    NSLog(@"%@", [NSString stringWithFormat:@"%@/%@", currentDirectory, DBNAME]);
    
    return [NSString stringWithFormat:@"%@/%@", currentDirectory, DBNAME];
    
}

//C39T100KHWHN


@end
