//
//  TaskTool.m
//  WindowSkip
//
//  Created by gdadmin on 4/5/17.
//  Copyright © 2017 108. All rights reserved.
//

#import "RadarTool.h"
#import "PlistTool.h"

NSString* const textChangeNotification = @"textChanged";

//extern NSString* const textChangeNotification;


@interface RadarTool()

@property (nonatomic, strong) NSArray *arguments;
@property (nonatomic, strong) NSString *text;
@end

@implementation RadarTool{
    PlistTool *plistHandler;
    NSTask *task;
    NSPipe *pipe;
}

@synthesize string;


-(instancetype) initWithArgArr:(NSArray*)array{
    
    self = [super init];
    
    if(self){
     
        NSString* accountRadar = [self getRadarAccount];
        NSString* radarToolPath = [self getRadarPath];
        task = [[NSTask alloc] init];
        [task setLaunchPath:@"/bin/bash"];
        NSArray *arguments = [NSArray arrayWithObjects:radarToolPath,accountRadar, nil];
        NSArray *argArr = [arguments arrayByAddingObjectsFromArray:array];
        NSLog(@"argArr: %@", argArr);
        
        self.arrResulrt = argArr;
        string = _text;        
    }
    return self;
}

-(NSString *)getRadarPath{
    
    NSString *bundle = [[NSBundle mainBundle] resourcePath];
    NSString *radarToolPath = [bundle stringByAppendingPathComponent:@"radartool"];
   // NSString *radarTool = [radarToolPath stringByAppendingPathComponent:@"radartool"];
    
    return radarToolPath;
}

-(NSString *)getRadarAccount{
    plistHandler = [PlistTool instance];
    
    NSString *config = [[NSBundle mainBundle] pathForResource:@"config" ofType:@"plist"];
    NSDictionary *configDic = [NSDictionary dictionaryWithContentsOfFile:config];
    NSArray *secondDic = [plistHandler valueForKey:@"Radar" inDictionary:configDic recursion:YES];
    
    NSString* keyConfig;
    NSString* valueConfig;
    
    if([secondDic respondsToSelector:@selector(objectAtIndex:)]){
        for(int i = 0 ; i< secondDic.count; i++){
            NSLog(@"check: %@", [secondDic[i] objectForKey:@"Check"]);
            id temp = [secondDic[i] objectForKey:@"Check"];
            if([temp isEqual:@"1"]){
               keyConfig = [secondDic[i] objectForKey:@"UserName"];
               valueConfig = [secondDic[i] objectForKey:@"Password"];
            }else{
            }
        }
    }
    
    
    NSString *accountRadar = [[NSString alloc] initWithFormat:@"%@:%@", keyConfig,valueConfig];
    return accountRadar;
}

/*
 *增加结点 key-value对
 *使用传统的方法获取checkQCR tool信息
 */

-(NSString *)excuteSecondTask
{
    
    [task setArguments:self.arrResulrt];
    
    pipe = [NSPipe pipe];
    
    [task setStandardOutput:pipe];
    
    NSFileHandle *file = [pipe fileHandleForReading];
    
    [task launch];
    
    NSData *data = [file readDataToEndOfFile];
    
    NSMutableString *str = [[NSMutableString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    return str;
}


/*
 *增加结点 key-value对
 *关联雷达号
 */
-(void) excuteTask
{
    [task setArguments:self.arrResulrt];
    pipe = [[NSPipe alloc]init];
    
    [task setStandardOutput:pipe];
    NSFileHandle *fh = [pipe fileHandleForReading];
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc removeObserver:self];
    
    [nc addObserver:self
           selector:@selector(taskTerminated:)
               name:NSFileHandleReadCompletionNotification
             object:task];
    [nc addObserver:self
           selector:@selector(dataReady:)
               name:NSFileHandleReadCompletionNotification
             object:fh];
    
    [task launch];
    [fh readInBackgroundAndNotify];
}


-(void)dataReady:(NSNotification *) n{
    
    NSData *data = [[n userInfo] valueForKey:NSFileHandleNotificationDataItem];
    
    NSLog(@"dataReady:%ld bytes", [data length]);
    
    if([data length]){
        
        NSLog(@"6");
        
        [self appendData:data];
    }else{
        
        NSLog(@"10");
        [self setTaskNil];
    }
    
    NSLog(@"9");
    
    if (task){
        
        NSLog(@"11");
        [[pipe fileHandleForReading] readInBackgroundAndNotify];
    }
}


-(void)appendData:(NSData *)d{
    
    _text = [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding];
    //NSLog(@"_text: %@", _text);
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setObject:_text forKey:@"text"];
    //NSDictionary *dic = [NSDictionary dictionaryWithObject:_text forKey:@"text"];

    [nc postNotificationName:textChangeNotification
                      object:self
                    userInfo:dic];
    
//    NSTextStorage *ts = [self.textView textStorage];
//    self.ts = [self.textView stringByAppendingString:s];
//    [radarTxtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
    //[ts replaceCharactersInRange:NSMakeRange([ts length], 0) withString:s];
}


-(void)setTaskNil{
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    
    [nc removeObserver: self];
    [nc addObserver:self
           selector:@selector(taskTerminated:)
               name:NSFileHandleReadCompletionNotification
             object:task];
    task = nil;
}

- (void)taskTerminated:(NSNotification *)note
{
    NSLog(@"taskTerminated:");
    task = nil;
}

@end
