//
//  qcrPerson.m
//  WindowSkip
//
//  Created by gdadmin on 2/16/17.
//  Copyright © 2017 108. All rights reserved.
//

#import "qcrPerson.h"



@implementation QcrPerson

@synthesize qcrPersonName;
@synthesize qcrCheckState;
@synthesize qcrPassWord;

-(id)init {
    
    self = [super init];
    if(self){
        
        qcrPersonName = @"blus";
        qcrCheckState = @"0";
        qcrPassWord = @"helloworld";
    }
    return self;
}

@end
