//
//  TaskTool.h
//  WindowSkip
//
//  Created by gdadmin on 4/5/17.
//  Copyright © 2017 108. All rights reserved.
//

#import <Foundation/Foundation.h>


extern NSString* const textChangeNotification;

@interface RadarTool : NSObject{
    NSString *string;
    
}

@property (nonatomic, strong) NSArray *arrResulrt;
@property (readwrite, copy) NSString *string;


-(instancetype) initWithArgArr:(NSArray*)array;


-(void) excuteTask;

-(NSString *)excuteSecondTask;

@end
