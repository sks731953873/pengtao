
//
//  SearchRadarDBWindowController.m
//  WindowSkip
//
//  Created by gdadmin on 2/21/17.
//  Copyright © 2017 108. All rights reserved.
//

#import "SearchRadarDBWindowController.h"
#import "FDRSealWindowController.h"
#import "DBManager.h"
#import <sqlite3.h>
#import <DHxls/DHWorkBook.h>
//#import "DHxlsReaderMac.h"
#import "PlistTool.h"
#import "CheckQCRTool.h"
#import "RadarTool.h"
#import "FileTool.h"
#import "SSZipArchive.h"
#import "ReadExcelTool.h"

#define DEFAULT_MODE                0
#define LIST_ATTACHMENT_MODE        1
#define DOWNLOAD_ATTACHMENT_MODE    2


@interface SearchRadarDBWindowController ()


@property(strong) FDRSealWindowController *FDRSealWindow;
@property(nonatomic, strong)ReadExcelTool *readExcel;


@end

@implementation SearchRadarDBWindowController{
    
    //get filePath
    NSString *excelPath;
    
    //excelRow
    int excelRowCount;
    
    DHxlsReader *reader;
    
    NSString *dateStr;
    
    PlistTool *plistTool;
    
    NSArray* QCRNode;
    NSString* QCRKeyConfig;
    NSString* QCRAccount;
    NSString* qcrToolPath;
    NSDictionary *configDic;
    NSTextView *QCRView;
    
    NSData *data;
    
    NSMutableArray *configArr;
    
    NSFileManager *fm;
    NSString* currentDirectory;
    
    FileTool* fileTool;
    NSArray *attach ;
    NSString* sandBox;
    
    NSInteger mode;

    NSString *excelFilePath;
    
    NSArray* transArray;
    
    NSInteger sheetCount;
}

NSArray *snKey;
NSString *searchRadarDir;
NSFileManager *searchRadarfm;

//check
NSMutableArray* ItemArr;
NSMutableArray* loseSn;
NSMutableArray* winMlbSN;
NSMutableArray* loseMlbSN;

NSMutableArray* winConfig;
NSMutableArray* loseConfig;

NSMutableArray* winUnit;
NSMutableArray* loseUnit;



- (void)windowDidLoad {
    [super windowDidLoad];
    
//    mode = DEFAULT_MODE;
    
    [self.displayView  setHasVerticalScroller:YES];
    [self.displayView  setHasHorizontalScroller:YES];
    [self.displayView  setAutoresizingMask:NSViewWidthSizable | NSViewHeightSizable];
    
    QCRView =[[NSTextView alloc]initWithFrame:CGRectMake(47, 0, 580, 150)];
    [self.displayView  setDocumentView:QCRView];
    [self.window.contentView addSubview:self.displayView ];
    QCRView.editable = NO;
    
    
    
    [QCRView setMinSize:NSMakeSize(0.0, 98)];
    [QCRView setMaxSize:NSMakeSize(FLT_MAX, FLT_MAX)];
    [QCRView setVerticallyResizable:YES];
    [QCRView setHorizontallyResizable:NO];
    [QCRView setAutoresizingMask:NSViewWidthSizable];
    [[QCRView textContainer]setContainerSize:NSMakeSize(60000,FLT_MAX)];
    [[QCRView textContainer]setWidthTracksTextView:YES];
    

    configArr = [NSMutableArray array];
    
    //current time
    dateStr = [NSString stringWithFormat:@"%@", [NSDate date]];
    
    
    //searchResult title
    self.searchResult.textColor=[NSColor blackColor];
    self.searchResult.font=[NSFont fontWithName:@"Helvetica" size:16.0];
    self.searchResult.stringValue= @"searchRadarDBResult";
    
    
    //back button
    [self.backToUploadBn setButtonType: NSMomentaryPushInButton];
    [self.backToUploadBn setBezelStyle: NSRoundedBezelStyle];
    [self.backToUploadBn setBordered: NO];
    [self.backToUploadBn setImage: [NSImage imageNamed: @"left_highlighted"]];
    [self.backToUploadBn setImagePosition: NSImageOnly];
    [self.backToUploadBn setTarget: self];
    self.backToUploadBn.hidden = YES;
    
    //get Excel
    [self.excelPathBn setButtonType: NSMomentaryPushInButton];
    [self.excelPathBn setBezelStyle: NSRoundedBezelStyle];
    [self.excelPathBn setBordered: NO];
    [self.excelPathBn setImage: [NSImage imageNamed: @"fileFolder.png"]];
    [self.excelPathBn setImagePosition: NSImageOnly];
    [self.excelPathBn setTarget: self];
    
    //self.backToUploadBn.hidden = YES;
    
    searchRadarfm = [NSFileManager defaultManager];
    searchRadarDir = [searchRadarfm currentDirectoryPath];
    
    QCRView.string = @"";
    [self.searchLog setTextColor:[NSColor redColor]];

    self.removeSNBn.hidden = YES;
    self.excelPathBn.hidden = YES;
    self.WSEBn.hidden = YES;
    self.singleExcelBn.hidden = YES;
    self.checkSNBn.hidden = NO;
}

- (IBAction)backToUploadRadar:(id)sender {
    
    _FDRSealWindow = [[FDRSealWindowController alloc] initWithWindowNibName:@"FDRSealWindowController"];
    
    NSArray *argArr = [NSArray arrayWithObjects:@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"", nil];
    
    _FDRSealWindow.SNArgu = argArr;
    
    NSString *argSN = @"";
    
    _FDRSealWindow.SN = argSN;
    
    NSString *argDate = @"";
    
    _FDRSealWindow.Date.stringValue = argDate;
    [_FDRSealWindow.window orderFront:nil];
    [_FDRSealWindow.window center];
    [self.window orderOut:nil];
}


// C39SL01GHNW0/C39SX03JHNVR/C39T100KHWHN
#pragma mark - NSTableViewDataSource
-(void)awakeFromNib{
    
    NSLog(@"searchArr: %@", _searchArr);
    
//    mode = DEFAULT_MODE;
    
    fileTool = [FileTool instance];
    
    //本地路径
    fm = [NSFileManager defaultManager];
    currentDirectory = [fm currentDirectoryPath];
    
    //沙河路径
    NSArray* path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    sandBox = [path objectAtIndex:0];
    
    //初始化dbManager
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"DataBase.db"];
    
    excelFilePath= [sandBox stringByAppendingPathComponent:attach[1]];

    //将_searchArr移植到_valueArr
    _Items = [NSMutableArray array];
    _FGSNs = [NSMutableArray array];
    _Units = [NSMutableArray array];
    _Configs = [NSMutableArray array];
    _MLBSNs = [NSMutableArray array];
    _RadarNos = [NSMutableArray array];
    _FailStations = [NSMutableArray array];
    _FailureSymptoms = [NSMutableArray array];
    _AppleGroups = [NSMutableArray array];
    _AppleDRIs = [NSMutableArray array];
    _HHDRIs = [NSMutableArray array];
    _F1Approves = [NSMutableArray array];
    _FADRIs = [NSMutableArray array];
    _Times = [NSMutableArray array];
    _Remarks = [NSMutableArray array];

    for(int i=0; i< _searchArr.count; i++){
        [_Items addObject:_searchArr[i][0]];
        [_FGSNs addObject:_searchArr[i][1]];
        [_Units addObject:_searchArr[i][2]];
        [_Configs addObject:_searchArr[i][3]];
        [_MLBSNs addObject:_searchArr[i][4]];
        [_RadarNos addObject:_searchArr[i][5]];
        [_FailStations addObject:_searchArr[i][6]];
        [_FailureSymptoms addObject:_searchArr[i][7]];
        [_AppleGroups addObject:_searchArr[i][8]];
        [_AppleDRIs addObject:_searchArr[i][9]];
        [_HHDRIs addObject:_searchArr[i][10]];
        [_F1Approves addObject:_searchArr[i][11]];
        [_FADRIs addObject:_searchArr[i][12]];
        [_Times addObject:_searchArr[i][13]];
        [_Remarks addObject:_searchArr[i][14]];
    }
    
//    task == nil;

    transArray = [self transArray];
    NSLog(@"temp: %@", transArray);
    
    ItemArr = [NSMutableArray array];
    loseSn = [NSMutableArray array];
    
    winMlbSN = [NSMutableArray array];
    loseMlbSN = [NSMutableArray array];
    
    winConfig = [NSMutableArray array];
    loseConfig = [NSMutableArray array];
    
    winUnit = [NSMutableArray array];
    loseUnit = [NSMutableArray array];
}

-(NSArray*)transArray{
    
    NSMutableArray *SumArr = [NSMutableArray arrayWithObjects:_FGSNs,_Units,_Configs,_MLBSNs,_RadarNos,_FailStations,_FailureSymptoms,_AppleGroups,_AppleDRIs,_HHDRIs,_F1Approves,_FADRIs,_Times,_Remarks,nil];
    
    NSMutableArray *arr = [NSMutableArray array];
    
    for(int i = 0; i< _FGSNs.count; i++){
        for(int j = 0;j<SumArr.count;j++){
            [arr addObject:[NSString stringWithFormat:@"%@",SumArr[j][i]]];
        }
    }
    
    NSLog(@"arr: %@", arr);
    
    NSMutableArray* arrs = [NSMutableArray array];
    for (int i = 0; i<_FGSNs.count * SumArr.count; i++) {
        
        NSMutableArray *arr1 =[NSMutableArray array];
        NSInteger count =0;
            
        while (count != SumArr.count && i < _FGSNs.count * SumArr.count) {
            count++;
            [arr1 addObject:arr[i]];
            i++;
        }
        
        [arrs addObject:arr1];
        i--;
    }
    return arrs;
}

#pragma mark - Table View Data Source
-(NSInteger)numberOfRowsInTableView:(NSTableView*)tableView{
    return _FGSNs.count;
}


-(id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    if([tableColumn.identifier isEqualTo:@"FGSN"]){
        return  (NSString*)[_FGSNs objectAtIndex:row];
    }else if([tableColumn.identifier isEqualTo:@"Item"]){
        return  (NSString*)[_Items objectAtIndex:row];
    }else if([tableColumn.identifier isEqualTo:@"Unit#"]){
        return  (NSString*)[_Units objectAtIndex:row];
    }else if([tableColumn.identifier isEqualTo:@"Config"]){
        return  (NSString*)[_Configs objectAtIndex:row];
    }else if([tableColumn.identifier isEqualTo:@"MLBSN"]){
        return  (NSString*)[_MLBSNs objectAtIndex:row];
    }else if([tableColumn.identifier isEqualTo:@"RadarNo"]){
        return  (NSString*)[_RadarNos objectAtIndex:row];
    }else if([tableColumn.identifier isEqualTo:@"FailStation"]){
        return  (NSString*)[_FailStations objectAtIndex:row];
    }else if([tableColumn.identifier isEqualTo:@"FailureSymptom"]){
        return  (NSString*)[_FailureSymptoms objectAtIndex:row];
    }else if([tableColumn.identifier isEqualTo:@"AppleGroup"]){
        return  (NSString*)[_AppleGroups objectAtIndex:row];
    }else if([tableColumn.identifier isEqualTo:@"AppleDRI"]){
        return  (NSString*)[_AppleDRIs objectAtIndex:row];
    }else if([tableColumn.identifier isEqualTo:@"HHDRI"]){
        return  (NSString*)[_HHDRIs objectAtIndex:row];
    }else if([tableColumn.identifier isEqualTo:@"F1Approve"]){
        return  (NSString*)[_F1Approves objectAtIndex:row];
    }else if([tableColumn.identifier isEqualTo:@"FADRI"]){
        return  (NSString*)[_FADRIs objectAtIndex:row];
    }else if([tableColumn.identifier isEqualTo:@"Date"]){
        return  (NSString*)[_Times objectAtIndex:row];
    }else if([tableColumn.identifier isEqualTo:@"Remark"]){
        return  (NSString*)[_Remarks objectAtIndex:row];
    }
    return 0;
}


-(void)tableView:(NSTableView*)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    
    NSString *strIdt = [tableColumn identifier];
    
    if([strIdt isEqualToString:@"Config"]){
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.Configs replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.Configs);
        
        [self excuteParser:row];
    }
    else if([strIdt isEqualToString:@"Unit#"]){
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.Units replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.Units);
        [self excuteParser:row];
    }
    else if([strIdt isEqualToString:@"MLBSN"]){
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.MLBSNs replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.MLBSNs);
        [self excuteParser:row];
    }
    else if([strIdt isEqualToString:@"RadarNo"]){
        
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.RadarNos replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.RadarNos);
        [self excuteParser:row];
        
    }else if([strIdt isEqualToString:@"FailStation"]){
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.FailStations replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.FailStations);
        [self excuteParser:row];
        
    }else if([strIdt isEqualToString:@"FailureSymptom"]){
        
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.FailureSymptoms replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.FailureSymptoms);
        [self excuteParser:row];
        
    }else if([strIdt isEqualToString:@"AppleGroup"]){
        
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.AppleGroups replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.AppleGroups);
        [self excuteParser:row];
        
    }else if([strIdt isEqualToString:@"AppleDRI"]){
        
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.AppleDRIs replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.AppleDRIs);
        [self excuteParser:row];
    }
    else if([strIdt isEqualToString:@"HHDRI"]){
        
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.HHDRIs replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.HHDRIs);
        [self excuteParser:row];
        
    }else if([strIdt isEqualToString:@"F1Approve"]){
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.F1Approves replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.F1Approves);
        [self excuteParser:row];
        
    }else if([strIdt isEqualToString:@"FADRI"]){
        
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.FADRIs replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.FADRIs);
        [self excuteParser:row];
        
    }else if([strIdt isEqualToString:@"Date"]){
        
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.Times replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.Times);
        [self excuteParser:row];
        
    }else if([strIdt isEqualToString:@"Remark"]){
        
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.Remarks replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.Remarks);
        [self excuteParser:row];
        
    }
}


-(void)excuteParser:(NSInteger)row{
    
    NSString *strParser = [NSString stringWithFormat:@"update radar_Info set FGSN= '%@', Unit='%@', Config= '%@', MLBSN='%@', RadarNo= '%@', FailStation='%@', FailureSymptom= '%@', AppleGroup='%@', AppleDRI='%@', HHDRI= '%@', F1Approve='%@', FADRI= '%@', Time='%@', Remark='%@' where _id=%@", _FGSNs[row], _Units[row], _Configs[row], _MLBSNs[row], _RadarNos[row], _FailStations[row], _FailureSymptoms[row],_AppleGroups[row], _AppleDRIs[row], _HHDRIs[row], _F1Approves[row], _FADRIs[row],_Times[row], _Remarks[row], _Items[row]];
    [self.dbManager executeQuery:strParser];
    if (self.dbManager.affectedRows != 0) {
        NSLog(@"Query was executed successfully. Affected rows = %d", self.dbManager.affectedRows);
        QCRView.string = [NSString stringWithFormat:@"modify was executed successfully. Affected rows = %d", self.dbManager.affectedRows];
    }else{
        QCRView.string = @"Could not execute the modify.";
        NSLog(@"Could not execute the modify.");
    }
    [self.searchLog setTextColor:[NSColor redColor]];
    [searchRadarTableView reloadData];
}


- (IBAction)removeSNItem:(id)sender {

    NSInteger row = [searchRadarTableView selectedRow];
    NSString *deleteStr = [NSString stringWithFormat:@"delete from radar_Info where _id=%ld", (long)[_Items[row] integerValue]];
    NSIndexSet *rows = [searchRadarTableView selectedRowIndexes];
    
    if([rows count] == 0){
        NSBeep();
        return;
    }
    
    [_Items removeObjectsAtIndexes:rows];
    [_FGSNs removeObjectsAtIndexes:rows];
    [_Units removeObjectsAtIndexes:rows];
    [_Configs removeObjectsAtIndexes:rows];
    [_MLBSNs removeObjectsAtIndexes:rows];
    [_RadarNos removeObjectsAtIndexes:rows];
    [_FailStations removeObjectsAtIndexes:rows];
    [_FailureSymptoms removeObjectsAtIndexes:rows];
    [_AppleGroups removeObjectsAtIndexes:rows];
    [_AppleDRIs removeObjectsAtIndexes:rows];
    [_HHDRIs removeObjectsAtIndexes:rows];
    [_F1Approves removeObjectsAtIndexes:rows];
    [_FADRIs removeObjectsAtIndexes:rows];
    [_Times removeObjectsAtIndexes:rows];
    [_Remarks removeObjectsAtIndexes:rows];
    
    [self.dbManager executeQuery:deleteStr];
    if (self.dbManager.affectedRows != 0) {
        NSLog(@"Query was executed successfully. Affected rows = %d", self.dbManager.affectedRows);
        QCRView.string = [NSString stringWithFormat:@"modify was executed successfully. Affected rows = %d", self.dbManager.affectedRows];
    }else{
        QCRView.string = @"Could not execute the modify.";
        NSLog(@"Could not execute the modify.");
    }
    
    [self.searchLog setTextColor:[NSColor redColor]];
    [searchRadarTableView reloadData];
}


- (IBAction)chooseItem:(id)sender {
    
    if(![self.itemToChoice indexOfSelectedItem])
    {
        NSLog(@"hh");
        return;
    }
    else if([[self.itemToChoice titleOfSelectedItem] isEqualToString:@"Write to specify Excel"]){
        NSLog(@"upload file");
        QCRView.string = @"Write to specify Excel";
        [self specifyExcelView];
    }
    else if([[self.itemToChoice titleOfSelectedItem] isEqualToString:@"Write to single Excel"]){
        NSLog(@"upload file");
        QCRView.string = @"Write to single Excel";
        [self singleExcelView];
    }
    else if([[self.itemToChoice titleOfSelectedItem] isEqualToString:@"Edit to delete SN"]){
        NSLog(@"upload file");
        QCRView.string = @"Edit to delete SN";
        [self editToDeleteView];
    }
    else if([[self.itemToChoice titleOfSelectedItem] isEqualToString:@"Check SN correct or not"]){
        NSLog(@"upload file");
        QCRView.string = @"Edit to delete SN";
        [self checkSNView];
    }
}



- (IBAction)getExcelPath:(id)sender {
    
    NSOpenPanel *panel = [NSOpenPanel openPanel];
    [panel setMessage:@""];
    [panel setPrompt:@"OK"];
    [panel setCanChooseDirectories:YES];
    [panel setCanCreateDirectories:YES];
    [panel setCanChooseFiles:YES];
    
    NSInteger result = [panel runModal];
    if (result == NSFileHandlingPanelOKButton)
    {
        excelPath = [[panel URL] path];
        NSLog(@"path_all: %@",excelPath);
        QCRView.string = excelPath;
    }
}


- (IBAction)writeToSpecifyExcel:(id)sender {

    NSString* path = @"/Users/DemonZhu/Desktop/(Ferrari)_SkipFDR-SEAL_UNITS_INFO(170424D).xls";
    
    _readExcel = [[ReadExcelTool alloc] initWithFilePath:path];
    
    NSInteger numberOfSheet = [_readExcel getSheetNum];
    NSLog(@"numberOfSheet: %ld", (long)numberOfSheet);
    
    DHCell				*cell;
    DHWorkBook *dhWB = [DHWorkBook new];
    
    NSInteger cout = 1;
    while (numberOfSheet) {
        
        _readExcel = [[ReadExcelTool alloc] initWithFilePath:path];
        
        NSArray* excelArr = [_readExcel transFromArray:cout-1 isExcel:NO];
    
        NSMutableArray* array = [NSMutableArray array];
        for (id obj in excelArr) {
            [array addObject:obj];
        }
        
        NSLog(@"numberOfSheet-1: %lu", (unsigned long)numberOfSheet-1);
//        if([num isEqualToString:[NSString stringWithFormat:@"%ld", cout-1]] && transArray.count){
        if((sheetCount == cout-1) && transArray.count){
            for (id oject in transArray ) {
                [array addObject:oject];
            }
        }
        NSLog(@"array: %@", array);
        
        //如果sheet位置在3，设置将其名字设置为 D22 Proto2.5
        NSString* fileName;
        if(cout == 3){
            fileName = @"D22 Proto2.5";
        }else{
            fileName = [NSString stringWithFormat:@"D22 Proto%ld", (long)cout];
        }
        
        DHWorkSheet *dhWS = [dhWB workSheetWithName:fileName];
        
        [dhWS height:500 row:1 format:NULL];
        [dhWS height:800 row:0 format:NULL];
        [dhWS width:2000 col:1 format:NULL];
        [dhWS width:5000 col:1 format:NULL];
        [dhWS width:8000 col:2 format:NULL];
        [dhWS width:6000 col:4 format:NULL];
        [dhWS width:10000 col:7 format:NULL];
        [dhWS width:40000 col:14 format:NULL];
    
        [dhWS merge:(NSRect){{0, 0}, {14, 0} }];
        
        cell = [dhWS label:@"(Ferrari)_SkipFDR-SEAL_UNITS_INFO" row:0 col:0];
        [cell horzAlign:HALIGN_CENTER];
        [cell fontBold:bold];
    
        [cell fillFGcolor:COLOR_BLUE];
    
        [cell fontColor:COLOR_RED];
        [cell fontItalic:YES];
        [cell fillBGcolor:COLOR_DARK_GREEN];
        [cell fontShadow:YES];

        
        cell = [dhWS label:@"Item" row:1 col:0];
        cell = [dhWS label:@"FGSN" row:1 col:1];
        cell = [dhWS label:@"Unit#" row:1 col:2];
        cell = [dhWS label:@"Config" row:1 col:3];
        cell = [dhWS label:@"MLBSN#" row:1 col:4];
        cell = [dhWS label:@"Radar#" row:1 col:5];
        cell = [dhWS label:@"Failure Station" row:1 col:6];
        cell = [dhWS label:@"Failure Symptom" row:1 col:7];
        cell = [dhWS label:@"Apple Group" row:1 col:8];
        cell = [dhWS label:@"Apple DRI" row:1 col:9];
        cell = [dhWS label:@"HH DRI" row:1 col:10];
        cell = [dhWS label:@"F1 Approve" row:1 col:11];
        cell = [dhWS label:@"FA DRI" row:1 col:12];
        cell = [dhWS label:@"Date" row:1 col:13];
        cell = [dhWS label:@"Remark" row:1 col:14];
        [cell fillBGcolor:COLOR_YELLOW];

        
        for(int i = 2; i< array.count+2; i++){
            NSLog(@"array.count: %lu", (unsigned long)array.count);
            for (int j = 1; j<15; j++) {
                cell = [dhWS label:array[i-2][j-1] row:i col:j];
                [dhWS height:500 row:i format:NULL];
            }
        }

        for (int i = 2; i< array.count+2; i++) {
            NSString *item = [NSString stringWithFormat:@"%d", i-1];
            cell = [dhWS label:item row:i col:0];
        }
        
        cout++;
        numberOfSheet--;
    }
    
    NSString *downloadPath = [sandBox stringByAppendingPathComponent:@"downloadDirectory"];
    
    NSString *downloadFile = [downloadPath stringByAppendingPathComponent:self.excel_name.stringValue];
    
    NSLog(@"downloadPathFile: %@", downloadFile);
    int fud = [dhWB writeFile:downloadFile];
    NSLog(@"fud: %d", fud);

    [[NSWorkspace sharedWorkspace] openFile:downloadFile withApplication:@"Microsoft Excel" andDeactivate:YES];
}


//选择sheet num
- (IBAction)getSheetNum:(id)sender {
    
    if(![self.sheetNum indexOfSelectedItem]){
        return;
    }else if ([[self.sheetNum titleOfSelectedItem] isEqualToString:@"1"]){
        sheetCount = 1;
    }else if ([[self.sheetNum titleOfSelectedItem] isEqualToString:@"2"]){
        sheetCount = 2;
    }else if ([[self.sheetNum titleOfSelectedItem] isEqualToString:@"3"]){
        sheetCount = 3;
    }else if ([[self.sheetNum titleOfSelectedItem] isEqualToString:@"4"]){
        sheetCount = 4;
    }
}



- (IBAction)writeToSingleExcelBn:(id)sender {
    
    NSMutableArray *temp = [NSMutableArray arrayWithObjects:_Items, _FGSNs, _Units, _Configs, _MLBSNs, _RadarNos, _FailStations, _FailureSymptoms, _AppleGroups, _AppleDRIs, _HHDRIs, _F1Approves, _FADRIs, _Times, _Remarks, nil];
    NSLog(@"temp:%@", temp);
    
    DHCell				*cell;
    DHWorkBook *dhWB = [DHWorkBook new];
    DHWorkSheet *dhWS = [dhWB workSheetWithName:@"SHEET1"];
    [dhWS height:500 row:1 format:NULL];
    [dhWS height:500 row:0 format:NULL];
    [dhWS width:60000 col:14 format:NULL];
    [dhWS width:10000 col:7 format:NULL];
    [dhWS width:10000 col:1 format:NULL];
    [dhWS width:10000 col:2 format:NULL];
    [dhWS width:10000 col:4 format:NULL];
    
    
    cell = [dhWS label:@"Item" row:0 col:0];
    cell = [dhWS label:@"FGSN" row:0 col:1];
    cell = [dhWS label:@"Unit#" row:0 col:2];
    cell = [dhWS label:@"Config" row:0 col:3];
    cell = [dhWS label:@"MLBSN#" row:0 col:4];
    cell = [dhWS label:@"Radar#" row:0 col:5];
    cell = [dhWS label:@"Failure Station" row:0 col:6];
    cell = [dhWS label:@"Failure Symptom" row:0 col:7];
    cell = [dhWS label:@"Apple Group" row:0 col:8];
    cell = [dhWS label:@"Apple DRI" row:0 col:9];
    cell = [dhWS label:@"HH DRI" row:0 col:10];
    cell = [dhWS label:@"F1 Approve" row:0 col:11];
    cell = [dhWS label:@"FA DRI" row:0 col:12];
    cell = [dhWS label:@"Date" row:0 col:13];
    cell = [dhWS label:@"Remark" row:0 col:14];
    
    NSLog(@"1");
    
    NSLog(@"temp.count: %lu", (unsigned long)temp.count);
    
    NSLog(@"_Items: %lu", (unsigned long)_Items.count);
    
    for(int i = 1; i< _Items.count+1; i++){
        for (int j = 0; j<temp.count; j++) {
            
            cell = [dhWS label:temp[j][i-1] row:i col:j];
            [dhWS height:500 row:i format:NULL];
        }
    }
    
    int fud = [dhWB writeFile:@"/tmp/test.xls"];
    NSLog(@"OK - bye! fud=%d", fud);
    [[NSWorkspace sharedWorkspace] openFile:@"/tmp/test.xls" withApplication:@"Microsoft Excel" andDeactivate:YES];
}


- (IBAction)checkSNCorrect:(id)sender {
    
    for(int i = 0; i< _FGSNs.count; i++){
        
        NSArray *arr = [NSArray arrayWithObjects:@"info",_FGSNs[i], nil];
        _checkQCRTool = [[CheckQCRTool alloc] initWithArr:arr];
        NSString *strInfo = [_checkQCRTool excuteAnotherTask];
        
        NSArray* strArr = [self getSNinfo:strInfo];
        if([strArr[0] isEqualToString:@""]){
            [loseSn addObject:_FGSNs[i]];
            continue;
        }
        
        if([strArr[0] isEqualToString:_MLBSNs[i]]){
            
            [winMlbSN addObject:_FGSNs[i]];
        }else{
            
            [loseMlbSN addObject:_FGSNs[i]];
        
        }
        id unit = [NSString stringWithFormat:@"%@_%@", strArr[13], strArr[18]];
        
        
        if([unit isEqualToString:_Units[i]]){
            [winUnit addObject:_FGSNs[i]];
        }else{
            [loseUnit addObject:_FGSNs[i]];
        }
        
        NSLog(@"loseUnit: %@", loseUnit);
        
        
        if([strArr[12] isEqualToString:_Configs[i]]){
            
            [winConfig addObject:_FGSNs[i]];
        }else{
            NSLog(@"hh");
            [loseConfig addObject:_FGSNs[i]];
        }
        NSLog(@"loseConfig: %@", loseConfig);
    }
    
    QCRView.string = [NSString stringWithFormat:@"The check info as below:\nIncorrect MLBSN :%@\n\nIncorrect Config: %@\n\nIncorrect Uinit#:%@\n\nCan not check SN: %@\n", loseMlbSN, loseConfig, loseUnit, loseSn];
    
    NSLog(@"loseSn: %@", loseSn);
    
}


-(NSArray *)getSNinfo:(NSString*)string{
    
    NSString *MLBSN = @"\\n\\s*MLBSN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BB_SNUM = @"\\s*BB_SNUM\\s=((\\s*)||(.*))\\s*\\n";
    NSString *CHIPID = @"\\s*CHIPID\\s=((\\s*)||(.*))\\s*\\n";
    NSString *CHIPVER = @"\\s*CHIPVER\\s=((\\s*)||(.*))\\s*\\n";
    NSString *ECID = @"\\s*ECID\\s=((\\s*)||(.*))\\s*\\n";
    NSString *NANDCS = @"\\s*NANDCS\\s=((\\s*)||(.*))\\s*\\n";
    NSString *WIFI = @"\\s*WIFI_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BT = @"\\s*BT_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
    NSString *EOUSB = @"\\s*EOUSB_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
    NSString *UDID = @"\\s*UDID\\s=((\\s*)||(.*))\\s*\\n";
    NSString *IMEI = @"\\s*IMEI\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BUILD_EVENT = @"\\s*BUILD_EVENT\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BUILD_MATRIX_CONFIG = @"\\s*BUILD_MATRIX_CONFIG\\s=((\\s*)||(.*))\\s*\\n";
    NSString *S_BUILD = @"\\s*S_BUILD\\s=((\\s*)||(.*))\\s*\\n";
    NSString *CG_SN = @"\\s*CG_SN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *MESA_MODULE_SN = @"\\s*MESA_MODULE_SN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *MPN = @"\\s*MPN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *REGION_CODE = @"\\s*REGION_CODE\\s=((\\s*)||(.*))\\s*\\n";
    NSString *UNIT = @"\\s*UNIT#\\s=((\\s*)||(.*))\\s*\\n";
    NSString *ROMEO_SN = @"\\s*ROMEO_SN\\s=((\\s*)||(.*))\\n";
    NSString *ROSALINE_SN = @"\\s*ROSALINE_SN\\s=((\\s*)||(.*))\\n";
    NSString *SAVAGE_SN = @"\\s*SAVAGE_SN\\s=((\\s*)||(.*))\\n";
    NSString *JULIET_SN = @"\\s*JULIET_SN\\s=((\\s*)||(.*))\\n";
    NSString *PRODUCTION_SOC = @"\\s*PRODUCTION_SOC\\s=((\\s*)||(.*))\\s*\\n";
    
    
    NSString *pattern_sum = [NSString stringWithFormat:@"%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@",MLBSN, BB_SNUM, CHIPID, CHIPVER, ECID, NANDCS, WIFI, BT, EOUSB, UDID, IMEI, BUILD_EVENT, BUILD_MATRIX_CONFIG, S_BUILD, CG_SN,MESA_MODULE_SN, MPN, REGION_CODE, UNIT, ROMEO_SN, ROSALINE_SN, SAVAGE_SN, JULIET_SN, PRODUCTION_SOC];
    
    NSRegularExpression *regex = [[NSRegularExpression alloc] initWithPattern:pattern_sum options:NSRegularExpressionCaseInsensitive error:nil];
    NSArray *results = [regex matchesInString:string options:0 range:NSMakeRange(0, string.length)];
    
    NSMutableArray *PatternArr = [[NSMutableArray alloc] init];
    [PatternArr removeAllObjects];
    
    
    for (NSTextCheckingResult *result in results){
        
        // NSLog(@"%@ %@", NSStringFromRange(result.range), [QCRInfo substringWithRange:result.range]);
        
        NSRange range = {(int)(result.range.location + 23), (int)(result.range.length -23)};
        NSString* temp = [string substringWithRange:range];
        
        //[patternArr addObject:[temp stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
        
        [PatternArr addObject:[temp stringByReplacingOccurrencesOfString:@"\n" withString:@""]];
    }
    
    PatternArr[0] = [PatternArr[0] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    NSLog(@"qcrPatternArr: %@", PatternArr);
    
    return PatternArr;
}



-(void)singleExcelView{
    self.excelPathBn.hidden = YES;
    self.WSEBn.hidden = YES;
    self.removeSNBn.hidden = YES;
    self.singleExcelBn.hidden = NO;
    self.checkSNBn.hidden =YES;
}

-(void)specifyExcelView{
    self.excelPathBn.hidden = NO;
    self.WSEBn.hidden = NO;
    self.removeSNBn.hidden = YES;
    self.singleExcelBn.hidden = YES;
    self.checkSNBn.hidden =YES;
}

-(void)editToDeleteView{
    self.excelPathBn.hidden = YES;
    self.WSEBn.hidden = YES;
    self.removeSNBn.hidden = NO;
    self.singleExcelBn.hidden = YES;
    self.checkSNBn.hidden =YES;
}

-(void)checkSNView{
    self.excelPathBn.hidden = YES;
    self.WSEBn.hidden = YES;
    self.removeSNBn.hidden = YES;
    self.singleExcelBn.hidden = YES;
    self.checkSNBn.hidden =NO;
}
@end
