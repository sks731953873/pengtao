//
//  QCRWindowController.m
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016 108. All rights reserved.
//
//  C39SL01GHNW0/C39SX03JHNVR/C39T100KHWHN

#import "QCRWindowController.h"
#import "UMWindowController.h"
#import "PlistTool.h"
#import "CheckQCRTool.h"
#import "ReadExcelTool.h"

static NSString *temCSV = @"fdr.csv";

@interface QCRWindowController ()

@property(strong) UMWindowController *UMWindow;
@property(nonatomic ,strong) ReadExcelTool* readExcel;

@end

@implementation QCRWindowController{
    
    PlistTool *plistTool;
    NSArray *secondDic;
    NSString *qcrToolPath;
    NSString *txtPath;
}

NSTextView *QCRView;
NSString *QCRKeyConfig;
NSString *QCRValueConfig;
NSString *QCRAccount;
BOOL isSNInfo;
NSMutableArray *qcrPatternArr;
NSArray *snArr;
NSFileManager *fileMa;
NSString *curDir;
NSString *csvPath;
NSOutputStream *output;
NSMutableArray *CSVSNArr;
NSString *string;

//NSMutableArray *keyArr;
//NSMutableArray *valueArr;

NSString *fullPath;

- (void)windowDidLoad {
    [super windowDidLoad];
    
    
    NSString* filePath = @"/Users/DemonZhu/Desktop/SHEET1.xls";

    _readExcel = [[ReadExcelTool alloc] initWithFilePath:filePath];

//    NSArray* readResult = [_readExcel readExcel:0 isExcel:YES];
//    NSLog(@"readResult: %@", readResult);
    
    NSArray* transResult = [_readExcel transFromArray:0 isExcel:YES];
    NSLog(@"transResult: %@", transResult);
    
    
    //qcr background color
    _qcrView.wantsLayer = YES;
    _qcrView.layer.backgroundColor = CGColorCreateGenericRGB(0.9f, 0.9f, 1.0f, 0.9f);
    
    isSNInfo = FALSE;
    
    
    //初始化本地路径
    fileMa = [NSFileManager defaultManager];
    curDir = [fileMa currentDirectoryPath];
    NSLog(@"currentPath: %@", curDir);
    
    //初始化csvPath
    csvPath = [curDir stringByAppendingPathComponent:temCSV];
    NSLog(@"CSV: %@", csvPath);
    
    //leftBn
    [self.qcrLeftBn setButtonType: NSMomentaryPushInButton];
    [self.qcrLeftBn setBezelStyle: NSRoundedBezelStyle];
    [self.qcrLeftBn setBordered: NO];
    [self.qcrLeftBn setImage: [NSImage imageNamed: @"left_highlighted"]];
    [self.qcrLeftBn setImagePosition: NSImageOnly];
    [self.qcrLeftBn setTarget: self];
    
    //初始化文本框
//    [self.QCRDisplay setBorderType:NSNoBorder];
    [self.QCRDisplay  setHasVerticalScroller:YES];
    [self.QCRDisplay  setHasHorizontalScroller:YES];
    [self.QCRDisplay  setAutoresizingMask:NSViewWidthSizable | NSViewHeightSizable];
    
    QCRView =[[NSTextView alloc]initWithFrame:CGRectMake(47, 0, 900, 200)];
    [self.QCRDisplay  setDocumentView:QCRView];
    [self.window.contentView addSubview:self.QCRDisplay ];
    QCRView.editable = NO;
    
    [QCRView setMinSize:NSMakeSize(0.0, 98)];
//    [QCRView setMaxSize:NSMakeSize(FLT_MAX, FLT_MAX)];
    [QCRView setVerticallyResizable:YES];
    [QCRView setHorizontallyResizable:NO];
    [QCRView setAutoresizingMask:NSViewWidthSizable];
    [[QCRView textContainer]setContainerSize:NSMakeSize(60000,FLT_MAX)];
    [[QCRView textContainer]setWidthTracksTextView:YES];
    
    
    //getPath
    [self.csvTxtPath setButtonType: NSMomentaryPushInButton];
    [self.csvTxtPath setBezelStyle: NSRoundedBezelStyle];
    [self.csvTxtPath setBordered: NO];
    [self.csvTxtPath setImage: [NSImage imageNamed: @"fileFolder.png"]];
    [self.csvTxtPath setImagePosition: NSImageOnly];
    [self.csvTxtPath setTarget: self];
    
    [QCRView setFont:[NSFont fontWithName:@"Helvetica" size:13.0]];
    QCRView.textColor = [NSColor blackColor];
    
    
    //初始化自定义 QDefaultLb & QDefaultField
    self.QGlobalLb.stringValue = @"Defalut:";
    self.QDefaultField.stringValue = @"------------------------------------------";
    self.QDefaultField.enabled = NO;
    
    self.QDefaultField.hidden = NO;
    self.QGlobalLb.hidden = NO;
    
    
    //初始化 SN Record
    self.SNRecBn.hidden = YES;
    self.SNRecField.hidden = YES;
    self.SNRecBn.title = @"Send";
    
    //初始化 SN Info
    self.SNInfoBn.hidden = YES;
    self.SNInfoField.hidden = YES;
    self.SNInfoBn.title = @"Send";
    
    //初始化MLB Record
    self.mlbRecBn.hidden = YES;
    self.mlbRecField.hidden = YES;
    self.mlbRecBn.title = @"Send";

    //初始化MLB Info
    self.mlbInfoBn.hidden = YES;
    self.mlbInfoField.hidden = YES;
    self.mlbInfoBn.title = @"Send";
    
    //amountCSVField
    self.csvTxtPath.hidden = YES;
    self.amountCsvBn.hidden = YES;
    self.csvNameField.hidden = YES;
    self.amountCsvBn.title = @"Send";
    
    //amountMLBcsv
    self.amountMLBcsvBn.hidden = YES;
    self.amountMLBcsvBn.title = @"Send";
    
    
    plistTool = [PlistTool instance];
    
    //获取config的bundle路径
    NSString *qcrBundlePath = [[NSBundle mainBundle] resourcePath];
    qcrToolPath = [qcrBundlePath stringByAppendingPathComponent:@"checkQCR"];
    
    //获得配置文件QCR账号密码
    NSString *bundle = [[NSBundle mainBundle] pathForResource:@"config" ofType:@"plist"];
    NSDictionary *configDic = [NSDictionary dictionaryWithContentsOfFile:bundle];
    
    
    secondDic = [plistTool valueForKey:@"QCR" inDictionary:configDic recursion:YES];
    NSLog(@"secondDic: %@", secondDic);
    
    if([secondDic respondsToSelector:@selector(objectAtIndex:)]){
        
        for(int i = 0 ; i< secondDic.count; i++){
            
            id temp = [secondDic[i] objectForKey:@"qcrCheck"];
            
            if([temp isEqual:@"1"]){
                
                QCRKeyConfig = [secondDic[i] objectForKey:@"qcrUserName"];
                
                QCRAccount = [secondDic[i] objectForKey:@"qcrPassword"];
                
            }else{
                
                
            }
        }
    }
    
    QCRAccount = [[NSString alloc] initWithFormat:@"%@:%@", QCRKeyConfig,QCRAccount];
    NSLog(@"QCRAccount: %@", QCRAccount);
}



- (IBAction)backToUMWindow:(id)sender {
    
    //停止task
    [self setTaskNil];
    
    //跳转到_UMWindow
    _UMWindow = [[UMWindowController alloc] initWithWindowNibName:@"UMWindowController"];
    [_UMWindow.window orderFront:nil];
    [_UMWindow.window center];
    [self.window orderOut:nil];
}

- (IBAction)SendSNRec:(id)sender {

    if([self.SNRecField.stringValue isEqualToString:@""]){
        QCRView.string = @"雷达号或者文件名不能为空";
        return;
    }else if([self.SNRecField.stringValue length] != 12){
        QCRView.string = @"SN需要12位数字";
        return;
    }
    else{
        isSNInfo = FALSE;

        QCRView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"record",self.SNRecField.stringValue, nil];
        NSLog(@"arr: %@", arr);
        _checkQCRTool = [[CheckQCRTool alloc] initWithArr:arr];
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        [_checkQCRTool excuteQCRTask];
        
        [nc addObserver:self
               selector:@selector(handleStringChange:)
                   name:stringChangeNotification
                 object:string];
        NSLog(@"Registered with notification center");
    }
}


-(void)handleStringChange:(NSNotification*) note{
    
    NSLog(@"Received notification: %@", note);
    
    //radarTxtView.string = @"";
    
    string = [[note userInfo] objectForKey:@"string"];
    NSLog(@"string: %lu", (unsigned long)[string length]);
    
    NSTextStorage *ts = [QCRView textStorage];
    [QCRView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
    [ts replaceCharactersInRange:NSMakeRange([ts length], 0) withString:string];
    
    //判断excuteQCRTask函数是否执行完成
    id temp = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSArray *tempArr = [temp componentsSeparatedByString:@"\n"];
    NSString* temp1= [tempArr lastObject];
    id temp2 = [temp1 stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSArray *tempArr1 = [temp2 componentsSeparatedByString:@" ="];
    
    if([tempArr1[0] isEqualToString:@"PRODUCTION_SOC"] && isSNInfo){
        [self getSNinfo];
    }
}



- (IBAction)SendSNInfo:(id)sender {

    if([self.SNInfoField.stringValue isEqualToString:@""]){
        QCRView.string = @"SN不能为空";
        return;
    }else if([self.SNInfoField.stringValue length] != 12){
        QCRView.string = @"SN需要12位数字";
        return;
    }else{
        isSNInfo = TRUE;
        
        QCRView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"info",self.SNInfoField.stringValue, nil];
        NSLog(@"arr: %@", arr);
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        _checkQCRTool = [[CheckQCRTool alloc] initWithArr:arr];
        [_checkQCRTool excuteQCRTask];
        [nc addObserver:self
               selector:@selector(handleStringChange:)
                   name:stringChangeNotification
                 object:nil];
        NSLog(@"Registered with notification center");
    }
}


- (IBAction)amountWriteCSV:(id)sender {
    NSLog(@"xxx");
    isSNInfo = TRUE;
    
    NSString *txtContent = [NSString stringWithContentsOfFile:txtPath encoding:NSUTF8StringEncoding error:NULL];
    
    NSLog(@"txtContent: %@", txtContent);
    
    NSMutableArray* arr = [NSMutableArray arrayWithObjects:txtContent, nil];
    
    NSLog(@"arr: %@", arr);
    
    if([txtContent isEqualToString:@""]||[self.csvNameField.stringValue isEqualTo:@""]){
        
        QCRView.string = @"txt文件 or csvName不能为空";
        return;
    }
    
    snArr = [txtContent componentsSeparatedByString:@"\n"];
    
    NSLog(@"snArr: %@", snArr);
    
    
    
    for (int i = 0; i<snArr.count; i++) {
        
        QCRTask = [[NSTask alloc] init];
        
        [QCRTask setLaunchPath:@"/bin/bash"];
        
        NSArray *arguments = [NSArray arrayWithObjects:qcrToolPath, QCRAccount,@"info",snArr[i], nil];
        
        NSLog(@"arguments:%@", arguments);
        
        [QCRTask setArguments:arguments];
        
        NSPipe *pipe = [NSPipe pipe];
        
        [QCRTask setStandardOutput:pipe];
        
        NSFileHandle *file = [pipe fileHandleForReading];
        
        [QCRTask launch];
        
        NSData *data = [file readDataToEndOfFile];
        
        NSMutableString *string = [[NSMutableString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"string: %@", string);
        
        QCRView.string= string;
        
        [self getSNinfo];
        
        if(![fileMa fileExistsAtPath:self.csvNameField.stringValue]){
            
            NSString *csvPath = [NSString stringWithFormat:@"./%@", self.csvNameField.stringValue];
            
            if([[NSFileManager defaultManager] createFileAtPath:csvPath contents:nil attributes:nil]){
                NSLog(@"OK");
            }
            
            if([[NSFileManager defaultManager] fileExistsAtPath:csvPath]){
                NSLog(@"yesok");
            }
            
            output = [[NSOutputStream alloc] initToFileAtPath:csvPath append:YES];
            
            [output open];
            
            NSString *header = @"SN,MLBSN,BB_SNUM,CHIPID,CHIPVER,ECID,NANDCS,WIFI,BT,EOUSB,UDID,IMEI,BUILD_EVENT,BUILD_MATRIX_CONFIG,S_BUILD,CG_SN,MESA_MODULE_SN,MPN,REGION_CODE,UNIT,ROMEO_SN,ROSALINE_SN,SAVAGE_SN,JULIET_SN,PRODUCTION_SOC\n";
            
            const uint8_t *headerString = (const uint8_t *)[header cStringUsingEncoding:NSUTF8StringEncoding];
            NSInteger headerLength = [header lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
            NSInteger result = [output write:headerString maxLength:headerLength];
            if (result <= 0) {
                NSLog(@"写入错误");
            }
            
            [output close];
        }
        
        //写入csv文件
        NSString *csvPath = [NSString stringWithFormat:@"./%@", self.csvNameField.stringValue];
        
        output = [[NSOutputStream alloc] initToFileAtPath:csvPath append:YES];
        
        [output open];
        
        NSString *row = [NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@\n",snArr[i],qcrPatternArr[0],qcrPatternArr[1],qcrPatternArr[2],qcrPatternArr[3],qcrPatternArr[4],qcrPatternArr[5],qcrPatternArr[6],qcrPatternArr[7],qcrPatternArr[8],qcrPatternArr[9],qcrPatternArr[10],qcrPatternArr[11],qcrPatternArr[12],qcrPatternArr[13],qcrPatternArr[14],qcrPatternArr[15],qcrPatternArr[16],qcrPatternArr[17],qcrPatternArr[18],qcrPatternArr[19],qcrPatternArr[20],qcrPatternArr[21],qcrPatternArr[22],qcrPatternArr[23]];
        
        const uint8_t *rowString = (const uint8_t *)[row cStringUsingEncoding:NSUTF8StringEncoding];
        NSInteger rowLength = [row lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
        NSInteger result = [output write:rowString maxLength:rowLength];
        if (result <= 0) {
            NSLog(@"无法写入内容");
        }
        
        [output close];
    }
}


-(void)setTaskNil{
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc removeObserver: self];
    [nc addObserver:self
           selector:@selector(taskTerminated:)
               name:NSFileHandleReadCompletionNotification
             object:QCRTask];
}


- (void)taskTerminated:(NSNotification *)note
{
    NSLog(@"taskTerminated:");
    QCRTask = nil;
}


- (IBAction)SendMLBRec:(id)sender {

    
    if([self.mlbRecField.stringValue isEqualToString:@""]){
        QCRView.string = @"MLB SN不能为空";
        return;
    }else if([self.mlbRecField.stringValue length] != 16){
        QCRView.string = @"MLB SN需要16位数字";
        return;
        
    }else{
        isSNInfo = NO;
        
        QCRView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"record",self.mlbRecField.stringValue, nil];
        NSLog(@"arr: %@", arr);
        _checkQCRTool = [[CheckQCRTool alloc] initWithArr:arr];
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        [_checkQCRTool excuteQCRTask];
        [nc addObserver:self
               selector:@selector(handleStringChange:)
                   name:stringChangeNotification
                 object:nil];
        NSLog(@"Registered with notification center");
    }
}


- (IBAction)SendMLBInfo:(id)sender {
        
    if([self.mlbInfoField.stringValue isEqualToString:@""]){
        QCRView.string = @"MLB SN 不能为空";
        return;
    }else if([self.mlbInfoField.stringValue length] != 16){
        QCRView.string = @"MLB SN 需要16位或者字母";
        NSLog(@"%@",self.mlbRecField.stringValue );
        return;
    }else{
        
        isSNInfo = YES;
        
        QCRView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"info",self.mlbInfoField.stringValue, nil];
        NSLog(@"arr: %@", arr);
        
        _checkQCRTool = [[CheckQCRTool alloc] initWithArr:arr];
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        [_checkQCRTool excuteQCRTask];
        [nc addObserver:self
               selector:@selector(handleStringChange:)
                   name:stringChangeNotification
                 object:nil];
        NSLog(@"Registered with notification center");
    }
}


-(void)getSNinfo{
    NSLog(@"QCRView: %@", QCRView.string);
    
    NSString *MLBSN = @"\\n\\s*MLBSN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BB_SNUM = @"\\s*BB_SNUM\\s=((\\s*)||(.*))\\s*\\n";
    NSString *CHIPID = @"\\s*CHIPID\\s=((\\s*)||(.*))\\s*\\n";
    NSString *CHIPVER = @"\\s*CHIPVER\\s=((\\s*)||(.*))\\s*\\n";
    NSString *ECID = @"\\s*ECID\\s=((\\s*)||(.*))\\s*\\n";
    NSString *NANDCS = @"\\s*NANDCS\\s=((\\s*)||(.*))\\s*\\n";
    NSString *WIFI = @"\\s*WIFI_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BT = @"\\s*BT_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
    NSString *EOUSB = @"\\s*EOUSB_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
    NSString *UDID = @"\\s*UDID\\s=((\\s*)||(.*))\\s*\\n";
    NSString *IMEI = @"\\s*IMEI\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BUILD_EVENT = @"\\s*BUILD_EVENT\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BUILD_MATRIX_CONFIG = @"\\s*BUILD_MATRIX_CONFIG\\s=((\\s*)||(.*))\\s*\\n";
    NSString *S_BUILD = @"\\s*S_BUILD\\s=((\\s*)||(.*))\\s*\\n";
    NSString *CG_SN = @"\\s*CG_SN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *MESA_MODULE_SN = @"\\s*MESA_MODULE_SN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *MPN = @"\\s*MPN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *REGION_CODE = @"\\s*REGION_CODE\\s=((\\s*)||(.*))\\s*\\n";
    NSString *UNIT = @"\\s*UNIT#\\s=((\\s*)||(.*))\\s*\\n";
    NSString *ROMEO_SN = @"\\s*ROMEO_SN\\s=((\\s*)||(.*))\\n";
    NSString *ROSALINE_SN = @"\\s*ROSALINE_SN\\s=((\\s*)||(.*))\\n";
    NSString *SAVAGE_SN = @"\\s*SAVAGE_SN\\s=((\\s*)||(.*))\\n";
    NSString *JULIET_SN = @"\\s*JULIET_SN\\s=((\\s*)||(.*))\\n";
    NSString *PRODUCTION_SOC = @"\\s*PRODUCTION_SOC\\s=((\\s*)||(.*))\\s*\\n";
    
    
    // NSString *pattern_sum = [NSString stringWithFormat:@"%@|%@|%@|%@|%@|%@|%@|%@|%@|%@",MLBSN, BB_SNUM, CHIPID, CHIPVER, ECID, NANDCS, WIFI, BT, EOUSB, UDID];
    
    // C39SL01GHNW0/C39SX03JHNVR/C39T100KHWHN
    NSString *pattern_sum = [NSString stringWithFormat:@"%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@",MLBSN, BB_SNUM, CHIPID, CHIPVER, ECID, NANDCS, WIFI, BT, EOUSB, UDID, IMEI, BUILD_EVENT, BUILD_MATRIX_CONFIG, S_BUILD, CG_SN,MESA_MODULE_SN, MPN, REGION_CODE, UNIT, ROMEO_SN, ROSALINE_SN, SAVAGE_SN, JULIET_SN, PRODUCTION_SOC];
    
    NSRegularExpression *regex = [[NSRegularExpression alloc] initWithPattern:pattern_sum options:NSRegularExpressionCaseInsensitive error:nil];
    NSArray *results = [regex matchesInString:QCRView.string options:0 range:NSMakeRange(0, QCRView.string.length)];
    
    qcrPatternArr = [[NSMutableArray alloc] init];
    [qcrPatternArr removeAllObjects];
    
    
    for (NSTextCheckingResult *result in results){
        
        // NSLog(@"%@ %@", NSStringFromRange(result.range), [QCRInfo substringWithRange:result.range]);
        NSRange range = {(int)(result.range.location + 23), (int)(result.range.length -23)};
        NSString* temp = [QCRView.string substringWithRange:range];
        //[patternArr addObject:[temp stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
        [qcrPatternArr addObject:[temp stringByReplacingOccurrencesOfString:@"\n" withString:@""]];
        
    }
    
    qcrPatternArr[0] = [qcrPatternArr[0] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    NSLog(@"qcrPatternArr: %@", qcrPatternArr);
    
    _MLBSN.stringValue = qcrPatternArr[0];
    _BB_SNUM.stringValue = qcrPatternArr[1];
    _CHIPID.stringValue = qcrPatternArr[2];
    _CHIPVER.stringValue = qcrPatternArr[3];
    _ECID.stringValue = qcrPatternArr[4];
    _NANDCS.stringValue = qcrPatternArr[5];
    _WIFI.stringValue = qcrPatternArr[6];
    _BT.stringValue = qcrPatternArr[7];
    _EOUSB.stringValue = qcrPatternArr[8];
    _UDID.stringValue = qcrPatternArr[9];
    _IMEI.stringValue = qcrPatternArr[10];
    _BUILD_EVENT.stringValue = qcrPatternArr[11];
    _BUILD_MATRIX_CONFIG.stringValue = qcrPatternArr[12];
    _S_BUILD.stringValue = qcrPatternArr[13];
    _CG_SN.stringValue = qcrPatternArr[14];
    _MESA_MODULE_SN.stringValue = qcrPatternArr[15];
    _MPN.stringValue = qcrPatternArr[16];
    _REGION_CODE.stringValue = qcrPatternArr[17];
    _UNIT.stringValue = qcrPatternArr[18];
    _ROMEO_SN.stringValue = qcrPatternArr[19];
    _ROSALINE_SN.stringValue = qcrPatternArr[20];
    _SAVAGE_SN.stringValue = qcrPatternArr[21];
    _JULIET_SN.stringValue = qcrPatternArr[22];
    _PRODUCTION_SOC.stringValue  = qcrPatternArr[23];
    
//    [self writeToCsv];
    
}

-(void)getMLBinfo{
    
    NSLog(@"QCRView: %@", QCRView.string);
    
    NSString *MLBSN = @"\\n\\s*MLBSN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BB_SNUM = @"\\s*BB_SNUM\\s=((\\s*)||(.*))\\s*\\n";
    NSString *CHIPID = @"\\s*CHIPID\\s=((\\s*)||(.*))\\s*\\n";
    NSString *CHIPVER = @"\\s*CHIPVER\\s=((\\s*)||(.*))\\s*\\n";
    NSString *ECID = @"\\s*ECID\\s=((\\s*)||(.*))\\s*\\n";
    NSString *NANDCS = @"\\s*NANDCS\\s=((\\s*)||(.*))\\s*\\n";
    NSString *WIFI = @"\\s*WIFI_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BT = @"\\s*BT_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
    NSString *EOUSB = @"\\s*EOUSB_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
    NSString *UDID = @"\\s*UDID\\s=((\\s*)||(.*))\\s*\\n";
    NSString *IMEI = @"\\s*IMEI\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BUILD_EVENT = @"\\s*BUILD_EVENT\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BUILD_MATRIX_CONFIG = @"\\s*BUILD_MATRIX_CONFIG\\s=((\\s*)||(.*))\\s*\\n";
    NSString *S_BUILD = @"\\s*S_BUILD\\s=((\\s*)||(.*))\\s*\\n";
    NSString *CG_SN = @"\\s*CG_SN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *MESA_MODULE_SN = @"\\s*MESA_MODULE_SN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *MPN = @"\\s*MPN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *REGION_CODE = @"\\s*REGION_CODE\\s=((\\s*)||(.*))\\s*\\n";
    NSString *UNIT = @"\\s*UNIT#\\s=((\\s*)||(.*))\\s*\\n";
    NSString *ROMEO_SN = @"\\s*ROMEO_SN\\s=((\\s*)||(.*))\\n";
    NSString *ROSALINE_SN = @"\\s*ROSALINE_SN\\s=((\\s*)||(.*))\\n";
    NSString *SAVAGE_SN = @"\\s*SAVAGE_SN\\s=((\\s*)||(.*))\\n";
    NSString *JULIET_SN = @"\\s*JULIET_SN\\s=((\\s*)||(.*))\\n";
    NSString *PRODUCTION_SOC = @"\\s*PRODUCTION_SOC\\s=((\\s*)||(.*))\\s*\\n";
    
    // C39SL01GHNW0/C39SX03JHNVR/C39T100KHWHN
    NSString *pattern_sum = [NSString stringWithFormat:@"%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@",MLBSN, BB_SNUM, CHIPID, CHIPVER, ECID, NANDCS, WIFI, BT, EOUSB, UDID, IMEI, BUILD_EVENT, BUILD_MATRIX_CONFIG, S_BUILD, CG_SN,MESA_MODULE_SN, MPN, REGION_CODE, UNIT, ROMEO_SN, ROSALINE_SN, SAVAGE_SN, JULIET_SN, PRODUCTION_SOC];
    
    NSRegularExpression *regex = [[NSRegularExpression alloc] initWithPattern:pattern_sum options:NSRegularExpressionCaseInsensitive error:nil];
    NSArray *results = [regex matchesInString:QCRView.string options:0 range:NSMakeRange(0, QCRView.string.length)];
    
    qcrPatternArr = [[NSMutableArray alloc] init];
    [qcrPatternArr removeAllObjects];
    
    
    for (NSTextCheckingResult *result in results){
        
        // NSLog(@"%@ %@", NSStringFromRange(result.range), [QCRInfo substringWithRange:result.range]);
        
        NSRange range = {(int)(result.range.location + 23), (int)(result.range.length -23)};
        NSString* temp = [QCRView.string substringWithRange:range];
        
        //[patternArr addObject:[temp stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
        
        [qcrPatternArr addObject:[temp stringByReplacingOccurrencesOfString:@"\n" withString:@""]];
        
    }
    
    
    NSLog(@"qcrPatternArr: %@", qcrPatternArr);
    
    _MLBSN.stringValue = qcrPatternArr[0];
    _BB_SNUM.stringValue = qcrPatternArr[1];
    _CHIPID.stringValue = qcrPatternArr[2];
    _CHIPVER.stringValue = qcrPatternArr[3];
    _ECID.stringValue = qcrPatternArr[4];
    _NANDCS.stringValue = qcrPatternArr[5];
    _WIFI.stringValue = qcrPatternArr[6];
    _BT.stringValue = qcrPatternArr[7];
    _EOUSB.stringValue = qcrPatternArr[8];
    _UDID.stringValue = qcrPatternArr[9];
    _IMEI.stringValue = qcrPatternArr[10];
    _BUILD_EVENT.stringValue = qcrPatternArr[11];
    _BUILD_MATRIX_CONFIG.stringValue = qcrPatternArr[12];
    _S_BUILD.stringValue = qcrPatternArr[13];
    _CG_SN.stringValue = qcrPatternArr[14];
    _MESA_MODULE_SN.stringValue = qcrPatternArr[15];
    _MPN.stringValue = qcrPatternArr[16];
    _REGION_CODE.stringValue = qcrPatternArr[17];
    _UNIT.stringValue = qcrPatternArr[18];
    _ROMEO_SN.stringValue = qcrPatternArr[19];
    _ROSALINE_SN.stringValue = qcrPatternArr[20];
    _SAVAGE_SN.stringValue = qcrPatternArr[21];
    _JULIET_SN.stringValue = qcrPatternArr[22];
    _PRODUCTION_SOC.stringValue  = qcrPatternArr[23];
    
    //    [self writeToCsv];
    
}




-(id)setPipe:(NSTask *) task{
    
    NSPipe *pipe = [NSPipe pipe];
    [task setStandardOutput:pipe];
    
    NSFileHandle *file = [pipe fileHandleForReading];
    
    [task launch];
    
    NSData *data = [file readDataToEndOfFile];
    NSMutableString *string = [[NSMutableString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    NSLog(@"string: %@", string);
    QCRView.string= string;
    
    return QCRView.string;
}


- (IBAction)QitemChoose:(id)sender {
    if(![self.QCRItemChioce indexOfSelectedItem])
    {
        return;
    }
    else if([[self.QCRItemChioce titleOfSelectedItem] isEqualToString:@"SN Record"]){
        NSLog(@"SN Record");
        QCRView.string = @"请在填写相应的SN";
        [self clearFieldContent];
        [self setTaskNil];
        [self SNRecView];
    }
    else if([[self.QCRItemChioce titleOfSelectedItem] isEqualToString:@"SN info"]){
        NSLog(@"SN info");
        QCRView.string = @"请在填写相应的SN";
        
        [self setTaskNil];
        [self SNInfoView];
    }
    else if([[self.QCRItemChioce titleOfSelectedItem] isEqualToString:@"MLB Record"]){
        NSLog(@"MLB Record");
        QCRView.string = @"请在填写相应的MLBSN";
        
        [self clearFieldContent];
        [self setTaskNil];
        [self mlbRecView];
    }
    else if([[self.QCRItemChioce titleOfSelectedItem] isEqualToString:@"MLB info"]){
        NSLog(@"MLB Record");
        QCRView.string = @"请在填写相应的MLBSN";
        
        [self clearFieldContent];
        [self setTaskNil];
        [self mlbInfoView];
    }
    else if([[self.QCRItemChioce titleOfSelectedItem] isEqualToString:@"Amount to createSNCSV"]){
        NSLog(@"Amount to createSNCSV");
        QCRView.string = @"请在填写相应的SN的txt文件";
        
        [self clearFieldContent];
        [self setTaskNil];
        [self amountCreateCSView];
    }
    else if([[self.QCRItemChioce titleOfSelectedItem] isEqualToString:@"Amount to createMLBCSV"]){
        NSLog(@"Amount to createSNCSV");
        QCRView.string = @"请在填写相应的SN的txt文件";
        
        [self clearFieldContent];
        [self setTaskNil];
        [self amountCreateMLBCSView];
    }
}


-(void)clearFieldContent{
    _MLBSN.stringValue = @"";
    _BB_SNUM.stringValue = @"";
    _CHIPID.stringValue = @"";
    _CHIPVER.stringValue = @"";
    _ECID.stringValue = @"";
    _NANDCS.stringValue = @"";
    _WIFI.stringValue = @"";
    _BT.stringValue = @"";
    _EOUSB.stringValue = @"";
    _UDID.stringValue = @"";
    _IMEI.stringValue = @"";
    _BUILD_EVENT.stringValue = @"";
    _BUILD_MATRIX_CONFIG.stringValue = @"";
    _S_BUILD.stringValue = @"";
    _CG_SN.stringValue = @"";
    _MESA_MODULE_SN.stringValue = @"";
    _MPN.stringValue = @"";
    _REGION_CODE.stringValue = @"";
    _UNIT.stringValue = @"";
    _ROMEO_SN.stringValue = @"";
    _ROSALINE_SN.stringValue = @"";
    _SAVAGE_SN.stringValue = @"";
    _JULIET_SN.stringValue = @"";
    _PRODUCTION_SOC.stringValue  = @"";
}


- (IBAction)writeCSV:(id)sender{
    
    if(![fileMa fileExistsAtPath:@"fdr.csv"]){
        if([[NSFileManager defaultManager] createFileAtPath:@"./fdr.csv" contents:nil attributes:nil]){
            NSLog(@"OK");
        }
        if([[NSFileManager defaultManager] fileExistsAtPath:csvPath]){
            NSLog(@"yesok");
        }
        output = [[NSOutputStream alloc] initToFileAtPath:csvPath append:YES];
        [output open];
        NSString *header = @"SN,MLBSN,BB_SNUM,CHIPID,CHIPVER,ECID,NANDCS,WIFI,BT,EOUSB,UDID,IMEI,BUILD_EVENT,BUILD_MATRIX_CONFIG,S_BUILD,CG_SN,MESA_MODULE_SN,MPN,REGION_CODE,UNIT,ROMEO_SN,ROSALINE_SN,SAVAGE_SN,JULIET_SN,PRODUCTION_SOC\n";
        const uint8_t *headerString = (const uint8_t *)[header cStringUsingEncoding:NSUTF8StringEncoding];
        NSInteger headerLength = [header lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
        NSInteger result = [output write:headerString maxLength:headerLength];
        if (result <= 0) {
            NSLog(@"写入错误");
        }
        [output close];
    }
    
    //判断是否fdr.csv文件中的SN,读取csv文件中的SN
    if([fileMa fileExistsAtPath:@"fdr.csv"]){
        
        NSString *fileContent = [NSString stringWithContentsOfFile:@"fdr.csv" encoding:NSUTF8StringEncoding error:nil];
        NSLog(@"fileContent: %@", fileContent);
        id  tempStr = [fileContent componentsSeparatedByString:@"\r\n"];
        NSLog(@"tempStr: %@", tempStr);
        
        CSVSNArr=[[NSMutableArray alloc]init];
        
        [CSVSNArr removeAllObjects];
        
        FILE *fp=fopen([csvPath UTF8String], "r");
        if (fp) {
            char buf[BUFSIZ];
            fgets(buf, BUFSIZ, fp);
            while (!feof(fp)) {
                char buf[BUFSIZ];
                fgets(buf, BUFSIZ, fp);
                
                // 处理文本信息 转化 成 数组文件
                
                NSString *s=[[NSString alloc]initWithUTF8String:(const char *)buf];
                
                if([s isEqual:[NSNull null]] || s == nil){
                    CSVSNArr = NULL;
                    
                }else{
                    
                    NSString *ss=[s stringByReplacingOccurrencesOfString:@"\r" withString:@""];
                    
                    ss=[ss stringByReplacingOccurrencesOfString:@"\n" withString:@""];
                    
                    NSArray *a=[ss componentsSeparatedByString:@","];
                    
                    [CSVSNArr addObject:a[0]];
                }
            }
            
            NSLog(@"CSVSNArr: %@", CSVSNArr);
        }
    }
    
    if(![CSVSNArr containsObject:self.SNInfoField.stringValue]){
        
        NSLog(@"YES");
        output = [[NSOutputStream alloc] initToFileAtPath:csvPath append:YES];
        
        [output open];

        NSString *row = [NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@\n",_SNInfoField.stringValue,_MLBSN.stringValue,_BB_SNUM.stringValue,_CHIPID.stringValue,_CHIPVER.stringValue,_ECID.stringValue,_NANDCS.stringValue,_WIFI.stringValue,_BT.stringValue,_EOUSB.stringValue,_UDID.stringValue,_IMEI.stringValue,_BUILD_EVENT.stringValue,_BUILD_MATRIX_CONFIG.stringValue,_S_BUILD.stringValue,_CG_SN.stringValue,_MESA_MODULE_SN.stringValue,_MPN.stringValue,_REGION_CODE.stringValue,_UNIT.stringValue,_ROMEO_SN.stringValue,_ROSALINE_SN.stringValue,_SAVAGE_SN.stringValue,_JULIET_SN.stringValue,_PRODUCTION_SOC.stringValue];
        
        const uint8_t *rowString = (const uint8_t *)[row cStringUsingEncoding:NSUTF8StringEncoding];
        NSInteger rowLength = [row lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
        NSInteger result = [output write:rowString maxLength:rowLength];
        if (result <= 0) {
            NSLog(@"无法写入内容");
        }
        
        [output close];
    }
}


-(void)writeToCsv{
    
    if(![fileMa fileExistsAtPath:@"fdr.csv"]){
        
        if([[NSFileManager defaultManager] createFileAtPath:@"./fdr.csv" contents:nil attributes:nil]){
            NSLog(@"OK");
        }
        
        if([[NSFileManager defaultManager] fileExistsAtPath:csvPath]){
            NSLog(@"yesok");
        }
        
        output = [[NSOutputStream alloc] initToFileAtPath:csvPath append:YES];
        
        [output open];
        
        NSString *header = @"SN,MLBSN,BB_SNUM,CHIPID,CHIPVER,ECID,NANDCS,WIFI,BT,EOUSB,UDID,IMEI,BUILD_EVENT,BUILD_MATRIX_CONFIG,S_BUILD,CG_SN,MESA_MODULE_SN,MPN,REGION_CODE,UNIT,ROMEO_SN,ROSALINE_SN,SAVAGE_SN,JULIET_SN,PRODUCTION_SOC\n";
        
        const uint8_t *headerString = (const uint8_t *)[header cStringUsingEncoding:NSUTF8StringEncoding];
        NSInteger headerLength = [header lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
        NSInteger result = [output write:headerString maxLength:headerLength];
        if (result <= 0) {
            NSLog(@"写入错误");
        }
        
        [output close];
    }
    
    //判断是否fdr.csv文件中的SN
    if([fileMa fileExistsAtPath:@"fdr.csv"]){
        
        
        NSString *fileContent = [NSString stringWithContentsOfFile:@"fdr.csv" encoding:NSUTF8StringEncoding error:nil];
        NSLog(@"fileContent: %@", fileContent);
        id  tempStr = [fileContent componentsSeparatedByString:@"\r\n"];
        NSLog(@"tempStr: %@", tempStr);
        
        
        CSVSNArr=[[NSMutableArray alloc]init];
        
        [CSVSNArr removeAllObjects];
        
        FILE *fp=fopen([csvPath UTF8String], "r");
        if (fp) {
            char buf[BUFSIZ];
            fgets(buf, BUFSIZ, fp);
            while (!feof(fp)) {
                char buf[BUFSIZ];
                fgets(buf, BUFSIZ, fp);
                
                // 处理文本信息 转化 成 数组文件
                
                NSString *s=[[NSString alloc]initWithUTF8String:(const char *)buf];
                
                if([s isEqual:[NSNull null]] || s == nil){
                    CSVSNArr = NULL;
                    
                }else{
                    
                    NSString *ss=[s stringByReplacingOccurrencesOfString:@"\r" withString:@""];
                    
                    ss=[ss stringByReplacingOccurrencesOfString:@"\n" withString:@""];
                    
                    NSArray *a=[ss componentsSeparatedByString:@","];
                    
                    [CSVSNArr addObject:a[0]];
                }
            }
            NSLog(@"CSVSNArr: %@", CSVSNArr);
        }
    }
    
    if(![CSVSNArr containsObject:self.SNInfoField.stringValue]){
        
        NSLog(@"YES");
        output = [[NSOutputStream alloc] initToFileAtPath:csvPath append:YES];
        
        [output open];
        
        NSString *row = [NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@\n",_SNInfoField.stringValue,_MLBSN.stringValue,_BB_SNUM.stringValue,_CHIPID.stringValue,_CHIPVER.stringValue,_ECID.stringValue,_NANDCS.stringValue,_WIFI.stringValue,_BT.stringValue,_EOUSB.stringValue,_UDID.stringValue,_IMEI.stringValue,_BUILD_EVENT.stringValue,_BUILD_MATRIX_CONFIG.stringValue,_S_BUILD.stringValue,_CG_SN.stringValue,_MESA_MODULE_SN.stringValue,_MPN.stringValue,_REGION_CODE.stringValue,_UNIT.stringValue,_ROMEO_SN.stringValue,_ROSALINE_SN.stringValue,_SAVAGE_SN.stringValue,_JULIET_SN.stringValue,_PRODUCTION_SOC.stringValue];

        const uint8_t *rowString = (const uint8_t *)[row cStringUsingEncoding:NSUTF8StringEncoding];
        NSInteger rowLength = [row lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
        NSInteger result = [output write:rowString maxLength:rowLength];
        if (result <= 0) {
            NSLog(@"无法写入内容");
        }
        
        [output close];
    }
}


-(void)SNRecView{
    
    self.QGlobalLb.stringValue = @"SN Record";
    self.QDefaultField.hidden = YES;
    self.QGlobalLb.hidden = NO;
    self.SNRecBn.hidden = NO;
    self.SNRecField.hidden = NO;
    self.SNInfoBn.hidden = YES;
    self.SNInfoField.hidden = YES;
    self.mlbRecBn.hidden = YES;
    self.mlbRecField.hidden = YES;
    self.mlbInfoBn.hidden = YES;
    self.mlbInfoField.hidden = YES;
    self.csvTxtPath.hidden = YES;
    self.amountCsvBn.hidden = YES;
    self.csvNameField.hidden = YES;
    self.amountMLBcsvBn.hidden = YES;
}

-(void)SNInfoView{

    self.QGlobalLb.stringValue = @"SN Info";
    self.QDefaultField.hidden = YES;
    self.QGlobalLb.hidden = NO;
    self.SNRecBn.hidden = YES;
    self.SNRecField.hidden = YES;
    self.SNInfoBn.hidden = NO;
    self.SNInfoField.hidden = NO;
    self.mlbRecBn.hidden = YES;
    self.mlbRecField.hidden = YES;
    self.mlbInfoBn.hidden = YES;
    self.mlbInfoField.hidden = YES;
    self.csvTxtPath.hidden = YES;
    self.amountCsvBn.hidden = YES;
    self.csvNameField.hidden = YES;
    self.amountMLBcsvBn.hidden = YES;
}

-(void)mlbRecView{
    
    self.QGlobalLb.stringValue = @"MLB Record";
    
    self.QDefaultField.hidden = YES;
    self.QGlobalLb.hidden = NO;
    
    self.SNRecBn.hidden = YES;

    self.SNRecField.hidden = YES;
    
    self.SNInfoBn.hidden = YES;

    self.SNInfoField.hidden = YES;
    
    self.mlbRecBn.hidden = NO;

    self.mlbRecField.hidden = NO;
    
    self.mlbInfoBn.hidden = YES;

    self.mlbInfoField.hidden = YES;
    
    self.csvTxtPath.hidden = YES;
    
    self.amountCsvBn.hidden = YES;
    
    self.csvNameField.hidden = YES;
    
    self.amountMLBcsvBn.hidden = YES;
    
}


-(void)mlbInfoView{
    self.QGlobalLb.stringValue = @"MLB Info";
    self.QDefaultField.hidden = YES;
    self.QGlobalLb.hidden = NO;
    self.SNRecBn.hidden = YES;
    self.SNRecField.hidden = YES;
    self.SNInfoBn.hidden = YES;
    self.SNInfoField.hidden = YES;
    self.mlbRecBn.hidden = YES;
    self.mlbRecField.hidden = YES;
    self.mlbInfoBn.hidden = NO;
    self.mlbInfoField.hidden = NO;
    self.csvTxtPath.hidden = YES;
    self.amountCsvBn.hidden = YES;
    self.csvNameField.hidden = YES;
    self.amountMLBcsvBn.hidden = YES;
}

-(void)amountCreateCSView{
    
    self.QGlobalLb.stringValue = @"Amount Create CSV";
    self.QDefaultField.hidden = YES;
    self.QGlobalLb.hidden = NO;
    self.SNRecBn.hidden = YES;
    self.SNRecField.hidden = YES;
    self.SNInfoBn.hidden = YES;
    self.SNInfoField.hidden = YES;
    self.mlbRecBn.hidden = YES;
    self.mlbRecField.hidden = YES;
    self.mlbInfoBn.hidden = YES;
    self.mlbInfoField.hidden = YES;
    self.csvTxtPath.hidden = NO;
    self.amountCsvBn.hidden = NO;
    self.csvNameField.hidden = NO;
    self.amountMLBcsvBn.hidden = YES;
}

-(void)amountCreateMLBCSView{
    
    self.QGlobalLb.stringValue = @"Amount Create MLB CSV";
    self.QDefaultField.hidden = YES;
    self.QGlobalLb.hidden = NO;
    self.SNRecBn.hidden = YES;
    self.SNRecField.hidden = YES;
    self.SNInfoBn.hidden = YES;
    self.SNInfoField.hidden = YES;
    self.mlbRecBn.hidden = YES;
    self.mlbRecField.hidden = YES;
    self.mlbInfoBn.hidden = YES;
    self.mlbInfoField.hidden = YES;
    self.csvTxtPath.hidden = NO;
    self.amountCsvBn.hidden = YES;
    self.csvNameField.hidden = NO;
    self.amountMLBcsvBn.hidden = NO;
}

- (IBAction)searchCSVPath:(id)sender {
    
    NSOpenPanel *panel = [NSOpenPanel openPanel];
    [panel setMessage:@""];
    [panel setPrompt:@"OK"];
    [panel setCanChooseDirectories:YES];
    [panel setCanCreateDirectories:YES];
    [panel setCanChooseFiles:YES];
    
    NSInteger result = [panel runModal];
    if (result == NSFileHandlingPanelOKButton)
    {
        txtPath = [[panel URL] path];
        NSLog(@"path_all: %@",txtPath);
        QCRView.string = txtPath;
    }
}



- (IBAction)amountMLBCSV:(id)sender {
    
    isSNInfo = TRUE;
    NSString *txtContent = [NSString stringWithContentsOfFile:txtPath encoding:NSUTF8StringEncoding error:NULL];
    NSLog(@"txtContent: %@", txtContent);
    if([txtContent isEqualToString:@""]||[self.csvNameField.stringValue isEqualTo:@""]){
        
        QCRView.string = @"txt文件 or csvName不能为空";
        return;
    }
    
    snArr = [txtContent componentsSeparatedByString:@","];
    NSLog(@"snArr: %@", snArr);
    
    for (int i = 0; i<snArr.count; i++) {
        
        QCRTask = [[NSTask alloc] init];
        
        [QCRTask setLaunchPath:@"/bin/bash"];
        
        NSArray *arguments = [NSArray arrayWithObjects:qcrToolPath, QCRAccount,@"info",snArr[i], nil];
        
        NSLog(@"arguments:%@", arguments);
        
        [QCRTask setArguments:arguments];
        NSPipe *pipe = [NSPipe pipe];
        [QCRTask setStandardOutput:pipe];
        NSFileHandle *file = [pipe fileHandleForReading];
        [QCRTask launch];
        NSData *data = [file readDataToEndOfFile];
        NSMutableString *string = [[NSMutableString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"string: %@", string);
        QCRView.string= string;
        
        [self getSNinfo];
        
        if(![fileMa fileExistsAtPath:self.csvNameField.stringValue]){
            NSString *csvPath = [NSString stringWithFormat:@"./%@", self.csvNameField.stringValue];            if([[NSFileManager defaultManager] createFileAtPath:csvPath contents:nil attributes:nil]){
                NSLog(@"OK");
            }
            
            if([[NSFileManager defaultManager] fileExistsAtPath:csvPath]){
                NSLog(@"yesok");
            }
            
            output = [[NSOutputStream alloc] initToFileAtPath:csvPath append:YES];
            [output open];
            NSString *header = @"MLBSN,BB_SNUM,CHIPID,CHIPVER,ECID,NANDCS,WIFI,BT,EOUSB,UDID,IMEI,BUILD_EVENT,BUILD_MATRIX_CONFIG,S_BUILD,CG_SN,MESA_MODULE_SN,MPN,REGION_CODE,UNIT,ROMEO_SN,ROSALINE_SN,SAVAGE_SN,JULIET_SN,PRODUCTION_SOC\n";
            
            const uint8_t *headerString = (const uint8_t *)[header cStringUsingEncoding:NSUTF8StringEncoding];
            NSInteger headerLength = [header lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
            NSInteger result = [output write:headerString maxLength:headerLength];
            if (result <= 0) {
                NSLog(@"写入错误");
            }
            [output close];
        }
        
        //写入csv文件
        NSString *csvPath = [NSString stringWithFormat:@"./%@", self.csvNameField.stringValue];
        output = [[NSOutputStream alloc] initToFileAtPath:csvPath append:YES];
        [output open];
        
        NSString *row = [NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@\n",snArr[i],qcrPatternArr[1],qcrPatternArr[2],qcrPatternArr[3],qcrPatternArr[4],qcrPatternArr[5],qcrPatternArr[6],qcrPatternArr[7],qcrPatternArr[8],qcrPatternArr[9],qcrPatternArr[10],qcrPatternArr[11],qcrPatternArr[12],qcrPatternArr[13],qcrPatternArr[14],qcrPatternArr[15],qcrPatternArr[16],qcrPatternArr[17],qcrPatternArr[18],qcrPatternArr[19],qcrPatternArr[20],qcrPatternArr[21],qcrPatternArr[22],qcrPatternArr[23]];
        
        const uint8_t *rowString = (const uint8_t *)[row cStringUsingEncoding:NSUTF8StringEncoding];
        NSInteger rowLength = [row lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
        NSInteger result = [output write:rowString maxLength:rowLength];
        if (result <= 0) {
            NSLog(@"无法写入内容");
        }
        [output close];
    }
}
@end
