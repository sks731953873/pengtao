//
//  FDRSealWindowController.h
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016 108. All rights reserved.
//

//#import <Cocoa/Cocoa.h>
//
//
//
//@interface FDRSealWindowController : NSWindowController{
//    
//    NSTask *FDRTask;
//    NSPipe *FDRPipe;
//}
//
//
//@property (strong) IBOutlet NSView *FDRSealView;
//
//@property (strong) IBOutlet NSButton *submitBn;
//
//@property (nonatomic, retain) IBOutlet NSButton *fdrLeftBn;
//
//@property (nonatomic, retain) IBOutlet NSTextField *SNField;
//
//@property (nonatomic, copy) NSMutableArray *patternArr;
//
///*
//@property (nonatomic, retain) IBOutlet NSTextField *MLBSNField;
//@property (nonatomic, retain) IBOutlet NSTextField *Config;
//@property (nonatomic, retain) IBOutlet NSTextField *regionCode;
//@property (nonatomic, retain) IBOutlet NSTextField *UnitNo;
//@property (nonatomic, retain) IBOutlet NSTextField *imei;
//@property (nonatomic, retain) IBOutlet NSTextField *BuildStage;
//@property (nonatomic, retain) IBOutlet NSTextField *WIFI_MAC_ADDR;
//@property (nonatomic, retain) IBOutlet NSTextField *chipVer;
//@property (nonatomic, retain) IBOutlet NSTextField *ecid;
//@property (nonatomic, retain) IBOutlet NSTextField *nandcs;
//@property (nonatomic, retain) IBOutlet NSTextField *BT_MAC_ADDR;
//@property (nonatomic, retain) IBOutlet NSTextField *chipId;
//@property (nonatomic, retain) IBOutlet NSTextField *eousbMacAddr;
//@property (nonatomic, retain) IBOutlet NSTextField *BBSum;
//@property (nonatomic, retain) IBOutlet NSTextField *RosalineSN;
//@property (nonatomic, retain) IBOutlet NSTextField *RomeoSN;
//@property (nonatomic, retain) IBOutlet NSTextField *savageSN;
//@property (nonatomic, retain) IBOutlet NSTextField *julietSN;
//@property (nonatomic, retain) IBOutlet NSTextField *MPN;
//@property (nonatomic, retain) IBOutlet NSTextField *UDID;
//@property (nonatomic, retain) IBOutlet NSTextField *S_BUILD;
//@property (nonatomic, retain) IBOutlet NSTextField *MESA_MODULE_SN;
//@property (nonatomic, retain) IBOutlet NSTextField *CG_SN;
//@property (nonatomic, retain) IBOutlet NSTextField *PRODUCTION_SOC;
//*/
//
//
//
// 
//@property (nonatomic, strong) IBOutlet NSTextField *searchField;
//
//
//@property (nonatomic, strong) IBOutlet NSScrollView *fdrDisplay;
//
//
//@property (nonatomic, copy) NSMutableArray *result;
//
//
//- (IBAction)backToUMWindow:(id)sender;
//
//- (IBAction)checkIn:(id)sender;
//
//
//
//- (IBAction)search:(id)sender;
//
//
//@end
