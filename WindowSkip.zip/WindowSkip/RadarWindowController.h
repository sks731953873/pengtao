//
//  ThirdWindowController.h
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016 108. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import <string.h>
#import <unistd.h>
#import <stdlib.h>
#import <sys/types.h>
#import <sys/socket.h>
#import <sys/ioctl.h>
#import <net/if.h>
#import <netinet/in.h>
#import <arpa/inet.h>
#import <netdb.h>
#import "RadarTool.h"

@interface RadarWindowController : NSWindowController{
    
//    NSTask *task;
//    NSPipe *pipe;
    
}

//引入radarTool
@property(nonatomic ,strong)RadarTool *toolTask;



@property (strong) IBOutlet NSView *radarView;

@property (strong) IBOutlet NSButton *radarLeftBn;


@property (nonatomic, retain) IBOutlet NSTextField *TitileInfo;

- (IBAction)backToUM:(id)sender;

@property (nonatomic, retain) IBOutlet NSPopUpButton *itemChoice;


//變量label
@property (strong) IBOutlet NSTextField *globalLb;
@property (nonatomic, retain) IBOutlet NSTextField *defaultField1;

//上传radar相关文件
@property (strong) IBOutlet NSTextField *radarNum;

@property (nonatomic, retain) IBOutlet NSButton *bn;
- (IBAction)searchFilePath:(id)sender;
@property (strong) IBOutlet NSButton *searchFilePathBn;




//删除radar相关文件
@property (strong) IBOutlet NSTextField *radarNumDelete;
@property (strong) IBOutlet NSTextField *fileNameDelete;
@property (nonatomic, retain) IBOutlet NSButton *bnDelete;


//download file
@property (strong) IBOutlet NSTextField *radarNumDL;
@property (strong) IBOutlet NSTextField *filenameDL;
@property (strong) IBOutlet NSButton *bnDL;

//search file
@property (strong) IBOutlet NSButton *savePathBn;
- (IBAction)savePath:(id)sender;


//list radar
@property (nonatomic, retain) IBOutlet NSTextField *radarNumList;
@property (nonatomic, retain) IBOutlet NSButton *bnList;



//更新雷达相关内容
@property (nonatomic, retain) IBOutlet NSTextField *radarNumUpdate;
//@property (nonatomic, retain) IBOutlet NSTextField *requestFileUpdate;
@property (strong) IBOutlet NSButton *updateBn;

//雷达info
@property (nonatomic, retain) IBOutlet NSTextField *radarNumInfo;
@property (nonatomic, retain) IBOutlet NSButton *infoBn;


//关联雷达
@property (nonatomic, retain) IBOutlet NSTextField *radarNumRelated;
@property (nonatomic, retain) IBOutlet NSButton *relatedBn;


// get CC邮件
@property (nonatomic, retain) IBOutlet NSTextField *radarNumCC;
@property (strong) IBOutlet NSButton *CCBn;

//set CC邮件
@property (nonatomic, retain) IBOutlet NSTextField *radarNumSetCC;
@property (nonatomic, retain) IBOutlet NSButton *setCCBn;


//pickerTimer
@property (strong) IBOutlet NSDatePicker *beginTimePicker;
@property (strong) IBOutlet NSDatePicker *endTimePicker;


//searchByTitle & searchByDate
@property (strong) IBOutlet NSTextField *searchByTitleField;
@property (nonatomic, retain) IBOutlet NSButton *searchByTitleBn;
@property (strong) IBOutlet NSButton *searchByDateBn;


//time

@property (strong) IBOutlet NSDatePickerCell *beginTime;
@property (strong) IBOutlet NSDateFormatter *beginTimeFomattor;

@property (strong) IBOutlet NSDatePickerCell *endTime;
@property (strong) IBOutlet NSDateFormatter *endTimeFomattor;

//find people

@property (strong) IBOutlet NSTextField *firstNameField;
@property (strong) IBOutlet NSTextField *lastNameField;
@property (strong) IBOutlet NSButton *findPeopleBn;

//check
@property (strong) IBOutlet NSButton *getCC;
@property (strong) IBOutlet NSButton *setCC;
@property (strong) IBOutlet NSButton *delCC;

//find_component_version
@property (strong) IBOutlet NSTextField *findComVerField;
@property (strong) IBOutlet NSButton *findComVerBn;

//find_component_name
@property (strong) IBOutlet NSTextField *findComNameField;
@property (strong) IBOutlet NSButton *findComNameBn;


//find_component_name_version
@property (strong) IBOutlet NSTextField *findNameField;
@property (strong) IBOutlet NSTextField *findVersionField;
@property (strong) IBOutlet NSButton *findComNameVerBn;

//creat radar
@property (strong) IBOutlet NSPopUpButton *component;
@property (strong) IBOutlet NSPopUpButton *version;
@property (strong) IBOutlet NSPopUpButton *reproducible;
- (IBAction)getRadarTxt:(id)sender;
@property (strong) IBOutlet NSButton *getRadarTxtBn;
@property (strong) IBOutlet NSPopUpButton *classification;
@property (strong) IBOutlet NSButton *createRadarBn;



//滚动条显示
@property (nonatomic, retain) IBOutlet NSScrollView *RecvInfo;



- (IBAction)RclickChoice:(id)sender;
- (IBAction)sendUpload:(id)sender;
- (IBAction)sendDelete:(id)sender;
- (IBAction)sendUpdate:(id)sender;
- (IBAction)sendRelated:(id)sender;
- (IBAction)sendCC:(id)sender;
- (IBAction)sendSetCC:(id)sender;
- (IBAction)sendInfo:(id)sender;
- (IBAction)sendList:(id)sender;
- (IBAction)sendDL:(id)sender;
- (IBAction)searchByTitleSend:(id)sender;
- (IBAction)searchByDateSend:(id)sender;
- (IBAction)findPeopleSend:(id)sender;
- (IBAction)findComVerSend:(id)sender;
- (IBAction)findComNameBn:(id)sender;
- (IBAction)findComNameVerSend:(id)sender;
- (IBAction)createRadar:(id)sender;





@end
