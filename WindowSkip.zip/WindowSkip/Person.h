//
//  Person.h
//  WindowSkip
//
//  Created by gdadmin on 1/14/17.
//  Copyright © 2017 108. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject{
    NSString *personName;
    NSString *checkState;
    NSString *passWord;
    
}

@property (readwrite, copy) NSString* personName;
@property (readwrite, copy) NSString* passWord;
@property (readwrite, copy) NSString* checkState;



@end
