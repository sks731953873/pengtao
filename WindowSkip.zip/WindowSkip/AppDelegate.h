//
//  AppDelegate.h
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016年 108. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "MainWindowController.h"
#import "UMWindowController.h"

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (strong) MainWindowController *mainWindow;



@end

