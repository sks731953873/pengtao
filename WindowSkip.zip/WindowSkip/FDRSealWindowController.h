//
//  SearchWindowController.h
//  WindowSkip
//
//  Created by gdadmin on 2/9/17.
//  Copyright © 2017 108. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DBManager.h"
#import "CheckQCRTool.h"


@interface FDRSealWindowController : NSWindowController<NSTableViewDataSource, NSTabViewDelegate>{
    
    NSMutableArray *Persons;
    
    NSTask *radarUploadTask;
    NSPipe *radarUploadPipe;
    
    NSMatrix *excelFormat;
}

@property(nonatomic, strong)CheckQCRTool *checkQCRTool;

@property(nonatomic , strong)NSMutableArray *argument;
@property(nonatomic , strong)NSMutableArray *result;

@property(nonatomic, copy)NSArray *SNArgu;
@property(nonatomic, copy)NSString *SN;


- (IBAction)backToUM:(id)sender;

@property (strong) IBOutlet NSButton *searchLftBn;


//Get apple info
@property (strong) IBOutlet NSTextField *UploadLb;


//调整window尺寸大小
@property (strong, readwrite) IBOutlet NSWindow *windowSize;


//LocalDB Field
@property (strong) IBOutlet NSTextField *FGSN;
@property (strong) IBOutlet NSTextField *Config;
@property (strong) IBOutlet NSTextField *MLBSN;
@property (strong) IBOutlet NSTextField *FailureSymptom;
@property (strong) IBOutlet NSTextField *FailStation;
@property (strong) IBOutlet NSTextField *Date;
@property (strong) IBOutlet NSPopUpButton *team;
@property (strong) IBOutlet NSScrollView *remarkScroll;

//RadarDB Field
@property (strong) IBOutlet NSTextField *Unit;
@property (strong) IBOutlet NSTextField *RadarNo;
@property (strong) IBOutlet NSTextField *HHDRI;
@property (strong) IBOutlet NSTextField *FADRI;
@property (strong) IBOutlet NSTextField *APPLEDRI;
@property (strong) IBOutlet NSTextField *F1Approve;
@property (strong) IBOutlet NSTextField *AppleGroup;

//localDB label
@property (strong) IBOutlet NSTextField *FGSNLb;
@property (strong) IBOutlet NSTextField *ConfigLb;
@property (strong) IBOutlet NSTextField *mlbSNLb;
@property (strong) IBOutlet NSTextField *FailureLb;
@property (strong) IBOutlet NSTextField *FSLb;
@property (strong) IBOutlet NSTextField *dateLb;
@property (strong) IBOutlet NSTextField *remarkLb;
@property (strong) IBOutlet NSTextField *teamLb;

//RadarDB label
@property (strong) IBOutlet NSTextField *UnitLb;
@property (strong) IBOutlet NSTextField *RadarNoLb;
@property (strong) IBOutlet NSTextField *HHDRILb;
@property (strong) IBOutlet NSTextField *FADRILb;
@property (strong) IBOutlet NSTextField *AppleDriLb;
@property (strong) IBOutlet NSTextField *F1ApproveLb;
@property (strong) IBOutlet NSTextField *AppleGroupLb;

//writeToRadarDB
@property (strong) IBOutlet NSButton *writeToRadarDBn;
- (IBAction)writeSingleToRadarDB:(id)sender;

//
- (IBAction)GetAppDri:(id)sender;
@property (strong) IBOutlet NSButton *GetAppDriBn;


//teamToChoose
- (IBAction)teamToChoose:(id)sender;

//writeToLocalDB
- (IBAction)writeLocalDB:(id)sender;
@property (strong) IBOutlet NSButton *writeLocalDBn;

//txtDisplay
@property (strong) IBOutlet NSScrollView *uploadRadarDisplay;


//gloabal label
@property (strong) IBOutlet NSTextField *gloabalLb;




//fdrchooseItem
@property (strong) IBOutlet NSPopUpButton *fdrItemChoose;
- (IBAction)fdrChooseItem:(id)sender;

//searchRadarDatabase
- (IBAction)searchRadarDB:(id)sender;
@property (strong) IBOutlet NSTextField *searchDB;
@property (strong) IBOutlet NSButton *seachRadarDB;

//searchLocalSNDatabase
@property (strong) IBOutlet NSTextField *searchLocalDBField;
@property (strong) IBOutlet NSButton *searchLocalSNBn;
- (IBAction)searchLocalSN:(id)sender;

@property (strong) IBOutlet NSTextField *currentDate;

//CheckIn
@property (strong) IBOutlet NSTextField *checkInSM;
@property (strong) IBOutlet NSButton *checkInBn;
- (IBAction)checkIn:(id)sender;

//SingleWriteToRadarDB
@property (strong) IBOutlet NSTextField *singleWriteRadarDBField;
@property (strong) IBOutlet NSButton *SingleWriteToRadarDBn;
- (IBAction)SingleWriteToRadarDB:(id)sender;


//radarBeginTime
@property (strong) IBOutlet NSDatePicker *radarBeginTime;
@property (strong) IBOutlet NSDateFormatter *radarBeginFormatter;

//radarEndTime
@property (strong) IBOutlet NSDatePicker *radarEndTime;
@property (strong) IBOutlet NSDateFormatter *radarEndFormatter;
@property (strong) IBOutlet NSButton *searchRadaByTimeBn;
- (IBAction)searchRadarDByTime:(id)sender;


//search localDB by time
@property (strong) IBOutlet NSButton *searchLocalDByTimeBn;
- (IBAction)searchLocalDByTime:(id)sender;


@property (nonatomic,strong) DBManager *dbManager;



//read sheet
@property (strong) IBOutlet NSButton *readExcelBn;
- (IBAction)readExcel:(id)sender;


//write new sheet
@property (strong) IBOutlet NSButton *writeExcelBn;
- (IBAction)writeToExcel:(id)sender;


//get path
- (IBAction)getPath:(id)sender;
@property (strong) IBOutlet NSButton *getPathBn;

@property(nonatomic, strong)NSMutableArray *SumArr;

//write sheet
@property (strong) IBOutlet NSDateFormatter *time;


@end
