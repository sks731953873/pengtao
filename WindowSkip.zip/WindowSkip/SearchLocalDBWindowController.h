//
//  SearchLocalDB.h
//  WindowSkip
//
//  Created by gdadmin on 2/28/17.
//  Copyright © 2017 108. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DBManager.h"

@interface SearchLocalDBWindowController : NSWindowController<NSTableViewDelegate, NSTableViewDataSource>{
    
    IBOutlet NSTableView *searchLocalDBTV;
    
}

@property (strong) IBOutlet NSTextField *searchLocalDBTitle;


//
@property(nonatomic, strong)NSMutableArray *items;
@property(nonatomic, strong)NSMutableArray *SNs;
@property(nonatomic, strong)NSMutableArray *Configs;
@property(nonatomic, strong)NSMutableArray *MLBSNs;
@property(nonatomic, strong)NSMutableArray *failStations;
@property(nonatomic, strong)NSMutableArray *failureSymptoms;
@property(nonatomic, strong)NSMutableArray *faDris;
@property(nonatomic, strong)NSMutableArray *Dates;
@property(nonatomic, strong)NSMutableArray *remarks;
@property(nonatomic, strong)NSMutableArray *teams;


//data convert
@property(nonatomic, copy)NSArray *searchLocalArr;

//back to fdrseal
@property (strong) IBOutlet NSButton *backToFdrView;

@property (strong) IBOutlet NSScrollView *scrollTableView;



- (IBAction)backToFDRWindow:(id)sender;

@property (strong) IBOutlet NSTextField *searchLocalDBLog;
- (IBAction)deleteLocalDBItem:(id)sender;

//
@property(nonatomic, strong) NSMutableArray *localDBValueArr;

@property(nonatomic, strong)DBManager *dbManager;


@property (strong) IBOutlet NSPopUpButton *itemToChoice;

//get excel path
@property (strong) IBOutlet NSButton *excelPathBn;
- (IBAction)getExcelPath:(id)sender;

//write to Specify excel
- (IBAction)writeToSpecifyExcel:(id)sender;
@property (strong) IBOutlet NSButton *WTSEBn;

//write to single excel
- (IBAction)writeToSingleExcel:(id)sender;
@property (strong) IBOutlet NSButton *writeToSingleExcelBn;


@end
