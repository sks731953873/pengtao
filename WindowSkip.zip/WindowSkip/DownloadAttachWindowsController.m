//
//  DownloadAttachWindowsController.m
//  WindowSkip
//
//  Created by gdadmin on 4/17/17.
//  Copyright © 2017 108. All rights reserved.
//

#import "DownloadAttachWindowsController.h"
#import "SearchRadarDBWindowController.h"
#import "RadarTool.h"
#import "PlistTool.h"
#import "FileTool.h"
#import "SSZipArchive.h"

@interface DownloadAttachWindowsController ()

@property(strong) SearchRadarDBWindowController *SearchRadarDBWindow;

@end

@implementation DownloadAttachWindowsController{
    
    PlistTool *plistHandler;
    FileTool *fileHandler;
    NSString* sandBox;
    NSString *d21MlbDir;
    NSString *d22MlbDir;
    NSString *d21FATPDir;
    NSString *d22FATPDir;
    
    //只建一个文件夹
    NSString* downloadDirectory;
}

- (void)windowDidLoad {
    
    [super windowDidLoad];
    
    plistHandler = [PlistTool instance];
    fileHandler = [FileTool instance];
    
    //沙河路径
    NSArray* path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    sandBox = [path objectAtIndex:0];
    
    
    //新建四个文件夹, 作为参考
    d21MlbDir = [sandBox stringByAppendingPathComponent:@"D21_MLB"];
    d22MlbDir = [sandBox stringByAppendingPathComponent:@"D22_MLB"];
    d21FATPDir = [sandBox stringByAppendingPathComponent:@"D21_FATP"];
    d22FATPDir = [sandBox stringByAppendingPathComponent:@"D22_FATP"];
    
    downloadDirectory = [sandBox stringByAppendingPathComponent:@"downloadDirectory"];
    
    BOOL isD21MlbDir = [fileHandler createDirectory:d21MlbDir];
    BOOL isD22MlbDir = [fileHandler createDirectory:d22MlbDir];
    BOOL isD21FATPDir = [fileHandler createDirectory:d21FATPDir];
    BOOL is22FATPDir = [fileHandler createDirectory:d22FATPDir];
    
    //只建一个文件夹
    
    BOOL isDownloadDirectory =[fileHandler createDirectory:downloadDirectory];


    
    NSLog(@"isDir: %d, %d, %d, %d, %d", isD21MlbDir, isD22MlbDir, isD21FATPDir, is22FATPDir, isDownloadDirectory);
}



-(NSArray* )getFdrData{
    
    NSString *config = [[NSBundle mainBundle] pathForResource:@"config" ofType:@"plist"];
    NSDictionary *configDic = [NSDictionary dictionaryWithContentsOfFile:config];
    NSDictionary *secondDic = [plistHandler valueForKey:@"FDRSeal" inDictionary:configDic recursion:YES];
    
    if([secondDic respondsToSelector:@selector(objectForKey:)]){
        
        NSEnumerator *enumerator = [secondDic keyEnumerator];
        NSString *str;
        while (str = [enumerator nextObject]) {
            
            if([_firstItem.stringValue isEqualToString:@"1"]&&[str isEqualToString:_firstItem.title]){
                
                id radarNo = [plistHandler valueForKey:_firstItem.title inDictionary:secondDic recursion:NO];
                NSArray *arr = [NSArray arrayWithObjects:radarNo, str, nil];
                
                return arr;
            }else if([_secondItem.stringValue isEqualToString:@"1"]&&[str isEqualToString:_secondItem.title]){
            
                id radarNo = [plistHandler valueForKey:_secondItem.title inDictionary:secondDic recursion:NO];
                NSArray *arr = [NSArray arrayWithObjects:radarNo, str, nil];
                
                return arr;
            
            }else if([_thirdItem.stringValue isEqualToString:@"1"]&&[str isEqualToString:_thirdItem.title]){
                
                id radarNo = [plistHandler valueForKey:_thirdItem.title inDictionary:secondDic recursion:NO];
                NSArray *arr = [NSArray arrayWithObjects:radarNo, str, nil];
                
                return arr;
            }else if([_fourthItem.stringValue isEqualToString:@"1"]&&[str isEqualToString:_fourthItem.title]){
                
                id radarNo = [plistHandler valueForKey:_fourthItem.title inDictionary:secondDic recursion:NO];
                NSArray *arr = [NSArray arrayWithObjects:radarNo, str, nil];
                return  arr;
                
            }else{
                continue;
            }
        }
    }
    return 0;
}

-(NSArray *)getListAttachments:(NSString*)radarNo{
    
    NSArray *attachArr;
    NSInteger count = 0;
    
    NSArray *arr = [NSArray arrayWithObjects:@"list", radarNo, nil];
    id attachment;
    id attachSize;
    
    while (true) {
        _radarTool = [[RadarTool alloc] initWithArgArr:arr];
        NSString* retAttach = [_radarTool excuteSecondTask];
        NSArray* temp = [retAttach componentsSeparatedByString:@"\n"];
        NSLog(@"temp: %@", temp);

        count++;
        NSLog(@"temp.count: %lu", (unsigned long)temp.count);
        
        if(temp.count>5){
            for (int i = 4; i< temp.count; i++) {
                id temp1 = [[temp[i] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] componentsSeparatedByString:@" "];
                NSLog(@"temp1: %@", temp1);
                if([[temp1[0] pathExtension] isEqualToString:@"xls"]||[[temp1[0] pathExtension] isEqualToString:@"xlsx"]){
                    NSLog(@"hh");
                    attachment = temp1[0];
                    attachSize = temp1[2];
                    break;
                }else{
                    continue;
                }
            }
        }
        
        attachArr = [NSArray arrayWithObjects:attachSize,attachment, nil];
        if(attachArr.count){
            break;
        }else if(count>8){
            break;
        }
    }
    
    NSLog(@"attachArr: %@", attachArr);
    return attachArr;
}

-(void)downloadAttachment{

    NSString* radarNum = [self getFdrData][0];
    
    NSArray* attachList = [self getListAttachments:radarNum];
    
    //分别保存四个不同文件夹
//    NSString *downloadPath = [sandBox stringByAppendingPathComponent:[self getFdrData][1]];
    
    
//    NSString *downloadPath = [sandBox stringByAppendingPathComponent:downloadDirectory];//保存在同一个文件夹
    
    NSString *downloadFile = [downloadDirectory stringByAppendingPathComponent:attachList[1]];
    
    NSArray* arr = [NSArray arrayWithObjects:@"download", radarNum, downloadFile,nil];
    
    NSInteger count = 0;
    
    while (true) {
        
        if(count>5){
            break;
        }
        
        _radarTool = [[RadarTool alloc] initWithArgArr:arr];
        NSString* retStr = [_radarTool excuteSecondTask];
        
        NSLog(@"retStr: %@", retStr);
        
        NSArray* temp = [retStr componentsSeparatedByString:@"\n"];
        NSLog(@"temp: %@", temp);
        
        NSArray* temp1 = [temp[3] componentsSeparatedByString:@" "];
        NSLog(@"temp1: %@", temp1);
        
        NSFileManager* fm = [NSFileManager defaultManager];
        
        if([[temp1 lastObject] isEqualToString:@"success"]&&[fm fileExistsAtPath:downloadFile]){
            
            NSInteger attachSize = [[fm attributesOfItemAtPath:downloadFile error:nil] fileSize];
            //
            if([attachList[0] isEqualToString:[NSString stringWithFormat:@"%ld", (long)attachSize]]){
                NSLog(@"success");
                break;
                
            }else{
                count++;
                continue;
            }
        }else{
            count++;
            continue;
        }
    }

}


-(void)compressFile{
    
    NSString* radarNum = [self getFdrData][0];
    NSArray* attachList = [self getListAttachments:radarNum];
    
    //分别将下载文件保存于四个不同文件夹
//    NSString *downloadPath = [sandBox stringByAppendingPathComponent:[self getFdrData][1]];
    
//    NSString *downloadPath = [sandBox stringByAppendingPathComponent:downloadDirectory];//将文件保存于一个文件夹
    
    NSString *downloadFile = [downloadDirectory stringByAppendingPathComponent:attachList[1]];

    // 1.创建一个zip文件（压缩）
    NSString *zipFile = [downloadDirectory stringByAppendingPathComponent:[attachList[1] stringByAppendingPathExtension:@"zip"]];
    
    NSArray *inputPaths = [NSArray arrayWithObjects:downloadFile,nil];
    
    BOOL temp = [SSZipArchive createZipFileAtPath:zipFile withFilesAtPaths:inputPaths];
    NSLog(@"temp : %d", temp);
}


- (IBAction)downloadAttach:(id)sender {
    
    NSLog(@"choiceItm: %@", _choiceItm.stringValue);
    

//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
    
    dispatch_queue_t concurrentQueue = dispatch_queue_create("helloworld", DISPATCH_QUEUE_CONCURRENT);
    
    dispatch_async(concurrentQueue, ^(void){
        
        NSString* radarNum = [self getFdrData][0];
        NSArray* listArr = [self getListAttachments:radarNum];
        
        NSLog(@"listArr: %@", listArr);
        
        [self downloadAttachment];
        [self compressFile];
    
    
    });
    NSLog(@"jj");
    
    
//    NSLog(@"radarNum:%@\n listArr:%@", radarNum, listArr);
//    if([self jurdgeSuccessNot]){
//        NSLog(@"Success");
//    }else{
//        NSLog(@"Failure");
//    }
//    
//    [self compressFile];
    

}

- (IBAction)notDownload:(id)sender {
    
    NSLog(@"secondItem: %@", _secondItem.title);
    
//    _SearchRadarDBWindow = [[SearchRadarDBWindowController alloc] initWithWindowNibName:@"SearchRadarDBWindowController"];
//    [_SearchRadarDBWindow.window orderFront:nil];
//    [_SearchRadarDBWindow.window center];
    [self.window orderOut:nil];
    
    
}
@end
