//  31601244
//  MainWindowController.m
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016年 108. All rights reserved.
//

#import "MainWindowController.h"
#import "UMWindowController.h"
#import "ConfigWindowController.h"

@interface MainWindowController ()

@property (strong) UMWindowController *UMWindow;
@property (strong) MainWindowController *mainWindow;
@property (strong) ConfigWindowController *configWindow;

@end

@implementation MainWindowController

NSString *loginKey;
NSString *loginValue;
//NSString *filePath;



- (void)windowDidLoad {
    [super windowDidLoad];
    
//    self.incorrectInfo.hidden = YES;
    self.incorrectInfo.stringValue = @"";
    _bgView.wantsLayer = YES;
    _bgView.layer.backgroundColor = CGColorCreateGenericRGB(1.00f, 1.00f, 1.00f, 1.0f);

    
    //UserLoginPw
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *cuDir = [fm currentDirectoryPath];
    
    NSString *filePath = [cuDir stringByAppendingPathComponent:@"config.plist"];
    NSLog(@"filePath:%@", filePath);
    
    
    //由UMWindow转到MainWindow时清除username和password
    self.userName.stringValue = self.clearUseName;
    self.passWord.stringValue = self.clearPassWd;
    
}


- (IBAction)nextToUMWindow:(id)sender {
    
//    if([self.userName.stringValue isEqualToString:loginKey] &&[self.passWord.stringValue isEqualToString:loginValue])
    {
    
        _UMWindow = [[UMWindowController alloc] initWithWindowNibName:@"UMWindowController"];
        //显示需要跳转的窗口
        [_UMWindow.window orderFront:nil];
        //关闭当前窗口
    
        [_UMWindow.window center];
    
        [self.window orderOut:nil];
    }
    /*
    else{
        self.incorrectInfo.hidden = NO;
        self.incorrectInfo.stringValue = @"Incorrect password";
        self.incorrectInfo.font = [NSFont systemFontOfSize:14.0];
        [self.incorrectInfo setTextColor:[NSColor redColor]];
    }
     */
}




@end
