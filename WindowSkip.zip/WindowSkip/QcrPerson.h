//
//  qcrPerson.h
//  WindowSkip
//
//  Created by gdadmin on 2/16/17.
//  Copyright © 2017 108. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QcrPerson : NSObject{
    NSString *qcrPersonName;
    NSString *qcrCheckState;
    NSString *qcrPassWord;

}

@property (readwrite, copy) NSString* qcrPersonName;
@property (readwrite, copy) NSString* qcrPassWord;
@property (readwrite, copy) NSString* qcrCheckState;

@end
