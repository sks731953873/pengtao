//
//  SearchLocalDB.m
//  WindowSkip
//
//  Created by gdadmin on 2/28/17.
//  Copyright © 2017 108. All rights reserved.
//

#import "SearchLocalDBWindowController.h"
#import "FDRSealWindowController.h"
#import <sqlite3.h>
#import "DBManager.h"
//#import "DHxlsReaderMac.h"
#import <DHxls/DHWorkBook.h>

#define ITEM_COUNT 10

@interface SearchLocalDBWindowController ()

@property(strong) FDRSealWindowController *FDRSealWindow;

@end

@implementation SearchLocalDBWindowController{
    
    NSString *searchLocalDBDir;
    NSFileManager *seachLocalDBfm;
    
    NSArray *localKey;
    
    NSUInteger cycleCount;
    
    //sandBox
    NSString *documentsDirectory;
    
    //get filePath
    NSString *excelPath;
    
//    DHxlsReader *reader;
}

- (void)windowDidLoad {
    [super windowDidLoad];
    
    //back button
    [self.backToFdrView setButtonType: NSMomentaryPushInButton];
    [self.backToFdrView setBezelStyle: NSRoundedBezelStyle];
    [self.backToFdrView setBordered: NO];
    [self.backToFdrView setImage: [NSImage imageNamed: @"left_highlighted"]];
    [self.backToFdrView setImagePosition: NSImageOnly];
    [self.backToFdrView setTarget: self];
    
    
    //currentDirectory
    seachLocalDBfm = [NSFileManager defaultManager];
    searchLocalDBDir = [seachLocalDBfm currentDirectoryPath];
    
    //Title
    self.searchLocalDBTitle.textColor=[NSColor blackColor];
    self.searchLocalDBTitle.font=[NSFont fontWithName:@"Helvetica" size:16.0];
    self.searchLocalDBTitle.stringValue= @"searchLocalDBResult";
    
    //log
    self.searchLocalDBLog.stringValue =@"";
    _scrollTableView.contentInsets = NSEdgeInsetsMake(0, 0, 2000, 1700);
    
}

- (IBAction)backToFDRWindow:(id)sender {
    
    _FDRSealWindow = [[FDRSealWindowController alloc] initWithWindowNibName:@"FDRSealWindowController"];
    NSArray *argArr = [NSArray arrayWithObjects:@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"", nil];
    _FDRSealWindow.SNArgu = argArr;
    NSString *argSN = @"";
    _FDRSealWindow.SN = argSN;
    NSString *argDate = @"";
    _FDRSealWindow.Date.stringValue = argDate;
    [_FDRSealWindow.window orderFront:nil];
    [_FDRSealWindow.window center];
    [self.window orderOut:nil];
}


- (IBAction)deleteLocalDBItem:(id)sender {
    // 执行语句
    if([seachLocalDBfm fileExistsAtPath:[self dbPath]]){
        [self deleteRow];
    }
}

-(void)deleteRow{
    
    NSInteger row = [searchLocalDBTV selectedRow];
    NSString *deleteStr = [NSString stringWithFormat:@"delete from local_Info where _id=%ld", (long)[_items[row] integerValue]];
    NSIndexSet *rows = [searchLocalDBTV selectedRowIndexes];
    
    if([rows count] == 0){
        NSBeep();
        return;
    }
    
    
    [_items removeObjectsAtIndexes:rows];
    [_SNs removeObjectsAtIndexes:rows];
    [_Configs removeObjectsAtIndexes:rows];
    [_MLBSNs removeObjectsAtIndexes:rows];
    [_failStations removeObjectsAtIndexes:rows];
    [_failureSymptoms removeObjectsAtIndexes:rows];
    [_Dates removeObjectsAtIndexes:rows];
    [_remarks removeObjectsAtIndexes:rows];
    [_teams removeObjectsAtIndexes:rows];
    
    [self.dbManager executeQuery:deleteStr];
    if (self.dbManager.affectedRows != 0) {
        NSLog(@"Query was executed successfully. Affected rows = %d", self.dbManager.affectedRows);
        self.searchLocalDBLog.stringValue = [NSString stringWithFormat:@"modify was executed successfully. Affected rows = %d", self.dbManager.affectedRows];
    }else{
        self.searchLocalDBLog.stringValue = @"Could not execute the modify.";
        NSLog(@"Could not execute the modify.");
    }
    [_searchLocalDBLog setTextColor:[NSColor redColor]];
    [searchLocalDBTV reloadData];
}


#pragma mark -NSTableViewDataSource

-(void)awakeFromNib{
    
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"DataBase.db"];
    
    _scrollTableView.contentInsets = NSEdgeInsetsMake(0, 0, 2000, 1700);
    
    //将searchArr进行移植
    _items = [NSMutableArray array];
    _SNs = [NSMutableArray array];
    _Configs = [NSMutableArray array];
    _MLBSNs = [NSMutableArray array];
    _failStations = [NSMutableArray array];
    _failureSymptoms = [NSMutableArray array];
    _faDris = [NSMutableArray array];
    _Dates = [NSMutableArray array];
    _remarks = [NSMutableArray array];
    _teams = [NSMutableArray array];
    
    cycleCount = _searchLocalArr.count/ITEM_COUNT;
    
    NSLog(@"_searchLocalArr: %lu", (unsigned long)_searchLocalArr.count);
    
    NSLog(@"cycleCount: %lu", (unsigned long)cycleCount);
    
    for(int i = 0; i< _searchLocalArr.count; i++){
        [_items addObject:_searchLocalArr[i][0]];
        [_SNs addObject:_searchLocalArr[i][1]];
        [_Configs addObject:_searchLocalArr[i][2]];
        [_MLBSNs addObject:_searchLocalArr[i][3]];
        [_failStations addObject:_searchLocalArr[i][4]];
        [_failureSymptoms addObject:_searchLocalArr[i][5]];
        [_faDris addObject:_searchLocalArr[i][6]];
        [_Dates addObject:_searchLocalArr[i][7]];
        [_remarks addObject:_searchLocalArr[i][8]];
        [_teams addObject:_searchLocalArr[i][9]];
    }
}

#pragma mark - Table View Data Source

-(NSInteger)numberOfRowsInTableView:(NSTableView *)tableView{
    
    return _SNs.count;
}

-(id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
   
    if([tableColumn.identifier isEqualTo:@"SN"]){
        NSString *Key = (NSString*)[_SNs objectAtIndex:row];
        return  Key;
    }else if([tableColumn.identifier isEqualTo:@"Config"]){
        NSString *Key = (NSString*)[_Configs objectAtIndex:row];
        return  Key;
    }else if([tableColumn.identifier isEqualTo:@"MLBSN"]){
        NSString *Key = (NSString*)[_MLBSNs objectAtIndex:row];
        return  Key;
    }else if([tableColumn.identifier isEqualTo:@"failStation"]){
        NSString *Key = (NSString*)[_failStations objectAtIndex:row];
        return  Key;
    }else if([tableColumn.identifier isEqualTo:@"failureSymptom"]){
        NSString *Key = (NSString*)[_failureSymptoms objectAtIndex:row];
        return  Key;
    }else if([tableColumn.identifier isEqualTo:@"FADRI"]){
        NSString *Key = (NSString*)[_faDris objectAtIndex:row];
        return  Key;
    }else if([tableColumn.identifier isEqualTo:@"Date"]){
        NSString *Key = (NSString*)[_Dates objectAtIndex:row];
        return  Key;
    }else if([tableColumn.identifier isEqualTo:@"Remark"]){
        NSString *Key = (NSString*)[_remarks objectAtIndex:row];
        return  Key;
    }else if([tableColumn.identifier isEqualTo:@"Team"]){
        NSString *Key = (NSString*)[_teams objectAtIndex:row];
        return  Key;
    }
    return 0;
}


//C39SX03JHNVR
-(void)tableView:(NSTableView*)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    
    NSString *strIdt = [tableColumn identifier];
    
    if([strIdt isEqualToString:@"Config"]){
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.Configs replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.Configs);
        [self excuteParser:row];
    }
    else if([strIdt isEqualToString:@"MLBSN"]){
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.MLBSNs replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.MLBSNs);
        [self excuteParser:row];
    }
    else if([strIdt isEqualToString:@"Team"]){
        
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.teams replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.teams);
        [self excuteParser:row];
        
    }else if([strIdt isEqualToString:@"Date"]){
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.Dates replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.Dates);
        [self excuteParser:row];
        
    }else if([strIdt isEqualToString:@"failStation"]){
        
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.failStations replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.failStations);
       [self excuteParser:row];
        
    }else if([strIdt isEqualToString:@"failureSymptom"]){
        
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.failureSymptoms replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.failureSymptoms);
        [self excuteParser:row];
        
    }else if([strIdt isEqualToString:@"FADRI"]){
        
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.faDris replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.faDris);
        [self excuteParser:row];
        
    }else if([strIdt isEqualToString:@"Remark"]){
        
        NSString *nsT = (NSString*)object;
        NSLog(@"*******%@",nsT);
        [self.remarks replaceObjectAtIndex:row withObject:nsT];
        NSLog(@"self.SNs: %@", self.remarks);
        [self excuteParser:row];
        
    }
}

-(void)excuteParser:(NSInteger)row{
    
    NSString *strParser = [NSString stringWithFormat:@"update local_Info set SN= '%@', Config='%@', MLBSN= '%@', failStation='%@', failureSymptom= '%@', faDri='%@', Date='%@', remark= '%@', team='%@' where _id=%ld", _SNs[row], _Configs[row], _MLBSNs[row], _failStations[row], _failureSymptoms[row],_faDris[row], _Dates[row], _remarks[row],_teams[row], [_items[row] integerValue]];
    [self.dbManager executeQuery:strParser];
    if (self.dbManager.affectedRows != 0) {
        NSLog(@"Query was executed successfully. Affected rows = %d", self.dbManager.affectedRows);
        self.searchLocalDBLog.stringValue = [NSString stringWithFormat:@"modify was executed successfully. Affected rows = %d", self.dbManager.affectedRows];
    }else{
        self.searchLocalDBLog.stringValue = @"Could not execute the modify.";
        NSLog(@"Could not execute the modify.");
    }
    [_searchLocalDBLog setTextColor:[NSColor redColor]];
    [searchLocalDBTV reloadData];
}


-(NSString *)dbPath{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    documentsDirectory = [paths objectAtIndex:0];
    return [NSString stringWithFormat:@"%@/DataBase.db", documentsDirectory];
}

- (IBAction)getExcelPath:(id)sender {
    NSOpenPanel *panel = [NSOpenPanel openPanel];
    [panel setMessage:@""];
    [panel setPrompt:@"OK"];
    [panel setCanChooseDirectories:YES];
    [panel setCanCreateDirectories:YES];
    [panel setCanChooseFiles:YES];
    
    NSInteger result = [panel runModal];
    if (result == NSFileHandlingPanelOKButton)
    {
        excelPath = [[panel URL] path];
        NSLog(@"path_all: %@",excelPath);
        self.searchLocalDBLog.stringValue = excelPath;
    }
}


- (IBAction)writeToSpecifyExcel:(id)sender {
    
    
    

}


- (IBAction)writeToSingleExcel:(id)sender {
    
    [_items removeAllObjects];
    for (int i = 1; i< _SNs.count+1; i++) {
        [_items addObject:[NSString stringWithFormat:@"%d", i]];
    }
    
    NSMutableArray *temp = [NSMutableArray arrayWithObjects:_items, _SNs, _Configs, _MLBSNs, _teams, _failStations, _failureSymptoms, _Dates, _remarks, nil];
    
    NSLog(@"temp:%@", temp);
    
    DHCell				*cell;
    DHWorkBook *dhWB = [DHWorkBook new];
    DHWorkSheet *dhWS = [dhWB workSheetWithName:@"SHEET1"];
    

    [dhWS height:500 row:0 format:NULL];

    [dhWS width:5000 col:1 format:NULL];
    [dhWS width:5000 col:2 format:NULL];
    [dhWS width:5000 col:3 format:NULL];
    [dhWS width:5000 col:4 format:NULL];
    
    
    cell = [dhWS label:@"Item" row:0 col:0];
    cell = [dhWS label:@"SN" row:0 col:1];
    cell = [dhWS label:@"Config" row:0 col:2];
    cell = [dhWS label:@"MLBSN" row:0 col:3];
    cell = [dhWS label:@"Team" row:0 col:4];
    cell = [dhWS label:@"failStation" row:0 col:5];
    cell = [dhWS label:@"failSymptom" row:0 col:6];
    cell = [dhWS label:@"FADRI" row:0 col:7];
    cell = [dhWS label:@"Date" row:0 col:8];
    cell = [dhWS label:@"Remark" row:0 col:9];
    
    
    NSLog(@"temp.count: %lu", (unsigned long)temp.count);
    
    NSLog(@"_Items: %lu", (unsigned long)_items.count);
    
    for(int i = 1; i< _items.count+1; i++){
        for (int j = 0; j<temp.count; j++) {
            
            cell = [dhWS label:temp[j][i-1] row:i col:j];
            [dhWS height:500 row:i format:NULL];
            [dhWS width:5000 col:j format:NULL];
        }
    }
    
    [dhWS width:10000 col:8 format:NULL];
    
    //    for(unsigned short idx=0; idx<10; ++idx) {
    //        cell = [dhWS label:[NSString stringWithFormat:@"Row %d", idx+1] row:idx col:0];
    //        if(idx & 1) {
    //            // prove we can get the cell reference later
    //            cell = [dhWS cell:idx col:0];
    //        }
    //        [cell horzAlign:HALIGN_LEFT];
    //        [cell indent:INDENT_0+idx];
    //    }
    //	[dhWS merge:(NSRect){{10, 10}, {3, 3} }];
    //
    //    //	NSData *now = [NSDate date];
    //    //	NSDate *then = [NSDate dateWithString:@"1899-01-01 12:00:00 +0000").
    //
    
    //
    //    for(unsigned short idx=0; idx<10; ++idx) {
    //        [dhWS number:3.1415f row:idx col:1 numberFormat:FMT_GENERAL+idx];
    //    }
    //
    //
    //
    //    [dhWS width:30000 col:2 format:NULL];
    //    for(unsigned short idx=0; idx<7; ++idx) {
    //        cell = [dhWS label:@"Hello World" row:idx col:2];
    //        [cell horzAlign:HALIGN_GENERAL+idx];
    //    }
    //
    //    [dhWS width:0xFFFF col:3 format:NULL];
    //    for(unsigned short idx=0; idx<4; ++idx) {
    //        [dhWS height:24 row:idx format:NULL];
    //        cell = [dhWS label:@"Hello World" row:idx col:3];
    //        [cell vertAlign:VALIGN_TOP+idx];
    //    }
    
    int fud = [dhWB writeFile:@"/tmp/test.xls"];
    NSLog(@"OK - bye! fud=%d", fud);
    [[NSWorkspace sharedWorkspace] openFile:@"/tmp/test.xls" withApplication:@"Microsoft Excel" andDeactivate:YES];
}
@end
