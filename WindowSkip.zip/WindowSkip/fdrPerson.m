//
//  fdrPerson.m
//  WindowSkip
//
//  Created by gdadmin on 4/17/17.
//  Copyright © 2017 108. All rights reserved.
//

#import "fdrPerson.h"

@implementation fdrPerson

@synthesize fdrPersonName;
@synthesize fdrPassWord;

-(id)init{
    
    self = [super init];
    
    if(self){
        
        fdrPersonName = @"D21_FATP";
        fdrPassWord = @"1234567";
    }
    return self;
}

@end
