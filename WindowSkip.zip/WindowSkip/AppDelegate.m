//
//  AppDelegate.m
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016年 108. All rights reserved.
//

#import "AppDelegate.h"
#import "MainWindowController.h"
#import "UMWindowController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    _mainWindow = [[MainWindowController alloc] initWithWindowNibName:@"MainWindowController"];
    _mainWindow.incorrectInfo.stringValue = @"";
    //让显示的位置居于屏幕的中心
    [[_mainWindow window] center];
    
    _mainWindow.window.contentMinSize = NSMakeSize(540, 270);
    _mainWindow.window.contentMaxSize = NSMakeSize(540, 270);
    _mainWindow.window.maxFullScreenContentSize = NSMakeSize(540, 270);
    _mainWindow.window.minFullScreenContentSize = NSMakeSize(540, 270);
    //前置显示窗口
    NSLog(@"MainWindowController");
    [_mainWindow.window orderFront:nil];

    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
    
    NSLog(@"hh");
}

@end
