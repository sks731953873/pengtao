//
//  DownloadAttachWindowsController.h
//  WindowSkip
//
//  Created by gdadmin on 4/17/17.
//  Copyright © 2017 108. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "RadarTool.h"


@interface DownloadAttachWindowsController : NSWindowController


@property(nonatomic, strong)RadarTool *radarTool;

@property (strong) IBOutlet NSMatrix *choiceItm;

- (IBAction)downloadAttach:(id)sender;
- (IBAction)notDownload:(id)sender;

@property (strong) IBOutlet NSButtonCell *firstItem;
@property (strong) IBOutlet NSButtonCell *secondItem;
@property (strong) IBOutlet NSButtonCell *thirdItem;
@property (strong) IBOutlet NSButtonCell *fourthItem;

@end
