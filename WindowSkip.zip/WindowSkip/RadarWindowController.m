//
//  ThirdWindowController.m
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016 108. All rights reserved.
//

//title: Restore got different behavior from different DFU mode
//date: 2016-11-29~2016-11-30


//30F455被借走

//
//C076524005AHNV97
#import "RadarWindowController.h"
#import "AppDelegate.h"
#import "UMWindowController.h"
#import "PlistTool.h"
#import "FileTool.h"
#import "RadarTool.h"

#define IPHEAD1  "10.172"
#define IPHEAD2  "10.175"

static NSFileManager *fileManager = nil;
static NSString *temFile = @"temFile.txt";
static NSString *File = @"File.txt";


@interface RadarWindowController ()

@property(strong) UMWindowController *secondWindow;
@property(strong) NSString *accountKey;

@end

@implementation RadarWindowController
{
    PlistTool *plistHandler;
    FileTool *fileTool;
    
    //abstract path
    NSString *abstractPath;
    
    //getRadarTxtFile
    NSString *radarTxtInfo;
    
    //radarBundlePath
    NSString *radarToolPath;
    
    
    NSTask *task;
    NSPipe *pipe;
    
    
    NSMutableArray *radarInfoArr;
}

//NSTextView *txtView ;
NSTextView *radarTxtView ;
NSFileManager *fm;
NSString *fPath;
NSString *tmpDir;
NSString *currentDir;

NSString *tempJson;
NSString *emailParserJson;

NSString *plistPaths;

BOOL isReadData;
NSString *readData;
NSMutableString *txtContent;
NSString *txtFilePath;
NSNotificationCenter *nc;

NSString *savePath;

- (void)windowDidLoad {
    [super windowDidLoad];
    
    NSLog(@"self.toolTask: %@", self.toolTask);
    

    
    //Radar背景颜色
    _radarView.wantsLayer = YES;
    _radarView.layer.backgroundColor = CGColorCreateGenericRGB(1.0f, 0.9f, 0.9f, 0.9f);
    
    
    fm = [NSFileManager defaultManager];
    
    //找到本地文件所在的路径
    currentDir = [fm currentDirectoryPath];    
    NSLog(@"%@", currentDir);
    
    fileTool = [FileTool instance];
    tmpDir = NSTemporaryDirectory();
    NSLog(@"tmpDir: %@", tmpDir);
    
    //获取应用程序程序包中资源文件路径
    NSString *bundle = [[NSBundle mainBundle] resourcePath];
    radarToolPath = [bundle stringByAppendingPathComponent:@"radartool"];
    
    
    
    fPath = [currentDir stringByAppendingPathComponent:temFile];
    txtFilePath = [currentDir stringByAppendingPathComponent:File];
    
    //找到Documents文件所在的路径
    NSString *documentPath =
    [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES) objectAtIndex:0];
    NSString *name = @"invoice.xlsx";
    NSString *filename = [documentPath stringByAppendingPathComponent:name];
    NSLog(@"filename: %@", filename);
    
    if([fileTool isExist:fPath]){
        
        NSLog(@"123");
        
    }
    
    //initial global label
    self.globalLb.stringValue = @"Default";
    

    plistHandler = [PlistTool instance];
    
    
    //    NSDate *toDate =[[NSDate alloc] initWithString:@"2000-10-10 12:00:00 -0500"];

    //initial beginTime
    
    [self.beginTimeFomattor  setDateFormat : @"yyyy-MM-dd" ];
    NSString  * mindateStr =  @"1900-01-01" ;
    NSString  * maxdateStr =  @"2099-01-01" ;
    NSDate  * mindate = [self.beginTimeFomattor  dateFromString :mindateStr];
    NSDate  * maxdate = [self.beginTimeFomattor  dateFromString :maxdateStr];
    
    self.beginTime.datePickerMode = NSDateFormatterLongStyle ;//设置日期显示格式
    self.beginTime.minDate = mindate;
    self.beginTime.maxDate = maxdate;
    self.beginTime.formatter = self.beginTimeFomattor;
    self.beginTime.backgroundColor = [ NSColor  whiteColor ];
    self.beginTime.dateValue = [NSDate date];
    
    _beginTimePicker.hidden = YES;
    _endTimePicker.hidden = YES;
    
    
    //initial endTime
    
    [self.endTimeFomattor  setDateFormat : @"yyyy-MM-dd" ];
    NSDate  * endMindate = [self.endTimeFomattor  dateFromString :mindateStr];
    NSDate  * endMaxdate = [self.endTimeFomattor  dateFromString :maxdateStr];
    self.endTime.datePickerMode = NSDateFormatterLongStyle ;//设置日期显示格式
    self.endTime.minDate = endMindate;
    self.endTime.maxDate = endMaxdate;
    self.endTime.formatter = self.endTimeFomattor;
    self.endTime.backgroundColor = [NSColor  whiteColor];
    self.endTime.dateValue = [NSDate date];
    
    
    //判断是否为办公网线
    int sd;
    struct ifreq ir;
    char *ip = NULL;
    struct sockaddr_in *srv = (struct sockaddr_in *)(&ir.ifr_addr);
    sd = socket(AF_INET, SOCK_DGRAM, 0);
    strcpy(ir.ifr_name, "en0");
    
    //初始化Radar主题
    self.TitileInfo.textColor=[NSColor blackColor];
    self.TitileInfo.font=[NSFont fontWithName:@"Helvetica" size:16.0];
    self.TitileInfo.stringValue= @"Radar";

    /*
    NSEnumerator *enumerator = [secondDic keyEnumerator];
    keyConfig = [enumerator nextObject];
    valueConfig = [secondDic objectForKey:keyConfig];
     */
    
    
    //初始化文本框
//    [self.RecvInfo setBorderType:NSNoBorder];
    [self.RecvInfo  setHasVerticalScroller:YES];
    [self.RecvInfo  setHasHorizontalScroller:YES];
    [self.RecvInfo  setAutoresizingMask:NSViewWidthSizable | NSViewHeightSizable];

    
    radarTxtView =[[NSTextView alloc]initWithFrame:CGRectMake(47, 0, 580, 98)];
    [self.RecvInfo  setDocumentView:radarTxtView];
    [self.window.contentView addSubview:self.RecvInfo];
    radarTxtView.editable = NO;
 

    [radarTxtView setMinSize:NSMakeSize(0.0, 98)];
    [radarTxtView setMaxSize:NSMakeSize(FLT_MAX, FLT_MAX)];
    [radarTxtView setVerticallyResizable:YES];
    [radarTxtView setHorizontallyResizable:NO];
    [radarTxtView setAutoresizingMask:NSViewWidthSizable];
    [[radarTxtView textContainer]setContainerSize:NSMakeSize(60000,FLT_MAX)];
    [[radarTxtView textContainer]setWidthTracksTextView:YES];

    [radarTxtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
    radarTxtView.textColor = [NSColor blackColor];
 
    
    
    //leftBn
    [self.radarLeftBn setButtonType: NSMomentaryPushInButton];
    [self.radarLeftBn setBezelStyle: NSRoundedBezelStyle];
    [self.radarLeftBn setBordered: NO];
    [self.radarLeftBn setImage: [NSImage imageNamed: @"left_highlighted"]];
    [self.radarLeftBn setImagePosition: NSImageOnly];
    [self.radarLeftBn setTarget: self];
    
    //search Folder
    [self.searchFilePathBn setButtonType: NSMomentaryPushInButton];
    [self.searchFilePathBn setBezelStyle: NSRoundedBezelStyle];
    [self.searchFilePathBn setBordered: NO];
    [self.searchFilePathBn setImage: [NSImage imageNamed: @"fileFolder.png"]];
    [self.searchFilePathBn setImagePosition: NSImageOnly];
    [self.searchFilePathBn setTarget: self];
    
    //save folder
    [self.savePathBn setButtonType: NSMomentaryPushInButton];
    [self.savePathBn setBezelStyle: NSRoundedBezelStyle];
    [self.savePathBn setBordered: NO];
    [self.savePathBn setImage: [NSImage imageNamed: @"fileFolder.png"]];
    [self.savePathBn setImagePosition: NSImageOnly];
    [self.savePathBn setTarget: self];
    
    //初始化default label & textfield

    self.defaultField1.stringValue = @"-----------------------------------------";
    self.defaultField1.enabled = NO;
    
    
    //初始化radarInfo

    self.radarNumInfo.hidden = YES;

    self.infoBn.hidden = YES;
    self.infoBn.title = @"send";

    //初始化upload按钮
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden = YES;
    self.bn.hidden = YES;
    self.updateBn.title = @"send";
    
    
    
    //初始化deleteFile相关button和textfiled
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;
    
   
    self.bnDelete.title = @"send";
    
    //初始化updateContent相关的button和textfiled
    self.radarNumUpdate.hidden = YES;
    self.updateBn.hidden = YES;
    self.updateBn.title = @"send";
    
    //初始化related radar相关的button和textfield
    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden =YES;
    self.relatedBn.title = @"send";
    
    //初始化被CC相关的button和textfield
    self.radarNumCC.hidden = YES;
    self.CCBn.hidden = YES;
    self.CCBn.stringValue = @"被CC邮件:";
    self.CCBn.title = @"send";
    
    
    //初始化SetCC
    
    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    self.setCCBn.title = @"send";
    
    //searchByTitleBn
    self.searchByTitleBn.title = @"send";
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = YES;
    self.searchByDateBn.title = @"send";
    self.searchByTitleField.hidden =YES;
    
    //初始化findPeople
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES ;

    //初始化list radar
    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
    self.bnList.title = @"send";
    
    //初始化 download file
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;
    self.bnDL.title = @"send";
    self.savePathBn.hidden = YES;
    
    //初始化 findComVerBn
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    self.findComVerBn.title = @"Send";
    
    //初始化 findComNameBn
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;
    self.findComNameBn.title = @"Send";
    
    //初始化 findComNameVersion
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
    self.findComNameVerBn.title = @"Send";
    
    //初始化 createRadr
    self.component.hidden = NO;
    self.version.hidden = NO;
    self.reproducible.hidden = NO;
    self.getRadarTxtBn.hidden = NO;
    self.createRadarBn.hidden = NO;
    self.classification.hidden = NO;
    
    
    //判断本地ip是否为10.172网段，并进行匹配
    if(ioctl(sd, SIOCGIFADDR, &ir)!=0)
    {
        radarTxtView.string=@"请检查网线是否连接上,并重新打开软件";
        [radarTxtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
        close(sd);
        return ;
    }
    
    ip=inet_ntoa(srv->sin_addr);
    if(strstr(ip,IPHEAD1)==NULL && strstr(ip,IPHEAD2)==NULL)
    {
        radarTxtView.string=@"请换为office网线,并重新打开软件";
        [radarTxtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
        close(sd);
        return ;
    }
    close(sd);
}




- (IBAction)backToUM:(id)sender {
//    AppDelegate *appDelegate = (AppDelegate *)[NSApplication sharedApplication];
//    [self.window close];
//    [[appDelegate.mainWindow window] makeKeyAndOrderFront:nil];
    
//    [self setTaskNil];
    
    //返回UM界面需要移除nc
    nc = [NSNotificationCenter defaultCenter];
    [nc removeObserver:self];
    
    _secondWindow = [[UMWindowController alloc] initWithWindowNibName:@"UMWindowController"];
    [_secondWindow.window orderFront:nil];
    [_secondWindow.window center];
    [self.window orderOut:nil];
}


- (void)alertEnded:(NSAlert *)alert
              code:(NSInteger)choice
           context:(void *)v
{
    NSLog(@"Alert sheet ended");
    
    if (choice == NSAlertDefaultReturn) {
    
        task = nil;
        _secondWindow = [[UMWindowController alloc] initWithWindowNibName:@"UMWindowController"];
        [_secondWindow.window orderFront:nil];
        [_secondWindow.window center];
        [self.window orderOut:nil];
        
    }
}


- (IBAction)RclickChoice:(id)sender {
    
    if(![self.itemChoice indexOfSelectedItem])
    {
        return;
    }else if([[self.itemChoice titleOfSelectedItem] isEqualToString:@"Upload radarNum file"]){
        NSLog(@"upload file");
        radarTxtView.string = @"fill the radarNum and upload file";
        [self uploadView];
    }else if([[self.itemChoice titleOfSelectedItem] isEqualToString:@"Create radarNum account"]){
        NSLog(@"upload file");
        radarTxtView.string = @"Create radarNum account";
        [self createRadarView];
    }else if([[self.itemChoice titleOfSelectedItem] isEqualToString:@"Delete radarNum file"]){
        NSLog(@"delte file");
        radarTxtView.string = @"fill the radarNum and delete file";
        [self deleteView];
    }else if([[self.itemChoice titleOfSelectedItem] isEqualToString:@"Update radarNum content"]){
        NSLog(@"update file");
        radarTxtView.string = @"fill the radarNum and update content";
        [self updateView];
    }else if([[self.itemChoice titleOfSelectedItem] isEqualToString:@"Download radarNum file"]){
        NSLog(@"download file");
        radarTxtView.string = @"fill the radarNum and download file";
        [self downloadView];
    }else if([[self.itemChoice titleOfSelectedItem] isEqualToString:@"Related radarNum"]){
        NSLog(@"related radar");
        radarTxtView.string = @"fill the radarNum";
        [self relatedView];
    }else if([[self.itemChoice titleOfSelectedItem] isEqualToString:@"GetCC radarNum"]){
        NSLog(@"get CC的邮件");
        radarTxtView.string = @"fill the radarNum";
        [self getCCView];
    }else if([[self.itemChoice titleOfSelectedItem] isEqualToString:@"SetCC radarNum"]){
        NSLog(@"set CC的邮件");
        radarTxtView.string = @"fill the radarNum";
        [self setCCView];
    }else if([[self.itemChoice titleOfSelectedItem] isEqualToString:@"RadarNum info"]){
        NSLog(@"Info radar");
        radarTxtView.string = @"fill the radarNum";
        
        [self infoView];
    }else if([[self.itemChoice titleOfSelectedItem] isEqualToString:@"Search By Date"]){
        NSLog(@"通过date查询信息");
        radarTxtView.string = @"fill the date";
        [self searchByDateView];
    }else if([[self.itemChoice titleOfSelectedItem] isEqualToString:@"Search By Title"]){
        NSLog(@"通过title查询getCC信息");
   
        radarTxtView.string = @"fill the title";
        
        [self searchByTitleView];
    }else if([[self.itemChoice titleOfSelectedItem] isEqualToString:@"Find people"]){
        
        NSLog(@"search peole info");
        
        radarTxtView.string = @"search peole info";
        
        [self searchByPeopleView];
        
    }else if ([[self.itemChoice titleOfSelectedItem] isEqualToString:@"List radarNum"]){
        
        NSLog(@"List radarNum");
        
        radarTxtView.string = @"List radarNum";
        
        [self listView];
    }else if ([[self.itemChoice titleOfSelectedItem] isEqualToString:@"Find_Compenent_Version"]){
        
        NSLog(@"Find_Compenent_Version");
        
        radarTxtView.string = @"Find_Compenent_Version";
        
        [self findComVerView];
    }else if ([[self.itemChoice titleOfSelectedItem] isEqualToString:@"Find_Compenent_Name"]){
        
        NSLog(@"Find_Compenent_Name");
        
        radarTxtView.string = @"Find_Compenent_Name";
        
        [self findComNameView];
    }else if ([[self.itemChoice titleOfSelectedItem] isEqualToString:@"Find_Compenent_Name_Version"]){
        
        NSLog(@"Find_Compenent_Name_Version");
        
        radarTxtView.string = @"Find_Compenent_Name_Version";
        
        [self findComNameVerView];
    }
}


- (IBAction)sendUpload:(id)sender {
    
    if([self.radarNum.stringValue isEqualToString:@""]||[abstractPath isEqualToString:@""]){
        radarTxtView.string = @"雷达号或者文件名不能为空";
        return;
    }else{
        
        radarTxtView.string = @"";
        
        NSString *path = [NSString stringWithFormat:@"%@", abstractPath];
        
        NSArray *arr = [NSArray arrayWithObjects:@"upload",self.radarNum.stringValue, path, nil];
        NSLog(@"arr: %@", arr);
        _toolTask = [[RadarTool alloc] initWithArgArr:arr];
        
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        
        [nc removeObserver:self];
        
        [_toolTask excuteTask];
        
        [nc addObserver:self
               selector:@selector(handleTextChange:)
                   name:textChangeNotification
                 object:nil];
    }
}

- (IBAction)searchFilePath:(id)sender {
    NSOpenPanel *panel = [NSOpenPanel openPanel];
    [panel setMessage:@""];
    [panel setPrompt:@"OK"];
    [panel setCanChooseDirectories:YES];
    [panel setCanCreateDirectories:YES];
    [panel setCanChooseFiles:YES];
    
    NSInteger result = [panel runModal];
    if (result == NSFileHandlingPanelOKButton)
    {
        abstractPath = [[panel URL] path];
        NSLog(@"path_all: %@",abstractPath);
        radarTxtView.string = abstractPath;
    }
}


- (IBAction)sendDelete:(id)sender {

    if([self.radarNumDelete.stringValue isEqualToString:@""]||[self.fileNameDelete.stringValue isEqualToString:@""]){
        radarTxtView.string = @"雷达号或者文件名不能为空";
        return;
    }else{
        radarTxtView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"deleteAttachment",self.radarNumDelete.stringValue,self.fileNameDelete.stringValue, nil];
        NSLog(@"arr: %@", arr);
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        _toolTask = [[RadarTool alloc] initWithArgArr:arr];
        [_toolTask excuteTask];
        
        [nc addObserver:self
               selector:@selector(handleTextChange:)
                   name:textChangeNotification
                 object:nil];
    }
}

- (IBAction)sendUpdate:(id)sender {
    
    if([self.radarNumUpdate.stringValue isEqualToString:@""]){
        radarTxtView.string = @"更新的文件名不能为空";
        return;
    }else{
        radarTxtView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"update",self.radarNumUpdate.stringValue,radarTxtView.string, nil];
        NSLog(@"arr: %@", arr);
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        _toolTask = [[RadarTool alloc] initWithArgArr:arr];
        [_toolTask excuteTask];

        [nc addObserver:self
               selector:@selector(handleTextChange:)
                   name:textChangeNotification
                 object:nil];
    }
}


- (IBAction)sendRelated:(id)sender {

    if([self.radarNumRelated.stringValue isEqualToString:@""]){
        radarTxtView.string = @"相关在雷达号不能为空";
        return;
    }else{
        radarTxtView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"related",self.radarNumRelated.stringValue, nil];
        NSLog(@"arr: %@", arr);
        
       
        nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
         _toolTask = [[RadarTool alloc] initWithArgArr:arr];
        [_toolTask excuteTask];
        [nc addObserver:self
               selector:@selector(handleTextChange:)
                   name:textChangeNotification
                 object:nil];
    }
}


-(void)handleTextChange:(NSNotification*) note{
    NSString *string = [[note userInfo] objectForKey:@"text"];
//    NSLog(@"string: %@", string);
    NSTextStorage *ts = [radarTxtView textStorage];
    [radarTxtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
    [ts replaceCharactersInRange:NSMakeRange([ts length], 0) withString:string];
//    NSLog(@"radarTxtView: %@", radarTxtView.string);
}


- (IBAction)sendCC:(id)sender {
    
    if([self.radarNumCC.stringValue isEqualToString:@""]){
        radarTxtView.string = @"CC雷达号不能为空";
        return;
    }else{
//        task = [[NSTask alloc] init];
//        [task setLaunchPath:@"/bin/bash"];
//        NSArray *arguments = [NSArray arrayWithObjects:radarToolPath, accountRadar,@"getcc",self.radarNumCC.stringValue,  nil];
//        NSLog(@"arguments:%@", arguments);
//        [self observerChange:arguments];
        
        radarTxtView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"getcc", self.radarNumCC.stringValue, nil];
        NSLog(@"arr: %@", arr);
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        _toolTask = [[RadarTool alloc] initWithArgArr:arr];
        [_toolTask excuteTask];
        [nc addObserver:self
               selector:@selector(handleTextChange:)
                   name:textChangeNotification
                 object:nil];
    }
}


- (IBAction)sendSetCC:(id)sender {
    
    if([self.radarNumSetCC.stringValue isEqualToString:@""]){
        radarTxtView.string = @"CC雷达号不能为空";
        return;
    }else{
        radarTxtView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"setcc", self.radarNumSetCC.stringValue, nil];
        NSLog(@"arr: %@", arr);
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        _toolTask = [[RadarTool alloc] initWithArgArr:arr];
        [_toolTask excuteTask];
        [nc addObserver:self
               selector:@selector(handleTextChange:)
                   name:textChangeNotification
                 object:nil];
    }
}


- (IBAction)sendInfo:(id)sender {
    
    if([self.radarNumInfo.stringValue isEqualToString:@""]){
        radarTxtView.string = @"Info雷达号不能为空";
        return;
    }else{
        radarTxtView.string = @"";
        
        NSArray *arr = [NSArray arrayWithObjects:@"info", self.radarNumInfo.stringValue, nil];
        NSLog(@"arr: %@", arr);
    
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
    
        _toolTask = [[RadarTool alloc] initWithArgArr:arr];
        [_toolTask excuteTask];
        
        [nc addObserver:self
               selector:@selector(handleTextChange:)
                   name:textChangeNotification
                 object:nil];
    }
}


- (IBAction)searchByTitleSend:(id)sender {
    
    if([self.searchByTitleField.stringValue isEqualToString:@""]){
        radarTxtView.string = @"输入日期不能为空";
        return;
    }else{
        radarTxtView.string = @"";
        NSArray *arguments;
        
        if((!self.getCC.state) && (!self.setCC.state) && (!self.delCC.state)){
            radarTxtView.string = @"pls choose the getcc or setcc or delcc";
            return;
        }else if((self.getCC.state) && (!self.setCC.state) && (!self.delCC.state)){
            arguments = [NSArray arrayWithObjects:@"search_by_title", self.searchByTitleField.stringValue,@"getcc" , nil];
            NSLog(@"arguments:%@", arguments);
        }else if((!self.getCC.state) && (self.setCC.state) && ((!self.delCC.state))){
            arguments = [NSArray arrayWithObjects:@"search_by_title", self.searchByTitleField.stringValue,@"setcc" , nil];
            NSLog(@"arguments:%@", arguments);
        }else if((!self.getCC.state) && (!self.setCC.state) && ((self.delCC.state))){
            arguments = [NSArray arrayWithObjects:@"search_by_title", self.searchByTitleField.stringValue,@"delcc" , nil];
            NSLog(@"arguments:%@", arguments);
        }
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        _toolTask = [[RadarTool alloc] initWithArgArr:arguments];
        [_toolTask excuteTask];
        [nc addObserver:self
               selector:@selector(handleTextChange:)
                   name:textChangeNotification
                 object:nil];

        
    }
}

- (IBAction)searchByDateSend:(id)sender {
    
    NSString *date = [[NSString alloc] initWithFormat:@"%@~%@", self.beginTime.stringValue, self.endTime.stringValue];
//    NSLog(@"date: %@", date);
    NSArray *arguments;
    radarTxtView.string = @"";
    
    if((!self.getCC.state) && (!self.setCC.state) && (!self.delCC.state)){
        radarTxtView.string = @"pls choose the getcc or setcc or delcc";
        return;
    }else if((self.getCC.state) && (!self.setCC.state) && (!self.delCC.state)){
        arguments = [NSArray arrayWithObjects:@"search_by_date", date,@"getcc" , nil];
        NSLog(@"arguments:%@", arguments);
    }else if((!self.getCC.state) && (self.setCC.state) && ((!self.delCC.state))){
        arguments = [NSArray arrayWithObjects:@"search_by_date", date,@"setcc" , nil];
        NSLog(@"arguments:%@", arguments);
    }else if((!self.getCC.state) && (!self.setCC.state) && ((self.delCC.state))){
        arguments = [NSArray arrayWithObjects:@"search_by_date", date,@"delcc" , nil];
        NSLog(@"arguments:%@", arguments);
    }

    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc removeObserver:self];
    
    _toolTask = [[RadarTool alloc] initWithArgArr:arguments];
    [_toolTask excuteTask];
    [nc addObserver:self
           selector:@selector(handleTextChange:)
               name:textChangeNotification
             object:nil];

}

- (IBAction)findPeopleSend:(id)sender {
    
    if([self.firstNameField.stringValue isEqualToString:@""] ||[self.lastNameField.stringValue isEqualToString:@""]){
        radarTxtView.string = @"FirstName or lastName cannot be null";
        return;
    }else{
        radarTxtView.string = @"";
        
        NSArray *arr = [NSArray arrayWithObjects:@"find_people", self.firstNameField.stringValue, self.lastNameField.stringValue, nil];
        NSLog(@"arr: %@", arr);
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        _toolTask = [[RadarTool alloc] initWithArgArr:arr];
        [_toolTask excuteTask];
        [nc addObserver:self
               selector:@selector(handleTextChange:)
                   name:textChangeNotification
                 object:nil];
    }
}

- (IBAction)findComVerSend:(id)sender {
    
    if([self.findComVerField.stringValue isEqualToString:@""]){
        radarTxtView.string = @"Info雷达号不能为空";
        return;
    }else{
        radarTxtView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"find_component", @".", self.findComVerField.stringValue, nil];
        NSLog(@"arr: %@", arr);
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        _toolTask = [[RadarTool alloc] initWithArgArr:arr];
        [_toolTask excuteTask];
        [nc addObserver:self
               selector:@selector(handleTextChange:)
                   name:textChangeNotification
                 object:nil];
    }
}

- (IBAction)findComNameBn:(id)sender {
    
    if([self.findComNameField.stringValue isEqualToString:@""]){
        radarTxtView.string = @"Info雷达号不能为空";
        return;
    }else{
        radarTxtView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"find_component", self.findComNameField.stringValue, @".", nil];
        NSLog(@"arr: %@", arr);
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        _toolTask = [[RadarTool alloc] initWithArgArr:arr];
        [_toolTask excuteTask];
        [nc addObserver:self
               selector:@selector(handleTextChange:)
                   name:textChangeNotification
                 object:nil];
    }
}

- (IBAction)findComNameVerSend:(id)sender {
    

    if([self.findNameField.stringValue isEqualToString:@""]||[self.findVersionField.stringValue isEqualToString:@""]){
        radarTxtView.string = @"Info雷达号不能为空";
        return;
    }else{
        radarTxtView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"find_component", self.findNameField.stringValue, self.findVersionField.stringValue, nil];
        NSLog(@"arr: %@", arr);
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        _toolTask = [[RadarTool alloc] initWithArgArr:arr];
        [_toolTask excuteTask];
        [nc addObserver:self
               selector:@selector(handleTextChange:)
                   name:textChangeNotification
                 object:nil];
    }
}

- (IBAction)createRadar:(id)sender {
    
    radarTxtView.string = @"";
    
    
//    NSString* component1 = [self.component.titleOfSelectedItem stringByReplacingOccurrencesOfString:@" " withString:@"\\ "];
//    NSString* component = [component1 stringByReplacingOccurrencesOfString:@"|" withString:@"\\|"];
//    
//    NSString* version = [self.version.titleOfSelectedItem stringByReplacingOccurrencesOfString:@" " withString:@"\\ "];
//    NSString* classification = [self.classification.titleOfSelectedItem stringByReplacingOccurrencesOfString:@" " withString:@"\\ "];
//    NSString* reproducible = [self.reproducible.titleOfSelectedItem stringByReplacingOccurrencesOfString:@" " withString:@"\\ "];
    
//    NSString* title1 = [NSString stringWithContentsOfFile:@"/tmp/1.txt" encoding:NSUTF8StringEncoding error:NULL];
//    NSString* title = [title1 stringByReplacingOccurrencesOfString:@" " withString:@"\\ "];
//    
//    NSLog(@"title: %@", title);
//    
//    NSString* decription1 = [NSString stringWithContentsOfFile:@"/tmp/2.txt" encoding:NSUTF8StringEncoding error:NULL];
//    NSString* decription2 = [decription1 stringByReplacingOccurrencesOfString:@" " withString:@"\\ "];
//    NSString* decription3 = [decription2 stringByReplacingOccurrencesOfString:@"\t" withString:@""];
//    NSString* decription = [decription3 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
//    NSLog(@"decription: %@", decription);
    
    
    
//    NSString* component = [self.component.titleOfSelectedItem stringByReplacingOccurrencesOfString:@" " withString:@"\\ "];
    NSString* component = @"FactoryCoreOSTriage";
    
//    NSString* version = self.version.titleOfSelectedItem;
    NSString* version = @"D21";
    
    
//    NSString* classification = [self.classification.titleOfSelectedItem stringByReplacingOccurrencesOfString:@" " withString:@"\\ "];
   
    NSString* reproducible = @"NoTry";
    
//    NSString* reproducible = [self.reproducible.titleOfSelectedItem stringByReplacingOccurrencesOfString:@" " withString:@"\\ "];
    NSString* classification = @"Crash/Hang/DataLoss";
    
    
    NSString *title = @"/tmp/1.txt";
    NSString *description = @"/tmp/2.txt";
    
    NSArray *arr = [NSArray arrayWithObjects:@"create_radar", component, version, title, description, classification, reproducible, nil];
    
    NSLog(@"arr: %@", arr);
    
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc removeObserver:self];
    
    _toolTask = [[RadarTool alloc] initWithArgArr:arr];
    [_toolTask excuteTask];
    [nc addObserver:self
           selector:@selector(handleTextChange:)
               name:textChangeNotification
             object:nil];
}


- (IBAction)sendList:(id)sender {
    
    if([self.radarNumList.stringValue isEqualToString:@""]){
        radarTxtView.string = @"radarNum cannot be null";
        return;
    }else{

        radarTxtView.string = @"";
        
        NSArray *arr = [NSArray arrayWithObjects:@"list", self.radarNumList.stringValue, nil];
        NSLog(@"arr: %@", arr);
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        _toolTask = [[RadarTool alloc] initWithArgArr:arr];
        [_toolTask excuteTask];
        [nc addObserver:self
               selector:@selector(handleTextChange:)
                   name:textChangeNotification
                 object:nil];
    }
}

- (IBAction)sendDL:(id)sender {
    if([self.radarNumDL.stringValue isEqualToString:@""] || [savePath isEqualToString:@""]){
        radarTxtView.string = @"radarNum or filenameDownlaod cannot be null";
        return;
    }else{
        radarTxtView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"download", self.radarNumDL.stringValue, savePath,nil];
        NSLog(@"arr: %@", arr);
    
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        _toolTask = [[RadarTool alloc] initWithArgArr:arr];
        [_toolTask excuteTask];
        [nc addObserver:self
               selector:@selector(handleTextChange:)
                   name:textChangeNotification
                 object:nil];
    }
}


-(id)setPipe:(NSTask *) task1 isReadData:(BOOL) isReadData{
    
    // 新建输出管道作为Task的输出
    pipe= [NSPipe pipe];
    
    [task setStandardOutput:pipe];
    
    NSLog(@"5");
    
    // 开始task
    NSFileHandle *file = [pipe fileHandleForReading];
    
    NSLog(@"a");
    
    [task1 launch];
    NSLog(@"1");

    NSData *data = [file readDataToEndOfFile];
    NSLog(@"2");
    
    NSMutableString *string = [[NSMutableString alloc] initWithData:data encoding:NSUTF8StringEncoding];

    NSLog(@"string: %@", string);
    radarTxtView.string= string;
    if(isReadData){
        
    }    
    return 0;
}

-(void)createRadarView{
    
    
    
}

-(void)uploadView{
    
    self.globalLb.stringValue = @"Upload file";
    
    self.defaultField1.hidden = YES;
    self.radarNum.hidden = NO;
    self.searchFilePathBn.hidden =  NO;
    self.bn.hidden = NO;
  
    radarTxtView.hidden = NO;
    self.RecvInfo.hidden = NO;
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;
 
    
    self.radarNumUpdate.hidden = YES;
    self.updateBn.hidden = YES;
    
    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden = YES;
    
    self.radarNumCC.hidden = YES;
   
    self.CCBn.hidden = YES;
    
    
    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    
   
    self.radarNumInfo.hidden = YES;
    self.infoBn.hidden = YES;
    
    
    
    self.beginTimePicker.hidden = YES;
    self.endTimePicker.hidden = YES;
    
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = YES;
    
    self.searchByTitleField.hidden = YES;
    
    self.getCC.hidden = YES;
    self.setCC.hidden = YES;
    self.delCC.hidden = YES;
    
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES ;
    
    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
    
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;
    
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;
    
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
}


-(void)downloadView{
    
    self.globalLb.stringValue = @"Download file";
    
    self.defaultField1.hidden = YES;
    
    
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden =  YES;
    self.bn.hidden = YES;
    
    
    radarTxtView.hidden = YES;
    self.RecvInfo.hidden = YES;
    
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;
    
    
    self.radarNumUpdate.hidden = YES;
    
    
    self.updateBn.hidden = YES;
    
    
    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden = YES;
    
    self.radarNumCC.hidden = YES;
    
    self.CCBn.hidden = YES;
    
    
    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    
    
    self.radarNumInfo.hidden = YES;
    self.infoBn.hidden = YES;
    
    
    
    self.beginTimePicker.hidden = YES;
    self.endTimePicker.hidden = YES;
    
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = YES;
    
    self.searchByTitleField.hidden = YES;
    
    self.getCC.hidden = YES;
    self.setCC.hidden = YES;
    self.delCC.hidden = YES;
    
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES ;
    
    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
    
    self.radarNumDL.hidden = NO;
    self.bnDL.hidden = NO;
    self.savePathBn.hidden = NO;
    radarTxtView.hidden = NO;
    self.RecvInfo.hidden = NO;
    
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;
    
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
}

-(void)deleteView{
    
    self.globalLb.stringValue = @"Delete file";
    
    self.defaultField1.hidden = YES;
    
    
    self.radarNumDelete.hidden = NO;
    self.fileNameDelete.hidden = NO;
    self.bnDelete.hidden = NO;
    
    
    radarTxtView.hidden = NO;
    self.RecvInfo.hidden = NO;
    
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden =  YES;
    self.bn.hidden = YES;

    self.radarNumUpdate.hidden = YES;
    self.updateBn.hidden = YES;
    
    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden = YES;
    
    self.radarNumCC.hidden = YES;
    
    self.CCBn.hidden = YES;
    
    
    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    
    
    self.radarNumInfo.hidden = YES;
    self.infoBn.hidden = YES;


    
    self.beginTimePicker.hidden = YES;
    self.endTimePicker.hidden = YES;
    
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = YES;
    
    self.searchByTitleField.hidden = YES;
    
    self.getCC.hidden = YES;
    self.setCC.hidden = YES;
    self.delCC.hidden = YES;
    
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES ;
    
    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
    
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;
    
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;
    
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
}

-(void)infoView{
    
    self.globalLb.stringValue = @"Radar info";
    
    self.defaultField1.hidden = YES;
    
    
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;
    
    
    radarTxtView.hidden = NO;
    self.RecvInfo.hidden = NO;
    
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden =  YES;
    self.bn.hidden = YES;
    
    
    self.radarNumUpdate.hidden = YES;
    
    
    self.updateBn.hidden = YES;
    
    
    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden = YES;
    
    self.radarNumCC.hidden = YES;
    
    self.CCBn.hidden = YES;
    
   
    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    
    
    self.radarNumInfo.hidden = NO;
    self.infoBn.hidden = NO;

    
    self.beginTimePicker.hidden = YES;
    self.endTimePicker.hidden = YES;
    
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = YES;
    
    self.searchByTitleField.hidden = YES;
    
    self.getCC.hidden = YES;
    self.setCC.hidden = YES;
    self.delCC.hidden = YES;
    
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES ;
    
    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
    
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;
    
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;
    
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
}

-(void)updateView{
    
    self.globalLb.stringValue = @"Update radar";
    
    self.defaultField1.hidden = YES;
   
    
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden =  YES;
    self.bn.hidden = YES;
   
    
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;
   
    
    self.radarNumUpdate.hidden = NO;
    radarTxtView.hidden = NO;
    
    self.updateBn.hidden = NO;
    
    
    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden = YES;
    
    self.radarNumCC.hidden = YES;
   
    self.CCBn.hidden = YES;
    
    
    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    
   
    self.radarNumInfo.hidden = YES;
    self.infoBn.hidden = YES;
    
    self.RecvInfo.hidden = NO;
    
    self.beginTimePicker.hidden = YES;
    self.endTimePicker.hidden = YES;
    
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = YES;
    
    self.searchByTitleField.hidden = YES;
    
    self.getCC.hidden = YES;
    self.setCC.hidden = YES;
    self.delCC.hidden = YES;
    
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES ;
    
    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
    
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;
    
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;
    
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
}


-(void)relatedView{
    
    self.globalLb.stringValue = @"Related CC";
    
    self.defaultField1.hidden = YES;
    
    
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden =  YES;
    self.bn.hidden = YES;
    
    
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;
    
    
    self.radarNumUpdate.hidden = YES;
//    radarTxtView.hidden = YES;
    
    self.updateBn.hidden = YES;

   
    self.relatedBn.hidden = NO;
    self.radarNumRelated.hidden = NO;
    
    radarTxtView.hidden = NO;
    self.RecvInfo.hidden = NO;
    
    self.radarNumCC.hidden = YES;
    
    self.CCBn.hidden = YES;
    
    
    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    
    
    self.radarNumInfo.hidden = YES;
    self.infoBn.hidden = YES;
    
    
    self.beginTimePicker.hidden = YES;
    self.endTimePicker.hidden = YES;
    
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = YES;
    
    self.searchByTitleField.hidden = YES;
    
    self.getCC.hidden = YES;
    self.setCC.hidden = YES;
    self.delCC.hidden = YES;
    
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES ;
    
    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
    
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;
    
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;
    
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
}


-(void)getCCView{
    
    self.globalLb.stringValue = @"Get CC";
    
    self.defaultField1.hidden = YES;
    
    
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden =  YES;
    self.bn.hidden = YES;
    
    
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;
    
    
    self.radarNumUpdate.hidden = YES;
//    txtView.hidden = YES;
    
    self.updateBn.hidden = YES;
    
    
    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden = YES;
    
    self.radarNumCC.hidden = NO;
   
    self.CCBn.hidden = NO;
    
    
    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    
    
    self.radarNumInfo.hidden = YES;
    self.infoBn.hidden = YES;
    
    radarTxtView.hidden = NO;
    self.RecvInfo.hidden = NO;
    

    self.beginTimePicker.hidden = YES;
    self.endTimePicker.hidden = YES;
    
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = YES;
    
    self.searchByTitleField.hidden = YES;
    
    self.getCC.hidden = YES;
    self.setCC.hidden = YES;
    self.delCC.hidden = YES;
    
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES ;
 
    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
    
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;
    
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;
    
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
}

-(void)setCCView{
    
    self.globalLb.stringValue = @"Set CC";
    self.defaultField1.hidden = YES;
    
    
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden =  YES;
    self.bn.hidden = YES;
   
    
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;
   
    
    self.radarNumUpdate.hidden = YES;
    //    txtView.hidden = YES;
   
    self.updateBn.hidden = YES;
    
  
    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden = YES;
    
    self.radarNumCC.hidden = YES;
 
    self.CCBn.hidden = YES;
    

    self.setCCBn.hidden = NO;
    self.radarNumSetCC.hidden = NO;
    
    
    self.radarNumInfo.hidden = YES;
    self.infoBn.hidden = YES;
    
    radarTxtView.hidden = NO;
    self.RecvInfo.hidden = NO;
    
    self.beginTimePicker.hidden = YES;
    self.endTimePicker.hidden = YES;
    
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = YES;
    
    self.searchByTitleField.hidden = YES;
    
    self.searchByTitleField.hidden = YES;
    
    self.getCC.hidden = YES;
    self.setCC.hidden = YES;
    self.delCC.hidden = YES;
    
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES ;

    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
    
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;
    
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;
    
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
}


-(void)searchByDateView{
   
    self.globalLb.stringValue = @"SearchByDate";
    
    self.defaultField1.hidden = YES;
  
    
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;
 
    
    radarTxtView.hidden = NO;
    self.RecvInfo.hidden = NO;
    
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden =  YES;
    self.bn.hidden = YES;
  
    
    self.radarNumUpdate.hidden = YES;
    //    txtView.hidden = YES;
   
    self.updateBn.hidden = YES;
    
   
    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden = YES;
    
    self.radarNumCC.hidden = YES;

    self.CCBn.hidden = YES;
    

    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    

    self.radarNumInfo.hidden = YES;
    self.infoBn.hidden = YES;
    

    
    _beginTimePicker.hidden = NO;
    _endTimePicker.hidden = NO;
    
    self.getCC.hidden = NO;
    self.setCC.hidden = NO;
    self.delCC.hidden = NO;
    
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = NO;
    
    self.searchByTitleField.hidden = YES;
    
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES ;
    
    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
    
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;
    
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;
    
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
}

-(void)searchByTitleView{
    
    self.globalLb.stringValue = @"SearchByTitle";
    
    self.defaultField1.hidden = YES;
 
    
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;
   
    
    radarTxtView.hidden = NO;
    self.RecvInfo.hidden = NO;
    
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden =  YES;
    self.bn.hidden = YES;

    
    self.radarNumUpdate.hidden = YES;
    //    txtView.hidden = YES;

    self.updateBn.hidden = YES;
    

    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden = YES;
    
    self.radarNumCC.hidden = YES;
 
    self.CCBn.hidden = YES;
    

    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    

    self.radarNumInfo.hidden = YES;
    self.infoBn.hidden = YES;
    
    self.beginTimePicker.hidden = YES;
    self.endTimePicker.hidden = YES;
    
    self.getCC.hidden = NO;
    self.setCC.hidden = NO;
    self.delCC.hidden = NO;
    
    self.searchByTitleBn.hidden = NO;
    self.searchByDateBn.hidden = YES;
    
    self.searchByTitleField.hidden = NO;
    
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES ;
    
    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
    
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;
    
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;
    
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
}


-(void)searchByPeopleView{
    
    self.globalLb.stringValue = @"SearchByPeople";
    
    self.defaultField1.hidden = YES;
  
    
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;

    
    radarTxtView.hidden = NO;
    self.RecvInfo.hidden = NO;
    
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden =  YES;
    self.bn.hidden = YES;

    
    self.radarNumUpdate.hidden = YES;
    //    txtView.hidden = YES;

    self.updateBn.hidden = YES;
    

    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden = YES;
    
    self.radarNumCC.hidden = YES;

    self.CCBn.hidden = YES;
    

    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    

    self.radarNumInfo.hidden = YES;
    self.infoBn.hidden = YES;

    self.beginTimePicker.hidden = YES;
    self.endTimePicker.hidden = YES;
    
    self.getCC.hidden = YES;
    self.setCC.hidden = YES;
    self.delCC.hidden = YES;
    
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = YES;
    
    self.searchByTitleField.hidden = YES;
    
    self.firstNameField.hidden = NO;
    self.lastNameField.hidden = NO;
    self.findPeopleBn.hidden  = NO ;
    
    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
  
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;
    
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;
    
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
}

-(void)listView{
    
    self.globalLb.stringValue = @"List Radar";
    
    self.defaultField1.hidden = YES;
    
    
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;
    
    
    radarTxtView.hidden = NO;
    self.RecvInfo.hidden = NO;
    
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden =  YES;
    self.bn.hidden = YES;
    
    
    self.radarNumUpdate.hidden = YES;
    //    txtView.hidden = YES;
    
    self.updateBn.hidden = YES;
    
    
    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden = YES;
    
    self.radarNumCC.hidden = YES;
    
    self.CCBn.hidden = YES;
    
    
    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    
    
    self.radarNumInfo.hidden = YES;
    self.infoBn.hidden = YES;
    
    self.beginTimePicker.hidden = YES;
    self.endTimePicker.hidden = YES;
    
    self.getCC.hidden = YES;
    self.setCC.hidden = YES;
    self.delCC.hidden = YES;
    
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = YES;
    
    self.searchByTitleField.hidden = YES;
    
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES;
    
    self.bnList.hidden = NO;
    self.radarNumList.hidden = NO;
    
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;
    
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;
    
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
}

-(void)findComVerView{
    
    self.globalLb.stringValue = @"findComVer";
    
    self.defaultField1.hidden = YES;
    
    
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;
    
    
    radarTxtView.hidden = NO;
    self.RecvInfo.hidden = NO;
    
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden =  YES;
    self.bn.hidden = YES;
    
    
    self.radarNumUpdate.hidden = YES;
    //    txtView.hidden = YES;
    
    self.updateBn.hidden = YES;
    
    
    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden = YES;
    
    self.radarNumCC.hidden = YES;
    
    self.CCBn.hidden = YES;
    
    
    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    
    
    self.radarNumInfo.hidden = YES;
    self.infoBn.hidden = YES;
    
    self.beginTimePicker.hidden = YES;
    self.endTimePicker.hidden = YES;
    
    self.getCC.hidden = YES;
    self.setCC.hidden = YES;
    self.delCC.hidden = YES;
    
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = YES;
    
    self.searchByTitleField.hidden = YES;
    
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES;
    
    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
    
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;

    self.findComVerBn.hidden = NO;
    self.findComVerField.hidden = NO;
    
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;
    
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
}

-(void)findComNameView{
    
    self.globalLb.stringValue = @"findComName";
    
    self.defaultField1.hidden = YES;
    
    
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;
    
    
    radarTxtView.hidden = NO;
    self.RecvInfo.hidden = NO;
    
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden =  YES;
    self.bn.hidden = YES;
    
    
    self.radarNumUpdate.hidden = YES;
    //    txtView.hidden = YES;
    
    self.updateBn.hidden = YES;
    
    
    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden = YES;
    
    self.radarNumCC.hidden = YES;
    
    self.CCBn.hidden = YES;
    
    
    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    
    
    self.radarNumInfo.hidden = YES;
    self.infoBn.hidden = YES;
    
    self.beginTimePicker.hidden = YES;
    self.endTimePicker.hidden = YES;
    
    self.getCC.hidden = YES;
    self.setCC.hidden = YES;
    self.delCC.hidden = YES;
    
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = YES;
    
    self.searchByTitleField.hidden = YES;
    
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES;
    
    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
    
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;
    
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    
    self.findComNameBn.hidden = NO;
    self.findComNameField.hidden = NO;
    
    self.findComNameVerBn.hidden = YES;
    self.findVersionField.hidden = YES;
    self.findNameField.hidden = YES;
}


-(void)findComNameVerView{
    
    self.globalLb.stringValue = @"findComName";
    
    self.defaultField1.hidden = YES;
    
    
    self.radarNumDelete.hidden = YES;
    self.fileNameDelete.hidden = YES;
    self.bnDelete.hidden = YES;
    
    
    radarTxtView.hidden = NO;
    self.RecvInfo.hidden = NO;
    
    self.radarNum.hidden = YES;
    self.searchFilePathBn.hidden =  YES;
    self.bn.hidden = YES;
    
    
    self.radarNumUpdate.hidden = YES;
    //    txtView.hidden = YES;
    
    self.updateBn.hidden = YES;
    
    
    self.relatedBn.hidden = YES;
    self.radarNumRelated.hidden = YES;
    
    self.radarNumCC.hidden = YES;
    
    self.CCBn.hidden = YES;
    
    
    self.setCCBn.hidden = YES;
    self.radarNumSetCC.hidden = YES;
    
    
    self.radarNumInfo.hidden = YES;
    self.infoBn.hidden = YES;
    
    self.beginTimePicker.hidden = YES;
    self.endTimePicker.hidden = YES;
    
    self.getCC.hidden = YES;
    self.setCC.hidden = YES;
    self.delCC.hidden = YES;
    
    self.searchByTitleBn.hidden = YES;
    self.searchByDateBn.hidden = YES;
    
    self.searchByTitleField.hidden = YES;
    
    self.firstNameField.hidden = YES;
    self.lastNameField.hidden = YES;
    self.findPeopleBn.hidden  = YES;
    
    self.bnList.hidden = YES;
    self.radarNumList.hidden = YES;
    
    self.radarNumDL.hidden = YES;
    self.bnDL.hidden = YES;
    self.savePathBn.hidden = YES;
    
    self.findComVerBn.hidden = YES;
    self.findComVerField.hidden = YES;
    
    self.findComNameBn.hidden = YES;
    self.findComNameField.hidden = YES;

    self.findComNameVerBn.hidden = NO;
    self.findVersionField.hidden = NO;
    self.findNameField.hidden = NO;
}




- (IBAction)test:(id)sender {
    NSSavePanel*    panel = [NSSavePanel savePanel];
    
    NSView *viewExt = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 180, 40)];
    
    NSTextField *labExt = [[NSTextField alloc] initWithFrame:NSMakeRect(0, 10, 80, 20)];
    
    [labExt setBordered:NO];
    
    [labExt setDrawsBackground:NO];
    
    labExt.stringValue = @"File type: ";
    
    NSComboBox *cbExt = [[NSComboBox alloc] initWithFrame:NSMakeRect(80, 8, 100, 25)];
    //[cbExt addItemsWithObjectValues:@[@".bmp", @".jpg", @".png", @".tif"]];
    [cbExt addItemsWithObjectValues:@[@".xls"]];
    cbExt.stringValue = @".txt";
    
    [viewExt addSubview:labExt];
    
    [viewExt addSubview:cbExt];
    
    [panel setAccessoryView:viewExt];
    
    NSInteger result = [panel runModal];
    if (result == NSFileHandlingPanelOKButton)
    {
        NSString *path = [[panel URL] path];
        NSLog(@"path: %@", path);
    }
}

- (IBAction)test2:(id)sender {
    NSOpenPanel *panel = [NSOpenPanel openPanel];
    [panel setMessage:@""];
    [panel setPrompt:@"OK"];
    [panel setCanChooseDirectories:YES];
    [panel setCanCreateDirectories:YES];
    [panel setCanChooseFiles:YES];
    NSString *path_all;
    NSInteger result = [panel runModal];
    if (result == NSFileHandlingPanelOKButton)
    {
        path_all = [[panel URL] path];
        NSLog(@"path_all: %@",path_all);
    }
}

- (IBAction)savePath:(id)sender {
    
    NSSavePanel*    panel = [NSSavePanel savePanel];
    [panel setNameFieldStringValue:@"Untitle.xls"];
    [panel setMessage:@"Choose the path to save the document"];
    [panel setAllowsOtherFileTypes:YES];
    [panel setAllowedFileTypes:@[@"xls", @"txt", @"xlsx"]];
    [panel setExtensionHidden:YES];
    [panel setCanCreateDirectories:YES];
    [panel beginSheetModalForWindow:self.window completionHandler:^(NSInteger result){
        if (result == NSFileHandlingPanelOKButton)
        {
            savePath = [[panel URL] path];
            
            radarTxtView.string = savePath;
            
            NSLog(@"path: %@", savePath);
        }
    }];
}

- (IBAction)getRadarTxt:(id)sender {
    
    NSOpenPanel *panel = [NSOpenPanel openPanel];
    [panel setMessage:@""];
    [panel setPrompt:@"OK"];
    [panel setCanChooseDirectories:YES];
    [panel setCanCreateDirectories:YES];
    [panel setCanChooseFiles:YES];
    
    NSInteger result = [panel runModal];
    if (result == NSFileHandlingPanelOKButton)
    {
        radarTxtInfo = [[panel URL] path];
        NSLog(@"path_all: %@",radarTxtInfo);
        radarTxtView.string = radarTxtInfo;
    }
    
    NSString* txtContent = [NSString stringWithContentsOfFile:radarTxtInfo encoding:NSUTF8StringEncoding error:NULL];
    NSLog(@"string: %@", txtContent);

    NSString* radarTitle = @"\\n\\[Radar Title\\]\\n(.*)\\n\\s*\\n\\[Radar Description\\]\\n((.*\\n)*)";
    
    NSString *pattern_sum = [NSString stringWithFormat:@"%@", radarTitle];
    
    NSRegularExpression *regex = [[NSRegularExpression alloc] initWithPattern:pattern_sum options:NSRegularExpressionCaseInsensitive error:nil];
    
    NSArray *results = [regex matchesInString:txtContent options:0 range:NSMakeRange(0, txtContent.length)];
    NSLog(@"results: %@", results);
    

    radarInfoArr = [NSMutableArray array];
    
    for (NSTextCheckingResult *result in results){
        
        for(int i = 1; i<[result numberOfRanges]; i++){
            
            NSLog(@"[result numberOfRanges]: %lu", (unsigned long)[result numberOfRanges]);
            
            NSString *component = [txtContent substringWithRange:[result rangeAtIndex:i]];
            
            [radarInfoArr addObject:component];
        }
    }
    
    
    [plistHandler write:radarInfoArr[0] toFile:@"/tmp/1.txt"];
    [plistHandler write:radarInfoArr[1] toFile:@"/tmp/2.txt"];
    NSLog(@"uploadRadarArr: %@", radarInfoArr);
}

@end
