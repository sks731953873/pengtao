//
//  ReadExcelTool.m
//  WindowSkip
//
//  Created by gdadmin on 4/21/17.
//  Copyright © 2017 108. All rights reserved.
//

#import "ReadExcelTool.h"
#import "DHxlsReaderIOS.h"

@implementation ReadExcelTool
{
    
    DHxlsReader *reader;
    NSString* excelFilePath;
    NSInteger excelRowCount;
    
}

- (instancetype )initWithFilePath:(NSString*)filePath{
    
    self = [super init];
    if(self){
        reader = [DHxlsReader xlsReaderFromFile:filePath];
        excelRowCount = 3;
    }
    return self;
}

-(NSInteger)getSheetNum{
    
    NSInteger sheetNum = reader.numberOfSheets;
    return sheetNum;
}


-(NSArray* )readExcel:(NSInteger)sheetNum isExcel:(BOOL)isExcel{
    
    NSMutableArray *SNArr = [NSMutableArray array];
    
    while(YES) {
        
        DHcell *cell = [reader cellInWorkSheetIndex:sheetNum row:excelRowCount col:2];
        
 //       NSLog(@"Cell:%@\n", [cell dump]);
        
        if(cell.type == cellBlank){
            
            break;
            
        }else{
            
            [SNArr addObject:[cell dump]];
            
        }
        excelRowCount++;
    }
    
    
//    NSLog(@"SNs: %@", SNArr);
    NSMutableArray *UnistArr = [NSMutableArray array];
    for (int i = 3; i< excelRowCount + 3; i++) {
        DHcell *cell = [reader cellInWorkSheetIndex:sheetNum row:i col:3];
        NSLog(@"Cell:%@\n", [cell dump]);
        
        if(cell.type == cellString){
            [UnistArr addObject:[cell dump]];
        }else{
            
            [UnistArr addObject:@"/"];
        }
    }
   
    
    NSMutableArray *Configs = [NSMutableArray array];
    for (int i = 3; i< excelRowCount + 3; i++) {
        DHcell *cell = [reader cellInWorkSheetIndex:sheetNum row:i col:4];
        NSLog(@"Cell:%@\n", [cell dump]);
        
        if(cell.type == cellString){
            [Configs addObject:[cell dump]];
        }else{
            
            [Configs addObject:@"/"];
        }
    }
    
    
    NSMutableArray *MLBSNs = [NSMutableArray array];
    for (int i = 3; i< excelRowCount + 3; i++) {
        DHcell *cell = [reader cellInWorkSheetIndex:sheetNum row:i col:5];
        NSLog(@"Cell:%@\n", [cell dump]);
        
        if(cell.type == cellString){
            [MLBSNs addObject:[cell dump]];
        }else{
            
            [MLBSNs addObject:@"/"];
        }
    }
   
    
    NSMutableArray *RadarNos = [NSMutableArray array];
    for (int i = 3; i< excelRowCount + 3; i++) {
        DHcell *cell = [reader cellInWorkSheetIndex:sheetNum row:i col:6];
        NSLog(@"Cell:%@\n", [cell dump]);
        
        if(cell.type == cellString){
            [RadarNos addObject:[cell dump]];
        }else{
            
            [RadarNos addObject:@"/"];
        }
    }
    
    NSMutableArray *FailStations = [NSMutableArray array];
    for (int i = 3;i<excelRowCount + 3;i++) {
        DHcell *cell = [reader cellInWorkSheetIndex:sheetNum row:i col:7];
        NSLog(@"Cell:%@\n", [cell dump]);
        
        if(cell.type == cellString){
            [FailStations addObject:[cell dump]];
        }else{
            
            [FailStations addObject:@"/"];
        }
    }
    
    NSLog(@"FailStations2: %@", FailStations);
    
    NSMutableArray *FailureSymptoms = [NSMutableArray array];
    for (int i = 3; i<excelRowCount + 3 ;i++) {
        DHcell *cell = [reader cellInWorkSheetIndex:sheetNum row:i col:8];
        NSLog(@"Cell1:%@\n", [cell dump]);
        if(cell.type == cellString){
            [FailureSymptoms addObject:[cell dump]];
        }else{
            
            [FailureSymptoms addObject:@"/"];
        }
    }
    
    NSMutableArray *AppleGroups = [NSMutableArray array];
    for (int i = 3; i<excelRowCount + 3; i++) {
        DHcell *cell = [reader cellInWorkSheetIndex:sheetNum row:i col:9];
        NSLog(@"Cell:%@\n", [cell dump]);
        if(cell.type == cellString){
            [AppleGroups addObject:[cell dump]];
        }else{
            
            [AppleGroups addObject:@"/"];
        }
    }
    
    NSMutableArray *AppleDRIs = [NSMutableArray array];
    for (int i = 3; i<excelRowCount + 3; i++) {
        DHcell *cell = [reader cellInWorkSheetIndex:sheetNum row:i col:10];
        NSLog(@"Cell:%@\n", [cell dump]);
        
        if(cell.type == cellString){
            [AppleDRIs addObject:[cell dump]];
        }else{
            
            [AppleDRIs addObject:@"/"];
        }
    }
    
    NSMutableArray *HHDRIs = [NSMutableArray array];
    for (int i = 3; i<excelRowCount + 3; i++) {
        DHcell *cell = [reader cellInWorkSheetIndex:sheetNum row:i col:11];
        NSLog(@"Cell:%@\n", [cell dump]);
        
        if(cell.type == cellString){
            [HHDRIs addObject:[cell dump]];
        }else{
            
            [HHDRIs addObject:@"/"];
        }
    }
    
    NSMutableArray *F1Approves = [NSMutableArray array];
    for (int i = 3; i<excelRowCount + 3; i++) {
        DHcell *cell = [reader cellInWorkSheetIndex:sheetNum row:i col:12];
        NSLog(@"Cell:%@\n", [cell dump]);
        
        if(cell.type == cellString){
            [F1Approves addObject:[cell dump]];
        }else{
            
            [F1Approves addObject:@"/"];
        }
    }
    
    NSMutableArray *FADRIs = [NSMutableArray array];
    for (int i = 3; i<excelRowCount + 3; i++) {
        DHcell *cell = [reader cellInWorkSheetIndex:sheetNum row:i col:13];
        NSLog(@"Cell:%@\n", [cell dump]);
        
        if(cell.type == cellString){
            [FADRIs addObject:[cell dump]];
        }else{
            [FADRIs addObject:@"/"];
        }
    }
    
    //    NSMutableArray *Times = [NSMutableArray array];
    //    for (int i = 0; i< FGSNs.count; i++) {
    //        [Times addObject:dateStr];
    //    }
    
    NSMutableArray *Times = [NSMutableArray array];
    for (int i = 3;i < excelRowCount + 3; i++) {
        
        DHcell *cell = [reader cellInWorkSheetIndex:sheetNum row:i col:14];
        NSLog(@"Cell:%@\n", [cell dump]);
        
        
        if(cell.type == cellString){
            NSLog(@"hh");
            [Times addObject:[cell dump]];
        }else if(cell.type == cellUnknown){
            NSLog(@"xx");
            [Times addObject:@"/"];
        }else{
            NSLog(@"gg");
            [Times addObject:@"/"];
        }
    }
    
    NSMutableArray *Remarks = [NSMutableArray array];
    for (int i = 3; i<excelRowCount + 3; i++) {
        DHcell *cell = [reader cellInWorkSheetIndex:sheetNum row:i col:15];
        NSLog(@"Cell:%@\n", [cell dump]);
        
        if(cell.type == cellString){
            [Remarks addObject:[cell dump]];
        }else{
            [Remarks addObject:@"/"];
        }
    }
   
    NSMutableArray *Items = [NSMutableArray array];
    for (int i = 1;i< SNArr.count+1 ; i++) {
        [Items addObject:[NSString stringWithFormat:@"%d", i]];
    }
    
    NSMutableArray* SumArr;
    
    if(!isExcel){
        
       // NSLog(@"SNArr:%@, UnistArr: %@", SNArr, UnistArr);
        SumArr = [NSMutableArray arrayWithObjects:SNArr,UnistArr,Configs,MLBSNs,RadarNos,FailStations,FailureSymptoms,AppleGroups,AppleDRIs,HHDRIs,F1Approves,FADRIs,Times,Remarks, nil];
    }else{
      //  NSLog(@"SNArr:%@, UnistArr: %@", SNArr, UnistArr);
        SumArr = [NSMutableArray arrayWithObjects:Items,SNArr,UnistArr,Configs,MLBSNs,RadarNos,FailStations,FailureSymptoms,AppleGroups,AppleDRIs,HHDRIs,F1Approves,FADRIs,Times,Remarks, nil];
    }

    return SumArr;
}

-(NSArray*)transFromArray:(NSInteger)sheetNum isExcel:(BOOL)isExcel{
    
    NSArray* SumArr = [self readExcel:sheetNum isExcel:isExcel];
    
 //   NSLog(@"SumArr: %@", SumArr);
    
    NSMutableArray *arr = [NSMutableArray array];
    
    for(int i = 0; i< excelRowCount-3;i++){
        for(int j = 0;j<SumArr.count;j++){
            [arr addObject:[NSString stringWithFormat:@"%@",SumArr[j][i]]];
        }
    }
    
//    NSLog(@"arr: %@", arr);

    NSMutableArray* arrs = [NSMutableArray array];
    for (int i = 0; i<(excelRowCount-3)*SumArr.count; i++) {
        
        NSMutableArray *arr1 =[NSMutableArray array];
        NSInteger count =0;
        
        if(isExcel){
            
            while (count != 15 && i < (excelRowCount-3)*SumArr.count) {
                count++;
                [arr1 addObject:arr[i]];
                i++;
            }
        }else{
            
            while (count != 14 && i < (excelRowCount-3)*SumArr.count) {
                count++;
                [arr1 addObject:arr[i]];
                i++;
            }
        }
        [arrs addObject:arr1];
        i--;
    }    
    return arrs;
}

@end