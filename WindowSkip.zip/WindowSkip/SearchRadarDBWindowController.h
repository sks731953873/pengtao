//
//  SearchRadarDBWindowController.h
//  WindowSkip
//
//  Created by gdadmin on 2/21/17.
//  Copyright © 2017 108. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DBManager.h"
#import "CheckQCRTool.h"
#import "RadarTool.h"

@interface SearchRadarDBWindowController : NSWindowController{
    
    IBOutlet NSTableView *searchRadarTableView;
    
    NSTask* task;
    NSPipe* pipe;

}

@property(nonatomic, strong)RadarTool *radarTool;
@property(nonatomic, strong)CheckQCRTool *checkQCRTool;



- (IBAction)backToUploadRadar:(id)sender;
@property (strong) IBOutlet NSButton *backToUploadBn;

@property(nonatomic, copy)NSArray *searchArr;


@property(nonatomic, strong)NSMutableArray *valueArr;
@property(nonatomic, strong) DBManager *dbManager;

@property (strong) IBOutlet NSTextField *searchLog;

@property (strong) IBOutlet NSTextField *searchResult;

@property(nonatomic, strong)NSMutableArray *Items;
@property(nonatomic, strong)NSMutableArray *FGSNs;
@property(nonatomic, strong)NSMutableArray *Units;
@property(nonatomic, strong)NSMutableArray *Configs;
@property(nonatomic, strong)NSMutableArray *MLBSNs;
@property(nonatomic, strong)NSMutableArray *RadarNos;
@property(nonatomic, strong)NSMutableArray *FailStations;
@property(nonatomic, strong)NSMutableArray *FailureSymptoms;
@property(nonatomic, strong)NSMutableArray *AppleGroups;
@property(nonatomic, strong)NSMutableArray *AppleDRIs;
@property(nonatomic, strong)NSMutableArray *HHDRIs;
@property(nonatomic, strong)NSMutableArray *F1Approves;
@property(nonatomic, strong)NSMutableArray *FADRIs;
@property(nonatomic, strong)NSMutableArray *Times;
@property(nonatomic, strong)NSMutableArray *Remarks;



//remove sn
- (IBAction)removeSNItem:(id)sender;
@property (strong) IBOutlet NSButton *removeSNBn;


//choose item
@property (strong) IBOutlet NSPopUpButton *itemToChoice;
- (IBAction)chooseItem:(id)sender;



//excelPath
@property (strong) IBOutlet NSButton *excelPathBn;
- (IBAction)getExcelPath:(id)sender;

//write to specify Excel
@property (strong) IBOutlet NSButton *WSEBn;
@property (strong) IBOutlet NSTextField *excelName;
- (IBAction)writeToSpecifyExcel:(id)sender;

- (IBAction)getSheetNum:(id)sender; //sheetNum
@property (strong) IBOutlet NSPopUpButton *sheetNum;
@property (strong) IBOutlet NSTextField *excel_name;




//write to single excel
@property (strong) IBOutlet NSButton *singleExcelBn;
- (IBAction)writeToSingleExcelBn:(id)sender;

//check SN coorect or not
- (IBAction)checkSNCorrect:(id)sender;
@property (strong) IBOutlet NSButton *checkSNBn;
@property (strong) IBOutlet NSScrollView *displayView;

//


@end
