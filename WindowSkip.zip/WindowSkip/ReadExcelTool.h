//
//  ReadExcelTool.h
//  WindowSkip
//
//  Created by gdadmin on 4/21/17.
//  Copyright © 2017 108. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DHxlsReaderIOS.h"


@interface ReadExcelTool : NSObject

- (instancetype )initWithFilePath:(NSString*)filePath;

-(NSArray*)readExcel:(NSInteger) sheetNum isExcel:(BOOL)isExcel;

-(NSArray*)transFromArray:(NSInteger)sheetNum isExcel:(BOOL)isExcel;

-(NSInteger) getSheetNum;
@end
