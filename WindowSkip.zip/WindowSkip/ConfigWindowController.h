//
//  ConfigWindowController.h
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016 108. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ConfigWindowController : NSWindowController<NSTableViewDelegate, NSTableViewDataSource>{
    
    NSMutableArray *Peoples;
    
    IBOutlet NSTableView *tableViewTest;
    IBOutlet NSTableView *qcrTableView;
    
    IBOutlet NSTableView *fdrTableView;
    
    
//    NSMutableArray *personArr;
//    NSMutableArray *passwdArr;
}


@property(nonatomic , strong) NSMutableArray *personArr;
@property(nonatomic , strong) NSMutableArray *passwdArr;
@property(nonatomic , strong) NSMutableArray *checkArr;

@property(nonatomic , strong) NSMutableArray *qcrPersonArr;
@property(nonatomic , strong) NSMutableArray *qcrPasswdArr;
@property(nonatomic , strong) NSMutableArray *qcrCheckArr;

@property(nonatomic , strong) NSMutableArray *fdrPersonArr;
@property(nonatomic , strong) NSMutableArray *fdrPasswdArr;



@property (strong) IBOutlet NSButton *leftBn;

//radar
@property (strong) IBOutlet NSButton *radarPlusBn;
@property (strong) IBOutlet NSButton *radarMinusBn;

//qcr
@property (strong) IBOutlet NSButton *qcrPlusBn;
@property (strong) IBOutlet NSButton *qcrMinusBn;

//fdr
@property (strong) IBOutlet NSButton *fdrPlusBn;
@property (strong) IBOutlet NSButton *fdrMinusBn;



- (IBAction)backToUM:(id)sender;

- (IBAction)addItem:(id)sender;

- (IBAction)deleteItem:(id)sender;

- (IBAction)addQcrItem:(id)sender;

- (IBAction)deleteQcrItem:(id)sender;

- (IBAction)addFdrItem:(id)sender;

- (IBAction)deleteFdrItem:(id)sender;


- (IBAction)selecteSeg:(id)sender;

@property (strong) IBOutlet NSScrollView *qcrBorderedScro;

@property (strong) IBOutlet NSScrollView *radarBorderedScro;

@property (strong) IBOutlet NSScrollView *fdrBorderedScro;

@property (strong) IBOutlet NSSegmentedControl *segment;

@end
