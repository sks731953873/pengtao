//
//  QCRWindowController.h
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016 108. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CheckQCRTool.h"

@interface QCRWindowController : NSWindowController{
    
    
    NSTask *QCRTask;
    NSPipe *QCRPipe;
}


@property(nonatomic, strong)CheckQCRTool *checkQCRTool;

@property (strong) IBOutlet NSView *qcrView;



- (IBAction)backToUMWindow:(id)sender;

@property (strong) IBOutlet NSButton *qcrLeftBn;

@property (nonatomic, retain) IBOutlet NSView *QCRView;


//defalut
@property (nonatomic, retain) IBOutlet NSTextField *QGlobalLb;
@property (nonatomic, retain) IBOutlet NSTextField *QDefaultField;




//SN record
@property (nonatomic, retain) IBOutlet NSTextField *SNRecField;
@property (nonatomic, retain) IBOutlet NSButton *SNRecBn;


//SN info
@property (nonatomic, retain) IBOutlet NSTextField *SNInfoField;
@property (nonatomic, retain) IBOutlet NSButton *SNInfoBn;

//MLB Record
@property (nonatomic, retain) IBOutlet NSTextField *mlbRecField;
@property (nonatomic, retain) IBOutlet NSButton *mlbRecBn;

//MLB info
@property (nonatomic, retain) IBOutlet NSTextField *mlbInfoField;
@property (nonatomic, retain) IBOutlet NSButton *mlbInfoBn;

//Amount create SNcsv

@property (strong) IBOutlet NSTextField *csvNameField;
@property (strong) IBOutlet NSButton *csvTxtPath;
@property (strong) IBOutlet NSButton *amountCsvBn;


//Amount create SNCSV
- (IBAction)amountMLBCSV:(id)sender;
@property (strong) IBOutlet NSButton *amountMLBcsvBn;




@property (nonatomic, retain) IBOutlet NSTextField *BUILD_EVENT;
@property (nonatomic, retain) IBOutlet NSTextField *MLBSN;
@property (nonatomic, retain) IBOutlet NSTextField *BUILD_MATRIX_CONFIG;
@property (nonatomic, retain) IBOutlet NSTextField *REGION_CODE;
@property (nonatomic, retain) IBOutlet NSTextField *S_BUILD;
@property (nonatomic, retain) IBOutlet NSTextField *MPN;
@property (nonatomic, retain) IBOutlet NSTextField *CHIPID;
@property (nonatomic, retain) IBOutlet NSTextField *ECID;
@property (nonatomic, retain) IBOutlet NSTextField *BB_SNUM;
@property (nonatomic, retain) IBOutlet NSTextField *EOUSB;
@property (nonatomic, retain) IBOutlet NSTextField *JULIET_SN;
@property (nonatomic, retain) IBOutlet NSTextField *ROSALINE_SN;
@property (nonatomic, retain) IBOutlet NSTextField *UDID;
@property (nonatomic, retain) IBOutlet NSTextField *WIFI;
@property (nonatomic, retain) IBOutlet NSTextField *CG_SN;
@property (nonatomic, retain) IBOutlet NSTextField *CHIPVER;
@property (nonatomic, retain) IBOutlet NSTextField *UNIT;
@property (nonatomic, retain) IBOutlet NSTextField *IMEI;
@property (nonatomic, retain) IBOutlet NSTextField *NANDCS;
@property (nonatomic, retain) IBOutlet NSTextField *BT;
@property (nonatomic, retain) IBOutlet NSTextField *ROMEO_SN;
@property (nonatomic, retain) IBOutlet NSTextField *SAVAGE_SN;
@property (nonatomic, retain) IBOutlet NSTextField *MESA_MODULE_SN;
@property (nonatomic, retain) IBOutlet NSTextField *PRODUCTION_SOC;




//itemChoice
@property (nonatomic, retain) IBOutlet NSPopUpButton *QCRItemChioce;
@property (nonatomic, retain) IBOutlet NSScrollView *QCRDisplay;


- (IBAction)SendSNRec:(id)sender;
- (IBAction)SendSNInfo:(id)sender;
- (IBAction)SendMLBRec:(id)sender;
- (IBAction)SendMLBInfo:(id)sender;
- (IBAction)QitemChoose:(id)sender;
- (IBAction)writeCSV:(id)sender;
- (IBAction)amountWriteCSV:(id)sender;
- (IBAction)searchCSVPath:(id)sender;




@end
