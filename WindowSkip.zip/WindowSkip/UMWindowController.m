//
//  NewsWindowController.m
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016年 108. All rights reserved.
//

#import "UMWindowController.h"
#import "AppDelegate.h"
#import "RadarWindowController.h"
#import "QCRWindowController.h"
#import "FDRSealWindowController.h"
#import "MainWindowController.h"
#import "ConfigWindowController.h"
#import "DownloadAttachWindowsController.h"

@interface UMWindowController ()

@property(strong) RadarWindowController *RadarWindow;

@property(strong) QCRWindowController *QCRWindow;

@property(strong) FDRSealWindowController *FDRWindow;

@property(strong) ConfigWindowController  *configWindow;

@property(strong) MainWindowController *mainWindow;

@property(strong) DownloadAttachWindowsController* DownloadAttachWindow;

@end

@implementation UMWindowController

- (void)windowDidLoad {
    [super windowDidLoad];
    
    _bgView.wantsLayer = YES;
    _bgView.layer.backgroundColor = CGColorCreateGenericRGB(0.9f, 1.0f, 0.9f, 0.9f);
    
    
}

- (IBAction)backToMainWindow:(id)sender {
    NSAlert *alert = [NSAlert alertWithMessageText:@"Do you want to logout?" defaultButton:@"LogOut" alternateButton:@"cancel" otherButton:nil informativeTextWithFormat:@"Do you want to save the data?"];
    [alert beginSheetModalForWindow:[self window] modalDelegate:self didEndSelector:@selector(alertEnded:code:context:) contextInfo:NULL];
}

- (void)alertEnded:(NSAlert *)alert
              code:(NSInteger)choice
           context:(void *)v
{
    NSLog(@"Alert sheet ended");

    if (choice == NSAlertDefaultReturn) {

        NSArray *temp = [NSArray arrayWithObjects:@"",@"", nil];
        
        
        
        _mainWindow = [[MainWindowController alloc] initWithWindowNibName:@"MainWindowController"];
        
        _mainWindow.clearUseName = temp[0];
        _mainWindow.clearPassWd = temp[1];
        
        [_mainWindow.window orderFront:nil];
        [_mainWindow.window center];
//        [self.window orderFront:nil];
        [self.window close];
        
        /*
        AppDelegate * appDelegate=(AppDelegate*)[[NSApplication sharedApplication]delegate];
        [self.window close];
        [appDelegate.mainWindow.window center];
        [[appDelegate.mainWindow window] makeKeyAndOrderFront:nil];
         */
    
    }
}




- (IBAction)nextToRadar:(id)sender {
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    
    [nc removeObserver:self];
    
    _RadarWindow = [[RadarWindowController alloc] initWithWindowNibName:@"RadarWindowController"];
    
    [_RadarWindow.window orderFront:nil];
    
    [_RadarWindow.window center];
    
    [self.window orderOut:nil];
}


- (IBAction)nextToQCR:(id)sender {
    _QCRWindow = [[QCRWindowController alloc] initWithWindowNibName:@"QCRWindowController"];
    
    [_QCRWindow.window orderFront:nil];
    
    [_QCRWindow.window center];
    
    [self.window orderOut:nil];
}


- (IBAction)nextToFDR:(id)sender {
    
    _FDRWindow = [[FDRSealWindowController alloc] initWithWindowNibName:@"FDRSealWindowController"];
    
    [_FDRWindow.window orderFront:nil];
    
    [_FDRWindow.window center];
    
    [self.window orderOut:nil];
    
    
 //   [NSThread sleepForTimeInterval:2.5];
    
    _DownloadAttachWindow = [[DownloadAttachWindowsController alloc] initWithWindowNibName:@"DownloadAttachWindowsController"];
    
    [_DownloadAttachWindow.window orderFront:nil];
    
    //    [_DownloadAttachWindow.window center];
}


- (IBAction)nextToConfig:(id)sender {
    
    _configWindow = [[ConfigWindowController alloc] initWithWindowNibName:@"ConfigWindowController"];
    
    
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"NO"];//添加按钮
    [alert addButtonWithTitle:@"YES"];
    [alert setInformativeText:@"警告文本信息？"];
    
    
    
    [alert messageText];
    [alert setAlertStyle:NSInformationalAlertStyle];
    [alert beginSheetModalForWindow:[self window ] completionHandler:^(NSModalResponse returnCode) {
        if(returnCode == NSAlertFirstButtonReturn){
            //第一个按钮被按下后执行
            
        }
        if(returnCode == NSAlertSecondButtonReturn)
        {
            [_configWindow.window orderFront:nil];
            
            [_configWindow.window center];
            
            [self.window orderOut:nil];
        }
        
    }];
    
    
//    [_configWindow.window orderFront:nil];
//    
//    [_configWindow.window center];
//    
//    [self.window orderOut:nil];
}

@end
