//
//  CheckRadarTool.h
//  WindowSkip
//
//  Created by gdadmin on 4/6/17.
//  Copyright © 2017 108. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString* const stringChangeNotification;

@interface CheckQCRTool : NSObject{
    
    NSString* string;
    
}

@property(nonatomic, strong) NSArray *resultArr;

-(instancetype) initWithArr:(NSArray*)array;

-(NSString *)getQCRAccount;

-(NSString *)getQCRPath;

-(void) excuteQCRTask;

-(NSString *)excuteAnotherTask;

@end
