//
//  MainWindowController.h
//  WindowSkip
//
//  Created by gdadmin on 16/11/27.
//  Copyright © 2016年 108. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MainWindowController : NSWindowController
@property (strong) IBOutlet NSView *bgView;
- (IBAction)nextToUMWindow:(id)sender;





@property (strong) IBOutlet NSTextField *userName;
@property (strong) IBOutlet NSSecureTextField *passWord;
@property (strong) IBOutlet NSTextField *incorrectInfo;
@property (nonatomic, copy) NSString *clearUseName;
@property (nonatomic, copy) NSString *clearPassWd;



@end
