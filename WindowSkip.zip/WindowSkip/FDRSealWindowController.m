//
//  SearchWindowController.m
//  WindowSkip
//
//  Created by gdadmin on 2/9/17.0
//  Copyright © 2017 108. All rights reserved. 
// C39SL01GHNW0/C39SX03JHNVR/C39T100KHWHN
// 29041667/85063/iris

#import "FDRSealWindowController.h"
#import <sqlite3.h>

#import "PlistTool.h"
#import "SearchRadarDBWindowController.h"
#import "UMWindowController.h"
#import "DownloadAttachWindowsController.h"
#import "SearchLocalDBWindowController.h"
#import "DBManager.h"
#import <DHxls/DHWorkBook.h>
#import "CheckQCRTool.h"
#import "ReadExcelTool.h"


#define DBNAME @"DataBase.db"
#define SINGLE_WRITEDB_MODE 1
#define CHECKIN_MODE 2
#define DEFAULT_MODE 0
#define EXCEL_LINE_COUNT 14


//
#define SN_MODE 3
#define MLB_MODE 4

@interface FDRSealWindowController ()

@property(strong) FDRSealWindowController* FDRSealWindow;
@property(strong) UMWindowController *UMWindow;
@property(strong) SearchRadarDBWindowController *SearchRadarDBWindow;
@property(strong) SearchLocalDBWindowController *SearchLocalDBWindow;
@property(strong) DownloadAttachWindowsController *downloadAttachWindow;
@property(nonatomic ,strong) ReadExcelTool* readExcel;

@end


@implementation FDRSealWindowController{
    
    //currentDirectory
    NSFileManager *fileManager;
    NSString *currentDire;
    
    PlistTool *plistHandler;
    
    //radarAccount
    NSString *uploadRadarKey;
    NSString *uploadRadarValue;
    NSString *uploadRadarAccount;
    
    //qcrAccount
    NSString *qcrKey;
    NSString *qcrValue;
    NSString *qcrAccount;
    
    //display
    NSTextView *fdrTxtView;
    NSTextView *remarkTxt;
    
    NSMutableArray *upRadarPattrernArr;
    
    //mode change
    NSInteger switchMode;
    
    
    //gloabal MLB
    NSMutableArray *patternArr;
    
    //search result
    NSMutableArray *searchRadarResult;
    NSMutableArray *searchLocalResult;
    
    //search localDB SN result
    NSMutableArray *searchLocalSNResult;
    
    //search localDB MLB result
    NSMutableArray *excelArrResult;
    
    //switch mlb or sn
    BOOL switchSNMlb;
    
    //team choice
    NSString *teamChoice;
    
    //nowTime
    NSString *nowtimeStr;
    
    //在radar中使用的时间
    NSString *getTime;
    
    //filePath
    NSString *excelPath;
    
    //
    NSString *fdrToolPath;

}

NSMutableArray *itemArr;
NSMutableArray *SNArr;
NSMutableArray *UnitsArr;
NSMutableArray *ConfigArr;
NSMutableArray *MLBSNArr;
NSMutableArray *RadarNoArr;
NSMutableArray *FailStationArr;
NSMutableArray *FailureSymptomArr;
NSMutableArray *AppleGroupArr;
NSMutableArray *AppleDriArr;
NSMutableArray *HHDriArr;
NSMutableArray *F1ApproveArr;
NSMutableArray *FADriArr;
NSMutableArray *DateArr;
NSMutableArray *RemarkArr;
NSMutableArray *temp;


- (void)windowDidLoad {
    [super windowDidLoad];
    
    NSLog(@"time: %@", _time);
    
    //调整window尺寸
    // _windowSize.contentLayoutRect.size = NSMakeSize(500, 500);
    
//    NSString* filePath = @"/Users/DemonZhu/Desktop/SHEET1.xls";
//    
//    _readExcel = [[ReadExcelTool alloc] initWithFilePath:filePath];
//    
//    NSArray* readResult = [_readExcel readExcel:0];
//    
//    NSLog(@"readResult: %@", readResult);
    
    
    //fileManager
    fileManager = [NSFileManager defaultManager];
    currentDire = [fileManager currentDirectoryPath];
    
    //init
    _dbManager = [[DBManager alloc] initWithDatabaseFilename:DBNAME];
    
    //初始化switchMode
    switchMode = DEFAULT_MODE;
    
    //初始化Radar主题
    self.UploadLb.textColor=[NSColor blackColor];
    self.UploadLb.font=[NSFont fontWithName:@"Helvetica" size:16.0];
    self.UploadLb.stringValue= @"FDRSeal";
    
    //leftBn
    [self.searchLftBn setButtonType: NSMomentaryPushInButton];
    [self.searchLftBn setBezelStyle: NSRoundedBezelStyle];
    [self.searchLftBn setBordered: NO];
    [self.searchLftBn setImage: [NSImage imageNamed: @"left_highlighted"]];
    [self.searchLftBn setImagePosition: NSImageOnly];
    [self.searchLftBn setTarget: self];
    
    //getPath
    [self.getPathBn setButtonType: NSMomentaryPushInButton];
    [self.getPathBn setBezelStyle: NSRoundedBezelStyle];
    [self.getPathBn setBordered: NO];
    [self.getPathBn setImage: [NSImage imageNamed: @"fileFolder.png"]];
    [self.getPathBn setImagePosition: NSImageOnly];
    [self.getPathBn setTarget: self];

    
    //uploadRadarView
    fdrTxtView =[[NSTextView alloc]initWithFrame:CGRectMake(47, 0, 580, 98)];
    [fdrTxtView setTextColor:[NSColor blackColor]];
    [self.uploadRadarDisplay  setDocumentView:fdrTxtView];
    [self.window.contentView addSubview:self.uploadRadarDisplay ];
    
    fdrTxtView.editable = NO;
    
    [fdrTxtView setMinSize:NSMakeSize(0.0, 98)];
    [fdrTxtView setMaxSize:NSMakeSize(FLT_MAX, FLT_MAX)];
    [fdrTxtView setVerticallyResizable:YES];
    [fdrTxtView setHorizontallyResizable:NO];
    [fdrTxtView setAutoresizingMask:NSViewWidthSizable];
    [[fdrTxtView textContainer] setContainerSize:NSMakeSize(60000, FLT_MAX)];
    [[fdrTxtView textContainer] setWidthTracksTextView:YES];
    
    [fdrTxtView setFont:[NSFont fontWithName:@"Helvetica" size:13.0]];
    fdrTxtView.textColor = [NSColor redColor];
    
    
    //remarkTxt
    [self.remarkScroll  setHasVerticalScroller:YES];
    [self.remarkScroll  setHasHorizontalScroller:YES];
    [self.remarkScroll  setAutoresizingMask:NSViewWidthSizable | NSViewHeightSizable];
    
    
    remarkTxt =[[NSTextView alloc]initWithFrame:CGRectMake(47, 0, 580, 98)];
    [self.remarkScroll  setDocumentView:remarkTxt];
    [self.window.contentView addSubview:self.remarkScroll];
    remarkTxt.editable = YES;
    remarkTxt.hidden = YES;
    
    [remarkTxt setMinSize:NSMakeSize(0.0, 98)];
    [remarkTxt setMaxSize:NSMakeSize(FLT_MAX, FLT_MAX)];
    [remarkTxt setVerticallyResizable:YES];
    [remarkTxt setHorizontallyResizable:YES];
    [remarkTxt setAutoresizingMask:NSViewWidthSizable];
    [[remarkTxt textContainer]setContainerSize:NSMakeSize(60000,FLT_MAX)];
    [[remarkTxt textContainer]setWidthTracksTextView:YES];
    [remarkTxt setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
    remarkTxt.textColor = [NSColor blackColor];
    
    //radarBegin time
    [self.radarBeginFormatter setDateFormat:@"yyyy-MM-dd"];
    self.radarBeginTime.datePickerMode = kCFDateFormatterNoStyle;
    self.radarBeginTime.formatter = self.radarBeginFormatter;
    self.radarBeginTime.backgroundColor = [NSColor whiteColor];
    self.radarBeginTime.dateValue = [NSDate date];
    self.radarBeginTime.hidden = YES;
    NSLog(@"radarBeginTime: %@", self.radarBeginTime.dateValue);
    
    //radarEnd time
    [self.radarEndFormatter setDateFormat:@"yyyy-MM-dd"];
    self.radarEndTime.datePickerMode = kCFDateFormatterNoStyle;
    self.radarEndTime.formatter = self.radarBeginFormatter;
    self.radarEndTime.backgroundColor = [NSColor whiteColor];
    self.radarEndTime.dateValue = [NSDate date];
    NSLog(@"self.radarEndTime.dateValue: %@", self.radarEndTime.dateValue);
    
    //set beijing time
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterFullStyle];// 修改下面提到的北京时间的日期格式
    [formatter setTimeStyle:NSDateFormatterFullStyle];// 修改下面提到的北京时间的时间格式
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss SSS"];// 此行代码与上面两行作用一样，故上面两行代码失效
    NSDate *datenow = [NSDate date];// 当前北京时间2016-06-28 13:**:** ***（可以获取当前北京时间、当前格林尼治时间、当前北京时间戳）
    nowtimeStr = [formatter stringFromDate:datenow];
    NSLog(@"nowtimeStr: %@", nowtimeStr);// 这个时间是北京时间
    
    
    self.radarEndTime.hidden = YES;
    self.searchRadaByTimeBn.hidden = YES;
    
    //current date， 当前时间
    NSString *time = [NSString stringWithFormat:@"%@",self.radarEndTime.dateValue];
    NSArray* temp = [time componentsSeparatedByString:@" "];
    self.currentDate.stringValue = temp[0];
    
    //localDByTime
    self.searchLocalDByTimeBn.hidden = YES;
    
    //uploadRadar
    self.FGSN.hidden = YES;
    self.Config.hidden = YES;
    self.MLBSN.hidden = YES;
    self.FailureSymptom.hidden = YES;
    self.FailStation.hidden = YES;
    self.Date.hidden = YES;
    
    self.Unit.hidden = YES;
    self.RadarNo.hidden = YES;
    self.HHDRI.hidden = YES;
    self.FADRI.hidden = YES;
    self.APPLEDRI.hidden = YES;
    self.F1Approve.hidden = YES;
    self.AppleGroup.hidden = YES;
    
    self.FGSNLb.hidden = YES;
    self.ConfigLb.hidden = YES;
    self.mlbSNLb.hidden = YES;
    self.FailureLb.hidden = YES;
    self.FSLb.hidden = YES;
    self.dateLb.hidden = YES;
    self.remarkLb.hidden = YES;

    
    self.UnitLb.hidden = YES;
    self.RadarNoLb.hidden= YES;
    self.HHDRILb.hidden = YES;
    self.FADRILb.hidden= YES;
    self.AppleDriLb.hidden = YES;
    self.F1ApproveLb.hidden = YES;
    self.AppleGroupLb.hidden = YES;
    
    //SingleWriteToRadarDB field
    self.SingleWriteToRadarDBn.hidden = YES;
    self.singleWriteRadarDBField.hidden = YES;
    
    
    //gloabalLb
    self.gloabalLb.stringValue = @"uploadRadar";
    self.gloabalLb.hidden = NO;
    
    //
    self.writeExcelBn.hidden = YES;
    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //writeLocalDBn/writeToRadarDBn
    self.writeLocalDBn.hidden = YES;
    self.writeToRadarDBn.hidden = YES;
    self.GetAppDriBn.hidden = YES;
    
    //checkIn
    self.checkInSM.hidden = NO;
    self.checkInBn.hidden = NO;
    self.checkInBn.stringValue = @"CheckIN";
    
    //seachRadarDB
    self.searchDB.hidden = YES;
    self.seachRadarDB.hidden = YES;
    self.seachRadarDB.stringValue = @"searchRadarDB";
    
    //searchLocalSNDB
    self.searchLocalDBField.hidden = YES;
    self.searchLocalSNBn.hidden = YES;
    self.searchLocalSNBn.stringValue = @"searchLocalDB";

    self.radarBeginTime.hidden = YES;
    
    //team
    self.team.hidden = YES;
    self.teamLb.hidden = YES;
    
    //remarkTxt
    self.remarkScroll.hidden = YES;
}


-(void)initInstance{
    
    
    
    
    
}

#pragma --remark -- checkin or single write to RadarDB
- (IBAction)checkIn:(id)sender {
    
    if([self.checkInSM.stringValue isEqualToString:@""]){
        
        return;
        
    }else{
        switchMode = CHECKIN_MODE;
        
        fdrTxtView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"info",self.checkInSM.stringValue, nil];
        NSLog(@"arr: %@", arr);
        _checkQCRTool = [[CheckQCRTool alloc] initWithArr:arr];
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        [_checkQCRTool excuteQCRTask];
        [nc addObserver:self
               selector:@selector(handleStringChange:)
                   name:stringChangeNotification
                 object:nil];
    }
}

-(void)handleStringChange:(NSNotification*) note{
    
    NSLog(@"Received notification: %@", note);
    
    //radarTxtView.string = @"";
    
    NSString *string = [[note userInfo] objectForKey:@"string"];
    
    NSTextStorage *ts = [fdrTxtView textStorage];
    [fdrTxtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
    [ts replaceCharactersInRange:NSMakeRange([ts length], 0) withString:string];
    
    
    //判断excuteQCRTask函数是否执行完成
    id temp = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSArray *tempArr = [temp componentsSeparatedByString:@"\n"];
    NSString* temp1= [tempArr lastObject];
    id temp2 = [temp1 stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSArray *tempArr1 = [temp2 componentsSeparatedByString:@" ="];
    
    if([tempArr1[0] isEqualToString:@"PRODUCTION_SOC"]){
        
        if(switchMode==CHECKIN_MODE){
            
            [self checkInMode];
            
        }else if(switchMode==SINGLE_WRITEDB_MODE){
            
            [self singleWriteRadarDB];
        }
    }
}


- (IBAction)SingleWriteToRadarDB:(id)sender {
    if([self.singleWriteRadarDBField.stringValue isEqualToString:@""]){
        NSLog(@"f");
        return;
    }else{
        
        switchMode = SINGLE_WRITEDB_MODE;
        fdrTxtView.string = @"";
        NSArray *arr = [NSArray arrayWithObjects:@"info", self.singleWriteRadarDBField.stringValue, nil];
        NSLog(@"arr: %@", arr);
        _checkQCRTool = [[CheckQCRTool alloc] initWithArr:arr];
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc removeObserver:self];
        
        [_checkQCRTool excuteQCRTask];
        
        [nc addObserver:self
               selector:@selector(handleStringChange:)
                   name:stringChangeNotification
                 object:nil];
        
        NSLog(@"Registered with notification center");
    }
}

-(void)clearTextField{
    _FGSN.stringValue = @"";
    _Config.stringValue = @"";
    _MLBSN.stringValue = @"";
    _FailureSymptom.stringValue = @"";
    _FailStation.stringValue = @"";
    _Unit.stringValue = @"";
    _RadarNo.stringValue = @"";
    _HHDRI.stringValue = @"";
    _FADRI.stringValue = @"";
    _APPLEDRI.stringValue = @"";
    _F1Approve.stringValue = @"";
    _AppleGroup.stringValue = @"";
    remarkTxt.string = @"";
}


-(void)checkInMode{
    NSArray *patternSNArr = [self getUnitInfo];
    
    //clear textField
    [self clearTextField];
    
    //作为radar数据库使用
    self.FGSN.stringValue = self.checkInSM.stringValue;
    
    //self.MLBSN.stringValue = [patternSNArr[0] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    self.MLBSN.stringValue = patternSNArr[0];
    self.Config.stringValue = patternSNArr[12];
    

    
    //填写radar界面出现
    if(patternSNArr){
        
        //将window尺寸变换
        _FDRSealWindow.window.contentMinSize = NSMakeSize(750, 650);
        _FDRSealWindow.window.contentMaxSize = NSMakeSize(750, 650);
        _FDRSealWindow.window.maxFullScreenContentSize = NSMakeSize(750, 650);
        _FDRSealWindow.window.minFullScreenContentSize = NSMakeSize(750, 650);
        
        [self uploadView];
    }
}


-(void)singleWriteRadarDB{
    
    NSArray *patternSNArr = [self getUnitInfo];
    
    //clear textField
    [self clearTextField];
    
    //作为radar数据库使用
    self.FGSN.stringValue = self.singleWriteRadarDBField.stringValue;
    
    self.MLBSN.stringValue = patternSNArr[0];
    self.Config.stringValue = patternSNArr[12];
    self.Unit.stringValue = [NSString stringWithFormat:@"%@_%@_%@", patternSNArr[11], patternSNArr[12], patternSNArr[18]];
    
    //填写radar界面出现
    if(patternArr){
        [self singleSNDBView];
    }
}

- (IBAction)writeLocalDB:(id)sender {
    
    const char * createSQL = "create table if not exists local_Info \
    (_id integer primary key autoincrement,\
    SN,\
    Config,\
    MLBSN,\
    failStation,\
    failureSymptom,\
    faDri,\
    Date,\
    remark,\
    team)";
    
    int temp = [_dbManager createTableWithSql:createSQL];
    if(temp){
        
   //     NSString* remarkTxt = [remarkTxt.string string];
        
        NSString *query = [NSString stringWithFormat:@"insert into local_Info values(null, '%@', '%@', '%@', '%@', '%@', '%@', '%@','%@', '%s')", _FGSN.stringValue,_Config.stringValue,_MLBSN.stringValue, _FailStation.stringValue, _FailureSymptom.stringValue,_FADRI.stringValue, _Date.stringValue, remarkTxt.string, [teamChoice UTF8String]];
        NSLog(@"query: %@", query);
        [_dbManager executeQuery:query];
        
        if (self.dbManager.affectedRows != 0) {
            NSLog(@"Query was executed successfully. Affected rows = %d", self.dbManager.affectedRows);
            fdrTxtView.string = [NSString stringWithFormat:@"Query was executed successfully. Affected rows = %d", self.dbManager.affectedRows];
        }
        else{
            fdrTxtView.string = @"Could not execute the query.";
            NSLog(@"Could not execute the query.");
        }
        [fdrTxtView setTextColor:[NSColor redColor]];
    }
}


-(NSArray*)getUnitInfo{
    
    NSString *MLBSN = @"\\n\\s*MLBSN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BB_SNUM = @"\\s*BB_SNUM\\s=((\\s*)||(.*))\\s*\\n";
    NSString *CHIPID = @"\\s*CHIPID\\s=((\\s*)||(.*))\\s*\\n";
    NSString *CHIPVER = @"\\s*CHIPVER\\s=((\\s*)||(.*))\\s*\\n";
    NSString *ECID = @"\\s*ECID\\s=((\\s*)||(.*))\\s*\\n";
    NSString *NANDCS = @"\\s*NANDCS\\s=((\\s*)||(.*))\\s*\\n";
    NSString *WIFI = @"\\s*WIFI_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BT = @"\\s*BT_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
    NSString *EOUSB = @"\\s*EOUSB_MAC_ADDR\\s=((\\s*)||(.*))\\s*\\n";
    NSString *UDID = @"\\s*UDID\\s=((\\s*)||(.*))\\s*\\n";
    NSString *IMEI = @"\\s*IMEI\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BUILD_EVENT = @"\\s*BUILD_EVENT\\s=((\\s*)||(.*))\\s*\\n";
    NSString *BUILD_MATRIX_CONFIG = @"\\s*BUILD_MATRIX_CONFIG\\s=((\\s*)||(.*))\\s*\\n";
    NSString *S_BUILD = @"\\s*S_BUILD\\s=((\\s*)||(.*))\\s*\\n";
    NSString *CG_SN = @"\\s*CG_SN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *MESA_MODULE_SN = @"\\s*MESA_MODULE_SN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *MPN = @"\\s*MPN\\s=((\\s*)||(.*))\\s*\\n";
    NSString *REGION_CODE = @"\\s*REGION_CODE\\s=((\\s*)||(.*))\\s*\\n";
    NSString *UNIT = @"\\s*UNIT#\\s=((\\s*)||(.*))\\s*\\n";
    NSString *ROMEO_SN = @"\\s*ROMEO_SN\\s=((\\s*)||(.*))\\n";
    NSString *ROSALINE_SN = @"\\s*ROSALINE_SN\\s=((\\s*)||(.*))\\n";
    NSString *SAVAGE_SN = @"\\s*SAVAGE_SN\\s=((\\s*)||(.*))\\n";
    NSString *JULIET_SN = @"\\s*JULIET_SN\\s=((\\s*)||(.*))\\n";
    NSString *PRODUCTION_SOC = @"\\s*PRODUCTION_SOC\\s=((\\s*)||(.*))\\s*\\n";
    
    // C39SL01GHNW0/C39SX03JHNVR/C39T100KHWHN
    NSString *pattern_sum = [NSString stringWithFormat:@"%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@|%@",MLBSN, BB_SNUM, CHIPID, CHIPVER, ECID, NANDCS, WIFI, BT, EOUSB, UDID, IMEI, BUILD_EVENT, BUILD_MATRIX_CONFIG, S_BUILD, CG_SN,MESA_MODULE_SN, MPN, REGION_CODE, UNIT, ROMEO_SN, ROSALINE_SN, SAVAGE_SN, JULIET_SN, PRODUCTION_SOC];
    
    NSRegularExpression *regex = [[NSRegularExpression alloc] initWithPattern:pattern_sum options:NSRegularExpressionCaseInsensitive error:nil];
    NSArray *results = [regex matchesInString:fdrTxtView.string options:0 range:NSMakeRange(0, fdrTxtView.string.length)];
    
    patternArr = [NSMutableArray array];
    for (NSTextCheckingResult *result in results){
        // NSLog(@"%@ %@", NSStringFromRange(result.range), [QCRInfo substringWithRange:result.range]);
        NSRange range = {(int)(result.range.location + 23), (int)(result.range.length -23)};
        NSString* temp = [fdrTxtView.string substringWithRange:range];
        //[patternArr addObject:[temp stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
        [patternArr addObject:[temp stringByReplacingOccurrencesOfString:@"\n" withString:@""]];
    }

    patternArr[0] = [patternArr[0] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return patternArr;
}


#pragma remark -- search radar database
- (IBAction)searchRadarDB:(id)sender {
    
    // NSLog(@"self.searchDB.stringValue: %@", self.searchDB.stringValue)
    
    if(![self.searchDB.stringValue isEqualToString:@""] && self.searchDB.stringValue.length >0){
        
        NSArray *searchRadarArr = [self searchRadarDBySN:self.searchDB.stringValue];
        
        NSLog(@"searchRadarArr: %@", searchRadarArr);
        
        if(searchRadarArr.count == 0){
            fdrTxtView.string = [NSString stringWithFormat:@"%@ not exist in Radar database", _searchDB.stringValue];
            [fdrTxtView setTextColor:[NSColor redColor]];
            return;
        }
        
        //next to _SearchRadarDBWindow
        _SearchRadarDBWindow = [[SearchRadarDBWindowController alloc] initWithWindowNibName:@"SearchRadarDBWindowController"];
        _SearchRadarDBWindow.searchArr = searchRadarArr;
        [_SearchRadarDBWindow.window orderFront:nil];
        [_SearchRadarDBWindow.window center];
       // [self.window orderOut:nil];
    }
}


-(NSArray *)searchRadarDBySN: (NSString *)searchSN {

    NSString *query = [NSString stringWithFormat:@"select * from radar_Info where FGSN='%@'", searchSN];
    NSArray *arrUnitInfo = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
    return arrUnitInfo;
}


#pragma remark -- search radar Database by date
- (IBAction)searchRadarDByTime:(id)sender {
    
    NSArray *searchRadarTimeArr = [self searchRadarDBByDate];
    
    NSLog(@"searchRadarTimeArr: %@", searchRadarTimeArr);
    
    _SearchRadarDBWindow = [[SearchRadarDBWindowController alloc] initWithWindowNibName:@"SearchRadarDBWindowController"];
    
    _SearchRadarDBWindow.searchArr = searchRadarTimeArr;
    [_SearchRadarDBWindow.window orderFront:nil];
    [_SearchRadarDBWindow.window center];
 //   [self.window orderOut:nil];
}

-(NSArray *)searchRadarDBByDate{
    
    NSString *query= [NSString stringWithFormat:@"select * from radar_Info where Time between '%@' and '%@'", self.radarBeginTime.stringValue, self.radarEndTime.stringValue];
    NSLog(@"query: %@", query);
    NSArray *arrUnitDate = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
    return arrUnitDate;
}


#pragma remark -- search local database by date
- (IBAction)searchLocalDByTime:(id)sender {
    
    _SearchLocalDBWindow = [[SearchLocalDBWindowController alloc] initWithWindowNibName:@"SearchLocalDBWindowController"];
    
    NSArray *searchLocalTimeArr = [self searchLocalDBByDate];
    
    NSLog(@"searchLocalArr: %@", searchLocalTimeArr);
    
    if(searchLocalTimeArr.count == 0){
        
        fdrTxtView.string = @"Not exist the data in database";
        [fdrTxtView setTextColor:[NSColor redColor]];
        return;
    }
    
    //next to _SearchRadarDBWindow
    _SearchLocalDBWindow.searchLocalArr = searchLocalTimeArr;
    [_SearchLocalDBWindow.window orderFront:nil];
    [_SearchLocalDBWindow.window center];
    //[self.window orderOut:nil];
}

-(NSArray*)searchLocalDBByDate{
    NSString *query= [NSString stringWithFormat:@"select * from local_Info where date between '%@' and '%@'", self.radarBeginTime.stringValue, self.radarEndTime.stringValue];
    NSLog(@"query: %@", query);
    NSArray *arrLocalUnitByDate = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
    return arrLocalUnitByDate;
}


#pragma remark -- seach local database by SN
- (IBAction)searchLocalSN:(id)sender {
    
    if(![self.searchLocalDBField.stringValue isEqualToString:@""] && self.searchLocalDBField.stringValue.length >0){
        
        _SearchLocalDBWindow = [[SearchLocalDBWindowController alloc] initWithWindowNibName:@"SearchLocalDBWindowController"];
        
        NSArray *searchLocalArr = [self searchLocalSNDataBase:self.searchLocalDBField.stringValue];
        
        NSLog(@"searchLocalArr: %@", searchLocalArr);
        
        if(searchLocalArr.count == 0){
            fdrTxtView.string = @"Not exist the data in database";
            [fdrTxtView setTextColor:[NSColor redColor]];
            return;
        }
        //next to _SearchRadarDBWindow
        _SearchLocalDBWindow.searchLocalArr = searchLocalArr;
        [_SearchLocalDBWindow.window orderFront:nil];
        [_SearchLocalDBWindow.window center];
        //[self.window orderOut:nil];
    }
}

-(NSArray *)searchLocalSNDataBase:(NSString*)searchSN{
    
    NSString *query = [NSString stringWithFormat:@"select * from local_Info where SN='%@'", searchSN];
    NSArray *arrLocalUnit = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
    return arrLocalUnit;
}

#pragma remark -- back to UnitManage UI
- (IBAction)backToUM:(id)sender {
    _UMWindow = [[UMWindowController alloc] initWithWindowNibName:@"UMWindowController"];
    [_UMWindow.window orderFront:nil];
    [_UMWindow.window center];
    [self.window orderOut:nil];
}


#pragma remark -- single writeToRadarDB
- (IBAction)writeSingleToRadarDB:(id)sender {

    const char * createSQL = "create table if not exists radar_Info \
    (_id integer primary key autoincrement,\
    FGSN,\
    Unit,\
    Config,\
    MLBSN,\
    RadarNo,\
    FailStation,\
    FailureSymptom,\
    AppleGroup,\
    AppleDRI,\
    HHDRI,\
    F1Approve,\
    FADRI,\
    Time,\
    Remark)";

    int temp = [_dbManager createTableWithSql:createSQL];
    
    if(temp){
    
        NSString *FailureSyptom = [_FailureSymptom.stringValue stringByReplacingOccurrencesOfString:@"'" withString:@"''"];
        NSString *RemarkTxt = [remarkTxt.string stringByReplacingOccurrencesOfString:@"'" withString:@"''"];
        
        NSString *query = [NSString stringWithFormat:@"insert into radar_Info values(null, '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@','%@', '%@', '%@', '%@', '%@', '%@')", _FGSN.stringValue,_Unit.stringValue, _Config.stringValue,_MLBSN.stringValue,_RadarNo.stringValue, _FailStation.stringValue, FailureSyptom, _AppleGroup.stringValue, _APPLEDRI.stringValue,_HHDRI.stringValue,_F1Approve.stringValue,_FADRI.stringValue, _Date.stringValue, RemarkTxt];
        NSLog(@"query: %@", query);
        [_dbManager executeQuery:query];
        
        if (self.dbManager.affectedRows != 0) {
            fdrTxtView.string = [NSString stringWithFormat:@"Query was executed successfully. Affected rows = %d", self.dbManager.affectedRows];
        }
        else{
            fdrTxtView.string = @"Could not execute the query.";
        }
        [fdrTxtView setTextColor:[NSColor redColor]];
    }
}

- (IBAction)teamToChoose:(id)sender {

    if(![self.team indexOfSelectedItem])
    {
        teamChoice = nil;
        return;
    }
    else if([[self.team titleOfSelectedItem] isEqualToString:@"DQE"]){
        teamChoice = @"DQE";
    }else if([[self.team titleOfSelectedItem] isEqualToString:@"Line"]){
        teamChoice = @"Line";
    }
}


#pragma mark - read excel and save in radar database
- (IBAction)readExcel:(id)sender {
    
    //获取excel数据
    _readExcel = [[ReadExcelTool alloc] initWithFilePath:excelPath];
    NSArray* excelTransResult = [_readExcel transFromArray:0 isExcel:YES];

   
    //将excel数据写入数据库
    _readExcel = [[ReadExcelTool alloc] initWithFilePath:excelPath];
    NSArray* excelTrasDBArr = [_readExcel transFromArray:0 isExcel:NO];
    NSLog(@"excelTrasDBArr: %@", excelTrasDBArr);
    [self writeToRadarDB:excelTrasDBArr];

    
    //jump to SearchRadarDBWindow
    _SearchRadarDBWindow = [[SearchRadarDBWindowController alloc] initWithWindowNibName:@"SearchRadarDBWindowController"];
    _SearchRadarDBWindow.searchArr = excelTransResult;
    [_SearchRadarDBWindow.window orderFront:nil];
    [_SearchRadarDBWindow.window center];
   // [self.window orderOut:nil];
}


-(void)writeToRadarDB:(NSArray*)array{
    
    const char * createSQL = "create table if not exists radar_Info \
    (_id integer primary key autoincrement,\
    FGSN,\
    Unit,\
    Config,\
    MLBSN,\
    RadarNo,\
    FailStation,\
    FailureSymptom,\
    AppleGroup,\
    AppleDRI,\
    HHDRI,\
    F1Approve,\
    FADRI,\
    Time,\
    Remark)";

    int temp = [_dbManager createTableWithSql:createSQL];
    NSLog(@"temp: %d", temp);
    
    NSMutableArray *SNItemArr = [NSMutableArray array];
    
    if(temp){
        
        
        for(int i = 0; i< array.count;i++){
            NSString *query = [NSString stringWithFormat:@"insert into radar_Info values(null, '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@')", array[i][0], array[i][1], array[i][2], array[i][3], array[i][4], array[i][5], array[i][6], array[i][7], array[i][8], array[i][9], array[i][10], array[i][11], array[i][12], array[i][13]];
            NSLog(@"query: %@", query);
            [_dbManager executeQuery:query];
            
            [SNItemArr addObject:[NSString stringWithFormat:@"%@\n", array[i][0]]];
            
            if (self.dbManager.affectedRows != 0) {
        
                fdrTxtView.string = [NSString stringWithFormat:@"Query was executed successfully. Affected rows = %d", self.dbManager.affectedRows];
            }
            else{
                
                fdrTxtView.string = @"Could not execute the query.";
            }
            [fdrTxtView setTextColor:[NSColor redColor]];
        }
    }
    NSString *referStr = @"The below SN have been added into radar database:\n\n";
    fdrTxtView.string =[referStr stringByAppendingString:[SNItemArr componentsJoinedByString:@""]];
}


-(NSArray*)inputData{
    NSString *query = [NSString stringWithFormat:@"select * from radar_Info"];
    NSArray *arrUnitInfo = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query]];
    return arrUnitInfo;
}

- (IBAction)getPath:(id)sender {
    NSOpenPanel *panel = [NSOpenPanel openPanel];
    [panel setMessage:@""];
    [panel setPrompt:@"OK"];
    [panel setCanChooseDirectories:YES];
    [panel setCanCreateDirectories:YES];
    [panel setCanChooseFiles:YES];
    
    NSInteger result = [panel runModal];
    if (result == NSFileHandlingPanelOKButton)
    {
        excelPath = [[panel URL] path];
        NSLog(@"path_all: %@",excelPath);
        fdrTxtView.string = excelPath;
    }
}


- (IBAction)fdrChooseItem:(id)sender {
    
    if(![self.fdrItemChoose indexOfSelectedItem])
    {
        NSLog(@"hh");
        return;
    }
    if([[self.fdrItemChoose titleOfSelectedItem] isEqualToString:@"CheckIn"]){
        NSLog(@"upload file");
        fdrTxtView.string = @"fill the radarNum info";
        [self checkInView];
    }
    
    else if([[self.fdrItemChoose titleOfSelectedItem] isEqualToString:@"Search RadarSN in RadarDB"]){
        NSLog(@"Search Radar info in Database");
        fdrTxtView.string = @"Search Radar info in Database";
        [self seachRadarDBView];
    }
    else if([[self.fdrItemChoose titleOfSelectedItem] isEqualToString:@"Search Local SN in LocalDB"]){
        NSLog(@"Search local SN info in Database");
        fdrTxtView.string = @"Search local info in Database";
        [self seachLocalDBView];
    }
    else if([[self.fdrItemChoose titleOfSelectedItem] isEqualToString:@"Search RadarSN by Date in RadarDB"]){
        NSLog(@"Search RadarSN by Date in Database");
        fdrTxtView.string = @"Search RadarSN by Date in Database";
        [self SeachRadarSNByDate];
    }
    else if([[self.fdrItemChoose titleOfSelectedItem] isEqualToString:@"Search Local SN by Date in localDB"]){
        NSLog(@"Search RadarSN by Date in Database");
        fdrTxtView.string = @"Search RadarSN by Date in Database";
        [self SeachLocaloSNByDate];
    }
    else if([[self.fdrItemChoose titleOfSelectedItem] isEqualToString:@"Amount Excel SN Write To RadarDB"]){
        NSLog(@"FDR Radar info Write To Excel");
        fdrTxtView.string = @"You should read excel firtstly, then write To Excel";
        [self FDRRadarView];
    }
    else if([[self.fdrItemChoose titleOfSelectedItem] isEqualToString:@"Single SN Write To RadarDB"]){
        NSLog(@"FDR Radar info Write To Excel");
        fdrTxtView.string = @"You should read excel firtstly, then write To Excel";
        [self singleSNDB];
    }
}


-(void)singleSNDB{
    self.FGSN.hidden = YES;
    self.MLBSN.hidden = YES;
    self.Config.hidden = YES;
    self.FailureSymptom.hidden = YES;
    self.FailStation.hidden = YES;
    self.Date.hidden = YES;
    self.team.hidden = YES;
    self.remarkScroll.hidden = YES;
    remarkTxt.hidden = YES;
    
    self.Unit.hidden = YES;
    self.RadarNo.hidden = YES;
    self.HHDRI.hidden = YES;
    self.FADRI.hidden = YES;
    self.APPLEDRI.hidden = YES;
    self.F1Approve.hidden = YES;
    self.AppleGroup.hidden = YES;
    
    self.UnitLb.hidden = YES;
    self.RadarNoLb.hidden= YES;
    self.HHDRILb.hidden = YES;
    self.FADRILb.hidden= YES;
    self.AppleDriLb.hidden = YES;
    self.F1ApproveLb.hidden = YES;
    self.AppleGroupLb.hidden = YES;
    
    self.FGSNLb.hidden = YES;
    self.mlbSNLb.hidden = YES;
    self.ConfigLb.hidden = YES;
    self.FailureLb.hidden = YES;
    self.FSLb.hidden = YES;
    self.dateLb.hidden = YES;
    self.remarkLb.hidden = YES;
    self.teamLb.hidden = YES;
    
    //checkIn
    self.checkInSM.hidden = YES;
    self.checkInBn.hidden = YES;
    
    self.writeToRadarDBn.hidden = YES;
    self.GetAppDriBn.hidden = YES;
    
    //gloabalLb
    self.gloabalLb.stringValue = @"single sn write to RadarDB";
    self.gloabalLb.hidden = NO;
    
    
    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    
    //seachRadarDB
    self.searchDB.hidden = YES;
    self.seachRadarDB.hidden = YES;
    
    //searchLocalSNDatabase
    self.searchLocalDBField.hidden = YES;
    self.searchLocalSNBn.hidden = YES;
    
    //writeLocalDBn
    self.writeLocalDBn.hidden = YES;
    
    
    self.radarEndTime.hidden = YES;
    self.radarBeginTime.hidden = YES;
    self.searchRadaByTimeBn.hidden = YES;
    
    self.searchLocalDByTimeBn.hidden = YES;
    
    //FDR radar info
    self.writeExcelBn.hidden = YES;
    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //SingleWriteToRadarDB
    self.SingleWriteToRadarDBn.hidden = NO;
    self.singleWriteRadarDBField.hidden = NO;
}


-(void)SeachLocaloSNByDate{
    self.FGSN.hidden = YES;
    self.MLBSN.hidden = YES;
    self.Config.hidden = YES;
    self.FailureSymptom.hidden = YES;
    self.FailStation.hidden = YES;
    self.Date.hidden = YES;
    self.team.hidden = YES;
    self.remarkScroll.hidden = YES;
    remarkTxt.hidden = YES;
    
    self.Unit.hidden = YES;
    self.RadarNo.hidden = YES;
    self.HHDRI.hidden = YES;
    self.FADRI.hidden = YES;
    self.APPLEDRI.hidden = YES;
    self.F1Approve.hidden = YES;
    self.AppleGroup.hidden = YES;
    
    self.UnitLb.hidden = YES;
    self.RadarNoLb.hidden= YES;
    self.HHDRILb.hidden = YES;
    self.FADRILb.hidden= YES;
    self.AppleDriLb.hidden = YES;
    self.F1ApproveLb.hidden = YES;
    self.AppleGroupLb.hidden = YES;
    
    
    self.FGSNLb.hidden = YES;
    self.mlbSNLb.hidden = YES;
    self.ConfigLb.hidden = YES;
    self.FailureLb.hidden = YES;
    self.FSLb.hidden = YES;
    self.dateLb.hidden = YES;
    self.remarkLb.hidden = YES;
    self.teamLb.hidden = YES;

    
    self.writeToRadarDBn.hidden = YES;
    self.GetAppDriBn.hidden = YES;
    
    //gloabalLb
    self.gloabalLb.stringValue = @"write fdr info to excel";
    self.gloabalLb.hidden = NO;
    

    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //checkIn
    self.checkInSM.hidden = YES;
    self.checkInBn.hidden = YES;
    
    //seachRadarDB
    self.searchDB.hidden = YES;
    self.seachRadarDB.hidden = YES;
    
    //searchLocalSNDatabase
    self.searchLocalDBField.hidden = YES;
    self.searchLocalSNBn.hidden = YES;
    
    //writeLocalDBn
    self.writeLocalDBn.hidden = YES;
    
    self.radarEndTime.hidden = NO;
    self.radarBeginTime.hidden = NO;
    self.searchLocalDByTimeBn.hidden = NO;
    
    self.searchRadaByTimeBn.hidden = YES;
    
    //FDR radar info
    self.writeExcelBn.hidden = YES;
    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //SingleWriteToRadarDB
    self.SingleWriteToRadarDBn.hidden = YES;
    self.singleWriteRadarDBField.hidden = YES;

}



-(void)singleSNDBView{
    NSLog(@"d");
    self.FGSN.hidden = NO;
    self.MLBSN.hidden = NO;
    self.Config.hidden = NO;
    self.FailureSymptom.hidden = NO;
    self.FailStation.hidden = NO;
    self.Date.hidden = NO;
    self.team.hidden = YES;
    self.remarkScroll.hidden = NO;
    remarkTxt.hidden = NO;
    
    self.Unit.hidden = NO;
    self.RadarNo.hidden = NO;
    self.HHDRI.hidden = NO;
    self.FADRI.hidden = NO;
    self.APPLEDRI.hidden = NO;
    self.F1Approve.hidden = NO;
    self.AppleGroup.hidden = NO;
    
    self.UnitLb.hidden = NO;
    self.RadarNoLb.hidden= NO;
    self.HHDRILb.hidden = NO;
    self.FADRILb.hidden= NO;
    self.AppleDriLb.hidden = NO;
    self.F1ApproveLb.hidden = NO;
    self.AppleGroupLb.hidden = NO;
    
    self.FGSNLb.hidden = NO;
    self.mlbSNLb.hidden = NO;
    self.ConfigLb.hidden = NO;
    self.FailureLb.hidden = NO;
    self.FSLb.hidden = NO;
    self.dateLb.hidden = NO;
    self.remarkLb.hidden = NO;
    self.teamLb.hidden = YES;

    self.checkInSM.hidden = YES;
    self.checkInBn.hidden = YES ;
    
    self.writeToRadarDBn.hidden = NO;
    self.GetAppDriBn.hidden = NO;
    
    //gloabalLb
    self.gloabalLb.stringValue = @"single sn write to RadarDB";
    self.gloabalLb.hidden = NO;
    
    
    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //checkIn
    self.checkInSM.hidden = YES;
    self.checkInBn.hidden = YES;
    
    //seachRadarDB
    self.searchDB.hidden = YES;
    self.seachRadarDB.hidden = YES;
    
    //searchLocalSNDatabase
    self.searchLocalDBField.hidden = YES;
    self.searchLocalSNBn.hidden = YES;
    
    //writeLocalDBn
    self.writeLocalDBn.hidden = YES;
    
    
    self.radarEndTime.hidden = YES;
    self.radarBeginTime.hidden = YES;
    self.searchRadaByTimeBn.hidden = YES;
    
    self.searchLocalDByTimeBn.hidden = YES;
    
    //FDR radar info
    self.writeExcelBn.hidden = YES;
    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //SingleWriteToRadarDB
    self.SingleWriteToRadarDBn.hidden = NO;
    self.singleWriteRadarDBField.hidden = NO;
}



-(void)FDRRadarView{
    
    self.FGSN.hidden = YES;
    self.MLBSN.hidden = YES;
    self.Config.hidden = YES;
    self.FailureSymptom.hidden = YES;
    self.FailStation.hidden = YES;
    self.Date.hidden = YES;
    self.team.hidden = YES;
    self.remarkScroll.hidden = YES;
    remarkTxt.hidden = YES;
    
    self.Unit.hidden = YES;
    self.RadarNo.hidden = YES;
    self.HHDRI.hidden = YES;
    self.FADRI.hidden = YES;
    self.APPLEDRI.hidden = YES;
    self.F1Approve.hidden = YES;
    self.AppleGroup.hidden = YES;
    
    self.UnitLb.hidden = YES;
    self.RadarNoLb.hidden= YES;
    self.HHDRILb.hidden = YES;
    self.FADRILb.hidden= YES;
    self.AppleDriLb.hidden = YES;
    self.F1ApproveLb.hidden = YES;
    self.AppleGroupLb.hidden = YES;
    
    self.FGSNLb.hidden = YES;
    self.mlbSNLb.hidden = YES;
    self.ConfigLb.hidden = YES;
    self.FailureLb.hidden = YES;
    self.FSLb.hidden = YES;
    self.dateLb.hidden = YES;
    self.remarkLb.hidden = YES;
    self.teamLb.hidden = YES;

    
    self.writeToRadarDBn.hidden = YES;
    self.GetAppDriBn.hidden = YES;
    
    //gloabalLb
    self.gloabalLb.stringValue = @"write fdr info to excel";
    self.gloabalLb.hidden = NO;
    

    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //checkIn
    self.checkInSM.hidden = YES;
    self.checkInBn.hidden = YES;
    
    //seachRadarDB
    self.searchDB.hidden = YES;
    self.seachRadarDB.hidden = YES;
    
    //searchLocalSNDatabase
    self.searchLocalDBField.hidden = YES;
    self.searchLocalSNBn.hidden = YES;
    
    //writeLocalDBn
    self.writeLocalDBn.hidden = YES;
    
    
    self.radarEndTime.hidden = YES;
    self.radarBeginTime.hidden = YES;
    self.searchRadaByTimeBn.hidden = YES;
    
    self.searchLocalDByTimeBn.hidden = YES;
    
    //FDR radar info
    self.writeExcelBn.hidden = NO;
    self.readExcelBn.hidden = NO;
    self.getPathBn.hidden = NO;
    
    //SingleWriteToRadarDB
    self.SingleWriteToRadarDBn.hidden = YES;
    self.singleWriteRadarDBField.hidden = YES;
}



-(void)SeachRadarSNByDate{
    
    self.FGSN.hidden = YES;
    self.MLBSN.hidden = YES;
    self.Config.hidden = YES;
    self.FailureSymptom.hidden = YES;
    self.FailStation.hidden = YES;
    self.Date.hidden = YES;
    self.team.hidden = YES;
    self.remarkScroll.hidden = YES;
    remarkTxt.hidden = YES;
    
    self.Unit.hidden = YES;
    self.RadarNo.hidden = YES;
    self.HHDRI.hidden = YES;
    self.FADRI.hidden = YES;
    self.APPLEDRI.hidden = YES;
    self.F1Approve.hidden = YES;
    self.AppleGroup.hidden = YES;
    
    self.UnitLb.hidden = YES;
    self.RadarNoLb.hidden= YES;
    self.HHDRILb.hidden = YES;
    self.FADRILb.hidden= YES;
    self.AppleDriLb.hidden = YES;
    self.F1ApproveLb.hidden = YES;
    self.AppleGroupLb.hidden = YES;
    
    self.FGSNLb.hidden = YES;
    self.mlbSNLb.hidden = YES;
    self.ConfigLb.hidden = YES;
    self.FailureLb.hidden = YES;
    self.FSLb.hidden = YES;
    self.dateLb.hidden = YES;
    self.remarkLb.hidden = YES;
    self.teamLb.hidden = YES;

    
    self.writeToRadarDBn.hidden = YES;
    self.GetAppDriBn.hidden = YES;
    
    //gloabalLb
    self.gloabalLb.stringValue = @"seachRadaSNByDate";
    self.gloabalLb.hidden = NO;
    
    

    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //checkIn
    self.checkInSM.hidden = YES;
    self.checkInBn.hidden = YES;
    
    //seachRadarDB
    self.searchDB.hidden = YES;
    self.seachRadarDB.hidden = YES;
    
    //searchLocalSNDatabase
    self.searchLocalDBField.hidden = YES;
    self.searchLocalSNBn.hidden = YES;
    
    //writeLocalDBn
    self.writeLocalDBn.hidden = YES;
    
    
    self.radarEndTime.hidden = NO;
    self.radarBeginTime.hidden = NO;
    
    self.searchRadaByTimeBn.hidden = NO;
    self.searchLocalDByTimeBn.hidden = YES;
    
    //FDR radar info
    self.writeExcelBn.hidden = YES;
    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //SingleWriteToRadarDB
    self.SingleWriteToRadarDBn.hidden = YES;
    self.singleWriteRadarDBField.hidden = YES;
}


-(void)seachLocalDBView{
    
    self.FGSN.hidden = YES;
    self.MLBSN.hidden = YES;
    self.Config.hidden = YES;
    self.FailureSymptom.hidden = YES;
    self.FailStation.hidden = YES;
    self.Date.hidden = YES;
    self.team.hidden = YES;
    self.remarkScroll.hidden = YES;
    remarkTxt.hidden = YES;
    
    self.Unit.hidden = YES;
    self.RadarNo.hidden = YES;
    self.HHDRI.hidden = YES;
    self.FADRI.hidden = YES;
    self.APPLEDRI.hidden = YES;
    self.F1Approve.hidden = YES;
    self.AppleGroup.hidden = YES;
    
    self.UnitLb.hidden = YES;
    self.RadarNoLb.hidden= YES;
    self.HHDRILb.hidden = YES;
    self.FADRILb.hidden= YES;
    self.AppleDriLb.hidden = YES;
    self.F1ApproveLb.hidden = YES;
    self.AppleGroupLb.hidden = YES;
    
    self.FGSNLb.hidden = YES;
    self.mlbSNLb.hidden = YES;
    self.ConfigLb.hidden = YES;
    self.FailureLb.hidden = YES;
    self.FSLb.hidden = YES;
    self.dateLb.hidden = YES;
    self.remarkLb.hidden = YES;
    self.teamLb.hidden = YES;

    
    self.writeToRadarDBn.hidden = YES;
    self.GetAppDriBn.hidden = YES;
    
    //gloabalLb
    self.gloabalLb.stringValue = @"searchLocalDB";
    self.gloabalLb.hidden = NO;
    

    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //checkIn
    self.checkInSM.hidden = YES;
    self.checkInBn.hidden = YES;
    
    //seachRadarDB
    self.searchDB.hidden = YES;
    self.seachRadarDB.hidden = YES;
    
    //searchLocalDatabase
    self.searchLocalDBField.hidden = NO;
    self.searchLocalSNBn.hidden = NO;
    
    //writeLocalDBn
    self.writeLocalDBn.hidden = YES;
    
    self.team.hidden = YES;
    self.teamLb.hidden = YES;
    
    self.radarEndTime.hidden = YES;
    self.radarBeginTime.hidden = YES;
    self.searchRadaByTimeBn.hidden = YES;
    self.searchLocalDByTimeBn.hidden = YES;
    
    //FDR radar info
    self.writeExcelBn.hidden = YES;
    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //SingleWriteToRadarDB
    self.SingleWriteToRadarDBn.hidden = YES;
    self.singleWriteRadarDBField.hidden = YES;
}


-(void)checkInView{
    
    self.FGSN.hidden = YES;
    self.Config.hidden = YES;
    self.MLBSN.hidden = YES;
    self.FailureSymptom.hidden = YES;
    self.FailStation.hidden = YES;
    self.Date.hidden = YES;
    self.team.hidden = YES;
    self.remarkScroll.hidden = YES;
    remarkTxt.hidden = YES;
    
    self.Unit.hidden = YES;
    self.RadarNo.hidden = YES;
    self.HHDRI.hidden = YES;
    self.FADRI.hidden = YES;
    self.APPLEDRI.hidden = YES;
    self.F1Approve.hidden = YES;
    self.AppleGroup.hidden = YES;
    
    self.UnitLb.hidden = YES;
    self.RadarNoLb.hidden= YES;
    self.HHDRILb.hidden = YES;
    self.FADRILb.hidden= YES;
    self.AppleDriLb.hidden = YES;
    self.F1ApproveLb.hidden = YES;
    self.AppleGroupLb.hidden = YES;
    
    self.FGSNLb.hidden = YES;
    self.ConfigLb.hidden = YES;
    self.mlbSNLb.hidden = YES;
    self.FailureLb.hidden = YES;
    self.FSLb.hidden = YES;
    self.dateLb.hidden = YES;
    self.remarkLb.hidden = YES;
    self.teamLb.hidden = YES;
    
    self.writeToRadarDBn.hidden = YES;
    self.GetAppDriBn.hidden = YES;
    
    //gloabalLb
    self.gloabalLb.stringValue = @"searchRadarDB";
    self.gloabalLb.hidden = NO;
    

    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //checkIn
    self.checkInSM.hidden = NO;
    self.checkInBn.hidden = NO;
    
    //seachRadarDB
    self.searchDB.hidden = YES;
    self.seachRadarDB.hidden = YES;
    
    //searchLocalDatabase
    self.searchLocalDBField.hidden = YES;
    self.searchLocalSNBn.hidden = YES;
    
    //writeLocalDBn
    self.writeLocalDBn.hidden = YES;
    
    //team
    self.team.hidden = YES;
    self.teamLb.hidden = YES;
    
    self.radarEndTime.hidden = YES;
    self.radarBeginTime.hidden = YES;
    self.searchRadaByTimeBn.hidden = YES;
    self.searchLocalDByTimeBn.hidden = YES;
    
    //FDR radar info
    self.writeExcelBn.hidden = YES;
    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //SingleWriteToRadarDB
    self.SingleWriteToRadarDBn.hidden = YES;
    self.singleWriteRadarDBField.hidden = YES;
}

-(void)uploadView{
    
    self.FGSN.hidden = NO;
    self.Config.hidden = NO;
    self.MLBSN.hidden = NO;
    self.FailureSymptom.hidden = NO;
    self.FailStation.hidden = NO;
    self.Date.hidden = NO;
    self.remarkScroll.hidden = NO;
    self.FADRI.hidden = NO;
    remarkTxt.hidden = NO;
    
    
    self.Unit.hidden = YES;
    self.RadarNo.hidden = YES;
    self.HHDRI.hidden = YES;
    self.APPLEDRI.hidden = YES;
    self.F1Approve.hidden = YES;
    self.AppleGroup.hidden = YES;
    
    self.UnitLb.hidden = YES;
    self.RadarNoLb.hidden= YES;
    self.HHDRILb.hidden = YES;
    self.AppleDriLb.hidden = YES;
    self.F1ApproveLb.hidden = YES;
    self.AppleGroupLb.hidden = YES;
    
    self.FGSNLb.hidden = NO;
    self.ConfigLb.hidden = NO;
    self.mlbSNLb.hidden = NO;
    self.FailureLb.hidden = NO;
    self.FSLb.hidden = NO;
    self.dateLb.hidden = NO;
    self.remarkLb.hidden = NO;
    self.FADRILb.hidden= NO;
    
    self.writeToRadarDBn.hidden = YES;
    self.GetAppDriBn.hidden = YES;
    
    //gloabalLb
    self.gloabalLb.stringValue = @"uploadRadar";
    self.gloabalLb.hidden = NO;
    

    self.readExcelBn.hidden = NO;
    self.getPathBn.hidden = NO;
    
    
    //checkIn
    self.checkInSM.hidden = NO;
    self.checkInBn.hidden = NO;
    
    //seachRadarDB
    self.searchDB.hidden = YES;
    self.seachRadarDB.hidden = YES;
    
    //searchLocalDatabase
    self.searchLocalDBField.hidden = YES;
    self.searchLocalSNBn.hidden = YES;
    
    //writeLocalDBn
    self.writeLocalDBn.hidden = NO;
    
    //team
    self.team.hidden = NO;
    self.teamLb.hidden = NO;
    
    self.radarEndTime.hidden = YES;
    self.radarBeginTime.hidden = YES;
    self.searchRadaByTimeBn.hidden = YES;
    self.searchLocalDByTimeBn.hidden = YES;
    
    //FDR radar info
    self.writeExcelBn.hidden = YES;
    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //SingleWriteToRadarDB
    self.SingleWriteToRadarDBn.hidden = YES;
    self.singleWriteRadarDBField.hidden = YES;
}


-(void)seachRadarDBView{    
    self.FGSN.hidden = YES;
    self.Config.hidden = YES;
    self.MLBSN.hidden = YES;
    self.FailureSymptom.hidden = YES;
    self.FailStation.hidden = YES;
    self.Date.hidden = YES;
    self.teamLb.hidden = YES;
    self.remarkScroll.hidden = YES;
    remarkTxt.hidden = YES;
    
    self.Unit.hidden = YES;
    self.RadarNo.hidden = YES;
    self.HHDRI.hidden = YES;
    self.FADRI.hidden = YES;
    self.APPLEDRI.hidden = YES;
    self.F1Approve.hidden = YES;
    self.AppleGroup.hidden = YES;
    
    self.FGSNLb.hidden = YES;
    self.ConfigLb.hidden = YES;
    self.mlbSNLb.hidden = YES;
    self.FailureLb.hidden = YES;
    self.FSLb.hidden = YES;
    self.dateLb.hidden = YES;
    self.remarkLb.hidden = YES;
    
    //gloabalLb
    self.gloabalLb.stringValue = @"searchRadarDB";
    self.gloabalLb.hidden = NO;
    
    self.writeToRadarDBn.hidden = YES;
    self.GetAppDriBn.hidden = YES;

    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //checkIn
    self.checkInSM.hidden = YES;
    self.checkInBn.hidden = YES;
    
    //seachRadarDB
    self.searchDB.hidden = NO;
    self.seachRadarDB.hidden = NO;
    
    //searchLocalDatabase
    self.searchLocalDBField.hidden = YES;
    self.searchLocalSNBn.hidden = YES;
    
    //writeLocalDBn
    self.writeLocalDBn.hidden = YES;
    
    //
    self.team.hidden = YES;
    self.teamLb.hidden = YES;
    
    self.radarEndTime.hidden = YES;
    self.radarBeginTime.hidden = YES;
    self.searchRadaByTimeBn.hidden = YES;
    self.searchLocalDByTimeBn.hidden = YES;
    
    //FDR radar info
    self.writeExcelBn.hidden = YES;
    self.readExcelBn.hidden = YES;
    self.getPathBn.hidden = YES;
    
    //SingleWriteToRadarDB
    self.SingleWriteToRadarDBn.hidden = YES;
    self.singleWriteRadarDBField.hidden = YES;
}


- (IBAction)writeToExcel:(id)sender {
    
    NSArray *temp = [self inputData];
    
    DHCell				*cell;
    DHWorkBook *dhWB = [DHWorkBook new];
    DHWorkSheet *dhWS = [dhWB workSheetWithName:@"SHEET1"];
    [dhWS height:500 row:1 format:NULL];
    [dhWS height:500 row:0 format:NULL];
    [dhWS width:60000 col:14 format:NULL];
    [dhWS width:10000 col:7 format:NULL];
    [dhWS width:10000 col:1 format:NULL];
    [dhWS width:10000 col:2 format:NULL];
    [dhWS width:10000 col:4 format:NULL];
    
    
    cell = [dhWS label:@"Item" row:0 col:0];
    cell = [dhWS label:@"FGSN" row:0 col:1];
    cell = [dhWS label:@"Unit#" row:0 col:2];
    cell = [dhWS label:@"Config" row:0 col:3];
    cell = [dhWS label:@"MLBSN#" row:0 col:4];
    cell = [dhWS label:@"Radar#" row:0 col:5];
    cell = [dhWS label:@"Failure Station" row:0 col:6];
    cell = [dhWS label:@"Failure Symptom" row:0 col:7];
    cell = [dhWS label:@"Apple Group" row:0 col:8];
    cell = [dhWS label:@"Apple DRI" row:0 col:9];
    cell = [dhWS label:@"HH DRI" row:0 col:10];
    cell = [dhWS label:@"F1 Approve" row:0 col:11];
    cell = [dhWS label:@"FA DRI" row:0 col:12];
    cell = [dhWS label:@"Date" row:0 col:13];
    cell = [dhWS label:@"Remark" row:0 col:14];
    
    
    for(int i = 1; i< temp.count; ++i){
        for (int j = 0; j<15; j++) {
            cell = [dhWS label:temp[i-1][j] row:i col:j];
            [dhWS height:500 row:i format:NULL];
        }
    }
    
    
//    for(unsigned short idx=0; idx<10; ++idx) {
//        cell = [dhWS label:[NSString stringWithFormat:@"Row %d", idx+1] row:idx col:0];
//        if(idx & 1) {
//            // prove we can get the cell reference later
//            cell = [dhWS cell:idx col:0];
//        }
//        [cell horzAlign:HALIGN_LEFT];
//        [cell indent:INDENT_0+idx];
//    }
//    //	[dhWS merge:(NSRect){{10, 10}, {3, 3} }];
//    
//    //	NSData *now = [NSDate date];
//    //	NSDate *then = [NSDate dateWithString:@"1899-01-01 12:00:00 +0000").
//    

//    
//    for(unsigned short idx=0; idx<10; ++idx) {
//        [dhWS number:3.1415f row:idx col:1 numberFormat:FMT_GENERAL+idx];
//    }
//    
//    
//    
//    [dhWS width:30000 col:2 format:NULL];
//    for(unsigned short idx=0; idx<7; ++idx) {
//        cell = [dhWS label:@"Hello World" row:idx col:2];
//        [cell horzAlign:HALIGN_GENERAL+idx];
//    }
//    
//    [dhWS width:0xFFFF col:3 format:NULL];
//    for(unsigned short idx=0; idx<4; ++idx) {
//        [dhWS height:24 row:idx format:NULL];
//        cell = [dhWS label:@"Hello World" row:idx col:3];
//        [cell vertAlign:VALIGN_TOP+idx];
//    }
    
    int fud = [dhWB writeFile:@"/tmp/test.xls"];
    NSLog(@"OK - bye! fud=%d", fud);
    [[NSWorkspace sharedWorkspace] openFile:@"/tmp/test.xls" withApplication:@"Microsoft Excel" andDeactivate:YES];
}



- (IBAction)GetAppDri:(id)sender {
    
    
    
}

@end
