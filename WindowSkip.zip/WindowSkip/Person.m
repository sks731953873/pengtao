//
//  Person.m
//  WindowSkip
//
//  Created by gdadmin on 1/14/17.
//  Copyright © 2017 108. All rights reserved.
//

#import "Person.h"
#import <Foundation/Foundation.h>


@implementation Person

@synthesize personName;
@synthesize checkState;
@synthesize passWord;

-(id)init {
    
    self = [super init];
    if(self){
    
        personName = @"west";
        checkState = @"0";
        passWord = @"helloworld";
    }
    return self;
}



@end
