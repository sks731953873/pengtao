//
//  UpdateItem.h
//  BCM
//
//  Created by mac on 04/03/2018.
//  Copyright © 2018 macjinlongpiaoxu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UpdateItem : NSObject

@property(nonatomic,strong)NSString  * fix_ABC_DEF_Res;
@property(nonatomic,strong)NSString  * fix_B2_E2_Res;
@property(nonatomic,strong)NSString  * fix_B4_E4_Res;
@property(nonatomic,strong)NSString  * fix_B_E_Res;
@property(nonatomic,strong)NSString  * fix_Cap;

@end
