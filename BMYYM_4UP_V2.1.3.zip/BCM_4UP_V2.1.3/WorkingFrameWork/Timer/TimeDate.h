//
//  TimeDate.h
//  BT_MIC_SPK
//
//  Created by EW on 16/5/30.
//  Copyright © 2016年 h. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TimeDate : NSObject
//=============================================
-(NSString*)GetSystemTimeSeconds;
-(NSString*)GetSystemTimeDay;
//=============================================
@end
//=============================================