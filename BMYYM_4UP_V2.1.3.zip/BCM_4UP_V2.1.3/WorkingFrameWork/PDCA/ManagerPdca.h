//
//  ManagerPdca.h
//  BCM
//
//  Created by mac on 07/04/2018.
//  Copyright © 2018 macjinlongpiaoxu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ManagerPdca : NSObject


-(void)start_Thread;

-(void)end_Thread;

@end
