//
//  FileConfigSet.m
//  BCM
//
//  Created by mac on 22/03/2018.
//  Copyright © 2018 macjinlongpiaoxu. All rights reserved.
//

#import "FileConfigSet.h"

@interface FileConfigSet ()

@end

@implementation FileConfigSet

- (void)windowDidLoad {
    [super windowDidLoad];
    
    // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
}

@end
