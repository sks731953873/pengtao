//
//  FileConfigSet.h
//  BCM
//
//  Created by mac on 22/03/2018.
//  Copyright © 2018 macjinlongpiaoxu. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface FileConfigSet : NSWindowController

@end
