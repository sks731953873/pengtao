//
//  UITableView+Extension.h
//  ZhiHuDaily
//
//  Created by 彭涛 on 16/2/25.
//  Copyright © 2016年 彭涛. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableView (Extension)

@property (nonatomic)BOOL disableTableHeaderView;

@end
