//
//  TDStoryContentModel.m
//  ZhiHuDaily
//
//  Created by 彭涛 on 16/3/6.
//  Copyright © 2016年 彭涛. All rights reserved.
//

#import "TDStoryContentModel.h"

@implementation TDStoryContentModel

+ (JSONKeyMapper *)keyMapper {
    return [[JSONKeyMapper alloc] initWithDictionary:@{@"id":@"storyID"}];
}

+ (BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
