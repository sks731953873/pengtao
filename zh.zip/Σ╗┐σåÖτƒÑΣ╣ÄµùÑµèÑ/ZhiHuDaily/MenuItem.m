//
//  ThemeItem.m
//  ZhiHuDaily
//
//  Created by 彭涛 on 16/3/4.
//  Copyright © 2016年 彭涛. All rights reserved.
//

#import "MenuItem.h"

@implementation MenuItem

- (instancetype)initWithDictionary:(NSDictionary *)dic {
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dic];
    }
    return self;
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    if ([key isEqualToString:@"id"]) {
        [self setValue:value forKey:@"themeID"];
    }
}

@end
