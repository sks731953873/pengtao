//
//  PanInteractionController.h
//  ZHTransition
//
//  Created by 彭涛 on 16/8/21.
//  Copyright © 2016年 彭涛. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PanInteractionController : UIPercentDrivenInteractiveTransition

@property(nonatomic,assign)BOOL active;

- (void)attachToViewController:(UIViewController *)vc;

@end
