//
//  TPStoryViewController.h
//  ZhiHuDaily
//
//  Created by 洪鹏宇 on 16/3/6.
//  Copyright © 2016年 洪鹏宇. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TDStoryViewModel.h"

@interface TPStoryViewController : BaseViewController

- (instancetype)initWithViewModel:(TDStoryViewModel *)vm;

@end
