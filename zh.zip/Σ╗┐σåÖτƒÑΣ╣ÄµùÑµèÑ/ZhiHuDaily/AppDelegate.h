//
//  AppDelegate.h
//  ZhiHuDaily
//
//  Created by 彭涛 on 16/2/1.
//  Copyright © 2016年 彭涛. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) MainViewController *mainViewController;

@end

