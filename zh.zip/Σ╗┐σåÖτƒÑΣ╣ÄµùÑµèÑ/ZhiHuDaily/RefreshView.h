//
//  RefreshView.h
//  HPYZhiHuDaily
//
//  Created by 彭涛 on 15/11/28.
//  Copyright © 2015年 彭涛. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RefreshView : UIView


@property(assign,nonatomic)BOOL refresh;

- (void)redrawFromProgress:(CGFloat)progress;

@end
