//
//  LeftMenuViewController.h
//  HPYZhiHuDaily
//
//  Created by 洪鹏宇 on 15/11/21.
//  Copyright © 2015年 洪鹏宇. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftMenuViewController : BaseViewController

@end
