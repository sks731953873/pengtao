//
//  CoverView.h
//  ZhiHuDaily
//
//  Created by 彭涛 on 16/3/2.
//  Copyright © 2016年 彭涛. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CoverView : UIView

@end
