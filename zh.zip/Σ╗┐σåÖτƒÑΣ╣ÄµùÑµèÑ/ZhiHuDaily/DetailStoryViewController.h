//
//  DetailStoryViewController.h
//  ZhiHuDaily
//
//  Created by 洪鹏宇 on 16/2/29.
//  Copyright © 2016年 洪鹏宇. All rights reserved.
//

#import "BaseViewController.h"
#import "DetailStoryViewModel.h"

@interface DetailStoryViewController : BaseViewController

- (instancetype)initWithViewModel:(DetailStoryViewModel *)vm;

@end
