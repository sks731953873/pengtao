//
//  ThemeItem.h
//  ZhiHuDaily
//
//  Created by 彭涛 on 16/3/4.
//  Copyright © 2016年 彭涛. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MenuItem : NSObject

@property (strong,nonatomic)NSString *themeID;
@property (strong,nonatomic)NSString *name;
@property (strong,nonatomic)NSString *imageName;

- (instancetype)initWithDictionary:(NSDictionary *)dic;

@end
