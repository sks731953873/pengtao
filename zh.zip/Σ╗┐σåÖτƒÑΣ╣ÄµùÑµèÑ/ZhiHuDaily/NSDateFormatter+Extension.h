//
//  NSDateFormatter+Extension.h
//  HPYZhiHuDaily
//
//  Created by 彭涛 on 15/11/22.
//  Copyright © 2015年 彭涛. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDateFormatter (Extension)

+ (instancetype)sharedInstance;

@end
