//
//  ZHDismissAnimationController.h
//  ZHTransition
//
//  Created by 彭涛 on 16/8/21.
//  Copyright © 2016年 彭涛. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ZHDismissAnimationController : NSObject <UIViewControllerAnimatedTransitioning>

@property (assign,nonatomic)NSTimeInterval animationDuration;

@end
