//
//  RecommenderView.h
//  ZhiHuDaily
//
//  Created by 彭涛 on 16/3/8.
//  Copyright © 2016年 彭涛. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecommenderView : UIView

- (void)setContentWithCommanders:(NSArray *)commanders;

@end
