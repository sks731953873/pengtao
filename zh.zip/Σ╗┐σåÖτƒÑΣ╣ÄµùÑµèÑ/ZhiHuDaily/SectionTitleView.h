//
//  SectionTitleView.h
//  HPYZhiHuDaily
//
//  Created by 彭涛 on 15/11/29.
//  Copyright © 2015年 彭涛. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SectionTitleView : UITableViewHeaderFooterView

@end
