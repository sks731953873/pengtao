//
//  SectionTitleView.m
//  HPYZhiHuDaily
//
//  Created by 彭涛 on 15/11/29.
//  Copyright © 2015年 彭涛. All rights reserved.
//

#import "SectionTitleView.h"

@implementation SectionTitleView


- (void)layoutSubviews {
    [super layoutSubviews];
    self.textLabel.centerX = self.width/2;
}

@end
