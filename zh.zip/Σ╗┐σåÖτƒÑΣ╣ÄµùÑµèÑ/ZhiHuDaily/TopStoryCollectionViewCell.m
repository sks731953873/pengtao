//
//  TopStoryCollectionViewCell.m
//  ZhiHuDaily
//
//  Created by 彭涛 on 16/8/22.
//  Copyright © 2016年 彭涛. All rights reserved.
//

#import "TopStoryCollectionViewCell.h"

@implementation TopStoryCollectionViewCell


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    //self.coverHeightConstraint.constant = 220.f;
}

@end
