//
//  DetailStoryModel.h
//  ZhiHuDaily
//
//  Created by 彭涛 on 16/2/29.
//  Copyright © 2016年 彭涛. All rights reserved.
//

#import <JSONModel/JSONModel.h>

@interface DetailStoryModel : JSONModel

@property(strong,nonatomic)NSString *body;
@property(strong,nonatomic)NSString *image_source;
@property(strong,nonatomic)NSString *title;
@property(strong,nonatomic)NSString *image;
@property(strong,nonatomic)NSString *storyID;
//@property(strong,nonatomic)NSArray *css;

@end
