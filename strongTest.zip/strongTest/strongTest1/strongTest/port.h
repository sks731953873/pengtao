//
//  port.h
//  strongTest
//
//  Created by strong on 2018/1/5.
//  Copyright © 2018年 strong. All rights reserved.
//

#ifndef port_h
#define port_h

#include <stdio.h>
#define PORTMAXNAME 128
#define PORTMAXENDFLAGE 128
#define PORTMAXCOUNTPDCA 64
typedef struct _port
{
    char tag_Name[PORTMAXNAME];//名称
    char tag_ReadEndFlage[PORTMAXENDFLAGE];//读取数据时候，结束标志
    char tag_SendendFlage[PORTMAXENDFLAGE];//读取数据时候，结束标志
    int tag_baudRate;//波特率
    int tag_dataBits;
    int tag_stopBits;//终止位s
    int tag_parity;
    int tag_flowControl;//
    int tag_echo;
}PortValue,*portValue;
typedef struct _PortValueManage
{
    int tag_totalCount;//个数
    PortValue tag_PortValue[PORTMAXCOUNTPDCA];//列表
}PortValueManage,*portValueManage;
#endif /* port_h */
