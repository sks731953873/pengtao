//
//  PopUp_SubView.m
//  strongTest
//
//  Created by 客人用户 on 2018/3/9.
//  Copyright © 2018年 strong. All rights reserved.
//

#import "PopUp_SubView.h"
#import "StepView.h"
//@interface PopUp_SubView()
//{
  // config
//}

//@end

@implementation PopUp_SubView

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}
- (IBAction)uai_SaveData:(id)sender {
    [self GetParameter];        //点击保存之后先获取参数
    Save();
    [self removeFromSuperview];
}

- (IBAction)uai_GiveUpSave:(id)sender {
    [self removeFromSuperview];
}

- (instancetype)initWithFrame:(CGRect)frame STEP:(LpStep) step              //step传入各个项内容
{
    
    NSArray *arr = [NSArray array];
    
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([PopUp_SubView class]) owner:nil topLevelObjects:&arr];
    
    for(int i = 0;i < arr.count;i++)
    {
        if([arr[i] isKindOfClass:[self class]])
        {
            PopUp_SubView *popUpView = arr[i];
            
            CGRect frame1 = {frame.origin.x,frame.origin.y,popUpView.frame.size.width,popUpView.frame.size.height};
            // stationView.frame = frame1;
            // CALayer *viewLayer = [CALayer layer];
            // [viewLayer setBackgroundColor:CGColorCreateGenericRGB(0.9, 0.9, 0.9, 1)];
            [popUpView setWantsLayer:YES];
            // [stationView setLayer:viewLayer];
            self = popUpView;           //这样就返回了这个弹窗的实例--uai
            _tag_step = step;           //把step这个结构传入了这个构造函数，初始化，将它传给
            [self InitData1];           //将控件的初始属性设置完成
            [self InitData2];
            
        }
    }
    return self;
}


-(void) InitData1
{
    [_tag_UiCoBoxType removeAllItems];
    [_tag_UiCoBoxType addItemWithObjectValue:(@"Socket")];
    [_tag_UiCoBoxType addItemWithObjectValue:(@"Script")];
    [_tag_UiCoBoxType addItemWithObjectValue:(@"Port")];
    [_tag_UiCoBoxType addItemWithObjectValue:(@"IoRead_1")];
    [_tag_UiCoBoxType addItemWithObjectValue:(@"IoRead_0")];
    [_tag_UiCoBoxType addItemWithObjectValue:(@"IoSet")];
    
    [_tag_UiCoBoxType addItemWithObjectValue:(@"wait")];
    [_tag_UiCoBoxType addItemWithObjectValue:(@"SocRead")];
    [_tag_UiCoBoxType addItemWithObjectValue:(@"SocReadClean")];
    [_tag_UiCoBoxType addItemWithObjectValue:(@"SnWrite")];
    [_tag_UiCoBoxType addItemWithObjectValue:(@"SnRead")];
    [_tag_UiCoBoxType addItemWithObjectValue:(@"SFC_GetSn")];
    [_tag_UiCoBoxType addItemWithObjectValue:(@"dealy")];
    [_tag_UiCoBoxType addItemWithObjectValue:(@"filename")];
    [_tag_UiBtnShow setTitle:@""];
    
    [_tag_UiCoBoxPDCA removeAllItems];
    [_tag_UiCoBoxPDCA addItemWithObjectValue:(@"NoPDCA")];
    
    [_tag_UiCoBoxSocket removeAllItems];
    //[_tag_UiCoBoxSocket addItemWithObjectValue:(@"0")];  为什么在stepView.m 中有这么一行？
    for(int i=0;i<IPCOUNT;i++)
    {
        [_tag_UiCoBoxSocket addItemWithObjectValue:([[NSString alloc ]initWithFormat:@"%d" ,i])];
    }
    
    [_tag_UiCoBoxThread removeAllItems];
    [_tag_UiCoBoxThread addItemWithObjectValue:@"Main"];
    [_tag_UiCoBoxThread addItemWithObjectValue:@"Thread"];
    
    
    //已经初始化过了。所以不用再进行初始化。---因为有xib文件。所以不用这样默认初始化。
    //_tag_UITextReadEnd = [[NSTextField alloc]init];         //初始化出一个文本在Mac平台上，Label控件与iOS中Label控件稍微有些不同，iOS中的label类型是UILabel，TextField的类型是UITextField，是分开的，而Mac中的Label控件类型是NSTextField，和可编辑文本框TextField是同一类型，所以如果要用代码生成Label的话，要声明Label的类型为NSTextField，    这是个label么？很明显不是
    [_tag_UiBtnEnter setButtonType:NSButtonTypeSwitch];
    [_tag_UiBtnEnter setTitle:@""];
    
    

    
}

-(void) InitData2            //初始化数据
{
    //这里写入
    _tag_UiTextName.stringValue = [[NSString alloc] initWithFormat:@"%s",_tag_step->tag_stepName];          //名称
    _tag_UiTextSleepData.stringValue=[[NSString alloc ]initWithFormat:@"%d",_tag_step->tag_SleepDate];      //延时时间
    //_tag_UiChkBoxEnable.state=[_tag_step->tag_enable.state integerValue];
    _tag_UIBtnEnable.state=_tag_step->tag_enable;   //直接用这个值就好了。因为tag_enable本来就是一个int值。         //
    //_tag_UIBtnParameter=
    //命令
    _tag_UiTextcommand.stringValue=[[NSString alloc]initWithFormat:@"%s",_tag_step->tag_sendCommand ];//将char格式的命令字符转变为string值，传入命令信号
    [_tag_UiCoBoxSocket selectItemAtIndex:_tag_step->tag_socket_index];     //用这样一个方法将索引号传递过去。
    [_tag_UiCoBoxPDCA selectItemAtIndex:_tag_step->tag_pdca_index];
    [_tag_UiCoBoxThread selectItemAtIndex:_tag_step->tag_isThread];
    [_tag_UiCoBoxType selectItemAtIndex:_tag_step->tag_type];
    
    //_tag_UITextReadEnd.stringValue=[[NSString alloc]initWithFormat:@:"%S",]       读结束，这个找不到
    _tag_UiBtnEnter.state=_tag_step->tag_readEnterKey;   //是否要有回车
    _tag_UiBtnShow.state=_tag_step->tag_isMainShow;     //主界面是否显示
    _tag_UITextfiltrationEndStep.stringValue=[[NSString alloc ]initWithFormat:@"%s",_tag_step->tag_filtrationEnd];
    _tag_UITextfiltrationEndStep.stringValue=[[NSString alloc ]initWithFormat:@"%s",_tag_step->tag_filtrationBegin];    //
    

}

- (void )GetParameter
{
    
    
    
    
    if(_tag_step)           //如果此参数存在的话
    {
        memset(_tag_step->tag_stepName,0,sizeof(_tag_step->tag_stepName));//第一个是指针，第二个是赋给指针的值，第三个是长度。  这个就是给_tag_step的tag_stepName属性赋值。
        
        strcat(_tag_step->tag_stepName,[_tag_UiTextName.stringValue UTF8String]);
        //if(tag_IsShowCommandOrResult == 2)
        //{
            memset(_tag_step->tag_sendCommand,0,sizeof(_tag_step->tag_sendCommand));
            //strcat(_tag_step->tag_sendCommand,[tag_UIResult.stringValue UTF8String]);
        //}
        //_tag_step->tag_SleepDate = [tag_UISleepTime integerValue];
        _tag_step->tag_type = _tag_UiCoBoxType.indexOfSelectedItem;                             //待补充  命令类型
        
        //_tag_step->tag_failNextStep = [tag_UIFAILNextStep.stringValue integerValue];          //待补充， 错误，下一步  待补充
        //_tag_step->tag_SucNextStep = [tag_UIOKNextStep.stringValue integerValue];             //待补充  成功，下一步
        _tag_step->tag_enable = _tag_UIBtnEnable.state;
        
        _tag_step->tag_SleepDate = [_tag_UiTextSleepData.stringValue integerValue];
        
        //以下三个都是数组，因此要先将数组清空，然后将内容加载进去。
        memset(_tag_step->tag_filtrationBegin,0,sizeof(_tag_step->tag_filtrationBegin));
        strcat(_tag_step->tag_filtrationBegin,[_tag_UITextfiltrationBeginStep.stringValue UTF8String]);
        
        memset(_tag_step->tag_filtrationEnd,0,sizeof(_tag_step->tag_filtrationEnd));
        strcat(_tag_step->tag_filtrationEnd,[_tag_UITextfiltrationEndStep.stringValue UTF8String]);
        
        memset(_tag_step->tag_ReadEndFlage,0,sizeof(_tag_step->tag_ReadEndFlage));
        strcat(_tag_step->tag_ReadEndFlage,[_tag_UITextReadEnd.stringValue UTF8String]);
        
        
        
        
        
        _tag_step->tag_pdca_index = _tag_UiCoBoxPDCA.indexOfSelectedItem;
        _tag_step->tag_socket_index = _tag_UiCoBoxSocket.indexOfSelectedItem;
        
        
        
        _tag_step->tag_isThread =  _tag_UiCoBoxThread.indexOfSelectedItem;
        
        _tag_step->tag_isMainShow = _tag_UiBtnShow.state;
        
        _tag_step->tag_readEnterKey = _tag_UiBtnEnter.state;
        
        
    }
    
}



@end

