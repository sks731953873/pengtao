//
//  PopUp_SubView.h
//  strongTest
//
//  Created by 客人用户 on 2018/3/9.
//  Copyright © 2018年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "step.h"
@interface PopUp_SubView : NSView
{
        LpStep _tag_step;//步骤
}
@property (weak) IBOutlet NSButton *tag_UIBtnEnable;
@property (weak) IBOutlet NSButton *tag_UIBtnParameter;     //参数
@property (weak) IBOutlet NSButton *tag_UiBtnRun;       //运行
@property (weak) IBOutlet NSComboBox *tag_UiCoBoxSocket;
@property (weak) IBOutlet  NSComboBox *tag_UiCoBoxThread;
@property (weak) IBOutlet   NSComboBox *tag_UiCoBoxPDCA;
@property (weak) IBOutlet NSComboBox *tag_UiCoBoxType;
@property (weak) IBOutlet NSButton *tag_UiBtnEnter;
@property (weak) IBOutlet NSButton *tag_UiBtnShow;

@property (weak) IBOutlet NSTextField *tag_UiTextName;
//@property (weak) IBOutlet NSTextField *tag_UiTextDelayed;//属性没有进行绑定的时候，就显示一个空的圈圈⭕️。
@property (weak) IBOutlet NSTextField *tag_UiTextSleepData;
@property (weak) IBOutlet NSTextField *tag_UITextReadEnd;
@property (weak) IBOutlet NSTextField *tag_UITextfiltrationEndStep;
@property (weak) IBOutlet NSTextField *tag_UITextfiltrationBeginStep;
@property (weak) IBOutlet NSTextField *tag_UiTextcommand;


- (IBAction)uai_SaveData:(id)sender;
- (IBAction)uai_GiveUpSave:(id)sender;
- (instancetype)initWithFrame:(CGRect)frame STEP:(LpStep) step;
@end



