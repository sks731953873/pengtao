//
//  DataSave.m
//  strongTest
//
//  Created by strong on 2018/1/15.
//  Copyright © 2018年 strong. All rights reserved.
//

#import "DataSave.h"

@implementation DataSave


#define DE_INI_Name @"Name"
#define DE_INI_SendCONTENT @"SendContent"
#define DE_INI_SleepDate @"SleepDate"
#define DE_INI_SucNextStep @"SucNextStep"
#define DE_INI_SucNextStep @"SucNextStep"
#define DE_INI_Type @"Type"
#define DE_INI_algorithmType @"algorithmType"
#define DE_INI_exctimes @"exctimes"
#define DE_INI_enable @"enable"
#define DE_INI_PdcaIndex @"PdcaIndex"
#define DE_INI_filtrationBegin @"filtrationBegin"
#define DE_INI_filtrationEnd @"filtrationEnd"
#define DE_INI_socketIndex @"socketIndex"
#define DE_INI_SnIndex @"SnIndex"
#define DE_INI_Thread @"Thread"
#define DE_INI_Wait @"wait"
#define  DE_INI_portIndex  @"portIndex"

#define  DE_INI_ISMAINSHOW  @"IsMainSHow"

#define  DE_INI_ip  @"ip"

#define  DE_INI_ReadEndFlage @"ReadEndFlage"
#define  DE_INI_SendendFlage @"SendendFlage"

#define  DE_INI_SendendEnterKey @"SendendEnterKey"
#define  DE_INI_ReadendEnterKey @"ReadendEnterKey"
#define  DE_INI_Port @"Port"

#define  DE_INI_Value @"Value"

#define  DE_INI_Max @"Max"
#define  DE_INI_Min @"Min"
#define  DE_INI_UUTO @"UUTO"
#define  DE_INI_csvReslut @"csvReslut"


#define  DE_INI_baudRate @"baudRate"
#define  DE_INI_dataBits @"dataBits"
#define  DE_INI_stopBits @"stopBits"
#define  DE_INI_parity @"parity"
#define  DE_INI_flowControl @"parity"
#define  DE_INI_echo @"parity"

#define  DE_INI_stationName @"stationName"
#define PORTINI @"PortList"
#define PDCAINI @"PDCAList"
#define SOCKETINI @"SOCKETList"
#define STEPINI @"STEPList"


#define DE_INI_sub_station @"sub_station"
#define DE_INI_limitsversion @"limitsversion"
#define DE_INI_sub_station @"sub_station"
#define DE_INI_softwareversion @"softwareversion"
#define DE_INI_station_id @"station_id"
#define DE_INI_sfc @"sfc"
#define DE_INI_softwarename @"softwarename"

#define DE_INI_csvFileName @"csvFileName"
#define DE_INI_csvDir @"csvDir"
#define DE_INI_logFileName @"logFileName"
#define DE_INI_logDir @"logDir"
#define DE_INI_scriptDir @"scriptDir"
#define DE_INI_customerBinDir @"customerBinDir"
#define DE_INI_IoShowInputCommand @"IoShowInputCommand"
#define DE_INI_IoShowInputInitCommand @"IoShowInputInitCommand"




#define DE_STATION_INI_FILENAME  @"Station.plist"
#define DE_IP_INI_FILENAME  @"IP.plist"
#define DE_PORT_INI_FILENAME  @"Port.plist"
#define DE_PDCA_INI_FILENAME  @"PDCA.plist"
#define DE_SysIni_INI_FILENAME  @"SysIni.plist"

#define DE_SysIni_SnGetMethod  @"SnGetMethod"


#define DE_INI_ArmFileName  @"ArmFileName"
#define DE_INI_DutFileName @"DutFileName"

#define DE_INI_ArmDir @"ArmDir"
#define DE_INI_DutDir @"DutDir"

#define DE_INI_isEnable @"DE_INI_isEnable"

#define DE_INI_MainShow @"DE_INI_MainShow"

#define DE_PDCA_tag_IsAttribute @"DE_PDCA_tag_IsAttribute"

#define DE_PDCA_tag_Beishu  @"DE_PDCA_tag_Beishu"

#define  DE_INI_stationType @"DE_INI_stationType"

#define DE_SysIni_SnLength @"DE_SysIni_SnLength"

-(NSMutableDictionary *)CreateDictionarySysIni:(sysIni) sysini
{
    
    NSMutableDictionary *dic =  [[NSMutableDictionary alloc] init];
    [dic setObject:[[NSString alloc] initWithUTF8String:sysini->tag_sub_station] forKey:DE_INI_sub_station];
    [dic setObject:[[NSString alloc] initWithUTF8String:sysini->tag_limitsversion] forKey:DE_INI_limitsversion];
    [dic setObject:[[NSString alloc] initWithUTF8String:sysini->tag_sub_station] forKey:DE_INI_sub_station];
    [dic setObject:[[NSString alloc] initWithUTF8String:sysini->tag_softwareversion] forKey:DE_INI_softwareversion];
    [dic setObject:[[NSString alloc] initWithUTF8String:sysini->tag_station_id] forKey:DE_INI_station_id];
    [dic setObject:[[NSString alloc] initWithUTF8String:sysini->tag_sfc] forKey:DE_INI_sfc];
    [dic setObject:[[NSString alloc] initWithUTF8String:sysini->tag_softwarename] forKey:DE_INI_softwarename];
    
    
    [dic setObject:[[NSString alloc] initWithUTF8String:sysini->tag_csvDir] forKey:DE_INI_csvDir];
      [dic setObject:[[NSString alloc] initWithUTF8String:sysini->tag_logDir] forKey:DE_INI_logDir];
    
    [dic setObject:[[NSString alloc] initWithUTF8String:sysini->tag_IoShowInputCommand] forKey:DE_INI_IoShowInputCommand];
    [dic setObject:[[NSString alloc] initWithUTF8String:sysini->tag_IoShowInputInitCommand] forKey:DE_INI_IoShowInputInitCommand];
    
    [dic setObject:[NSString stringWithUTF8String:sysini->tag_scriptDir] forKey:DE_INI_scriptDir];
    [dic setObject:[NSString stringWithUTF8String:sysini->tag_customerBinDir] forKey:DE_INI_customerBinDir];
    [dic setObject:[NSString stringWithUTF8String:sysini->tag_csvFileName] forKey:DE_INI_csvFileName];
    [dic setObject:[NSString stringWithUTF8String:sysini->tag_LogFileName] forKey:DE_INI_logFileName];
    
    
    [dic setObject:[NSString stringWithUTF8String:sysini->tag_ArmFileName] forKey:DE_INI_ArmFileName];
    [dic setObject:[NSString stringWithUTF8String:sysini->tag_DutFileName] forKey:DE_INI_DutFileName];
    
    [dic setObject:[NSString stringWithUTF8String:sysini->tag_ArmDir] forKey:DE_INI_ArmDir];
    [dic setObject:[NSString stringWithUTF8String:sysini->tag_DutDir] forKey:DE_INI_DutDir];
    
    
    [dic setObject:[[NSString alloc] initWithFormat:@"%d" ,sysini->tag_SnGetMethod] forKey:DE_SysIni_SnGetMethod];
 
    [dic setObject:[[NSString alloc] initWithFormat:@"%d" ,sysini->tag_SnLength] forKey:DE_SysIni_SnLength];
  

    return dic;
}
-( void)GetDictionarySysIni:(sysIni ) sysini   DIC:(NSDictionary*) dic
{
    memset(sysini,0,sizeof(SysIni));
 
    if(dic)
    {
        strcat(sysini->tag_sfc,[[dic valueForKey:DE_INI_sfc] UTF8String]);
        strcat(sysini->tag_softwarename,[[dic valueForKey:DE_INI_softwarename] UTF8String]);
        strcat(sysini->tag_station_id,[[dic valueForKey:DE_INI_station_id] UTF8String]);
        strcat(sysini->tag_softwareversion,[[dic valueForKey:DE_INI_softwareversion] UTF8String]);
        strcat(sysini->tag_sub_station,[[dic valueForKey:DE_INI_sub_station] UTF8String]);
        strcat(sysini->tag_limitsversion,[[dic valueForKey:DE_INI_limitsversion] UTF8String]);
        if([[dic valueForKey:DE_INI_csvDir] UTF8String])
          strcat(sysini->tag_csvDir,[[dic valueForKey:DE_INI_csvDir] UTF8String]);
        if([[dic valueForKey:DE_INI_logDir] UTF8String])
          strcat(sysini->tag_logDir,[[dic valueForKey:DE_INI_logDir] UTF8String]);
        
        if([[dic valueForKey:DE_INI_scriptDir] UTF8String])
            strcat(sysini->tag_scriptDir,[[dic valueForKey:DE_INI_scriptDir] UTF8String]);
        
        if([[dic valueForKey:DE_INI_customerBinDir] UTF8String])
            strcat(sysini->tag_customerBinDir,[[dic valueForKey:DE_INI_customerBinDir] UTF8String]);
        if([[dic valueForKey:DE_INI_logFileName] UTF8String])
            strcat(sysini->tag_LogFileName,[[dic valueForKey:DE_INI_logFileName] UTF8String]);
        
        if([[dic valueForKey:DE_INI_csvFileName] UTF8String])
            strcat(sysini->tag_csvFileName,[[dic valueForKey:DE_INI_csvFileName] UTF8String]);
        
        if([[dic valueForKey:DE_INI_IoShowInputCommand] UTF8String])
            strcat(sysini->tag_IoShowInputCommand,[[dic valueForKey:DE_INI_IoShowInputCommand] UTF8String]);
        if([[dic valueForKey:DE_INI_IoShowInputInitCommand] UTF8String])
            strcat(sysini->tag_IoShowInputInitCommand,[[dic valueForKey:DE_INI_IoShowInputInitCommand] UTF8String]);
        
        if([[dic valueForKey:DE_SysIni_SnGetMethod] UTF8String])
          sysini->tag_SnGetMethod = atoi( [[dic valueForKey:DE_SysIni_SnGetMethod] UTF8String]);
        
      /*  [dic setObject:[NSString stringWithUTF8String:sysini->tag_ArmFileName] forKey:DE_INI_ArmFileName];
        [dic setObject:[NSString stringWithUTF8String:sysini->tag_DutFileName] forKey:DE_INI_DutFileName];
        
        [dic setObject:[NSString stringWithUTF8String:sysini->tag_ArmDir] forKey:DE_INI_ArmDir];
        [dic setObject:[NSString stringWithUTF8String:sysini->tag_DutDir] forKey:DE_INI_DutDir];*/
        
        
        
        if([[dic valueForKey:DE_INI_ArmFileName] UTF8String])
            strcat(sysini->tag_ArmFileName,[[dic valueForKey:DE_INI_ArmFileName] UTF8String]);
        if([[dic valueForKey:DE_INI_DutFileName] UTF8String])
            strcat(sysini->tag_DutFileName,[[dic valueForKey:DE_INI_DutFileName] UTF8String]);
        
        if([[dic valueForKey:DE_INI_ArmDir] UTF8String])
            strcat(sysini->tag_ArmDir,[[dic valueForKey:DE_INI_ArmDir] UTF8String]);
        if([[dic valueForKey:DE_INI_DutFileName] UTF8String])
            strcat(sysini->tag_DutDir,[[dic valueForKey:DE_INI_DutDir] UTF8String]);

        if([[dic valueForKey:DE_SysIni_SnLength] UTF8String])
            
            sysini->tag_SnLength = atoi([[dic valueForKey:DE_INI_DutDir] UTF8String]);
        
      if(sysini->tag_SnLength == 0)
          sysini->tag_SnLength  = 17;
        
    }
    return ;
}






-(NSMutableDictionary *)CreateDictionaryStep:(LpStep) step
{

    NSMutableDictionary *dic =  [[NSMutableDictionary alloc] init];
    [dic setObject:[[NSString alloc] initWithUTF8String:step->tag_stepName] forKey:DE_INI_Name];
    [dic setObject:[[NSString alloc] initWithUTF8String:step->tag_sendCommand] forKey:DE_INI_SendCONTENT];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d", step->tag_SleepDate] forKey:DE_INI_SleepDate];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d", step->tag_SucNextStep] forKey:DE_INI_SucNextStep];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d", step->tag_type] forKey:DE_INI_Type];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d", step->tag_exctimes] forKey:DE_INI_exctimes];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d", step->tag_algorithmType] forKey:DE_INI_algorithmType];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d",step->tag_enable] forKey:DE_INI_enable];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d",step->tag_pdca_index] forKey:DE_INI_PdcaIndex];
    [dic setObject:[[NSString alloc] initWithUTF8String:step->tag_filtrationBegin] forKey:DE_INI_filtrationBegin];
    [dic setObject:[[NSString alloc] initWithUTF8String:step->tag_filtrationEnd] forKey:DE_INI_filtrationEnd];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d",step->tag_socket_index] forKey:DE_INI_socketIndex];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d",step->tag_port_index] forKey:DE_INI_portIndex];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d",step->tag_isThread] forKey:DE_INI_Thread];
     [dic setObject:[[NSString alloc] initWithFormat:@"%d",step->tag_isMainShow] forKey:DE_INI_ISMAINSHOW];
     [dic setObject:[[NSString alloc] initWithUTF8String:step->tag_ReadEndFlage] forKey:DE_INI_ReadEndFlage];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d",step->tag_readEnterKey] forKey:DE_INI_ReadendEnterKey];
    
     return dic;
}
-( void)GetDictionaryStep:(LpStep) step   DIC:(NSDictionary*) dic
{

    
    memset(step,0,sizeof(Step));
    strcat(step->tag_stepName,[[dic valueForKey:DE_INI_Name] UTF8String]);
    strcat(step->tag_sendCommand,[[dic valueForKey:DE_INI_SendCONTENT] UTF8String]);
    strcat(step->tag_filtrationBegin,[[dic valueForKey:DE_INI_filtrationBegin] UTF8String]);
    strcat(step->tag_filtrationEnd,[[dic valueForKey:DE_INI_filtrationEnd] UTF8String]);
    
    step->tag_SleepDate =  atoi([[dic valueForKey:DE_INI_SleepDate] UTF8String]);
    
    step->tag_SucNextStep = atoi([[dic valueForKey:DE_INI_SucNextStep] UTF8String]);
    step->tag_type = atoi([[dic valueForKey:DE_INI_Type] UTF8String]);
    if ([[dic valueForKey:DE_INI_algorithmType] UTF8String]) {
        step->tag_algorithmType = atoi([[dic valueForKey:DE_INI_algorithmType] UTF8String]);
    }
    if ([[dic valueForKey:DE_INI_exctimes] UTF8String]) {
        step->tag_exctimes = atoi([[dic valueForKey:DE_INI_exctimes] UTF8String]);
    }
    step->tag_enable = atoi([[dic valueForKey:DE_INI_enable] UTF8String]);
    step->tag_pdca_index = atoi([[dic valueForKey:DE_INI_PdcaIndex] UTF8String]);
    step->tag_socket_index = atoi([[dic valueForKey:DE_INI_socketIndex] UTF8String]);
    step->tag_port_index = atoi([[dic valueForKey:DE_INI_portIndex] UTF8String]);
    step->tag_isThread = atoi([[dic valueForKey:DE_INI_Thread] UTF8String]);
    NSString *str = [dic valueForKey:DE_INI_ISMAINSHOW] ;
    if(str)
    step->tag_isMainShow = atoi([[dic valueForKey:DE_INI_ISMAINSHOW] UTF8String]);
    
    if([[dic valueForKey:DE_INI_ReadendEnterKey] UTF8String])
            step->tag_readEnterKey = atoi([[dic valueForKey:DE_INI_ReadendEnterKey] UTF8String]);
    if([[dic valueForKey:DE_INI_ReadEndFlage] UTF8String])
            strcat(step->tag_ReadEndFlage,[[dic valueForKey:DE_INI_ReadEndFlage] UTF8String]);
    
    
    return ;
}


-(NSMutableDictionary *)CreateDictionaryIp:(ipConfig) ip
{
    
    NSMutableDictionary *dic =  [[NSMutableDictionary alloc] init];
    [dic setObject:[[NSString alloc] initWithUTF8String:ip->tag_name] forKey:DE_INI_Name];
    [dic setObject:[[NSString alloc] initWithUTF8String:ip->tag_ip] forKey:DE_INI_ip];
    [dic setObject:[[NSString alloc] initWithFormat:@"%s", ip->tag_ReadEndFlage] forKey:DE_INI_ReadEndFlage];
    [dic setObject:[[NSString alloc] initWithFormat:@"%s", ip->tag_SendendFlage] forKey:DE_INI_SendendFlage];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d", ip->tag_port] forKey:DE_INI_Port];
     [dic setObject:[[NSString alloc] initWithFormat:@"%d", ip->tag_isSendEnterkey] forKey:DE_INI_SendendEnterKey];
     [dic setObject:[[NSString alloc] initWithFormat:@"%d", ip->tag_isReadEnterkey] forKey:DE_INI_ReadendEnterKey];
    return dic;
}
-( void)GetDictionaryIp:(ipConfig) ip   DIC:(NSDictionary*) dic
{
    
    
    memset(ip,0,sizeof(IPConfig));
    strcat(ip->tag_name,[[dic valueForKey:DE_INI_Name] UTF8String]);
    strcat(ip->tag_ip,[[dic valueForKey:DE_INI_ip] UTF8String]);
    strcat(ip->tag_ReadEndFlage ,[[dic valueForKey:DE_INI_ReadEndFlage] UTF8String]);
    
    if([[dic valueForKey:DE_INI_SendendFlage] UTF8String])
    
    strcat(ip->tag_SendendFlage,[[dic valueForKey:DE_INI_SendendFlage] UTF8String]);
    
    
    if([[dic valueForKey:DE_INI_SendendEnterKey] UTF8String])
    {
        ip->tag_isSendEnterkey = atoi([[dic valueForKey:DE_INI_SendendEnterKey] UTF8String]);
    }
    
    
    if([[dic valueForKey:DE_INI_ReadendEnterKey] UTF8String])
    {
        ip->tag_isReadEnterkey = atoi([[dic valueForKey:DE_INI_ReadendEnterKey] UTF8String]);
    }
    
    ip->tag_port =  atoi([[dic valueForKey:DE_INI_Port] UTF8String]);
    
    return;
}


-(NSMutableDictionary *)CreateDictionaryPDCA:(pdcaValue) vaule
{

    NSMutableDictionary *dic =  [[NSMutableDictionary alloc] init];
    [dic setObject:[[NSString alloc] initWithUTF8String:vaule->tag_Name] forKey:DE_INI_Name];
    [dic setObject:[[NSString alloc] initWithUTF8String:vaule->tag_Value] forKey:DE_INI_Value];
    [dic setObject:[[NSString alloc] initWithFormat:@"%s", vaule->tag_Max] forKey:DE_INI_Max];
    [dic setObject:[[NSString alloc] initWithFormat:@"%s", vaule->tag_Min] forKey:DE_INI_Min];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d", vaule->tag_ValueType] forKey:DE_INI_Type];
    
    [dic setObject:[[NSString alloc] initWithFormat:@"%s", vaule->tag_uutio] forKey:DE_INI_UUTO];
    [dic setObject:[[NSString alloc] initWithFormat:@"%s", vaule->tag_csvReslut] forKey:DE_INI_csvReslut];
    
     [dic setObject:[[NSString alloc] initWithFormat:@"%d", vaule->tag_IsAttribute] forKey:DE_PDCA_tag_IsAttribute];

    [dic setObject:[[NSString alloc] initWithFormat:@"%f", vaule->tag_Beishu] forKey:DE_PDCA_tag_Beishu];
    return dic;
    
}



-( void)GetDictionaryPDCA:(pdcaValue) vaule   DIC:(NSDictionary*) dic
{
 
    memset(vaule,0,sizeof(PdcaValue));//memset 一般使用“0”初始化内存单元，而且通常是给数组或结构体进行初始化
    strcat(vaule->tag_Name,[[dic valueForKey:DE_INI_Name] UTF8String]);
    strcat(vaule->tag_Value,[[dic valueForKey:DE_INI_Value] UTF8String]);
    strcat(vaule->tag_Max ,[[dic valueForKey:DE_INI_Max] UTF8String]);
    strcat(vaule->tag_Min,[[dic valueForKey:DE_INI_Min] UTF8String]);
    
    NSString *str = [dic valueForKey:DE_INI_UUTO] ;
    if(str)
    strcat(vaule->tag_uutio,[[dic valueForKey:DE_INI_UUTO] UTF8String]);
    
    
    vaule->tag_ValueType = atoi([[dic valueForKey:DE_INI_Type] UTF8String]);//atoi (表示 ascii to integer)是把字符串转换成整型数的一个函数
    
    
    NSString *str1 = [dic valueForKey:DE_INI_csvReslut] ;
    if(str1)
        strcat(vaule->tag_csvReslut,[[dic valueForKey:DE_INI_csvReslut] UTF8String]);
    
    if([[dic valueForKey:DE_PDCA_tag_IsAttribute] UTF8String])
        vaule->tag_IsAttribute = atoi( [[dic valueForKey:DE_PDCA_tag_IsAttribute] UTF8String]);
    if([[dic valueForKey:DE_PDCA_tag_Beishu] UTF8String])
        vaule->tag_Beishu = atof( [[dic valueForKey:DE_PDCA_tag_Beishu] UTF8String]);
    if(vaule->tag_Beishu == 0.0)
        vaule->tag_Beishu = 1.0;

    return ;
}


-(NSMutableDictionary *)CreateDictionaryPort:(portValue) vaule
{
    
    char tag_Name[PORTMAXNAME];//名称
    char tag_ReadEndFlage[PORTMAXENDFLAGE];//读取数据时候，结束标志
    char tag_SendendFlage[PORTMAXENDFLAGE];//读取数据时候，结束标志
    int tag_baudRate;//波特率
    int tag_dataBits;
    int tag_stopBits;//终止位s
    int tag_parity;
    int tag_flowControl;//
    int tag_echo;

    
    NSMutableDictionary *dic =  [[NSMutableDictionary alloc] init];
    [dic setObject:[[NSString alloc] initWithUTF8String:vaule->tag_Name] forKey:DE_INI_Name];
    [dic setObject:[[NSString alloc] initWithUTF8String:vaule->tag_ReadEndFlage] forKey:DE_INI_ReadEndFlage];
    [dic setObject:[[NSString alloc] initWithFormat:@"%s", vaule->tag_SendendFlage] forKey:DE_INI_SendendFlage];

    [dic setObject:[[NSString alloc] initWithFormat:@"%d", vaule->tag_baudRate] forKey:DE_INI_baudRate];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d", vaule->tag_dataBits] forKey:DE_INI_dataBits];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d", vaule->tag_stopBits] forKey:DE_INI_stopBits];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d", vaule->tag_parity] forKey:DE_INI_parity];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d", vaule->tag_flowControl] forKey:DE_INI_flowControl];
    [dic setObject:[[NSString alloc] initWithFormat:@"%d", vaule->tag_echo] forKey:DE_INI_echo];
    return dic;
}
-( void)GetDictionaryPort:(portValue) vaule   DIC:(NSDictionary*) dic
{
    
    memset(vaule,0,sizeof(portValue));
    
    
    
    strcat(vaule->tag_Name,[[dic valueForKey:DE_INI_Name] UTF8String]);
    strcat(vaule->tag_ReadEndFlage,[[dic valueForKey:DE_INI_ReadEndFlage] UTF8String]);
    strcat(vaule->tag_ReadEndFlage ,[[dic valueForKey:DE_INI_SendendFlage] UTF8String]);
    
    
    vaule->tag_baudRate = atoi([[dic valueForKey:DE_INI_baudRate] UTF8String]);
    vaule->tag_dataBits = atoi([[dic valueForKey:DE_INI_dataBits] UTF8String]);
    vaule->tag_parity = atoi([[dic valueForKey:DE_INI_stopBits] UTF8String]);
    vaule->tag_flowControl = atoi([[dic valueForKey:DE_INI_parity] UTF8String]);
    vaule->tag_flowControl = atoi([[dic valueForKey:DE_INI_flowControl] UTF8String]);
    vaule->tag_echo = atoi([[dic valueForKey:DE_INI_echo] UTF8String]);
    return ;
}


-(NSMutableDictionary *)CreateDictionaryStation:(lpStation) lp1Station
{
    
    NSMutableDictionary *dic =  [[NSMutableDictionary alloc]init];
    NSMutableArray *step = [[NSMutableArray alloc] init];
    for(int i =0;i <lp1Station->tag_totalCount;i++ )
    {
       NSMutableDictionary*dic1 =  [self CreateDictionaryStep:&lp1Station->tag_step[i] ];
      [step addObject:dic1];
        
    }
    [dic setObject:[[NSString alloc] initWithFormat:@"%d",lp1Station->tag_snIndex] forKey:DE_INI_SnIndex];
    
    [dic setObject:[[NSString alloc] initWithFormat:@"%d",lp1Station->tag_socket_index] forKey:DE_INI_socketIndex];
    [dic setObject:[[NSString alloc] initWithUTF8String:lp1Station->tag_Name] forKey:DE_INI_stationName];
      [dic setObject:[[NSString alloc] initWithFormat:@"%d",lp1Station->tag_isThread] forKey:DE_INI_Thread];
     [dic setObject:[[NSString alloc] initWithFormat:@"%d",lp1Station->tag_isWait] forKey:DE_INI_Wait];
    NSString  *isEnbale  = [[NSString alloc] initWithFormat:@"%d",lp1Station->tag_isEnable];
    [dic setObject:isEnbale forKey:DE_INI_isEnable];
    
    
    [dic setObject:[[NSString alloc] initWithFormat:@"%d",lp1Station->tag_MainShow] forKey:DE_INI_MainShow];
    [dic setObject:step forKey:STEPINI];
    
    
    
    [dic setObject:[[NSString alloc] initWithFormat:@"%d",lp1Station->tag_stationType] forKey:DE_INI_stationType];
    [dic setObject:step forKey:STEPINI];
    
    return dic;
}

-(NSMutableDictionary *)CreateDictionaryIpBag:(ipBag) value
{
    
    NSMutableDictionary *dic =  [[NSMutableDictionary alloc]init];
    NSMutableArray *Array = [[NSMutableArray alloc] init];
    for(int i =0;i <IPCOUNT;i++ )
    {
        NSMutableDictionary*dic1 =  [self CreateDictionaryIp:&value->tag_ipConfig[i] ];
        [Array addObject:dic1];
        
    }
    [dic setObject:Array forKey:SOCKETINI];
    return dic;
}


-(NSMutableDictionary *)CreateDictionaryPdcaManage:(pdcaValueManage) value
{
    
    NSMutableDictionary *dic =  [[NSMutableDictionary alloc]init];
    NSMutableArray *Array = [[NSMutableArray alloc] init];
    for(int i =0;i <value->tag_totalCount;i++ )
    {
        NSMutableDictionary*dic1 =  [self CreateDictionaryPDCA:&value->tag_PdcaValue[i] ];
        [Array addObject:dic1];
        
    }
    [dic setObject:Array forKey:PDCAINI];
    return dic;
}


-(NSMutableDictionary *)CreateDictionaryPortManage:(portValueManage) value
{
    
    NSMutableDictionary *dic =  [[NSMutableDictionary alloc]init];
    NSMutableArray *Array = [[NSMutableArray alloc] init];
    for(int i =0;i <value->tag_totalCount;i++ )
    {
        NSMutableDictionary*dic1 =  [self CreateDictionaryIp:&value->tag_PortValue[i] ];
        [Array addObject:dic1];
        
    }
    [dic setObject:Array forKey:PORTINI];
    return dic;
}


-(NSMutableArray *)CreateDictionaryStationManage:(stationManage) lpStationManage
{
    
    
    NSMutableDictionary *dic = [[NSDictionary alloc] init];
    NSMutableArray *step = [[NSMutableArray alloc] init];
    for(int i =0;i <lpStationManage->tag_totalCount;i++ )
    {
        NSMutableDictionary*dic1 =  [self CreateDictionaryStation:&lpStationManage->tag_Station[i] ];
        [step addObject:dic1];
        
    }
    
    return step;
}


-(void) loadStation:(stationManage) lpStationManage
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *plistpath = [paths objectAtIndex:0];
   
    NSString *filename=[plistpath stringByAppendingPathComponent:DE_STATION_INI_FILENAME];
    NSArray *aManage =    [NSArray   arrayWithContentsOfFile:filename];
    lpStationManage->tag_totalCount = aManage.count;
    for(int i =0; i< lpStationManage->tag_totalCount;i++)
      {
          NSDictionary *station = aManage[i];
          NSString *name =  [station valueForKey:DE_INI_stationName];
          NSString *SocketIndex =  [station valueForKey:DE_INI_socketIndex];
          NSString *SnIndex =  [station valueForKey:DE_INI_SnIndex];
          NSString *Wait =  [station valueForKey:DE_INI_Wait];
          NSString *isEnable =  [station valueForKey:DE_INI_isEnable];
          NSString *MainShow =  [station valueForKey:DE_INI_MainShow];
         
          NSString *stationType =  [station valueForKey:DE_INI_stationType];
          
          NSString *thread =  [station valueForKey:DE_INI_Thread];
          
          NSArray *stepList =  [station valueForKey:STEPINI];
          lpStationManage->tag_Station[i].tag_isOpenSpreadOut = 1;
          
          
          memset(lpStationManage->tag_Station[i].tag_Name,0,sizeof(lpStationManage->tag_Station[i].tag_Name));
          strcat(lpStationManage->tag_Station[i].tag_Name,[name UTF8String]);
          
          if(SnIndex)
          {
              lpStationManage->tag_Station[i].tag_snIndex = atoi([SnIndex UTF8String]);
          }
          if(SocketIndex)
          {
              lpStationManage->tag_Station[i].tag_socket_index = atoi([SocketIndex UTF8String]);
          }
          
          
          if(Wait)
          {              lpStationManage->tag_Station[i].tag_isWait = atoi([Wait UTF8String]);
          }
          if(thread)
          {
              lpStationManage->tag_Station[i].tag_isThread = atoi([thread UTF8String]);
          }
          

          
          if(MainShow)
          {
              lpStationManage->tag_Station[i].tag_MainShow = atoi([MainShow UTF8String]);
          }
          if(isEnable)
          {
              lpStationManage->tag_Station[i].tag_isEnable = atoi([isEnable UTF8String]);
          }
          
          lpStationManage->tag_Station[i].tag_totalCount = stepList.count;
          
          for(int j = 0; j < lpStationManage->tag_Station[i].tag_totalCount;j++)
          {
              NSDictionary * step = stepList[j];
              [self GetDictionaryStep:&lpStationManage->tag_Station[i].tag_step[j] DIC: step];
          }
          if(stationType)
          {
              lpStationManage->tag_Station[i].tag_stationType = atoi([stationType UTF8String]);
          }
      }
}
extern char *GetCurrentTimeCtr();

-(void) SaveStation:(stationManage) lpStationManage
{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *plistpath = [paths objectAtIndex:0];

    NSString *filename=[plistpath stringByAppendingPathComponent:DE_STATION_INI_FILENAME];
   char *time = GetCurrentTimeCtr();
    NSString *Beifenfilename = [[NSString alloc] initWithFormat:@"%@/%s%@" ,plistpath,time,DE_STATION_INI_FILENAME];

    NSFileManager* fm = [NSFileManager defaultManager];
    [fm createFileAtPath:filename contents:nil attributes:nil];

    //写入内容
    NSMutableArray *dic = [self CreateDictionaryStationManage:lpStationManage];
    
    
    
    [dic writeToFile:filename atomically:YES];
    [dic writeToFile:Beifenfilename atomically:YES];

}


-(void) loadIP:(ipBag) value
{
   
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
        NSString *plistpath = [paths objectAtIndex:0];
   
        NSString *filename=[plistpath stringByAppendingPathComponent:DE_IP_INI_FILENAME];
        NSDictionary *station =    [NSDictionary   dictionaryWithContentsOfFile:filename];
        
        NSArray *ArrayList =  [station valueForKey:SOCKETINI];
        value->tag_count = ArrayList.count;
        
        for(int j = 0; j <  value->tag_count;j++)
        {
            NSDictionary * val = ArrayList[j];
            [self GetDictionaryIp:&value->tag_ipConfig[j] DIC: val];
        }
    
    
}
-(void) SaveIP:(ipBag) value
{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *plistpath = [paths objectAtIndex:0];
 
    NSString *filename=[plistpath stringByAppendingPathComponent:DE_IP_INI_FILENAME];
    
    NSFileManager* fm = [NSFileManager defaultManager];
    [fm createFileAtPath:filename contents:nil attributes:nil];
    
    //写入内容
    NSMutableDictionary *dic = [self CreateDictionaryIpBag:value];
    [dic writeToFile:filename atomically:YES];
    
}

-(void) loadPort:(portValueManage) value
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *plistpath = [paths objectAtIndex:0];

    NSString *filename=[plistpath stringByAppendingPathComponent:DE_PORT_INI_FILENAME];
    NSDictionary *station =    [NSDictionary   dictionaryWithContentsOfFile:filename];
    
    NSArray *ArrayList =  [station valueForKey:SOCKETINI];
    value->tag_totalCount = ArrayList.count;
    
    for(int j = 0; j <  value->tag_totalCount;j++)
    {
        NSDictionary * val = ArrayList[j];
        [self GetDictionaryPort:&value->tag_PortValue[j] DIC: val];
    }
}


-(void) SavePort:(portValueManage) value
{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *plistpath = [paths objectAtIndex:0];

    NSString *filename=[plistpath stringByAppendingPathComponent:DE_PORT_INI_FILENAME];
    
    NSFileManager* fm = [NSFileManager defaultManager];
    [fm createFileAtPath:filename contents:nil attributes:nil];
    
    //写入内容
    NSMutableDictionary *dic = [self CreateDictionaryPort:value];
    [dic writeToFile:filename atomically:YES];
    
}

-(void) loadPDCA:(pdcaValueManage) value
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *plistpath = [paths objectAtIndex:0];

    NSString *filename=[plistpath stringByAppendingPathComponent:DE_PDCA_INI_FILENAME];
    NSDictionary *station =    [NSDictionary   dictionaryWithContentsOfFile:filename];
   
    NSArray *ArrayList =  [station valueForKey:PDCAINI];
    value->tag_totalCount = ArrayList.count;
    
    for(int j = 0; j <  value->tag_totalCount;j++)
    {
        NSDictionary * val = ArrayList[j];
        [self GetDictionaryPDCA:&value->tag_PdcaValue[j] DIC: val];
    }
    
}


-(void) SavePDCA:(pdcaValueManage) value
{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *plistpath = [paths objectAtIndex:0];

    NSString *filename=[plistpath stringByAppendingPathComponent:DE_PDCA_INI_FILENAME];
    
    NSFileManager* fm = [NSFileManager defaultManager];
    [fm createFileAtPath:filename contents:nil attributes:nil];
    
    //写入内容
    NSMutableDictionary *dic = [self CreateDictionaryPdcaManage:value];
    [dic writeToFile:filename atomically:YES];
    
}


-(void) loadSysIni:(sysIni) value
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *plistpath = [paths objectAtIndex:0];

    NSString *filename=[plistpath stringByAppendingPathComponent:DE_SysIni_INI_FILENAME];
    NSDictionary *sys =    [NSDictionary   dictionaryWithContentsOfFile:filename];

    [self GetDictionarySysIni:value DIC: sys];
 
    
}
-(void) SaveSysIni:(sysIni) value
{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *plistpath = [paths objectAtIndex:0];

    NSString *filename=[plistpath stringByAppendingPathComponent:DE_SysIni_INI_FILENAME];
    
    NSFileManager* fm = [NSFileManager defaultManager];
    [fm createFileAtPath:filename contents:nil attributes:nil];
    
    //写入内容
    NSMutableDictionary *dic = [self CreateDictionarySysIni:value];
    [dic writeToFile:filename atomically:YES];
    
}


void SaveData()
{
    DataSave *data = [[DataSave alloc] init];
    
    
    [data SavePDCA:&g_sConfig->tag_pdcaValueManage];
     [data SaveIP:&g_sConfig->tag_IpBag];
      [data SavePort:&g_sConfig->tag_PortValueManage];
     [data SaveStation:&g_sConfig->tag_stationManage];
    [data SaveSysIni:&g_sConfig->tag_SysIni];
    
}

extern char *FWDLCOMMAND[];
void loadFWDL()
{
    int i =0;
    memset(&g_sConfig->tag_stationManage,0,sizeof(g_sConfig->tag_stationManage));
    g_sConfig->tag_stationManage.tag_totalCount = 1;
   
   while(FWDLCOMMAND[i])
   {
       memcpy(&g_sConfig->tag_stationManage.tag_Station[0].tag_step[i].tag_stepName,FWDLCOMMAND[i],10);
       memcpy(g_sConfig->tag_stationManage.tag_Station[0].tag_step[i].tag_sendCommand,FWDLCOMMAND[i],strlen(FWDLCOMMAND[i]));
       g_sConfig->tag_stationManage.tag_Station[0].tag_totalCount++;
       i++;
   }
}
extern char *FCTCOMMAND[];
void loadFCT()
{
    int i =0;
    memset(&g_sConfig->tag_stationManage,0,sizeof(g_sConfig->tag_stationManage));
    g_sConfig->tag_stationManage.tag_totalCount = 1;
    
    while(FWDLCOMMAND[i])
    {
        memcpy(&g_sConfig->tag_stationManage.tag_Station[0].tag_step[i].tag_stepName,FCTCOMMAND[i],10);
        memcpy(g_sConfig->tag_stationManage.tag_Station[0].tag_step[i].tag_sendCommand,FCTCOMMAND[i],strlen(FCTCOMMAND[i]));
        g_sConfig->tag_stationManage.tag_Station[0].tag_totalCount++;
        i++;
    }
}
void DataLoad()
{
    DataSave *data = [[DataSave alloc] init];
    [data loadPDCA:&g_sConfig->tag_pdcaValueManage];
    [data loadIP:&g_sConfig->tag_IpBag];
    [data loadPort:&g_sConfig->tag_PortValueManage];
    [data loadStation:&g_sConfig->tag_stationManage];
    [data loadSysIni:&g_sConfig->tag_SysIni];
    
}



void WriteNewFile(char *fileName,char *content)
{
    NSError *error = [[NSError alloc] init];
    NSString *Connect = [[NSString alloc] initWithUTF8String:content];
    NSString *filename = [[NSString alloc] initWithUTF8String:fileName];
    [Connect writeToFile:filename atomically:YES encoding:NSUTF8StringEncoding error:&error];
}
@end
