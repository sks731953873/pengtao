//
//  Log.h
//  strongTest
//
//  Created by strong on 2018/1/17.
//  Copyright © 2018年 strong. All rights reserved.
//

#ifndef Log_h
#define Log_h

#include <stdlib.h>
#define LOGMAXCOUNT 1024*1024
typedef struct _uct_log
{
    char *tag_log;
    char *tag_time;
    struct _uct_log *tag_next;
}Log,*lpLog;

typedef struct _uct_logHead
{
    int tag_Count;
   lpLog tag_Headlog;
     lpLog tag_Endlog;
}logHead,*lpLogHead;
void AddLog(char *Text);
void CelanLog();
#endif /* Log_h */
