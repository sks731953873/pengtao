//
//  pdcaView.m
//  strongTest
//
//  Created by strong on 2017/12/20.
//  Copyright © 2017年 strong. All rights reserved.
//

#import "pdcaView.h"
#include "Config.h"

@implementation pdcaView

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}
/*******************************************************************************************
 **函数名：InitUI
 **参数：:(int) index PDCA:(pdcaValue) pdca
 **功能：初始化步骤
 **返回值：
 *******************************************************************************************/
-(void)InitUI:(int) index PDCA:(pdcaValue) pdca
{
    tag_pdcaValue = pdca;
    
    tag_UIIndex = [[NSTextField alloc] init];
    tag_UIIndex.stringValue = [[NSString alloc] initWithFormat:@"%2d",index];
   
    
    
    tag_UIName = [[NSTextField alloc] init];
    if(strlen(tag_pdcaValue->tag_Name) >0)
    {
        tag_UIName.stringValue = [[NSString alloc] initWithUTF8String:tag_pdcaValue->tag_Name];
    }

    tag_UIUuto = [[NSTextField alloc] init];

    if(strlen(tag_pdcaValue->tag_uutio) >0)
    {
        tag_UIUuto.stringValue = [[NSString alloc] initWithFormat:@"%s",tag_pdcaValue->tag_uutio];
    }
     tag_UIIsPass = [[NSTextField alloc] init];
    
    tag_UIMax = [[NSTextField alloc] init];
    
    if(strlen(tag_pdcaValue->tag_Max) >0)
    {
        tag_UIMax.stringValue = [[NSString alloc] initWithFormat:@"%s",tag_pdcaValue->tag_Max];
    }
    
    tag_UIMin = [[NSTextField alloc] init];
    
    if(strlen(tag_pdcaValue->tag_Min) >0)
    {
        tag_UIMin.stringValue = [[NSString alloc] initWithFormat:@"%s",tag_pdcaValue->tag_Min];
    }
     tag_UIcsv_reslut = [[NSTextField alloc] init];
    if(strlen(tag_pdcaValue->tag_csvReslut) >0)
    {
        tag_UIcsv_reslut.stringValue = [[NSString alloc] initWithFormat:@"%s",tag_pdcaValue->tag_csvReslut];
    }
    
    
    
    [tag_UICommandType selectItemAtIndex:tag_pdcaValue->tag_ValueType];
    
    
    tag_UISave = [[NSButton alloc] init];
    [tag_UISave setTitle:@"保存"];
    [tag_UISave  setTarget:self];
    [tag_UISave setAction:@selector(SaveClick:)];
    [tag_UISave setBezelStyle:NSBezelStyleSmallSquare];
    
    /*
     enum_pdcaValueType_string_pass,//返回结果的类型 串类型
     
     enum_pdcaValueType_bool,
     enum_pdcaValueType_double,//
     enum_pdcaValueType_string_Value,//保存数据
     enum_pdcaValueType_string_Set,//设置
     */
    
    
    tag_UICommandType = [[NSComboBox alloc] init];
    [tag_UICommandType addItemWithObjectValue:(@"String_pass")];
    [tag_UICommandType addItemWithObjectValue:(@"Bool")];
    [tag_UICommandType addItemWithObjectValue:(@"Double")];
    [tag_UICommandType addItemWithObjectValue:(@"String_value")];
    [tag_UICommandType addItemWithObjectValue:(@"String_Set")];
    [tag_UICommandType addItemWithObjectValue:(@"SnRead")];
    [tag_UICommandType addItemWithObjectValue:(@"Int")];
    [tag_UICommandType selectItemAtIndex:tag_pdcaValue->tag_ValueType];
    
    tag_UIIsAttribute =[[NSButton alloc] init];
    [tag_UIIsAttribute setButtonType:NSButtonTypeSwitch];
    [tag_UIIsAttribute setTitle:@""];
    [tag_UIIsAttribute setState:tag_pdcaValue->tag_IsAttribute];
    
    
    tag_UIBeishu =[[NSTextField alloc] init];
    if(tag_pdcaValue->tag_Beishu ==0)
        tag_pdcaValue->tag_Beishu =1.0;
    tag_UIBeishu.stringValue =  [[NSString alloc] initWithFormat:@"%f",tag_pdcaValue->tag_Beishu];
}
/*******************************************************************************************
 **函数名：SaveClick
 **参数：:
 **功能：工位保存
 **返回值：
 *******************************************************************************************/
- (IBAction)SaveClick:(id)sender
{
    
    if(tag_UIName.stringValue.length ==0)
    {
        NSAlert *alert = [NSAlert new];
        [alert addButtonWithTitle:@"确定"];
        [alert setMessageText:@"名称为空，请输入名称，再保存!"];
        [alert beginSheetModalForWindow:[tag_UIName window] completionHandler:^(NSModalResponse returnCode) {
            if(returnCode == NSAlertFirstButtonReturn)
            {
                
                
            }
        }];
        return ;
    }
    memset(tag_pdcaValue->tag_Name,0,sizeof(tag_pdcaValue->tag_Name));
    
    strcat(tag_pdcaValue->tag_Name,[tag_UIName.stringValue UTF8String]);
    
    memset(tag_pdcaValue->tag_Max,0,sizeof(tag_pdcaValue->tag_Max));
    
    strcat(tag_pdcaValue->tag_Max,[tag_UIMax.stringValue UTF8String]);
    
    memset(tag_pdcaValue->tag_Min,0,sizeof(tag_pdcaValue->tag_Min));
    
    strcat(tag_pdcaValue->tag_Min,[tag_UIMin.stringValue UTF8String]);
    
    memset(tag_pdcaValue->tag_uutio,0,sizeof(tag_pdcaValue->tag_uutio));
    
    strcat(tag_pdcaValue->tag_uutio,[tag_UIUuto.stringValue UTF8String]);
    
    tag_pdcaValue->tag_ValueType = tag_UICommandType.indexOfSelectedItem;
    

    memset(tag_pdcaValue->tag_csvReslut,0,sizeof(tag_pdcaValue->tag_csvReslut));
    
    strcat(tag_pdcaValue->tag_csvReslut,[tag_UIcsv_reslut.stringValue UTF8String]);
    


    NSAlert *alert = [NSAlert new];
    [alert addButtonWithTitle:@"确定"];
    [alert addButtonWithTitle:@"取消"];
    [alert setMessageText:@"确定保存输入文本?"];
    [alert setInformativeText:@"如果确定保存，之前的文本不能再找回!"];
    
    [alert beginSheetModalForWindow:[tag_UISave window] completionHandler:^(NSModalResponse returnCode) {
        if(returnCode == NSAlertFirstButtonReturn){
            
            Save();
            
        }else if(returnCode == NSAlertSecondButtonReturn){
            
        }
    }];
}

/*******************************************************************************************
 **函数名：SaveClick
 **参数：:
 **功能：工位保存
 **返回值：
 *******************************************************************************************/
- (void)GetParameter
{
    
   
    memset(tag_pdcaValue->tag_Name,0,sizeof(tag_pdcaValue->tag_Name));
    
    strcat(tag_pdcaValue->tag_Name,[tag_UIName.stringValue UTF8String]);
    
    memset(tag_pdcaValue->tag_Max,0,sizeof(tag_pdcaValue->tag_Max));
    
    strcat(tag_pdcaValue->tag_Max,[tag_UIMax.stringValue UTF8String]);
    
    memset(tag_pdcaValue->tag_Min,0,sizeof(tag_pdcaValue->tag_Min));
    
    strcat(tag_pdcaValue->tag_Min,[tag_UIMin.stringValue UTF8String]);
    
    memset(tag_pdcaValue->tag_uutio,0,sizeof(tag_pdcaValue->tag_uutio));
    
    strcat(tag_pdcaValue->tag_uutio,[tag_UIUuto.stringValue UTF8String]);
    
    tag_pdcaValue->tag_ValueType = tag_UICommandType.indexOfSelectedItem;
    
    
    memset(tag_pdcaValue->tag_csvReslut,0,sizeof(tag_pdcaValue->tag_csvReslut));
    
    strcat(tag_pdcaValue->tag_csvReslut,[tag_UIcsv_reslut.stringValue UTF8String]);
    tag_pdcaValue->tag_IsAttribute = tag_UIIsAttribute.state;
    
    
    tag_pdcaValue->tag_Beishu = atof( [tag_UIBeishu.stringValue UTF8String]);
    
    if(tag_pdcaValue->tag_Beishu ==0.0)
        tag_pdcaValue->tag_Beishu =1.0;
    //   [tag_UIIsAttribute setState:tag_pdcaValue->tag_IsAttribute];
}


/*******************************************************************************************
 **函数名：UIUpdata
 **参数：:(int) index  显示的ID STEP:(LpStep) step 步骤
 **功能：刷新步骤
 **返回值：
 *******************************************************************************************/
-(void)UIUpdata:(int) index PDCA:(pdcaValue) pdca
{
    
    if(pdca)
    tag_pdcaValue = pdca;
    tag_UIIndex.stringValue = [[NSString alloc] initWithFormat:@"%2d",index];
    {
        tag_UIName.stringValue = [[NSString alloc] initWithUTF8String:tag_pdcaValue->tag_Name];
    }
    {
        tag_UIUuto.stringValue = [[NSString alloc] initWithFormat:@"%s",tag_pdcaValue->tag_uutio];
    }
   
    {
        tag_UIMax.stringValue = [[NSString alloc] initWithFormat:@"%s",tag_pdcaValue->tag_Max];
    }
    {
        tag_UIMin.stringValue = [[NSString alloc] initWithFormat:@"%s",tag_pdcaValue->tag_Min];
    }
    
    [tag_UICommandType selectItemAtIndex:tag_pdcaValue->tag_ValueType];
}
/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：
 **返回值：
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{

    id retid = nil;
    NSString *title =  tableColumn.title;
    if(tableView.tableColumns[uiPdca_enum_index] == tableColumn)
    {
        
        retid = tag_UIIndex;
    }
    else
        if(tableView.tableColumns[uiPdca_enum_name] == tableColumn)
        {
            retid = tag_UIName;
            
        }
        else
            if(tableView.tableColumns[uiPdca_enum_csv_reslut] == tableColumn)
            {
                retid = tag_UIcsv_reslut;
            }
            else
                if(tableView.tableColumns[uiPdca_enum_Max] == tableColumn)
                {
                    retid = tag_UIMax;
                }
                else
                    if(tableView.tableColumns[uiPdca_enum_Min] == tableColumn)
                    {
                        retid = tag_UIMin;
                    }
                    else
                        if(tableView.tableColumns[uiPdca_enum_type] == tableColumn)
                        {
                            retid = tag_UICommandType;
                        }
                        else
                            if(tableView.tableColumns[uiPdca_enum_Uuto] == tableColumn)
                            {
                                retid = tag_UIUuto;
                            }
                            else
                                if(tableView.tableColumns[uiPdca_enum_IsAttribute] == tableColumn)
                                {
                                    retid = tag_UIIsAttribute;
                                }
                                else
                                    if(tableView.tableColumns[uiPdca_enum_Beishu] == tableColumn)
                                    {
                                        retid = tag_UIBeishu;
                                    }
                         
    
    
    return retid;
}

@end
