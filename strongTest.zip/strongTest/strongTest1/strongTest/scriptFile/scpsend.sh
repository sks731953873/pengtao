#!/usr/bin/expect -f
#author=zhongwenpan
set hostip [lindex $argv 0]
set destpath  [lindex $argv 1]
set hostfile [lindex $argv 2]

spawn scp $destpath root@$hostip:/opt/seeing/dut_firmware/$hostfile
expect {
    "*(yes/no)?" {
        send "yes\n" 
        expect "* password:"
        send "123456\n"
    }
    "* password:" {
        send "123456\n"
    }
}
interact


