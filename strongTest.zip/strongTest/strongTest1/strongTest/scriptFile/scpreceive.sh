#!/usr/bin/expect -f
#author=zhongwenpan
set hostip [lindex $argv 0]
set sendpath [lindex $argv 1]
set sendfile  [lindex $argv 2]

spawn scp root@$hostip:/opt/seeing/log/$sendpath $sendfile
expect {
"*(yes/no)?" {
send "yes\n"
expect "* password:"
send "123456\n"
}
"* password:" {
send "123456\n"
}
}
interact
