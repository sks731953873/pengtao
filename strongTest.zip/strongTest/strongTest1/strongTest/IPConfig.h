//
//  IPConfig.h
//  strongTest
//
//  Created by strong on 2017/12/19.
//  Copyright © 2017年 strong. All rights reserved.
//

#ifndef IPConfig_h
#define IPConfig_h

#include <stdio.h>

#define IPCOUNT 60
#define IPMAXLEN 40
#define IPNAMEMAXLEN 1024
#define MAXENDFLAGE 1024
//一个ip配置
typedef struct _IPConfig
{
    char tag_ip[IPMAXLEN];//IP地址
    int  tag_port;
    int tag_isSendEnterkey;//是否需要回车换行
     int tag_isReadEnterkey;//是否需要回车换行
    int tag_isReadEnterkey2;//是否需要回车换行,优先等级高，值来源于step
    char tag_ReadEndFlage[MAXENDFLAGE];//读取数据时候，结束标志
    char tag_ReadEndFlage2[MAXENDFLAGE];//读取数据时候，结束标志,优先等级高，值来源于step
    char tag_SendendFlage[MAXENDFLAGE];//读取数据时候，结束标志
    char tag_name[IPNAMEMAXLEN];//名称
}IPConfig,*ipConfig;
//IP管理
typedef struct _IpBag
{
    int tag_count;//IP的个数
    IPConfig tag_ipConfig[IPCOUNT];
    
}IpBag,*ipBag;
/*******************************************************************************************
 **函数名：IpDel
 **参数：,IpDel(ipBag ipbag,int index) 第几个ip
 **功能： 删除一个ip配置
 **返回值：
 *******************************************************************************************/

int IpDel(ipBag ipbag,int index);
#endif /* IPConfig_h */
