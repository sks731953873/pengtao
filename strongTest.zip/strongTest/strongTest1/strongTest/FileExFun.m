//
//  FileBase.m
//  TestResistance
//
//  Created by TOD on 6/26/14.
//  Copyright (c) 2014 CeWay. All rights reserved.
//

#import "FileExFun.h"

@implementation FileExFun



+(void) InitFWDL
{
   // [   [NSString alloc] initWithUTF8String:Temp]
    //[FileExFun _1Product= [NSString alloc] initWithUTF8String:@""];
}
/*
 从 string 中截取 begin 和 end 之间的字符串 例子请见 StringToIn函数中 107行
 */
+(BOOL) ContainStr:(NSString *) string BEGIN:(NSString *) begin
{
    char *cStr = [string UTF8String];
    char *cbegin = [begin UTF8String];
    char *FindBegin =  strstr(cStr,cbegin);
    if(FindBegin)
    {
        return YES;
    }
    return NO;
}
//获取指定字符之后的内容
+(NSString *) GetSubLast:(NSString *) string BEGIN:(NSString *) begin
{
    char *cStr = [string UTF8String];
    char *cbegin = [begin UTF8String];
    char *FindBegin =  strstr(cStr,cbegin);
    if(FindBegin)
    {
        int len=strlen(FindBegin)-strlen(cbegin);
        char *Temp = malloc(len+1);
        memset(Temp,0,len+1);
        memcpy(Temp,FindBegin + strlen(cbegin),len);
        NSString *ret = [[NSString alloc] initWithUTF8String:Temp]    ;
        return ret;
    }
    return nil;
}
//获取指定字符之前的内容
+(NSString *) GetSubPrevious:(NSString *) string BEGIN:(NSString *) begin LEN:(int ) len
{
    char *cStr = [string UTF8String];
    char *cbegin = [begin UTF8String];
    char *FindBegin =  strstr(cStr,cbegin);
    if(FindBegin)
    {
        char *Temp = malloc(len+1);
        memset(Temp,0,len+1);
        memcpy(Temp,FindBegin - len,len);
        NSString *ret = [[NSString alloc] initWithUTF8String:Temp]    ;
        free(Temp);
        return ret;
        
    }
    return nil;
}
/*
 从 string 中截取 begin 和 end 之间的字符串 例子请见 StringToIn函数中 107行
 */
+(NSString *) GetSub:(NSString *) string BEGIN:(NSString *) begin  END:(NSString *) end
{
    char *cStr = [string UTF8String];
    char *cbegin = [begin UTF8String];
    char *cend = [end UTF8String];
    char *FindBegin =  strstr(cStr,cbegin);
    if(FindBegin)
    {
        char *FindEnd =  strstr(FindBegin,cend);
        if(FindEnd)
        {
            
            char *Temp = malloc(FindEnd-FindBegin -  strlen(cbegin)+1);
            memset(Temp,0,FindEnd-FindBegin -  strlen(cbegin)+1);
            memcpy(Temp,FindBegin + strlen(cbegin),FindEnd-FindBegin -  strlen(cbegin));
            NSString *ret = [[NSString alloc] initWithUTF8String:Temp]    ;
            free(Temp);
            
            return ret;
        }
    }
    return nil;
}

/*
 从 string 中截取 begin 和 end 之间的字符串
 */
+(NSString *) CtrGetSub:(char *) cStr BEGIN:(char *) cbegin  END:(char *) cend
{
    
    char *FindBegin =  strstr(cStr,cbegin);
    if(FindBegin)
    {
        char *FindEnd =  strstr(FindBegin,cend);
        if(FindEnd)
        {
            
            
            
            char *Temp = malloc(FindEnd-FindBegin -  strlen(cbegin)+1);
            memset(Temp,0,FindEnd-FindBegin -  strlen(cbegin)+1);
            memcpy(Temp,FindBegin + strlen(cbegin),FindEnd-FindBegin -  strlen(cbegin));
            NSString *ret = [[NSString alloc] initWithUTF8String:Temp]    ;
            free(Temp);
            
            return ret;
        }
    }
    return nil;
}
/*
 从 string 中截取 begin 后面 len长度的字符串
 */
+(NSString *) GetSubLenght:(NSString *) string BEGIN:(NSString *) begin  LEN:(int) len
{
    char *cStr = [string UTF8String];
    char *cbegin = [begin UTF8String];
    char *FindBegin =  strstr(cStr,cbegin);
    if(FindBegin)
    {
        char *Temp = malloc(len+1);
        memset(Temp,0,len+1);
        memcpy(Temp,FindBegin + strlen(cbegin),len);
        NSString *ret = [[NSString alloc] initWithUTF8String:Temp]    ;
        free(Temp);
        return ret;
        
    }
    return nil;
}
/*
 从 string 中截取 begin 后面 len长度的字符串 例子请见 StringToIn函数中 107行
 */
+(NSString *) CtrGetSubLenght:(char *) cStr BEGIN:(char *) cbegin  LEN:(int) len
{
    char *FindBegin =  strstr(cStr,cbegin);
    if(FindBegin)
    {
        
        char *Temp = malloc(len+1);
        memset(Temp,0,len+1);
        memcpy(Temp,FindBegin + strlen(cbegin),len);
        NSString *ret = [[NSString alloc] initWithUTF8String:Temp]    ;
        free(Temp);
        return ret;
        
    }
    return nil;
}
///*
// 串转整型
// */
//void StringToInt()
//{
//    NSString *str = @"123.0";
//    NSInteger i = [str integerValue];//装整型
//    double d = [str doubleValue];//装浮点型
//    
//    
//    char * ch = "123.0";
//    d = atof(ch);//装浮点型
//    i = atoi(ch);//装整型
//    
//    char *cTeststr = "ABCD123EFGTJK45";
//    char *cBein = "CD";
//    char *cEnd = "K4";
//    NSString *Teststr = @"ABCD123EFGTJK45";
//    NSString *Bein = @"CD";
//    NSString *End = @"K4";
////    
////    NSString *Ret1 =   [ViewController  CtrGetSubLenght:cTeststr BEGIN:cBein LEN:5 ];
////    NSLog(@"%@",Ret1);
////    NSString *Ret2 =   [ViewController  CtrGetSub:cTeststr BEGIN:cBein END:cEnd];
////    NSString *Ret3 =   [ViewController  GetSubLenght:Teststr BEGIN:Bein LEN:5 ];
////    NSString *Ret4 =   [ViewController  GetSub:Teststr BEGIN:Bein END:End];
//    
////    NSLog(@"%@",Ret1);
////    NSLog(@"%@",Ret2);
////    NSLog(@"%@",Ret3);
////    NSLog(@"%@",Ret4);
//    
//}
+(NSString *) getSendOfCh  :(NSString *) strCH:(NSString *) strType
{
    if([strType isEqualToString:@"10"]==YES)
    {
        return @"[]io set(11,bit32=0,bit1=0,bit6=0,bit11=0,bit17=0,bit22=0,bit27=0,bit33=0,bit38=0,bit43=0,bit49=0)";
    }
    else if([strType isEqualToString:@"11"])
    {
        return [[NSString alloc] initWithFormat:@"[]programmer(ch%@,stm32,l0xx,B332-charger-v0009-hw0003.bin)",strCH] ;
    }
    else if([strType isEqualToString:@"12"])
    {
        return [[NSString alloc] initWithFormat:@"[]programmer(ch%@,stm32,l4xx,B332-superbin-primer-v0009-hw0003-not-signed.bin)",strCH] ;
    }
    else if([strType isEqualToString:@"13"])
    {
        return [[NSString alloc] initWithFormat:@"[]programmer(ch%@,stm32,l4xx,B332-superbin-v0009-hw0003-not-signed.bin)",strCH] ;
    }
    else if([strType isEqualToString:@"14"])
    {
        return [[NSString alloc] initWithFormat:@"[]programmer(ch%@,nrf5xble,52xx,radio_0011.bin)",strCH] ;
    }
    if([strCH isEqualToString:@"1"]==YES)
    {
        if([strType isEqualToString:@"0"]==YES)
        {
            return @"[]io set(5,bit32=1,bit1=1,bit4=1,bit3=0,bit2=0)";
        }
        else if([strType isEqualToString:@"4"]==YES)
        {
            return @"[]io set(5,bit32=1,bit1=1,bit4=0,bit3=1,bit2=0)";
        }
        else if([strType isEqualToString:@"5"]==YES)
        {
            return @"[]io set(5,bit32=1,bit1=1,bit4=0,bit3=0,bit2=1)";
        }
        else if([strType isEqualToString:@"2"]==YES)
        {
            return @"[]io set(5,bit32=1,bit1=1,bit4=0,bit3=0,bit2=0)";
        }
        else if([strType isEqualToString:@"6"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l0xx)",strCH];
            //return @"[]programmer id(ch1,stm32,l0xx)";
        }
        else if([strType isEqualToString:@"7"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l4xx)",strCH];
        }
        else if([strType isEqualToString:@"8"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,nrf5xble,52xx)",strCH];
        }
        else if([strType isEqualToString:@"9"]==YES)
        {//[]firmware check(ch1)
            return [[NSString alloc] initWithFormat:@"[]firmware check(ch%@)",strCH];
        }
        
    }
    else if([strCH isEqualToString:@"2"]==YES)
    {
        if([strType isEqualToString:@"0"]==YES)
        {
            return @"[]io set(5,bit32=1,bit6=1,bit9=1,bit8=0,bit7=0)";
        }
        else if([strType isEqualToString:@"4"]==YES)
        {
            return @"[]io set(5,bit32=1,bit6=1,bit9=0,bit8=1,bit7=0)";
        }
        else if([strType isEqualToString:@"5"]==YES)
        {
            return @"[]io set(5,bit32=1,bit6=1,bit9=0,bit8=0,bit7=1)";
        }
        else if([strType isEqualToString:@"2"]==YES)
        {
            return @"[]io set(5,bit32=1,bit6=1,bit9=0,bit8=0,bit7=0)";
        }
        else if([strType isEqualToString:@"6"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l0xx)",strCH];
            //return @"[]programmer id(ch1,stm32,l0xx)";
        }
        else if([strType isEqualToString:@"7"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l4xx)",strCH];
        }
        else if([strType isEqualToString:@"8"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,nrf5xble,52xx)",strCH];
        }
    }
    else if([strCH isEqualToString:@"3"]==YES)
    {
        if([strType isEqualToString:@"0"]==YES)
        {
            return @"[]io set(5,bit32=1,bit11=1,bit14=1,bit13=0,bit12=0)";
        }
        else if([strType isEqualToString:@"4"]==YES)
        {
            return @"[]io set(5,bit32=1,bit11=1,bit14=0,bit13=1,bit12=0)";
        }
        else if([strType isEqualToString:@"5"]==YES)
        {
            return @"[]io set(5,bit32=1,bit11=1,bit14=0,bit13=0,bit12=1)";
        }
        else if([strType isEqualToString:@"2"]==YES)
        {
            return @"[]io set(5,bit32=1,bit11=1,bit14=0,bit13=0,bit12=0)";
        }
        else if([strType isEqualToString:@"6"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l0xx)",strCH];
            //return @"[]programmer id(ch1,stm32,l0xx)";
        }
        else if([strType isEqualToString:@"7"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l4xx)",strCH];
        }
        else if([strType isEqualToString:@"8"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,nrf5xble,52xx)",strCH];
        }
    }
    else if([strCH isEqualToString:@"4"]==YES)
    {
        if([strType isEqualToString:@"0"]==YES)
        {
            return @"[]io set(5,bit32=1,bit17=1,bit20=1,bit19=0,bit18=0)";
        }
        else if([strType isEqualToString:@"4"]==YES)
        {
            return @"[]io set(5,bit32=1,bit17=1,bit20=0,bit19=1,bit18=0)";
        }
        else if([strType isEqualToString:@"5"]==YES)
        {
            return @"[]io set(5,bit32=1,bit17=1,bit20=0,bit19=0,bit18=1)";
        }
        else if([strType isEqualToString:@"2"]==YES)
        {
            return @"[]io set(5,bit32=1,bit17=1,bit20=0,bit19=0,bit18=0)";
        }
        else if([strType isEqualToString:@"6"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l0xx)",strCH];
            //return @"[]programmer id(ch1,stm32,l0xx)";
        }
        else if([strType isEqualToString:@"7"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l4xx)",strCH];
        }
        else if([strType isEqualToString:@"8"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,nrf5xble,52xx)",strCH];
        }
    }
    else if([strCH isEqualToString:@"5"]==YES)
    {
        if([strType isEqualToString:@"0"]==YES)
        {
            return @"[]io set(5,bit32=1,bit22=1,bit25=1,bit24=0,bit23=0)";
        }
        else if([strType isEqualToString:@"4"]==YES)
        {
            return @"[]io set(5,bit32=1,bit22=1,bit25=0,bit24=1,bit23=0)";
        }
        else if([strType isEqualToString:@"5"]==YES)
        {
            return @"[]io set(5,bit32=1,bit22=1,bit25=0,bit24=0,bit23=1)";
        }
        else if([strType isEqualToString:@"2"]==YES)
        {
            return @"[]io set(5,bit32=1,bit22=1,bit25=0,bit24=0,bit23=0)";
        }
        else if([strType isEqualToString:@"6"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l0xx)",strCH];
            //return @"[]programmer id(ch1,stm32,l0xx)";
        }
        else if([strType isEqualToString:@"7"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l4xx)",strCH];
        }
        else if([strType isEqualToString:@"8"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,nrf5xble,52xx)",strCH];
        }
    }
    else if([strCH isEqualToString:@"6"]==YES)
    {
        if([strType isEqualToString:@"0"]==YES)
        {
            return @"[]io set(5,bit32=1,bit27=1,bit30=1,bit29=0,bit28=0)";
        }
        else if([strType isEqualToString:@"4"]==YES)
        {
            return @"[]io set(5,bit32=1,bit27=1,bit30=0,bit29=1,bit28=0)";
        }
        else if([strType isEqualToString:@"5"]==YES)
        {
            return @"[]io set(5,bit32=1,bit27=1,bit30=0,bit29=0,bit28=1)";
        }
        else if([strType isEqualToString:@"2"]==YES)
        {
            return @"[]io set(5,bit32=1,bit27=1,bit30=0,bit29=0,bit28=0)";
        }
        else if([strType isEqualToString:@"6"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l0xx)",strCH];
            //return @"[]programmer id(ch1,stm32,l0xx)";
        }
        else if([strType isEqualToString:@"7"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l4xx)",strCH];
        }
        else if([strType isEqualToString:@"8"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,nrf5xble,52xx)",strCH];
        }
    }
    else if([strCH isEqualToString:@"7"]==YES)
    {
        if([strType isEqualToString:@"0"]==YES)
        {
            return @"[]io set(5,bit32=1,bit33=1,bit36=1,bit35=0,bit34=0)";
        }
        else if([strType isEqualToString:@"4"]==YES)
        {
            return @"[]io set(5,bit32=1,bit33=1,bit36=0,bit35=1,bit34=0)";
        }
        else if([strType isEqualToString:@"5"]==YES)
        {
            return @"[]io set(5,bit32=1,bit33=1,bit36=0,bit35=0,bit34=1)";
        }
        else if([strType isEqualToString:@"2"]==YES)
        {
            return @"[]io set(5,bit32=1,bit33=1,bit36=0,bit35=0,bit34=0)";
        }
        else if([strType isEqualToString:@"6"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l0xx)",strCH];
            //return @"[]programmer id(ch1,stm32,l0xx)";
        }
        else if([strType isEqualToString:@"7"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l4xx)",strCH];
        }
        else if([strType isEqualToString:@"8"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,nrf5xble,52xx)",strCH];
        }
    }
    else if([strCH isEqualToString:@"8"]==YES)
    {
        if([strType isEqualToString:@"0"]==YES)
        {
            return @"[]io set(5,bit32=1,bit38=1,bit41=1,bit40=0,bit39=0)";
        }
        else if([strType isEqualToString:@"4"]==YES)
        {
            return @"[]io set(5,bit32=1,bit38=1,bit41=0,bit40=1,bit39=0)";
        }
        else if([strType isEqualToString:@"5"]==YES)
        {
            return @"[]io set(5,bit32=1,bit38=1,bit41=0,bit40=0,bit39=1)";
        }
        else if([strType isEqualToString:@"2"]==YES)
        {
            return @"[]io set(5,bit32=1,bit38=1,bit41=0,bit40=0,bit39=0)";
        }
        else if([strType isEqualToString:@"6"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l0xx)",strCH];
            //return @"[]programmer id(ch1,stm32,l0xx)";
        }
        else if([strType isEqualToString:@"7"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l4xx)",strCH];
        }
        else if([strType isEqualToString:@"8"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,nrf5xble,52xx)",strCH];
        }
    }
    else if([strCH isEqualToString:@"9"]==YES)
    {
        if([strType isEqualToString:@"0"]==YES)
        {
            return @"[]io set(5,bit32=1,bit43=1,bit46=1,bit45=0,bit44=0)";
        }
        else if([strType isEqualToString:@"4"]==YES)
        {
            return @"[]io set(5,bit32=1,bit43=1,bit46=0,bit45=1,bit44=0)";
        }
        else if([strType isEqualToString:@"5"]==YES)
        {
            return @"[]io set(5,bit32=1,bit43=1,bit46=0,bit45=0,bit44=1)";
        }
        else if([strType isEqualToString:@"2"]==YES)
        {
            return @"[]io set(5,bit32=1,bit43=1,bit46=0,bit45=0,bit44=0)";
        }
        else if([strType isEqualToString:@"6"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l0xx)",strCH];
            //return @"[]programmer id(ch1,stm32,l0xx)";
        }
        else if([strType isEqualToString:@"7"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l4xx)",strCH];
        }
        else if([strType isEqualToString:@"8"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,nrf5xble,52xx)",strCH];
        }
    }
    else if([strCH isEqualToString:@"10"]==YES)
    {
        if([strType isEqualToString:@"0"]==YES)
        {
            return @"[]io set(5,bit32=1,bit49=1,bit52=1,bit51=0,bit50=0)";
        }
        else if([strType isEqualToString:@"4"]==YES)
        {
            return @"[]io set(5,bit32=1,bit49=1,bit52=0,bit51=1,bit50=0)";
        }
        else if([strType isEqualToString:@"5"]==YES)
        {
            return @"[]io set(5,bit32=1,bit49=1,bit52=0,bit51=0,bit50=1)";
        }
        else if([strType isEqualToString:@"2"]==YES)
        {
            return @"[]io set(5,bit32=1,bit49=1,bit52=0,bit51=0,bit50=0)";
        }
        else if([strType isEqualToString:@"6"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l0xx)",strCH];
            //return @"[]programmer id(ch1,stm32,l0xx)";
        }
        else if([strType isEqualToString:@"7"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,stm32,l4xx)",strCH];
        }
        else if([strType isEqualToString:@"8"]==YES)
        {
            return [[NSString alloc] initWithFormat:@"[]programmer id(ch%@,nrf5xble,52xx)",strCH];
        }
    }

    return @"";
}


+(void)AFileDelete
{
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *strpath1 = [NSString stringWithFormat:@"%@/file1.txt",NSHomeDirectory()];
    
    bool bRet = [fm removeItemAtPath:strpath1 error:nil];
    if(!bRet)
    {
        NSLog(@"delete file error");
    }
}
+(void)AFileMove
{
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *strpath1 = [NSString stringWithFormat:@"%@/file1.txt",NSHomeDirectory()];
    NSString *strpath2 = [NSString stringWithFormat:@"%@/file2.txt",NSHomeDirectory()];
    
    bool bRet = [fm moveItemAtPath:strpath1 toPath:strpath2 error:nil];
    if(!bRet)
    {
        NSLog(@"move file error");
    }
    
    //copy
    //    NSFileManager *fm = [NSFileManager defaultManager];
    //    NSString *strpath1 = [NSString stringWithFormat:@"%@/file1.txt",NSHomeDirectory()];
    //    NSString *strpath2 = [NSString stringWithFormat:@"%@/file2.txt",NSHomeDirectory()];
    //
    //    bool bRet = [fm copyItemAtPath:strpath1 toPath:strpath2 error:nil];
    //    if(!bRet)
    //    {
    //        NSLog(@"copy file error");
    //    }
}
+(void)ADiretoryCreate
{
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *strpath1 = [NSString stringWithFormat:@"%@/testdir",NSHomeDirectory()];
    bool bRet = [fm createDirectoryAtPath:strpath1 withIntermediateDirectories:NO attributes:nil error:nil];
    if(!bRet)
    {
        NSLog(@"create dir error");
    }
}

+(BOOL)ADiretoryExist :(NSString *) filePath
{
    NSFileManager *fm = [NSFileManager defaultManager];
    bool bRet = [fm fileExistsAtPath:filePath];
    if(!bRet)
    {
        return NO;
    }
    else
    {
        return YES;
    }
}

@end
