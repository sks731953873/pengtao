//
//  ViewController.m
//  strongTest
//
//  Created by strong on 2017/12/15.
//  Copyright © 2017年 strong. All rights reserved.
//

#import "ViewController.h"
#import "MenuToolView.h"
#import "StationDebugView.h"
#import "MainView.h"

#import "FCTDLStationView.h"
#import "DataSave.h"
#import "SRLogInViewControlloer.h"
CGRect g_Main_Menu_Frame ={0,0,1300,60};
@interface ViewController ()
{
    
    MenuToolView * tag_MainMenuUIView;
    StationDebugView * tag_StationDebugView;
    MainView * tag_MainView;
    
     FCTDLStationView * tag_FCTStationView;
    FCTDLStationView * tag_FDLStationView;
}
@end
@implementation ViewController

/*
 从 string 中截取 begin 和 end 之间的字符串 例子请见 StringToIn函数中 107行
 */
+(NSString *) GetSub:(NSString *) string BEGIN:(NSString *) begin  END:(NSString *) end
{
    char *cStr = [string UTF8String];
    char *cbegin = [begin UTF8String];
    char *cend = [end UTF8String];
    char *FindBegin =  strstr(cStr,cbegin);
    if(FindBegin)
    {
        char *FindEnd =  strstr(FindBegin,cend);
        if(FindEnd)
        {
          
            char *Temp = malloc(FindEnd-FindBegin -  strlen(cbegin)+1);
            memset(Temp,0,FindEnd-FindBegin -  strlen(cbegin)+1);
            memcpy(Temp,FindBegin + strlen(cbegin),FindEnd-FindBegin -  strlen(cbegin));
            NSString *ret = [[NSString alloc] initWithUTF8String:Temp]    ;
            free(Temp);
          
            return ret;
        }
    }
    return nil;
}
/*
 从 string 中截取 begin 和 end 之间的字符串
 */
+(NSString *) CtrGetSub:(char *) cStr BEGIN:(char *) cbegin  END:(char *) cend
{
  
    char *FindBegin =  strstr(cStr,cbegin);
    if(FindBegin)
    {
        char *FindEnd =  strstr(FindBegin,cend);
        if(FindEnd)
        {

            char *Temp = malloc(FindEnd-FindBegin -  strlen(cbegin)+1);
            memset(Temp,0,FindEnd-FindBegin -  strlen(cbegin)+1);
            memcpy(Temp,FindBegin + strlen(cbegin),FindEnd-FindBegin -  strlen(cbegin));
            NSString *ret = [[NSString alloc] initWithUTF8String:Temp]    ;
            free(Temp);
            
            return ret;
        }
    }
    return nil;
}
/*
 从 string 中截取 begin 后面 len长度的字符串
 */
+(NSString *) GetSubLenght:(NSString *) string BEGIN:(NSString *) begin  LEN:(int) len
{
    char *cStr = [string UTF8String];
    char *cbegin = [begin UTF8String];
    char *FindBegin =  strstr(cStr,cbegin);
    if(FindBegin)
    {
        char *Temp = malloc(len+1);
        memset(Temp,0,len+1);
        memcpy(Temp,FindBegin + strlen(cbegin),len);
        NSString *ret = [[NSString alloc] initWithUTF8String:Temp]    ;
        free(Temp);
        return ret;
       
    }
    return nil;
}
/*
 从 string 中截取 begin 后面 len长度的字符串 例子请见 StringToIn函数中 107行
 */
+(NSString *) CtrGetSubLenght:(char *) cStr BEGIN:(char *) cbegin  LEN:(int) len
{
    char *FindBegin =  strstr(cStr,cbegin);
    if(FindBegin)
    {

        char *Temp = malloc(len+1);
        memset(Temp,0,len+1);
        memcpy(Temp,FindBegin + strlen(cbegin),len);
        NSString *ret = [[NSString alloc] initWithUTF8String:Temp]    ;
        free(Temp);
        return ret;
        
    }
    return nil;
}
/*
 串转整型
 */
void StringToInt()
{
    NSString *str = @"123.0";
    NSInteger i = [str integerValue];//装整型
    double d = [str doubleValue];//装浮点型
    
    
    char * ch = "123.0";
    d = atof(ch);//装浮点型
    i = atoi(ch);//装整型
    
    char *cTeststr = "ABCD123EFGTJK45";
    char *cBein = "CD";
    char *cEnd = "K4";
    NSString *Teststr = @"ABCD123EFGTJK45";
    NSString *Bein = @"CD";
    NSString *End = @"K4";
    
   NSString *Ret1 =   [ViewController  CtrGetSubLenght:cTeststr BEGIN:cBein LEN:5 ];
    NSLog(@"%@",Ret1);
   NSString *Ret2 =   [ViewController  CtrGetSub:cTeststr BEGIN:cBein END:cEnd];
    NSString *Ret3 =   [ViewController  GetSubLenght:Teststr BEGIN:Bein LEN:5 ];
    NSString *Ret4 =   [ViewController  GetSub:Teststr BEGIN:Bein END:End];
  
     NSLog(@"%@",Ret1);
     NSLog(@"%@",Ret2);
     NSLog(@"%@",Ret3);
     NSLog(@"%@",Ret4);
    
}
/*
 添加例子
 */
void Test()
{
   
}
extern void PdcaUpDataTEST();


- (void)viewDidLoad
{
   
    [super viewDidLoad];

    //CGRect cg = {0,self.view.frame.size.height -g_Main_Menu_Frame.size.height-20,g_Main_Menu_Frame.size.width,g_Main_Menu_Frame.size.height};
    CGRect cg = {0,self.view.frame.size.height -g_Main_Menu_Frame.size.height-20,g_Main_Menu_Frame.size.width,g_Main_Menu_Frame.size.height};
    
    
    if(!tag_MainMenuUIView)
    {
        tag_MainMenuUIView = [[MenuToolView alloc] initWithFrame:cg];
        tag_MainMenuUIView.tag_mainButtonDelegate = self;
    }
   
    
    //CGRect cg2 = {0,tag_MainMenuUIView.frame.origin.y - tag_MainMenuUIView.frame.size.height,0,0};
    CGRect cg2 = {0,tag_MainMenuUIView.frame.origin.y - tag_MainMenuUIView.frame.size.height,0,0};
    if(!tag_StationDebugView)
    {
        tag_StationDebugView = [[StationDebugView alloc] initWithFrame:cg2];
         CGRect cg22 = {0,tag_MainMenuUIView.frame.origin.y - tag_StationDebugView.frame.size.height+10,
             tag_StationDebugView.frame.size.width,tag_StationDebugView.frame.size.height};
        tag_StationDebugView.frame = cg22;
    }


    if(!tag_MainView)
    {
        tag_MainView = [[MainView alloc] initWithFrame:cg];
        CGRect cg22 = {0,tag_MainMenuUIView.frame.origin.y - tag_MainView.frame.size.height,
            tag_MainView.frame.size.width,tag_MainView.frame.size.height};
        tag_MainView.frame = cg22;
    }
    

    [self.view addSubview:tag_MainMenuUIView];
    [self.view addSubview:tag_MainView];
    
    // Do any additional setup after loading the view.
}


-(void)MainButtonDelegate:(id) obj
{
    [tag_StationDebugView removeFromSuperview];
    [tag_MainView removeFromSuperview];
    [tag_FCTStationView removeFromSuperview];
    [tag_FDLStationView removeFromSuperview];
    [tag_MainView removeFromSuperview];
    
    CGRect cg22 = {0,tag_MainMenuUIView.frame.origin.y - tag_MainView.frame.size.height,tag_MainView.frame.size.width,tag_MainView.frame.size.height};
    tag_MainView.frame = cg22;

    [self.view addSubview:tag_MainView ];
}



-(void)LoginBtnDelegate:(id) obj
{
    SRLogInViewControlloer *logInVc = [[SRLogInViewControlloer alloc]init];
    logInVc.optionBlock = ^(NSString *user){
       // self.label_user.stringValue = user;
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center postNotificationName:@"SRLoginNotification" object:user];
    };
    [self presentViewControllerAsSheet:logInVc];
    
}



-(void)LoginButtonDelegate:(id) obj
{
    [tag_StationDebugView removeFromSuperview];
    [tag_MainView removeFromSuperview];
    [tag_FCTStationView removeFromSuperview];
    [tag_FDLStationView removeFromSuperview];
    [tag_MainView removeFromSuperview];
    CGRect cg = {0,self.view.frame.size.height -80,1450,60};

}

-(void)FCTButtonDelegate:(id) obj
{
    [tag_StationDebugView removeFromSuperview];
    [tag_MainView removeFromSuperview];
    [tag_FCTStationView removeFromSuperview];
    [tag_FDLStationView removeFromSuperview];
    [tag_MainView removeFromSuperview];
    CGRect cg = {0,self.view.frame.size.height -80,1450,60};
    CGRect cg2 = {0,cg.origin.y-770,1450,770};
    tag_FCTStationView.frame = cg2;
    [self.view addSubview:tag_FCTStationView ];
}
-(void)FDLButtonDelegate:(id) obj
{
    [tag_StationDebugView removeFromSuperview];
    [tag_MainView removeFromSuperview];
    [tag_FCTStationView removeFromSuperview];
    [tag_FDLStationView removeFromSuperview];
    [tag_MainView removeFromSuperview];
    CGRect cg = {0,self.view.frame.size.height -80,1450,60};
    CGRect cg2 = {0,cg.origin.y-770,1450,770};
    tag_FDLStationView.frame = cg2;
    [self.view addSubview:tag_FDLStationView ];
}

-(void)DebugButtonDelegate:(id) obj
{
    [tag_StationDebugView removeFromSuperview];
    [tag_MainView removeFromSuperview];
    [tag_FCTStationView removeFromSuperview];
    [tag_FDLStationView removeFromSuperview];
    [tag_MainView removeFromSuperview];
    
    CGRect cg22 = {0,tag_MainMenuUIView.frame.origin.y - tag_MainView.frame.size.height+10,
        tag_MainView.frame.size.width,tag_MainView.frame.size.height};

    tag_StationDebugView.frame = cg22;
    [self.view addSubview:tag_StationDebugView ];
}
/*******************************************************************************************
 **函数名：FCTstationRun
 **参数：::(NSObject*) o
 **功能： FCT 界面点启动按钮执行的函数
 **返回值：
 *******************************************************************************************/
-(void)FCTstationRun:(NSObject*) o
{
    
  // FCT 界面点启动按钮执行的函数
}

/*******************************************************************************************
 **函数名：FDLstationRun
 **参数：::(NSObject*) o
 **功能： FDL 界面点启动按钮执行的函数
 **返回值：
 *******************************************************************************************/
-(void)FDLstationRun:(NSObject*) o
{
  
}
/*******************************************************************************************
 **函数名：FCTThread
 **参数：::(NSObject*) o
 **功能： FDL 界面点启动按钮执行的函数 启动一个线程 执行的函数为 FCTstationRun
 **返回值：
 *******************************************************************************************/
- (void)FCTThread
{
    
    NSThread  *tag_myThread = [[NSThread alloc] initWithTarget:self
                                                      selector:@selector(FCTstationRun:)
                                                        object:nil];
    [tag_myThread start];
    
}
/*******************************************************************************************
 **函数名：FDLThread
 **参数：::(NSObject*) o
 **功能： FDL 界面点启动按钮执行的函数 启动一个线程 执行的函数为 FDLstationRun
 **返回值：
 *******************************************************************************************/
- (void)FDLThread
{
    
    NSThread  *tag_myThread = [[NSThread alloc] initWithTarget:self
                                                      selector:@selector(FDLstationRun:)
                                                        object:nil];
    [tag_myThread start];
    
}
-(void)FCTDLStartDelegate:(id) obj
{
  if(tag_FDLStationView == obj)
  {
      //FDL的启动函数
      [self FDLThread];
  }
    else
    {
        [self FCTThread];
        //FCT的启动函数
    }
}
/*******************************************************************************************
 **函数名：FDLStop
 **参数：::(NSObject*) o
 **功能： FDL 终止
 **返回值：
 *******************************************************************************************/
- (void)FDLStop
{
    //FDL 终止
  
  
}
/*******************************************************************************************
 **函数名：FCTStop
 **参数：::(NSObject*) o
 **功能： FCT 终止
 **返回值：
 *******************************************************************************************/
- (void)FCTStop
{
 
    //FCT 终止
    
}
-(void)FCTDLStopButtonDelegate:(id) obj
{
    if(tag_FDLStationView == obj)
    {
         [self FDLStop];
        //FDL的停止函数
    }
    else
    {
          [self FCTStop];
        //FDL的停止函数
    }
}

- (void)callThread{
    NSLog(@"%@",[NSThread currentThread]);
}

- (void)setRepresentedObject:(id)representedObject
{
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}
- (BOOL)windowShouldClose:(id)sender {
    [NSApp stopModalWithCode:1];
    return TRUE;
}  

@end
