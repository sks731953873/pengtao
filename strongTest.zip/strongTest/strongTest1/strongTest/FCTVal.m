//
//  FCTVal.m
//  strongTest
//
//  Created by strong on 2018/1/11.
//  Copyright © 2018年 strong. All rights reserved.
//

#import "FCTVal.h"

@implementation FCTVal

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];

    // Drawing code here.
}

-(id)initWithName:(NSString *)name andAge:(int)age{
    if(self=[super init]){ //super代表父类
        self._1Product1=@"";
        self._2SerialNumber=@"";
        self._3PStation_ID=@"";
        self._31SiteID=@"";
        self._4PassFailResult=@"";
        self._5ErrorMessage=@"";
        self._6FailedList=@"";
        self._7TestStartTime=@"";
        self._8TestStopTime=@"";
        self._9L0Result=@"";
        self._10L4Result_1=@"";
        self._11L4Result_2=@"";
        self._12BLEResult=@"";
        self.SaveFileName=@"";
        
    }
    return self;
}
-(void) InitVal
{
   self._1Product1 = @"B332";//
  self._2SerialNumber = @"";//
  self._3PStation_ID = @"CWNJ_Cxx-2FAP-xx_3_MLB-FWDL";//
    self._31SiteID=@"";
  self._4PassFailResult = @"";//
  self._5ErrorMessage = @"";//
  self._6FailedList = @"";//
  self._7TestStartTime = @"";//
  self._8TestStopTime = @"";//
  self._9L0Result = @"";//
  self._10L4Result_1 = @"";//
  self._11L4Result_2 = @"";//
  self._12BLEResult = @"";//
    self.SaveFileName=@"";
}
-(NSString*) GetCsvStr
{
    NSString * strret=@"";
    strret=[NSString stringWithFormat:@",%@,%@,%@,%@,%@,%@",self._1Product1,self._2SerialNumber,self._3PStation_ID,self._31SiteID,
            self._4PassFailResult,self._5ErrorMessage];
    strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@",strret,self._6FailedList,self._7TestStartTime,
            self._8TestStopTime,self._9L0Result];
    strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@",strret,self._10L4Result_1,self._11L4Result_2,
            self._12BLEResult,@""];
    
    return strret;
}
-(NSString*) GetCsvTitle
{
    NSString * strret=@"";
    strret=[NSString stringWithFormat:@",%@,%@,%@,%@,%@,%@,%@,%@",@"Product",@"SerialNumber",@"Station_ID",@"Site_ID",@"PASS/FAIL",@"Error_Message",@"Failed_List",@"TestStartTime"];
    strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,@"TestStopTime",@"L0Result",@"L4Result_1",@"L4Result_2",@"BLE_Result" ];
    
    return strret;
}




@end
