//
//  main.m
//  strongTest
//
//  Created by strong on 2017/12/15.
//  Copyright © 2017年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Config.h"
#include "work.h"
extern void loginit();
 
int main(int argc, const char * argv[]) {
    
    Load() ;
    
    workInit(0);
    
    
    loginit();
    PdcaUpDataTEST();
    return NSApplicationMain(argc, argv);
}
