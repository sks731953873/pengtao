//
//  FCTDLStationView.m
//  strongTest
//
//  Created by strong on 2018/1/10.
//  Copyright © 2018年 strong. All rights reserved.
//

#import "FCTDLStationView.h"

@interface FCTDLStationView()<NSTableViewDelegate,NSTableViewDataSource>
{
    
    fctDlValueManage tag_fctDlValueManage;
    NSMutableArray *tag_UITableRight;//
    int tag_upRightSelectRow;
    NSMutableArray *tag_UITableLeft;//
    int *tag_Channel;
    int tag_upLeftSelectRow;
    int tag_count ;
    NSMutableArray *tag_UIStationArray;//用于管理工位
    
}
@property (weak) IBOutlet NSTableView *tag_uiLeftTable;

@end
@implementation FCTDLStationView

/*******************************************************************************************
 **函数名：initWithFrame
 **参数：:(CGRect)frame
 **功能：初始化 大小
 **返回值：
 *******************************************************************************************/

- (instancetype)initWithFrame:(CGRect)frame
                  FCTDLMANAGE:(fctDlValueManage)  fctDlmanage
                      CHANNEL:(int *) channel
{
    
    NSArray *arr = [NSArray array];
    
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([FCTDLStationView class]) owner:nil topLevelObjects:&arr];
    
    for(int i = 0;i < arr.count;i++)
    {
        if([arr[i] isKindOfClass:[self class]])
        {
            FCTDLStationView *stationView = arr[i];
            stationView.frame = frame;
            CALayer *viewLayer = [CALayer layer];
            [viewLayer setBackgroundColor:CGColorCreateGenericRGB(0.9, 0.9, 0.9, 1)];
            [stationView setWantsLayer:YES];
            [stationView setLayer:viewLayer];
            self = stationView;
            tag_fctDlValueManage = fctDlmanage;
            tag_Channel = channel;
            tag_UITableLeft = [[NSMutableArray alloc] init];
            
          
            [self UiInit ];
           [self StationUpdate ];
            [self UpdataChannel ];
            self.tag_uiLeftTable.dataSource = self;
            self.tag_uiLeftTable.delegate = self;
            
            break;
        }
        
    }
    NSTimer *timer;
    timer = [NSTimer scheduledTimerWithTimeInterval: 0.1
                                             target: self
                                           selector: @selector(handleTimer:)
                                           userInfo: nil
                                            repeats: YES];
    return self;
    
}

/*******************************************************************************************
 **函数名：UiInit
 **参数：(id)sender
 **功能：IP 列表管理，初始化，初始化20个ip列表，把配置初始化到对应的
 **返回值：
 *******************************************************************************************/
-(void) UiInit
{
    
    for(int i = 0; i<MAXIFCTDL;i++)
    {
        
        
        FCTDLView *mainStep = [[FCTDLView alloc] init];
        [mainStep InitUI:i+1 FCTDL:&tag_fctDlValueManage->tag_FctDlValue[i]];
        
        [tag_UITableLeft addObject:mainStep];
        
    }
    
}
/*******************************************************************************************
 **函数名：numberOfRowsInTableView
 **参数：:
 **功能：设置列表的函数，ip列表，步骤列表，工位列表
 **返回值：
 *******************************************************************************************/
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView
{
    if(tableView == self.tag_uiLeftTable)
    {
        
        
        return tag_fctDlValueManage->tag_totalCount;
        
    }
    
    return 0;
}
/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：初始化列表中的内容
 **返回值：
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    id retid = nil;
    if(tableView == self.tag_uiLeftTable)
    {
        FCTDLView *mainStepView1 = tag_UITableLeft[row];
        
        return  [mainStepView1 tableView:tableView viewForTableColumn:tableColumn row:row];
        
    }
    
    return retid;
}
/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：初始化列表中高度
 **返回值：
 *******************************************************************************************/
- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row
{
    if(tableView == self.tag_uiLeftTable)
    {
        
        return 20;
    }
    return 0;
}
- (void) handleTimer: (NSTimer *) timer
{
    [self updataUIIOShow];
    
    [self UpdataPdca];
}
- (void)updataUIIOShow{
   
    
    
}
-(void) UpdataPdca
{
    int i =0 ;
    
    while(i < tag_fctDlValueManage->tag_totalCount)
    {
        
        if(tag_count != tag_fctDlValueManage->tag_totalCount)
        {
            tag_count =   tag_fctDlValueManage->tag_totalCount;
            [self.tag_uiLeftTable reloadData];
        }
        
        FCTDLView *stepv = tag_UITableLeft[i];
        [stepv UIUpdata:i];
        i++;
    }
    
}
-(void) UpdataChannel
{
    _tag_Channel1.state = tag_Channel[0];
    _tag_Channel2.state = tag_Channel[1];
    _tag_Channel3.state = tag_Channel[2];
    _tag_Channel4.state = tag_Channel[3];
    _tag_Channel5.state = tag_Channel[4];
    _tag_Channel6.state = tag_Channel[5];
    _tag_Channel7.state = tag_Channel[6];
    _tag_Channel8.state = tag_Channel[7];
    _tag_Channel9.state = tag_Channel[8];
    _tag_Channel10.state = tag_Channel[9];
    _tag_Channel11.state = tag_Channel[10];
    _tag_Channel12.state = tag_Channel[11];
    _tag_Channel13.state = tag_Channel[12];
    _tag_Channel14.state = tag_Channel[13];
    _tag_Channel15.state = tag_Channel[14];
    _tag_Channel16.state = tag_Channel[15];
    _tag_Channel17.state = tag_Channel[16];
    _tag_Channel18.state = tag_Channel[17];
    _tag_Channel19.state = tag_Channel[18];
    _tag_Channel20.state = tag_Channel[19];
    
}

/*******************************************************************************************
 **函数名：StationUpdate
 **参数：:
 **功能：工位刷新
 **返回值：
 *******************************************************************************************/
-(void) StationUpdate
{
    
    
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}
- (IBAction)StartAction:(id)sender {
    [_tag_ButtonDelegate FCTDLStartDelegate:self];
}

- (IBAction)StopAction:(id)sender {
        [_tag_ButtonDelegate FCTDLStopButtonDelegate:self];
}
- (IBAction)ChannelAtions:(id)sender
{
    NSButton *button = sender;
    tag_Channel[button.tag] = button.state;
  
    
}
- (IBAction)SaveAction:(id)sender
{
    
    NSAlert *alert = [NSAlert new];
    [alert addButtonWithTitle:@"确定"];
    [alert addButtonWithTitle:@"取消"];
    [alert setMessageText:@"确定保存?"];
    [alert setInformativeText:@"如果确定保存，请点确定!"];
    
    [alert beginSheetModalForWindow:[self window] completionHandler:^(NSModalResponse returnCode) {
        if(returnCode == NSAlertFirstButtonReturn){
            
            Save();
            
            
            
        }else if(returnCode == NSAlertSecondButtonReturn){
            
        }
    }];
 
}
@end
