//
//  DeviceManagement.m
//  X322MotorTest
//
//  Created by CW-IT-MINI-001 on 14-1-8.
//  Copyright (c) 2014年 __MyCompanyName__. All rights reserved.
//

#import "DeviceManagement.h"

@implementation DeviceManagement


@synthesize fixturePort;
@synthesize failDeviceNames;


static DeviceManagement* device = nil;

+(DeviceManagement*)Instance
{
    if (device == nil)
    {
        device = [[super allocWithZone:NULL] init];
    }
    
    return device;
}

+(id)allocWithZone:(NSZone*)zone
{
    return [self Instance];
}
//
//-(id)copyWithZone:(NSZone*)zone
//{
//    return self;
//}
//
//-(id)retain
//{
//    return self;
//}
//
//-(NSUInteger)retainCount
//{
//    return NSUIntegerMax;
//}
//
//-(oneway void)release
//{
//    
//}


/*singleton partern*/

-(id) init
{
    self = [super init];
    if (!self)
    {
        return nil;
    }
    
    
    fixturePort = [[SerialPort alloc] init];

    failDeviceNames = [[NSMutableArray alloc] init];
    
    return self;
}

-(BOOL)openDevice
{
    isOpen = YES;
    
    /*
    [i2cRXPort SearchDevice];
    
    BOOL isOpenI2cTx = [i2cTXPort OpenPort:[i2cRXPort i2cTX]];
    
    if (!isOpenI2cTx)
    {
        [failDeviceNames addObject:@"TXModel"];
        isOpen = NO;
    }
    
    BOOL isOpenI2cRx = [i2cRXPort OpenPort:[i2cRXPort i2cRX]];
    
    if (!isOpenI2cRx)
    {
        [failDeviceNames addObject:@"RXModel"];
        isOpen = NO;
    }
    
    
    BOOL isOpenMeter = [agilentPort OpenDevice];
    
    if (!isOpenMeter)
    {
        [failDeviceNames addObject:@"Agilent 34410A"];
        isOpen = NO;
    }
    */
        
    
    BOOL isOpenFixture = [fixturePort Open:[[ConfigFile Instance] fixtureName]
                                  BaudRate:BAUD_9600
                                   DataBit:DATA_BITS_DEFAULT 
                                   StopBit:StopBitsDefault
                                    Parity: Parity_Default
                               FlowControl:FLOW_CONTROL_DEFAULT];
    
    if (!isOpenFixture)
    {
        [failDeviceNames addObject:@"FixtureDevice"];
        isOpen = NO;
    }
    
//   // BOOL isOpenDut = [dutPort Open:[[ConfigFile Instance] dutName]
//                                  BaudRate:BAUD_115200
//                                   DataBit:DATA_BITS_DEFAULT
//                                   StopBit:StopBitsDefault
//                                    Parity: Parity_Default
//                               FlowControl:FLOW_CONTROL_DEFAULT];
    
//    if (!isOpenDut)
//    {
//        [failDeviceNames addObject:@"DutDevice"];
//        isOpen = NO;
//    }
    
  /*  BOOL isOpenGPIB = YES;
    
    if (![GPIB Find])
    {
        isOpenGPIB = NO;
    }
    
    if (![GPIB Open])
    {
        isOpenGPIB = NO;
    }
    
    if (!isOpenGPIB)
    {
        [failDeviceNames addObject:@"GPIBDevice"];
        isOpen = NO;
    }*/
    
    return isOpen;
}

-(void)CloseDevice
{
    [fixturePort Close];
 //   [agilentPort CloseDevice];
//    [GPIB Close];
//    [i2cTXPort ClosePort];
//    [i2cRXPort ClosePort];
}


@end
