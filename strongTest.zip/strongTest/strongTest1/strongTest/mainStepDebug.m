//
//  mainStepDebug.m
//  strongTest
//
//  Created by strong on 2017/12/30.
//  Copyright © 2017年 strong. All rights reserved.
//

#import "mainStepDebug.h"
#include "Config.h"
@implementation mainStepDebug
/*******************************************************************************************
 **函数名：InitUI
 **参数：::(int) index STATION:(lpStation) lpstation
 **功能：初始化
 **返回值：
 *******************************************************************************************/

-(void)InitUI:(int) index STEP:(LpStep) step PDCAMANAGE:(pdcaValueManage) pdcam STATION:(lpStation) station
{
    if(!step )
    {
        _tag_lpStation = station;
        
        tag_UIIndex = [[NSTextField alloc] init];
        tag_UIIndex.stringValue = [[NSString alloc] initWithUTF8String:station->tag_Name];
        
      //  tag_UIName = [[NSTextField alloc] init];
     //  tag_UIName.stringValue = [[NSString alloc] initWithFormat:@"%s",station->tag_Name];
    }
    else
    {
        _tag_lpLpStep = step;
        tag_pdcaValueManage = pdcam;
        _tag_lpStation = station;
        tag_UIIndex = [[NSTextField alloc] init];
        tag_UIIndex.stringValue = [[NSString alloc] initWithFormat:@"%2d",index];
        
        [tag_UIIndex setBordered:NO];
        [tag_UIIndex setEditable:NO];//控制是标签还是编辑框
        tag_UIName = [[NSTextField alloc] init];
        tag_UIName.stringValue = [[NSString alloc] initWithUTF8String:step->tag_stepName];
        
        
        tag_UIValue = [[NSTextField alloc] init];
        tag_UIMax = [[NSTextField alloc] init];
        tag_UIMin = [[NSTextField alloc] init];
        tag_UIIsPass = [[NSTextField alloc] init];
         tag_UIuuto = [[NSTextField alloc] init];
        
        
        tag_NSProgressIndicator = [[NSProgressIndicator alloc] init];
        [self UIUpdata: index];
    }

}
-(NSString *)CreateStrDoubel3f:(char *) var
{

    int i = 0;
    int len = strlen(var);
    int RetLen = 30;
    int j = 0;
    int m = 0;
    char *ret = malloc(RetLen);
    memset(ret,0,RetLen);
    while(j < RetLen && i < len)
    {
        if((var[i] <='9' && var[i] >='0') || var[i] <='-')
        {
            ret[j] = var[i];
            if(m >0)
            {
                m++;
            }
            if(m >3)
            {
                break;
            }
            j++;
        }
        else
        if(var[i] == '.')
        {
            ret[j] = var[i];
            j++;
            m =1;
        }
        i++;
    }
    NSString *restr = [[NSString alloc] initWithFormat:@"%s",ret];
    free(ret);
    return restr;
}

/*******************************************************************************************
 **函数名：UIUpdata
 **参数：::(int) index STATION:(lpStation) lpstation
 **功能：刷新
 **返回值：
 *******************************************************************************************/
-(void)UIUpdata:(int) index
{
    extern char gloabe_sn[100][100];
     NSString *ispass;

    pdcaValue pdca  =&_tag_lpLpStep->tag_pdcaValue ;
  
    if(!_tag_lpLpStep )
    {
            tag_UIName.stringValue = [[NSString alloc] initWithFormat:@"%s",_tag_lpStation->tag_Name];
            return ;
    }
    
   
    
    tag_UIName.stringValue = [[NSString alloc] initWithUTF8String:_tag_lpLpStep->tag_stepName];
    
    [tag_UIName setBordered:NO];
    [tag_UIName setEditable:NO];//控制是标签还是编辑框
    
    tag_UIMax.stringValue = [[NSString alloc] initWithFormat:@"%s",pdca->tag_Max];
    
    
    [tag_UIMax setBordered:NO];
    [tag_UIMax setEditable:NO];//控制是标签还是编辑框
    tag_UIMin.stringValue = [[NSString alloc] initWithFormat:@"%s",pdca->tag_Min];
    
    [tag_UIMin setBordered:NO];
    [tag_UIMin setEditable:NO];//控制是标签还是编辑框
    
    tag_UIuuto.stringValue = [[NSString alloc] initWithFormat:@"%s",pdca->tag_uutio];
    
    [tag_UIuuto setBordered:NO];
    [tag_UIuuto setEditable:NO];//控制是标签还是编辑框
    
    tag_UIIsPass.stringValue =  [[NSString alloc] initWithFormat:@"%s",pdca->tag_strPassFail];
    
    [tag_UIIsPass setBordered:NO];
    [tag_UIIsPass setEditable:NO];//控制是标签还是编辑框
    
    tag_UIValue.stringValue =  [[NSString alloc] initWithFormat:@"%s",pdca->tag_Value];
    
    [tag_UIValue setBordered:NO];
    [tag_UIValue setEditable:NO];//控制是标签还是编辑框
    
    if(pdca->tag_strPassFail[0] == 'F')
    {
      //  tag_UIIsPass.layer.backgroundColor = [[NSColor redColor] CGColor];
        [tag_UIIsPass setBackgroundColor:[NSColor redColor]];
        [tag_UIIsPass setTextColor:[NSColor whiteColor]];
     
        [tag_UIName setBackgroundColor:[NSColor redColor]];
        [tag_UIName setTextColor:[NSColor whiteColor]];
        [tag_UIValue setBackgroundColor:[NSColor redColor]];
        [tag_UIValue setTextColor:[NSColor whiteColor]];
        [tag_UIMin setBackgroundColor:[NSColor redColor]];
        [tag_UIMin setTextColor:[NSColor whiteColor]];
        [tag_UIMax setBackgroundColor:[NSColor redColor]];
        [tag_UIMax setTextColor:[NSColor whiteColor]];
        
        
    }
    else
    {
        //tag_UIIsPass.b
      //  tag_UIIsPass.layer.borderColor= [[NSColor whiteColor] CGColor];
      //  tag_UIIsPass.drawsBackground = true;
        
        [tag_UIIsPass setBackgroundColor:[NSColor whiteColor]];
        
        
        [tag_UIIsPass setTextColor:[NSColor blackColor]];
        
        
        [tag_UIName setBackgroundColor:[NSColor whiteColor]];
        [tag_UIName setTextColor:[NSColor blackColor]];
        [tag_UIValue setBackgroundColor:[NSColor whiteColor]];
        [tag_UIValue setTextColor:[NSColor blackColor]];
        [tag_UIMin setBackgroundColor:[NSColor whiteColor]];
        [tag_UIMin setTextColor:[NSColor blackColor]];
        [tag_UIMax setBackgroundColor:[NSColor whiteColor]];
        [tag_UIMax setTextColor:[NSColor blackColor]];
    }
 
}
/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：
 **返回值：
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    
  
    id retid = nil;

    if(tableView.tableColumns[uimainStepDebug_enum_index] == tableColumn)
    {
        
        retid = tag_UIIndex;
    }
    else
        if(tableView.tableColumns[uimainStepDebug_enum_name] == tableColumn)
        {
            retid = tag_UIName;
            
        }
        else
            if(tableView.tableColumns[uimainStepDebug_enum_value] == tableColumn)
            {
                retid = tag_UIValue;
            }
            else
                if(tableView.tableColumns[uimainStepDebug_enum_Max] == tableColumn)
                {
                    retid = tag_UIMax;
                }
                else
                    if(tableView.tableColumns[uimainStepDebug_enum_Min] == tableColumn)
                    {
                        retid = tag_UIMin;
                    }
                    else
                        if(tableView.tableColumns[uimainStepDebug_enum_IsPass] == tableColumn)
                        {
                            retid = tag_UIIsPass;
                        }
                        else
                         /*   if(tableView.tableColumns[uimainStepDebug_enum_ProgressIndicatorStep] == tableColumn)
                            {
                                retid = tag_NSProgressIndicator;
                            }
                            else*/
                                if(tableView.tableColumns[uimainStepDebug_enum_uuto] == tableColumn)
                                {
                                    retid = tag_UIuuto;
                                }
 
    
    return retid;
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
