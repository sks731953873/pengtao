//
//  DownLoadStation.c
//  strongTest
//
//  Created by strong on 2017/12/26.
//  Copyright © 2017年 strong. All rights reserved.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/timeb.h>

#include "Config.h"
StationManage s_StationManage = {0};
Station s_Station = {0};
extern char gloabe_sn[20][100];
#define DE_SNWRITE_LABER "[[SN]]"
extern char* PortSendData( portValue port,  char *sendData,int ReadTime);
extern char *GetCurrentDataCtr();
/*******************************************************************************************
 **函数名：isExit
 **参数：,Station  *station。运行的工位
 **功能：运行一个工位
 **返回值：= 1 退出
 ******************/
int isExit(Station  *station)
{
    stationManage lpsm = station->tag_user;
    return lpsm->tag_WorkStop;
}
/*******************************************************************************************
 **函数名：isExit
 **参数：,Station  *station。运行的工位
 **功能：运行一个工位
 **返回值：= 1 退出
 ******************/
int isStop()
{
    return g_sConfig->tag_stationManage.tag_WorkStop;
}
/*******************************************************************************************
 **函数名：isExit
 **参数：,Station  *station。运行的工位
 **功能：运行一个工位
 **返回值：= 1 退出
 ******************/
int isPause()
{
    return g_sConfig->tag_SysIni.tag_parse;
}
/*******************************************************************************************
 **函数名：isExit
 **参数：,Station  *station。运行的工位
 **功能：运行一个工位
 **返回值：= 1 退出
 ******************/
char* isLogFile()
{
    return &g_sConfig->tag_SysIni.tag_logFile[0];
}

/*******************************************************************************************
 **函数名：getSystemTime
 **参数：,int wait
 **功能：延时
 **返回值：< 0失败
 *******************************************************************************************/
long long getSystemTime()
{
    struct timeval tv;
    gettimeofday(&tv,NULL);    //该函数在sys/time.h头文件中
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
   /* struct timeb t;
    ftime(&t);
    return 1000 * t.time + t.millitm;*/
}
/*******************************************************************************************
 **函数名：SleepWait
 **参数：,int wait
 **功能：延时
 **返回值：< 0失败
 *******************************************************************************************/
void SleepWait(Station  *station,int wait)
{
   extern  void NSThreadsleep(int delay);
    long long tmBegin = getSystemTime();
    long long tmEnd = tmBegin;
  
    while((tmEnd - tmBegin) <= wait)
    {
        if(isExit(station))
        {
            return ;
        }
        NSThreadsleep(10);
        tmEnd = getSystemTime();
        
    }
    
}
/*******************************************************************************************
 **函数名：SleepWait
 **参数：,int wait
 **功能：延时
 **返回值：< 0失败
 *******************************************************************************************/
void Wait(int wait)
{
    long long tmBegin = getSystemTime();
    long long tmEnd = tmBegin;
    while((tmEnd - tmBegin) <= wait)
    {
        NSThreadsleep(10);
        tmEnd = getSystemTime();
        
    }
}
/*******************************************************************************************
 **函数名：cleanAllValue
 **参数：,Station  *station。运行的工位
 **功能：清除标记
 **返回值：< 0失败
 *******************************************************************************************/
void cleanAllValue(Station  *station)
{
    int i = 0;
    
    while(i < station->tag_totalCount)
    {
        memset(  station->tag_step[i].tag_Result,0,sizeof(station->tag_step[i].tag_Result));
        i++;
    }
    
}
/*******************************************************************************************
 **函数名：isFinish
 **参数：,Station  *station。运行的工位
 **功能：判断工位是否运行完成
 **返回值：1 完成，0 未完成
 *******************************************************************************************/
int isFinish(Station  *station,int begin,int end)
{
    int i = begin;
    stationManage lpm = station->tag_user;
    while(i < station->tag_totalCount && i < end)
    {
      if(station->tag_step[i].tag_workState ==1)
      {
          return 0;
      }
     if(lpm->tag_WorkStop ==1)
     {
         return 1;
     }
        i++;
    }
    return 1;
}


/*******************************************************************************************
 **函数名：waitFinish
 **参数：,Station  *station。运行的工位
 **功能：等待完成
 **返回值：1 完成，0 未完成
 *******************************************************************************************/
void waitFinish(Station  *station,int begin,int end)
{
    int i = 0;
    
    while(1)
    {
      
            
        /*if(isFinish(station,begin,end) ==1)
        {
            return ;
        }*/
          if(station->tag_WorkState == 0)
          {
              return ;
          }
      // Sleep(100);
        i++;
    }
  
}

/*******************************************************************************************
 **函数名：stationExe
 **参数：,Station  *station。运行的工位
 **功能：运行一个工位
 **返回值：< 0失败
 *******************************************************************************************/
int stationExe(Station  *station)
{
    extern char *GetCurrentTimeCtr();
    int ret = 0;
    int i = 0;

    station->tag_WorkState = 1;
    station->tag_Index  = 0;
    stationManage lp_stationManage = (stationManage)station->tag_user;
    if(!lp_stationManage)
        return 0;
    
    cleanAllValue(station);
    memset(station->tag_StartTime, 0, sizeof(station->tag_StartTime));
    strcat(station->tag_StartTime, GetCurrentTimeCtr());
    station->tag_logStartTime =  getSystemTime();
    while(i < station->tag_totalCount)
    {
        ret = 0;
        
        LpStep step = &station->tag_step[i];
        int excTimes = 0;
        while (excTimes < step->tag_exctimes + 1) {
             ret = StepRun(step);
            if (strstr(step->tag_pdcaValue.tag_strPassFail, "P")) {
                break;
            }
            excTimes ++;
        }
        
        station->tag_Index++;
        if(isExit(station))
        {
            station->tag_WorkState = 0;
            return -1;
        }
        i++;
    }

    station->tag_WorkState = 0;
    memset(station->tag_EndTime, 0, sizeof(station->tag_EndTime));
    strcat(station->tag_EndTime, GetCurrentTimeCtr());
    return 0;
}

void StationStepInit(StationManage  *stationManage,int ExeStationType)
{
    int i = 0;
    int j = 0;
    while(i < stationManage->tag_totalCount)
    {
        
        stationManage->tag_Station[i].tag_user =stationManage;
        j = 0;
        while(j < stationManage->tag_Station[i].tag_totalCount && ExeStationType == stationManage->tag_Station[i].tag_stationType)
        {
            
            int pdcaIndex = stationManage->tag_Station[i].tag_step[i].tag_pdca_index;
            int pdcaCount = g_sConfig->tag_pdcaValueManage.tag_totalCount;
            int snIndex =stationManage->tag_Station[i].tag_snIndex;
            stationManage->tag_Station[i].tag_step[j].tag_workState = 0;
            
            if(pdcaIndex > 0 && pdcaIndex  < pdcaCount)
            {
                memcpy(&stationManage->tag_Station[i].tag_step[j].tag_pdcaValue,&g_sConfig->tag_pdcaValueManage.tag_PdcaValue[pdcaIndex-1],sizeof(PdcaValue));
            }
            
            
            memset(stationManage->tag_Station[i].tag_step[j].tag_pdcaValue.tag_Value,0,sizeof(stationManage->tag_Station[i].tag_step[j].tag_pdcaValue.tag_Value));
            memset(stationManage->tag_Station[i].tag_step[j].tag_pdcaValue.tag_strPassFail,0,sizeof(stationManage->tag_Station[i].tag_step[j].tag_pdcaValue.tag_strPassFail));
            
            
            stationManage->tag_Station[i].tag_step[j].tag_pdcaValue.tag_sn = &gloabe_sn[snIndex];
         //   memset(stationManage->tag_Station[i].tag_step[j].tag_Result,0,sizeof(stationManage->tag_Station[i].tag_step[j].tag_Result));
            j++;
        }
        
        i++;
    }
}



/*******************************************************************************************
 **函数名：StepRun
 **参数：,(Step *step)
 ipConfig soc)
 **功能： 单步执行
 **返回值：< 0失败
 *******************************************************************************************/
int stationThread_Run(void *station)
{
    pthread_t t1;
    pthread_create(&t1,NULL,stationExe,(void *)station);

    return 0;
}


/*******************************************************************************************
 **函数名：stationExe
 **参数：,Station  *station。运行的工位
 **功能：运行一个工位
 **返回值：< 0失败
 *******************************************************************************************/
int stationManageExe(StationManage  *stationManage,int ExeStationType)
{
    int i = 0;
    int j = 0;
    stationManage->tag_StepIndex =0;
    if(stationManage->tag_WorkStop == 1)
    {
        return 0;
    }
    memset( g_sConfig->tag_SysIni.tag_logFile,0,sizeof(g_sConfig->tag_SysIni.tag_logFile));
    sprintf(g_sConfig->tag_SysIni.tag_logFile,"%s/log/%s.log",g_sConfig->tag_SysIni.tag_logDir,GetCurrentTimeCtr());
    StationStepInit(stationManage,ExeStationType);
    while(i < stationManage->tag_totalCount)
    {
        if(stationManage->tag_Station[i].tag_isWait && stationManage->tag_Station[i].tag_stationType == ExeStationType)
        {
            
            while(j < i)
            {
                SleepWait(&stationManage->tag_Station[j],2000);
                waitFinish(&stationManage->tag_Station[j],0,stationManage->tag_Station[j].tag_totalCount);
                j++;
            }
        }
        
        
        stationManage->tag_Station[i].tag_user =stationManage;
        if(stationManage->tag_Station[i].tag_isEnable && stationManage->tag_Station[i].tag_stationType == ExeStationType)
        {
            
            if(stationManage->tag_Station[i].tag_isThread)
            {
                stationThread_Run(&stationManage->tag_Station[i]);
            }
            else
            {
                SleepWait(&stationManage->tag_Station[j],1000);
                stationExe(&stationManage->tag_Station[i]);
            }
        }
        if(stationManage->tag_WorkStop == 1)
        {
            
            
            break;
        }
        i++;
    }
    i = 0;
    while(i < stationManage->tag_totalCount)
    {
        if( stationManage->tag_Station[i].tag_stationType == ExeStationType)
        {
            
            waitFinish(&stationManage->tag_Station[i],0,stationManage->tag_Station[i].tag_totalCount);
        }
        i++;
    }
    
    
    {
        extern void PdcaUpData();
        if(g_sConfig->tag_stationManage.tag_WorkStop == 0 && ExeStationType == enum_station_type_work)
        {
           
            PdcaUpData();
          
        }
    }
    return 0;
}


/*******************************************************************************************
 **函数名：stepDelete
 **参数：,Station  *station。运行的工位 ,int delIndex 删除第几个工位
 **功能：删除一个步骤
 **返回值：< 0失败
 *******************************************************************************************/
int stepDelete(Station *station,int delIndex)
{
  if(delIndex == -1)
      return 0;
    if(delIndex < MAXSTEP -1&& station->tag_totalCount >0)
    {
        if(delIndex == 0)
        {
            memcpy( &s_Station.tag_step[0],&station->tag_step[1],MAXSTEP*sizeof(Step));
            memcpy(&station->tag_step[0], &s_Station.tag_step[0],MAXSTEP*sizeof(Step));
        }
        else
        {
            memcpy( &s_Station.tag_step[0],&station->tag_step[0],delIndex*sizeof(Step));
            memcpy( &s_Station.tag_step[delIndex],&station->tag_step[delIndex+1],(MAXSTEP-delIndex)*sizeof(Step));
            memcpy(&station->tag_step[0], &s_Station.tag_step[0],MAXSTEP*sizeof(Step));
        }
        station->tag_totalCount--;
    }
    return 0;
}
/*******************************************************************************************
 **函数名：stepInster
 **参数：,Station  *station。运行的工位 ,int delIndex 第几个步骤，,Step *step 插入的步骤
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
int stepInster(Station *station,int index,Step *step)
{
  
    if(index == -1)
    {
        index = 0;
    }
    if(index < MAXSTEP-1 && station->tag_totalCount <MAXSTEP-1)
    {
        memcpy(&s_Station.tag_step[0], &station->tag_step[0], (index)*sizeof(Step));
        memcpy(&s_Station.tag_step[index], step, sizeof(Step));
        memcpy(&s_Station.tag_step[index+1], &station->tag_step[index], (MAXSTEP-1-index)*sizeof(Step));
        memcpy(&station->tag_step[0], &s_Station.tag_step[0],(MAXSTEP-1)*sizeof(Step));
        station->tag_totalCount++;
    }
    return 0;
}

/*******************************************************************************************
 **函数名：stationDelete
 **参数：,StationManage *station,int delIndex 第几个工位
 **功能：删除一个工位
 **返回值：
 *******************************************************************************************/
int stationDelete(StationManage *station,int delIndex)
{
    
    if(delIndex <0)
    {
        return 0;
    }
    if(delIndex < (MAXSTATION-1) && station->tag_totalCount >0)
    {
        if(delIndex == 0)
        {
            memcpy( &s_StationManage.tag_Station[0],&station->tag_Station[1],(MAXSTATION-1)*sizeof(Station));
            memcpy(&station->tag_Station[0], &s_StationManage.tag_Station[0],(MAXSTATION-1)*sizeof(Station));
            
        }
        else
        {
            memcpy( &s_StationManage.tag_Station[0],&station->tag_Station[0],delIndex*sizeof(Station));
            memcpy( &s_StationManage.tag_Station[delIndex],&station->tag_Station[delIndex+1],((MAXSTATION-2)-delIndex)*sizeof(Station));
            
            memcpy(&station->tag_Station[0], &s_StationManage.tag_Station[0],(MAXSTATION-1)*sizeof(Station));
        }
        station->tag_totalCount--;
    }
    return 0;
}


/*******************************************************************************************
 **函数名：stationInster
 **参数：,StationManage *station,int delIndex 第几个工位
 **功能：插入一个工位
 **返回值：
 *******************************************************************************************/
int stationInster(StationManage *station,int index)
{

    if(index == -1)
    {
        index = 0;
    }
    if(index < (MAXSTATION-1) && station->tag_totalCount <(MAXSTATION-1))
    {
        
        memcpy(&s_StationManage.tag_Station[0], &station->tag_Station[0], (index+1)*sizeof(Station));
        memcpy(&s_StationManage.tag_Station[index], &s_StationManage, sizeof(Station));
        memcpy(&s_StationManage.tag_Station[index+1], &station->tag_Station[index], ((MAXSTATION-1)-index)*sizeof(Station));
        memcpy(&station->tag_Station[0], &s_StationManage.tag_Station[0],(MAXSTATION-1)*sizeof(Station));
        s_StationManage.tag_Station[index].tag_user = station;
        s_StationManage.tag_Station[index+1].tag_user = station;
        station->tag_totalCount++;
    }
    return 0;
}


/*******************************************************************************************
 **函数名：GetSocket
 **参数：,
 **参数：
 **功能：获取一个csocket指针
 **返回值：< 0失败
 *******************************************************************************************/
cSocket GetSocket (void *p)
{
    LpStep step = (LpStep)p;
    cSocket lpsoc = 0;
    lpStationRun   dls = (lpStationRun)step->tag_user;
 
    if(step->tag_socket_index >0)
    {
        return &dls->tag_cSocket[step->tag_socket_index-1];
    }
    else
        if(dls && dls->tag_station->tag_socket_index >=0)
        {
            return &dls->tag_cSocket[dls->tag_station->tag_socket_index]; 
        }
        else
        {
            return &dls->tag_cSocket[0];
            
        }
    
}


/*******************************************************************************************
 **函数名：GetSocket
 **参数：,
 **参数：
 **功能：获取一个csocket指针
 **返回值：< 0失败
 *******************************************************************************************/
cSocket GetSerialPort (void *p)
{
    LpStep step = (LpStep)p;

    lpStationRun   dls = (lpStationRun)step->tag_user;
    if(step->tag_port_index >0)
    {
        return &dls->tag_cSocket[step->tag_socket_index-1];
    }
    else
        if(dls->tag_station->tag_socket_index >=0)
        {
            return &dls->tag_cSocket[dls->tag_station->tag_socket_index];
        }
        else
        {
            return &dls->tag_cSocket[0];
            
        }
}

/*******************************************************************************************
 **函数名：SocketSend
 **参数：,void *p。数据指针
 **参数：char *sendBuffer。发送的数据
 **功能：
 **返回值：< 0失败
 *******************************************************************************************/
int PortSend(char *sendBuffer,void *p)
{
    LpStep step = (LpStep)p;
    lpStationRun   dls = (lpStationRun)step->tag_user;
    int ret = 0;
    cSocket lpsoc = GetSocket(p);
    return ret ;
}
char DUTCmdfilePathZip[512] = {0};

extern char *GetCurrentDataCtr();

/*******************************************************************************************
 **函数名：SocketSend
 **参数：,void *p。数据指针
 **参数：char *sendBuffer。发送的数据
 **功能：
 **返回值：< 0失败
 *******************************************************************************************/
int SocketSend(char *sendBuffer,void *p)
{
    LpStep step = (LpStep)p;
    lpStationRun   dls = (lpStationRun)step->tag_user;
    int ret = 1;
    int index = 0;
    int j = 0;
    char *Enter = "\r\n";
    cSocket lpsoc = GetSocket(p);
    lpsoc->tag_outReadTime = step->tag_SleepDate;
    if(!lpsoc->sockectSend)
    {
        socketInit(lpsoc);
    }
    
    memset(lpsoc->tag_readBuffer,0,sizeof(lpsoc->tag_readBuffer));
    memset(lpsoc->tag_sendBuffer ,0,sizeof(lpsoc->tag_sendBuffer));
    memcpy(lpsoc->tag_sendBuffer ,sendBuffer,strlen(sendBuffer));
    strcat(lpsoc->tag_sendBuffer,lpsoc->tag_ipConfig->tag_SendendFlage);
    if(lpsoc->tag_ipConfig->tag_isSendEnterkey)
    {
        strcat(lpsoc->tag_sendBuffer,Enter);
    }
    lpsoc->tag_sendLen = strlen(lpsoc->tag_sendBuffer);
    
    if(strlen(lpsoc->tag_ipConfig->tag_ip)<=0)
    {
        printf("函数:%s第：%d行\r\n",__func__,__LINE__);
        return enum_step_run_result_no_Ip;
    }
    if( lpsoc->tag_sendLen <= 0 )
    {
          printf("函数:%s第：%d行\r\n",__func__,__LINE__);
        return enum_step_run_result_len_0;
    }

    if(lpsoc->tag_id < 0  || SocketIsColse(lpsoc) != 0)
    {
        lpsoc->sockectClose(lpsoc);
        lpsoc->sockectConnect(lpsoc);
    }
    
    if( lpsoc->tag_id<0 || SocketIsColse(lpsoc) == 1)
    {
        
        ret= lpsoc->sockectConnect(lpsoc);
        if( lpsoc->tag_id<0 || SocketIsColse(lpsoc) == 1)
        {
            ret= lpsoc->sockectConnect(lpsoc);
        }
    }
    
    if(ret >0 && strlen(lpsoc->tag_sendBuffer)  > 0)
    {
        //发送前读取后清空buffer
       // ret =  lpsoc->sockectRead(lpsoc);
       // memset(lpsoc->tag_readBuffer,0,sizeof(lpsoc->tag_readBuffer));
        extern int ReadDataClean2(void*  Soc);
        ReadDataClean2(lpsoc);
        if((ret =  lpsoc->sockectSend(lpsoc))>0)
        {
        
            char *fileName = malloc(1024);
            memset(fileName,0,1024);
            if(dls->tag_station->tag_snIndex <0)
            {
                dls->tag_station->tag_snIndex = 0;
            }
            
            if(dls->tag_station->tag_snIndex < 20)
            {
                strcat(fileName, g_sConfig->tag_SysIni.tag_DutDir);
                strcat(fileName, "/");
            
                strcat(fileName, GetCurrentDataCtr());
                
                strcat(fileName, "/");
                strcat(fileName, &gloabe_sn[dls->tag_station->tag_snIndex]);//fch
                
                              index = strlen(fileName);
                
                
                for(int i= 0;i < strlen(g_sConfig->tag_SysIni.tag_DutFileName);i++)
                {
                    if( g_sConfig->tag_SysIni.tag_DutFileName[i] == '%')
                    {
                        j = i;
                        j ++;
                        break;
                        
                    }
                    else
                    {
                        fileName[i+index] = g_sConfig->tag_SysIni.tag_DutFileName[i];
                    }
                }
                
                strcat(fileName, dls->tag_station->tag_Name);
                strcat(fileName, "-");
                strcat(fileName, dls->tag_station->tag_StartTime);
              //  strcat(fileName, "_DUT_log.txt");

                 index =strlen(fileName);
                
                while(j <strlen(g_sConfig->tag_SysIni.tag_DutFileName))
                {
                    fileName[index] = g_sConfig->tag_SysIni.tag_DutFileName[j];
                    j ++;
                    index++;
                }
                
                    lpStationRun dls = (lpStationRun)step->tag_user; //有sn才写入
                    if(dls->tag_station->tag_snIndex >= 0){
                        char *   descript = malloc(1024*100);
                        memset(descript, 0, 1024*100);
                        sprintf(descript, "stepName:%s",step->tag_stepName);
                        logwrite(fileName,descript);
                        memset(descript, 0, sizeof(descript));
                        sprintf(descript, "send:%s",lpsoc->tag_sendBuffer);
                        logwrite(fileName,descript);
                        free(descript);
//                        logwrite(fileName,step->tag_stepName);
//                        logwrite(fileName,lpsoc->tag_sendBuffer);
                    }
                
               // memset(dls->tag_station->tag_ArmFile,0,sizeof(dls->tag_station->tag_ArmFile));
               // strcat(dls->tag_station->tag_ArmFile, fileName);
               //     logwrite(fileName,lpsoc->tag_readBuffer);
               
             }
         
             /************************/
            
            SleepWait(dls->tag_station ,200);
            
            memset(lpsoc->tag_ipConfig->tag_ReadEndFlage2,0,sizeof(lpsoc->tag_ipConfig->tag_ReadEndFlage2));
            strcat(lpsoc->tag_ipConfig->tag_ReadEndFlage2,step->tag_ReadEndFlage);
            lpsoc->tag_ipConfig->tag_isReadEnterkey2 = step->tag_readEnterKey;
            lpsoc->tag_ReadBufferIsClean = 0;
            ret =  lpsoc->sockectRead(lpsoc);
            if(dls->tag_station->tag_snIndex >= 0){
                char *   descript = malloc(1024*100);
                memset(descript, 0, 1024*100);
                sprintf(descript, "receive:%s",lpsoc->tag_readBuffer);
                memset(dls->tag_station->tag_DutFile, 0, sizeof(dls->tag_station->tag_DutFile));
                strcat(dls->tag_station->tag_DutFile,fileName);
                logwrite(fileName,descript);
                free(descript);
              //  logwrite(fileName,lpsoc->tag_readBuffer);
            }
            
          //  memcpy(step->tag_Result ,dls->tag_cSocket.tag_readBuffer,dls->tag_cSocket.tag_ReadLen);
            free(fileName);
            return enum_step_run_result_ok;
            
        }
        else
        {
            lpsoc->sockectClose(lpsoc);
            printf("函数:%s第：%d行\r\n",__func__,__LINE__);
            return enum_step_run_result_SocErr;
        }

    }
    else
    {
         lpsoc->sockectClose(lpsoc);
         printf("函数:%s第：%d行\r\n",__func__,__LINE__);
        return enum_step_run_result_SocErr;
    }
    return ret ;

}



/*******************************************************************************************
 **函数名：SocketSend
 **参数：,void *p。数据指针
 **参数：char *sendBuffer。发送的数据
 **功能：
 **返回值：< 0失败
 *******************************************************************************************/
int SocketReadApi(void *p)
{
    LpStep step = (LpStep)p;
    lpStationRun   dls = (lpStationRun)step->tag_user;
    int ret = 0;
    cSocket lpsoc = GetSocket(p);
    lpsoc->tag_outReadTime = step->tag_SleepDate;
    if(!lpsoc->sockectSend)
    {
        socketInit(lpsoc);
    }
    if(strlen(lpsoc->tag_ipConfig->tag_ip)<=0)
    {
        printf("函数:%s第：%d行\r\n",__func__,__LINE__);
        return enum_step_run_result_no_Ip;
    }
    if(lpsoc->tag_id<=0)
    {
        
        ret= lpsoc->sockectConnect(lpsoc);
        if(ret <=0 )
        {
            lpsoc->sockectClose(lpsoc);
            return enum_step_run_result_SocErr;
        }
    }
    if(ret >=0 )
    {
        memset(lpsoc->tag_ipConfig->tag_ReadEndFlage2,0,sizeof(lpsoc->tag_ipConfig->tag_ReadEndFlage2));
        strcat(lpsoc->tag_ipConfig->tag_ReadEndFlage2,step->tag_ReadEndFlage);
        lpsoc->tag_ipConfig->tag_isReadEnterkey2 = step->tag_readEnterKey;
        lpsoc->tag_ReadBufferIsClean = 1;
        ret =  lpsoc->ReadDataNotClean(lpsoc);
    }
    else
    {
        lpsoc->sockectClose(lpsoc);
        printf("函数:%s第：%d行\r\n",__func__,__LINE__);
        return enum_step_run_result_SocErr;
    }
    return ret ;
    
}
#pragma Mark---写 csv


int ReadSnStepExe(void *p)
{
    char sn1[100] = {0};
    char sn2[100] = {0};
    char sn3[100] = {0};
    int i = 0;
    int j = 0;
    int len = 0;
    
    
    LpStep step = (LpStep)p;
    lpStationRun   dls = (lpStationRun)step->tag_user;
    lpStation station = dls->tag_station;
   // char *sn =&gloabe_sn[ dls->tag_station->tag_snIndex];

    memset(sn1,0,100);
    memset(sn2,0,100);
    memset(sn3,0,100);
    SocketStepExe(p);
    len = strlen(step->tag_Result);
    while(i < len && i < 100)
    {
        if(step->tag_Result[i] == '\r' || step->tag_Result[i] == '\n')
        {
            break;
        }
        if((step->tag_Result[i]<='9' && step->tag_Result[i]>='0')
           || (step->tag_Result[i]>='A' && step->tag_Result[i]<='Z')
           || (step->tag_Result[i]>='a' && step->tag_Result[i]<='z')
           
           )
        {
            sn1[i] = step->tag_Result[i];
        }
        i++;
    }
    i = 0;
    j = len-1;
    while(j >0 && i <  50)
    {
        if(step->tag_Result[j] == ' ' || step->tag_Result[i] == '|')
        {
            break;
        }
        if((step->tag_Result[i]<='9' && step->tag_Result[i]>='0')
           || (step->tag_Result[i]>='A' && step->tag_Result[i]<='Z')
           || (step->tag_Result[i]>='a' && step->tag_Result[i]<='z')
           
           )
        {
        sn2[i]= step->tag_Result[j];
        }
        i++;
        j--;
    }
    
    j = strlen(sn1);
    i = i-1;
    while(i >=0)
    {
        sn1[j] =  sn2[i] ;
        i--;
        j++;
        
    }
    
    memset(step->tag_Result,0,sizeof(step->tag_Result));
    strcat(step->tag_Result,sn1);
    
    AddLog(step->tag_Result);
    
    /* if(strlen(sn) ==0)
    {
        memset(sn,0,100);
        strcat(sn,step->tag_Result);
    }
    
    j = strlen(step->tag_Result);
    i = 0;
   while(i <MAXRESULT)
    {
        if((sn[i]<='9' && sn[i]>='0')
           || (sn[i]>='A' && sn[i]<='Z')
           || (sn[i]>='a' && sn[i]<='z')
           
           )
        {
            
        }
        else
        {
            sn[i] = 0;
        }
        i++;
    }*/
    
  /*  G6480520HB1JL01
    0010 :31 57 22                                        | 1W*/
    
    return 0;
}

/**
 解析字符串，把子字符串存放在二维数组中
 
 @param str 要解析的字符串
 @param tag_totalResut 二维数组
 @param count 二维数组长度
 */
int getStrArr(LpStep step,char tag_totalResut[][100],int count ){
    cSocket lpsoc = GetSocket(step);
    int i = 0;
    char *findBegin = step->tag_filtrationBegin;
    char *findEnd = step->tag_filtrationEnd;
    char *findBeginStr = strstr(lpsoc->tag_readBuffer, findBegin);
    if (findBeginStr) {
        while (i < count) {
            findBeginStr = strstr(findBeginStr, findBegin);
            if (!findBeginStr) {
                break;
            }
            char *findEndStr = strstr(findBeginStr, findEnd);
            if (!findEndStr) {
                break;
            }
            long len = findEndStr - findBeginStr;
            long memCpyLen = len - strlen(findBegin);
            char tag_result[100] = {0};
            if (memCpyLen > sizeof(tag_result)) {
                return i;
            }
            memcpy(tag_result, findBeginStr + strlen(findBegin), memCpyLen);
            
            strcat(tag_totalResut[i], tag_result);
            findBeginStr = findBeginStr + len;
            i ++;
        }
    }
    return i;
}

/**
 根据对应步骤中
 
 @param step <#step description#>
 @param doubleResult <#doubleResult description#>
 */
void dealResultWithStepName(LpStep step,double doubleResult){
    
    memset(step->tag_Result, 0, sizeof(step->tag_Result));
    
    if (strstr(step->tag_stepName, "Jakku Accel")){
        sprintf(step->tag_Result,"%f",doubleResult/ 8192);
    }else if((strstr(step->tag_stepName, "Graphite")&&strstr(step->tag_stepName, "accel average"))||
             (strstr(step->tag_stepName, "Graphite")&&strstr(step->tag_stepName, "accel std"))){
        sprintf(step->tag_Result,"%f",doubleResult/ 4096);
    }else if((strstr(step->tag_stepName, "Graphite")&&strstr(step->tag_stepName, "gyro average"))||
             (strstr(step->tag_stepName, "Graphite")&&strstr(step->tag_stepName, "gyro std"))){
        sprintf(step->tag_Result,"%f",doubleResult/ 16.4);
    }
}

/**
 计算方差和平均差
 
 @param step step参数
 */
void AlgorithmReadStepExe(LpStep step){
    
    char tag_totalResut[512][100] = {0};
    
    int arrCount = getStrArr(step,tag_totalResut,512);
    if (!strlen(tag_totalResut)) {
        return;
    }
    
    double doubleX[512] = {0};
    double doubleY[512] = {0};
    double doubleZ[512] = {0};
    
    
    int i = 0;
    while (i < arrCount-1) {
        char *str = tag_totalResut[i];
        
        char X[128] = {0};
        char Y[128] = {0};
        char Z[128] = {0};
        char *strYZ = strstr(str, ",") + 1;
        long len = strYZ - str;
        memcpy(X, str, len - 1);
        char *strZ = strstr(strYZ, ",") + 1;
        len = strZ - strYZ;
        memcpy(Y, strYZ, len - 1);
        strcat(Z, strZ);
        doubleX[i] = atof(X);
        doubleY[i] = atof(Y);
        doubleZ[i] = atof(Z);
        i ++;
    }
    
    //求平均值
    int index = 0;
    double averageX = 0,averageY = 0,averageZ = 0;
    double sumX = 0,sumY = 0,sumZ = 0;
    while (1) {
        if (index >= arrCount-1){
            averageX = sumX/index;
            averageY = sumY/index;
            averageZ = sumZ/index;
            break;
        }
        sumX = sumX + doubleX[index];
        sumY = sumY + doubleY[index];
        sumZ = sumZ + doubleZ[index];
        index ++;
    }
    
    //求方差
    int sqrIndex = 0;
    double sqrX = 0,sqrY = 0,sqrZ = 0; //(x1-average)^2 + (x2-average)^2 + ...
    while (1) {
        if (sqrIndex >= arrCount-1){
            sqrX = sqrt(sqrX / sqrIndex);
            sqrY = sqrt(sqrY / sqrIndex);
            sqrZ = sqrt(sqrZ / sqrIndex);
            break;
        }
        sqrX = sqrX + (doubleX[sqrIndex] - averageX)*(doubleX[sqrIndex] - averageX);
        sqrY = sqrY + (doubleY[sqrIndex] - averageY)*(doubleY[sqrIndex] - averageY);
        sqrZ = sqrZ + (doubleZ[sqrIndex] - averageZ)*(doubleZ[sqrIndex] - averageZ);
        sqrIndex ++;
    }
    switch (step->tag_algorithmType) {
        case enum_algorithmType_avgX:
            dealResultWithStepName(step,averageX);
            
            
            break;
        case enum_algorithmType_avgY:
            dealResultWithStepName(step,averageY);
            
            
            break;
        case enum_algorithmType_avgZ:
            dealResultWithStepName(step,averageZ);
            
            
            break;
        case enum_algorithmType_sqrtX:
            dealResultWithStepName(step,sqrX);
            
            
            break;
        case enum_algorithmType_sqrtY:
            dealResultWithStepName(step,sqrY);
            
            
            break;
        case enum_algorithmType_sqrtZ:
            dealResultWithStepName(step,sqrZ);
            
            
            break;
        default:
            memset(step->tag_Result, 0, sizeof(step->tag_Result));
            break;
    }
}


/*******************************************************************************************
 **函数名：SocketStepExe
 **参数：,void *p。数据指针
 **功能：socket 数据发送,发送配置的指令
 **返回值：< 0失败
 *******************************************************************************************/
int SocketStepExe(void *p)
{
    int ret = 0;
    int m = 0;
    int len = 0;
    LpStep step = (LpStep)p;
    lpStationRun   dls = (lpStationRun)step->tag_user;
    cSocket lpsoc = GetSocket(p);
    char *begin1 = &lpsoc->tag_readBuffer[0];
    int beginLen =strlen(step->tag_filtrationBegin);
    int endLen =strlen(step->tag_filtrationEnd);
    char *end1 = 0;
    char *  begin = 0;
    ret = SocketSend(step->tag_sendCommand,p);
    
    if(lpsoc->tag_ReadLen > 0)
    {
        end1 = &lpsoc->tag_readBuffer[strlen(lpsoc->tag_readBuffer)];
        if(beginLen >0)
        {
            begin =  strstr(lpsoc->tag_readBuffer,step->tag_filtrationBegin);
            if(begin )
            {
                begin1 = begin;
            }
        }
        if(endLen >0)
        {
            
            char * end =  strstr(begin1,step->tag_filtrationEnd);
            if(begin)
            {
                end =  strstr(begin1+strlen(step->tag_filtrationBegin),step->tag_filtrationEnd);
            }
            else
            {
                end =  strstr(begin1,step->tag_filtrationEnd);
            }
            
            if(end)
            {
                end1 = end;
            }
            
        }
        if(end1-begin1-beginLen >0 && end1-begin1-beginLen < MAXRESULT)
        {
            memcpy( step->tag_Result,begin1 + beginLen,end1-begin1-beginLen);
        }
        else
            if(end1-begin1-beginLen >0 )
            {
                
                memcpy( step->tag_Result,begin1 + beginLen,MAXRESULT-1);
                
            }
            else
            {
                memset(step->tag_Result,0,sizeof(step->tag_Result));
            }
        m = sizeof(step->tag_Result)-1;
        while(m >=0)
        {
            
            if(step->tag_Result[m] == ' ')
            {
                step->tag_Result[m] = 0;
            }
            else
                break;
            m--;
        }
    }
    else
    {
        memset(lpsoc->tag_currentReadBuffer, 0, sizeof(lpsoc->tag_currentReadBuffer));//fch
        strcat(lpsoc->tag_currentReadBuffer, lpsoc->tag_readBuffer);//fch
        return -1;
    }
    
    memset(lpsoc->tag_currentReadBuffer, 0, sizeof(lpsoc->tag_currentReadBuffer));//fch
    strcat(lpsoc->tag_currentReadBuffer, lpsoc->tag_readBuffer);//fch
    
    //温度测试
    if (step->tag_type == enum_commandType_SocketTemp) {
        int i = 0;
        int isDigital = 1;
        while (i < strlen(step->tag_Result)) {
            if (step->tag_Result[i] != ' ')
            {
                
                if (step->tag_Result[i] == '\r' || step->tag_Result[i] == '\n') {
                    break;
                }
                if (step->tag_Result[i] <'0' || step->tag_Result[i] >'9') {
                    isDigital = 0;
                    break;
                } ;
            };
            i ++;
        }
        if (isDigital) {
            double double_result = atof(step->tag_Result);
            memset(step->tag_Result, 0, sizeof(step->tag_Result));
            sprintf(step->tag_Result, "%.0f",double_result + 23);
        }
        
    }
    return 0;
}

/*******************************************************************************************
 **函数名：SocketStepSnWrite
 **参数：,void *p。数据指针
 **功能：socket 数据发送,发送配置的指令
 **返回值：< 0失败
 *******************************************************************************************/
int SocketStepSnWrite(void *p)
{
    int ret = 0;
    LpStep step = (LpStep)p;
    lpStationRun   dls = (lpStationRun)step->tag_user;
    
    cSocket lpsoc = GetSocket(p);
    char *begin1 = &lpsoc->tag_readBuffer[0];
    int beginLen =strlen(step->tag_filtrationBegin);
    int endLen =strlen(step->tag_filtrationEnd);
    char *end1 = 0;
    char *SendData = malloc(1024);
    char *Sn_Index =   strstr(step->tag_sendCommand,DE_SNWRITE_LABER);
    if(Sn_Index)
    {
        memset(SendData,0,1024);
        memcpy(SendData,step->tag_sendCommand,Sn_Index-step->tag_sendCommand);
        memcpy(&SendData[strlen(SendData)],gloabe_sn[dls->tag_station->tag_snIndex],strlen(gloabe_sn[dls->tag_station->tag_snIndex]));
        memcpy(&SendData[strlen(SendData)],Sn_Index + strlen(DE_SNWRITE_LABER),strlen(Sn_Index + strlen(DE_SNWRITE_LABER)));
        
    }
    if((ret = SocketSend(SendData, p)) ==0)
    {
        end1 = &lpsoc->tag_readBuffer[strlen(lpsoc->tag_readBuffer)];
        if(beginLen >0)
        {
            char *  begin =  strstr(lpsoc->tag_readBuffer,step->tag_filtrationBegin);
            if(begin )
            {
                begin1 = begin;
            }
        }
        if(endLen >0)
        {
            char * end =  strstr(lpsoc->tag_readBuffer,step->tag_filtrationEnd);
            if(end)
            {
                end1 = end;
            }
            
        }
        if(end1-begin1-beginLen >0 && end1-begin1-beginLen < MAXRESULT)
        {
            memcpy( step->tag_Result,begin1 + beginLen,end1-begin1-beginLen);
        }
        else
            if(end1-begin1-beginLen >0 )
            {
                memcpy( step->tag_Result,begin1 + beginLen,MAXRESULT-1);
            }
            else
            {
                memset(step->tag_Result,0,sizeof(step->tag_Result));
            }
    }
    else
    {
         free(SendData);
        return ret;
    }

    free(SendData);
    
    return ret;
}


/*******************************************************************************************
 **函数名：SocketStepSnWrite
 **参数：,void *p。数据指针
 **功能：socket 数据发送,发送配置的指令
 **返回值：< 0失败
 *******************************************************************************************/
int SocketStepSnRead(void *p)
{
    int ret = 0;
    LpStep step = (LpStep)p;
    lpStationRun   dls = (lpStationRun)step->tag_user;
    
    cSocket lpsoc = GetSocket(p);
    char *begin1 = &lpsoc->tag_readBuffer[0];
    int beginLen =strlen(step->tag_filtrationBegin);
    int endLen =strlen(step->tag_filtrationEnd);
    char *end1 = 0;
    char *SendData = malloc(1024);
    char *Sn_Index =   strstr(step->tag_sendCommand,DE_SNWRITE_LABER);
    if(Sn_Index)
    {
        memset(SendData,0,1024);
        memcpy(SendData,step->tag_sendCommand,Sn_Index-step->tag_sendCommand);
        memcpy(&SendData[strlen(SendData)],gloabe_sn[dls->tag_station->tag_snIndex],strlen(gloabe_sn[dls->tag_station->tag_snIndex]));
        memcpy(&SendData[strlen(SendData)],Sn_Index + strlen(DE_SNWRITE_LABER),strlen(Sn_Index + strlen(DE_SNWRITE_LABER)));
    }
    if((ret = SocketSend(SendData, p)) ==0)
    {
        end1 = &lpsoc->tag_readBuffer[strlen(lpsoc->tag_readBuffer)];
        if(beginLen >0)
        {
            char *  begin =  strstr(lpsoc->tag_readBuffer,step->tag_filtrationBegin);
            if(begin )
            {
                begin1 = begin;
            }
        }
        if(endLen >0)
        {
            char * end =  strstr(lpsoc->tag_readBuffer,step->tag_filtrationEnd);
            if(end)
            {
                end1 = end;
            }
            
        }
        if(end1-begin1-beginLen >0 && end1-begin1-beginLen < MAXRESULT)
        {
            memcpy( step->tag_Result,begin1 + beginLen,end1-begin1-beginLen);
        }
        else
            if(end1-begin1-beginLen >0 )
            {
                memcpy( step->tag_Result,begin1 + beginLen,MAXRESULT-1);
            }
            else
            {
                memset(step->tag_Result,0,sizeof(step->tag_Result));
            }
    }
    else
    {
        free(SendData);
        return ret;
    }
    
    free(SendData);
    
    return ret;
}


/*******************************************************************************************
 **函数名：IOSocketReadIo
 **参数：,void *p。数据指针 var 等于几
 **功能：socketIO 读
 **返回值：< 0失败
 *******************************************************************************************/
int IOSocketReadIo(void *p,char var)
{
    int ret = 0;
    LpStep step = (LpStep)p;
    char bit[128] = {0};
    char Buffer[128] = {0};
    char Ret[128] = {0};
    lpStationRun   dls = (lpStationRun)step->tag_user;
    long long tmBegin = getSystemTime();
    long long tmEnd = tmBegin;
    int n =0;
    int i = 0;
    char varR = '0';
    cSocket lpsoc = GetSocket(p);
    while((tmEnd - tmBegin) <= step->tag_SleepDate)
    {
        memset(Buffer,0,sizeof(Buffer));
        memset(bit,0,sizeof(bit));
        sprintf(bit,"=");
        sprintf(Buffer,"%s",step->tag_sendCommand);
        memset(step->tag_Result,0,sizeof(step->tag_Result));
        if((ret =SocketSend(Buffer, p)) ==0)
        {
           
            char *index =  strstr(lpsoc->tag_readBuffer,bit);
            n = 0;
            while(index)
            {
                if(index )
                {
                    Ret[n] = index[strlen(bit)];
 
                }
                index = index +strlen(bit);
                index =  strstr(index,bit);
                n++;
            }
            while(i < n)
            {
                if(Ret[i]  == var)
                {
                    varR ='1';
                }
                else
                {
                    varR = '0';
                    break;
                }
                i++;
            }
        }
        
        if(varR == '1')
        {
            step->tag_Result[0] = '1';
            break;
        }
        else
        {
             step->tag_Result[0] = '0';
        }
        tmEnd = getSystemTime();
        if(isExit(dls->tag_station))
        {
            return enum_step_run_result_Stop;
        }
    }
    return ret ;
}
/*******************************************************************************************
 **函数名：IOSocketReadIo
 **参数：,void *p。数据指针 var 等于几
 **功能：socketIO 读
 **返回值：< 0失败
 *******************************************************************************************/
int SocketRead(void *p)
{
    int ret = 0;
    LpStep step = (LpStep)p;
    char bit[128] = {0};
    char Buffer[128] = {0};
    char Ret[128] = {0};
    char *readBuffer = malloc(1024*200);
    lpStationRun   dls = (lpStationRun)step->tag_user;
    long long tmBegin = getSystemTime();
      char *Enter = "\r\n";
    long long tmEnd = tmBegin;
    int n =0;
    int i = 0;
    char varR = '0';
    cSocket lpsoc = GetSocket(p);
    memset(readBuffer,0,1024*200);
    if(!lpsoc->sockectSend)
    {
        socketInit(lpsoc);
    }
    if(strlen(step->tag_sendCommand) >0)
    {
         memset(lpsoc->tag_sendBuffer,0,strlen(lpsoc->tag_sendBuffer));
         memcpy(lpsoc->tag_sendBuffer ,step->tag_sendCommand,strlen(step->tag_sendCommand));
        strcat(lpsoc->tag_sendBuffer,lpsoc->tag_ipConfig->tag_SendendFlage);
        if(lpsoc->tag_ipConfig->tag_isSendEnterkey)
        {
            strcat(lpsoc->tag_sendBuffer,Enter);
        }
        lpsoc->tag_sendLen = strlen(lpsoc->tag_sendBuffer);
 
        if(lpsoc->tag_id<=0)
        {
        
            ret= lpsoc->sockectConnect(lpsoc);
        }
        if(ret >=0 && strlen(lpsoc->tag_sendBuffer)  > 0)
        {
            //发送前读取后清空buffer
            // ret =  lpsoc->sockectRead(lpsoc);
            // memset(lpsoc->tag_readBuffer,0,sizeof(lpsoc->tag_readBuffer));
        
            if((ret =  lpsoc->sockectSend(lpsoc))>0)
            {
            
            }
            
        }
    }
    Wait(50);
    while((tmEnd - tmBegin) <= step->tag_SleepDate)
    {
        memset(Buffer,0,sizeof(Buffer));
        memset(bit,0,sizeof(bit));
        sprintf(bit,"=");
    
        memset(step->tag_Result,0,sizeof(step->tag_Result));
        if((ret =SocketReadApi( p)) >0 && strlen(readBuffer) +strlen( lpsoc->tag_readBuffer) < 1024*200)
        {
            strcat(readBuffer,lpsoc->tag_readBuffer);
        }
        else
        {
            return 0;
        }
        if(strlen(step->tag_filtrationBegin) == 0)
        {
             strcat(step->tag_Result,lpsoc->tag_readBuffer);
            return 0;
        }
        else
        if(strlen(step->tag_filtrationBegin) >0)
        {
                char *find =   strstr(readBuffer,step->tag_filtrationBegin);
                if(strlen(step->tag_filtrationBegin) > 0)
                {
                    if(find)
                    {
                        char *findEnd =   strstr(find,step->tag_filtrationEnd);
                        if(  findEnd)
                        {
                            int len1 = findEnd -find;
                            int len2 = strlen(step->tag_filtrationBegin);;
                            int MemCpylen = findEnd -find-strlen(step->tag_filtrationBegin);
                            if(len1 < len2)
                                MemCpylen = len1;
                                memset(step->tag_Result,0,sizeof(step->tag_Result));
                                memcpy(step->tag_Result,find+strlen(step->tag_filtrationBegin),MemCpylen);
                                free(readBuffer);
                            if(step->tag_SleepDate >(tmEnd - tmBegin))
                            {
                                SleepWait(dls->tag_station, step->tag_SleepDate -(tmEnd - tmBegin));
                            }
                            return enum_step_run_result_ok;
                }
                else
                {
                    memset(step->tag_Result,0,sizeof(step->tag_Result));
                    strcat(step->tag_Result,find);
                }

                free(readBuffer);
                if(step->tag_SleepDate >(tmEnd - tmBegin))
                {
                    SleepWait(dls->tag_station, step->tag_SleepDate -(tmEnd - tmBegin));
                }
            
            return enum_step_run_result_ok;
        }
      
        }
        }
        tmEnd = getSystemTime();
        if(isExit(dls->tag_station))
        {
            free(readBuffer);
            return enum_step_run_result_Stop;
        }
    }
     free(readBuffer);
    return enum_step_run_result_ok ;
}

/**
 socket读，指针一路后移

 @param p <#p description#>
 @return <#return value description#>
 */
int SocketReadClean(void *p)
{
    LpStep step = (LpStep)p;
    char *readBuffer = malloc(1024*200);
    cSocket lpsoc = GetSocket(p);
    memset(readBuffer,0,1024*200);
    
    memset(step->tag_Result,0,sizeof(step->tag_Result));
    
    strcat(readBuffer,lpsoc->tag_currentReadBuffer);
    
    if(strlen(step->tag_filtrationBegin) == 0)
    {
        strcat(step->tag_Result,lpsoc->tag_currentReadBuffer);
        free(readBuffer);
        return 0;
    }
    else if(strlen(step->tag_filtrationBegin) >0)
    {
        char *find =   strstr(readBuffer,step->tag_filtrationBegin);
        if(strlen(step->tag_filtrationBegin) > 0)
        {
            if(find)
            {
                char *findEnd =   strstr(find,step->tag_filtrationEnd);
                
                if(  findEnd)
                {
                    int len1 = findEnd -find;
                    int len2 = strlen(step->tag_filtrationBegin);;
                    int MemCpylen = findEnd -find-strlen(step->tag_filtrationBegin);
                    if(len1 < len2)
                        MemCpylen = len1;
                    memset(step->tag_Result,0,sizeof(step->tag_Result));
                    memcpy(step->tag_Result,find+strlen(step->tag_filtrationBegin),MemCpylen);
                    free(readBuffer);
                    
                    memset(lpsoc->tag_currentReadBuffer, 0, sizeof(lpsoc->tag_currentReadBuffer));
                    strcat(lpsoc->tag_currentReadBuffer, findEnd);
                    return 0;
                }
                else
                {
                    memset(step->tag_Result,0,sizeof(step->tag_Result));
                    strcat(step->tag_Result,find);
                    memset(lpsoc->tag_currentReadBuffer, 0, sizeof(lpsoc->tag_currentReadBuffer));
                    strcat(lpsoc->tag_currentReadBuffer, find);
                }
                free(readBuffer);
                return 0;
            }
        }
    }
    free(readBuffer);
    return 0 ;
}


/*******************************************************************************************
 **函数名：IOSocketSetIo
 **参数：,void *p。数据指针
 **功能：socketIO 设置
 **返回值：< 0失败
 *******************************************************************************************/
int IOSocketSetIo(void *p)
{
    int ret = 0;

    LpStep step = (LpStep)p;
    char bit[128] = {0};
    char *Buffer = (char *) malloc(1024);
    lpStationRun   dls = (lpStationRun)step->tag_user;
    memset(Buffer,0,1024);
    sprintf(Buffer,"%s",step->tag_sendCommand);
    memset(step->tag_Result,0,sizeof(step->tag_Result));
    cSocket lpsoc = GetSocket(p);
    if((ret =SocketSend(Buffer, p)) ==0)
    {
        int index =  strstr(lpsoc->tag_readBuffer,"ACK(DONE)");
        if(index >0)
        {
            step->tag_Result[0] = "1";
            step->tag_Result[1] = 0;
        }
        else
        {
            step->tag_Result[0] = "0";
            step->tag_Result[1] = 0;
        }
    }
    free(Buffer);
    return ret ;
}
/*******************************************************************************************
 **函数名：ScriptStepExe
 **参数：,void *p。数据指针
 **功能：脚本执行
 **返回值：< 0失败
 *******************************************************************************************/
int ScriptStepExe(void *p)
{
    int ret = 0;
    char *cmd = malloc(1024);
    char oldFile[512] = {0};
    LpStep step = (LpStep)p;
    cSocket lpsoc = GetSocket(p);
    lpStationRun   dls = (lpStationRun)step->tag_user;
    char fileName[512] = {0};
    memset(fileName,0,512);
    memset(oldFile,0,512);
    memset(cmd,0,1024);
    if (strstr(step->tag_sendCommand,"fwdl"))
    {
        strcat(cmd, g_sConfig->tag_SysIni.tag_scriptDir);
        cmd[strlen(cmd)] = '/';
        strcat(cmd, "scpreceive.sh");
        cmd[strlen(cmd)] = ' ';
        strcat(cmd, lpsoc->tag_ipConfig->tag_ip);
        cmd[strlen(cmd)] = ' ';
        
        strcat(cmd, step->tag_sendCommand);
        cmd[strlen(cmd)] = ' ';
        strcat(cmd, g_sConfig->tag_SysIni.tag_ArmDir);
        cmd[strlen(cmd)] = '/';
        strcat(cmd, step->tag_sendCommand);
        
        AddLog(cmd);
        //system(cmd);
        extern void systemTest(char *array);
        systemTest(cmd);
        /*
         等待执行脚本
         */
        Wait(step->tag_SleepDate);
        
        /*   sprintf(fileName,"%s/%s/%s%s",g_sConfig->tag_SysIni.tag_logDir,GetCurrentDataCtr(),sn,g_sConfig->tag_SysIni.tag_LogFileName);
         
         replaceStr(logCmdfilePathZip,fileName,GetCurrentTimeCtrA());*/
        
        
        /*  sprintf(fileName,"%s/%s/%s_%s_%s",g_sConfig->tag_SysIni.tag_ArmDir,GetCurrentDataCtr(),
         gloabe_sn[dls->tag_station->tag_snIndex-1],
         g_sConfig->tag_SysIni.tag_ArmFileName,
         dls->tag_station->tag_StartTime);*/
        
        sprintf(fileName,"%s/%s/%s%s",g_sConfig->tag_SysIni.tag_ArmDir,GetCurrentDataCtr(),
                gloabe_sn[dls->tag_station->tag_snIndex],
                g_sConfig->tag_SysIni.tag_ArmFileName);
        
        memset( dls->tag_station->tag_ArmFile,0,sizeof(dls->tag_station->tag_ArmFile));
        char time[128] = {0};
        memset(time,0,128);
        sprintf(time,"%s_%s",dls->tag_station->tag_Name,dls->tag_station->tag_StartTime);
        replaceStr(dls->tag_station->tag_ArmFile,fileName,time);
        memset( fileName,0,sizeof(fileName));
        strcat( fileName,dls->tag_station->tag_ArmFile);
        
        
        // 文件拷贝
        // fileName 是新文件文件名， oldFile是从文件拷贝出来的文件名，需要封工配合写此文件
        memset(oldFile, 0, sizeof(oldFile));
        strcat(oldFile, g_sConfig->tag_SysIni.tag_ArmDir);
        oldFile[strlen(oldFile)] = '/';
        strcat(oldFile, step->tag_sendCommand);
        rename(oldFile, fileName);
        //   FilecopyDel(fileName,oldFile);
        // FilecopyDel(fileName,"/Users/strong/Desktop/DFU_Log_Data/fwdl1.log");
        
        
    }
    if (strstr(step->tag_sendCommand,"ch")) {
        strcat(cmd, g_sConfig->tag_SysIni.tag_scriptDir);
        cmd[strlen(cmd)] = '/';
        strcat(cmd, "scpsend.sh");
        cmd[strlen(cmd)] = ' ';
        strcat(cmd, lpsoc->tag_ipConfig->tag_ip);
        cmd[strlen(cmd)] = ' ';
        strcat(cmd, g_sConfig->tag_SysIni.tag_customerBinDir);
        cmd[strlen(cmd)] = '/';
        strcat(cmd, step->tag_sendCommand);
        systemTest(cmd);
    }
    free(cmd);
    return ret ;
}


/*******************************************************************************************
 **函数名：ScriptStepExe
 **参数：,void *p。数据指针
 **功能：脚本执行
 **返回值：< 0失败
 *******************************************************************************************/
int FileMoveStepExe(void *p)
{
   extern  void systemTest(char *array);
    int ret = 0;
    char *cmd = malloc(1024);
    char oldFile[512] = {0};
    char *array[3] = {0};
    LpStep step = (LpStep)p;
    cSocket lpsoc = GetSocket(p);
    lpStationRun   dls = (lpStationRun)step->tag_user;
    char fileName[512] = {0};
    memset(fileName,0,512);
    memset(oldFile,0,512);
    memset(cmd,0,1024);
    array[0] =step->tag_sendCommand;
   // system(step->tag_sendCommand);
    systemTest(step->tag_sendCommand);
    SleepWait(dls->tag_station, step->tag_SleepDate);
    free(cmd);
    return ret ;
}


/*******************************************************************************************
 **函数名：PortStepExe
 **参数：,void *p。数据指针
 **功能： 通过串口发送指令
 **返回值：< 0失败
 *******************************************************************************************/
int PortStepExe(void *p)
{
    int ret = 0;
    LpStep step = (LpStep)p;
    lpStationRun   dls = (lpStationRun)step->tag_user;
    char *Read  =  PortSendData(&dls->tag_portValueManage->tag_PortValue[step->tag_port_index], step->tag_sendCommand, step->tag_SleepDate);
    memset(step->tag_Result,0,sizeof(step->tag_Result));
    strcat(step->tag_Result,Read);
    return 0 ;
}

/**
 <#Description#>
 */
void SFC_GetSN(void *p){
    extern const char * GetMainViewSN();
    const char * mainViewSN = GetMainViewSN();
    extern char* GetSfcSn(const char *sn,void *p);
    GetSfcSn(mainViewSN,p);
}

/*******************************************************************************************
 **函数名：StepExe
 **参数：,void *p。数据指针
 **功能： 单步执行的指令
 **返回值：< 0失败
 *******************************************************************************************/
int StepExe(void *p)
{
    int ret = 0;
    LpStep step = (LpStep)p;
    memset(step->tag_Result,0,sizeof(MAXRESULT));
    lpStationRun   dls = (lpStationRun)step->tag_user;
    stationManage lp_stationManage = (stationManage)dls->tag_station->tag_user;
    long long tmBegin = getSystemTime();
    long long tmEnd = tmBegin;
    dls->tag_station->tag_stepCurr = step;
    
    lp_stationManage->tag_CurrStep = step;
    lp_stationManage->tag_currStation = dls->tag_station;
    switch (step->tag_type)
    {
        case enum_commandType_PORT:
            ret = PortStepExe(p);
            tmEnd = getSystemTime();
            SleepWait(dls->tag_station ,step->tag_SleepDate - (tmEnd -tmBegin));
            break;
        case enum_commandType_SCRIPT:
            ret = ScriptStepExe(p);
         
             tmEnd = getSystemTime();
             SleepWait(dls->tag_station ,step->tag_SleepDate - (tmEnd -tmBegin));
            break;
        case enum_commandType_SOCKET:
            ret = SocketStepExe(p);
            tmEnd = getSystemTime();
            if(strlen(step->tag_Result) == 0)
            {
               SleepWait(dls->tag_station ,step->tag_SleepDate - (tmEnd -tmBegin));
            }
            break;
        case enum_commandType_SOCKET_READIO_1:
            ret = IOSocketReadIo(p,'1');
            break;
        case enum_commandType_SOCKET_READIO_0:
            ret = IOSocketReadIo(p,'0');
            break;
        case enum_commandType_SOCKET_SETIO:
            ret = IOSocketSetIo(p);
            tmEnd = getSystemTime();
            SleepWait(dls->tag_station ,step->tag_SleepDate - (tmEnd -tmBegin));
            SleepWait(dls->tag_station ,step->tag_SleepDate);
            break;
        case enum_commandType_waitBeforeFinish:
           waitFinish(dls->tag_station,0,dls->tag_station->tag_Index-1);
           tmEnd = getSystemTime();
           SleepWait(dls->tag_station ,step->tag_SleepDate - (tmEnd -tmBegin));
           break;
        case enum_commandType_socketRead:
            ret = SocketRead(p);
            tmEnd = getSystemTime();
            SleepWait(dls->tag_station ,step->tag_SleepDate - (tmEnd -tmBegin));
            break;
        case enum_commandType_socketCelan:
            SocketReadClean(p);
            break;
        case enum_commandType_SnWrite:
            ret = SocketStepSnWrite(p);
            tmEnd = getSystemTime();
            SleepWait(dls->tag_station ,step->tag_SleepDate - (tmEnd -tmBegin));
            break;
        case enum_commandType_SnRead:
           ret = ReadSnStepExe(p);
            tmEnd = getSystemTime();
            break;
        case enum_commandType_SFC_SN:
            SFC_GetSN(p);
            tmEnd = getSystemTime();
            SleepWait(dls->tag_station ,step->tag_SleepDate - (tmEnd -tmBegin));
            break;
        case enum_commandType_delay:
            SleepWait(dls->tag_station ,step->tag_SleepDate );
            break;
        case enum_commandType_fileMove:
            ret = FileMoveStepExe(p);
            break;
        case enum_commandType_AlgorithmRead:
            AlgorithmReadStepExe(p);
            break;
        case enum_commandType_SocketTemp:
            ret = SocketStepExe(p);
            tmEnd = getSystemTime();
            if(strlen(step->tag_Result) == 0)
                SleepWait(dls->tag_station ,step->tag_SleepDate - (tmEnd -tmBegin));
            break;
        default:
            break;
    }
   if( step->tag_pdca_index >0)
   {

       pdcaValueSet2(&step->tag_pdcaValue, step->tag_Result);
    
   }
   return ret ;
}


/*******************************************************************************************
 **函数名：StationInit
 **参数：,(lpStation station,  初始化一个工位
 ipConfig soc)
 **功能： 单步执行的指令
 **返回值：< 0失败
 *******************************************************************************************/
int StationInit(stationManage lpstationManage, lpStationRun lps, lpStation station,ipBag ip,pdcaValueManage lppdca,portValueManage port)
{
    int ret = 0;
    int i = 0;
    lps->tag_pdcaValueManage = lppdca;
    lps->tag_portValueManage = port;
    lps->tag_station = station;
    station->tag_user = lpstationManage;
    //lps->tag_cSocket.tag_ipConfig =  soc;
    station->tag_WorkState = 0;
    extern   sConfig  g_sConfig;
    while( i < lps->tag_station->tag_totalCount )
    {
        
        lps->tag_station->tag_step[i].tag_Exe  = StepExe;
        lps->tag_station->tag_step[i].tag_user = lps;
        if(lps->tag_station->tag_step[i].tag_pdca_index > 0 &&  lps->tag_station->tag_step[i].tag_pdca_index <= lppdca->tag_totalCount )
           {
               memcpy(&lps->tag_station->tag_step[i].tag_pdcaValue, &lppdca->tag_PdcaValue[lps->tag_station->tag_step[i].tag_pdca_index-1], sizeof(PdcaValue));
               memset(lps->tag_station->tag_step[i].tag_pdcaValue.tag_Value, 0, sizeof(lps->tag_station->tag_step[i].tag_pdcaValue.tag_Value));
           }
        i++;
    }
    
    
    i = 0;
    while(i < IPCOUNT)
    {
        lps->tag_cSocket[i].tag_ipConfig = &ip->tag_ipConfig[i];
        i++;
    }
    
    
    return ret ;
}


int RestWork(stationManage lpstationManag)
{
    int ret = 0;
    if(lpstationManag->tag_WorkStop == 1)
    {
        return enum_workState_stopting;
    }
    if(lpstationManag->tag_WorkState != 0)
    {
        return enum_workState_working;
    }
    
    lpstationManag->tag_RestState = 1;
    
    ret = stationManageExe(lpstationManag, enum_station_type_rest);
    
    if(ret == 0 && lpstationManag->tag_WorkStop == 0)
    {
        lpstationManag->tag_RestState = 2;
        lpstationManag->tag_WorkStop = 0;
    }
    else
    {
        lpstationManag->tag_RestState  = 0;
    }
    return enum_workState_resting;
}

int StopWork(stationManage lpstationManag,int type)
{
    int ret = 0;
    
    int i = 0;
    int j = 0;
    lpstationManag->tag_WorkStop = 1;
    g_sConfig->tag_stationManage.tag_RestState = 0;
    g_sConfig->tag_stationManage.tag_WorkState = 0;
    Wait(2000);
    return 0;
    while(j < g_sConfig->tag_stationManage.tag_totalCount)
    {
        lpStation lstat = &g_sConfig->tag_stationManage.tag_Station[j];
        while(i < lstat->tag_totalCount && type == lstat->tag_stationType)
        {
            cSocket soc = GetSocket(&lstat->tag_step[i]);
            if(soc->sockectClose)
            {
                soc->sockectClose(soc);
            }
            i++;
        }
        lstat->tag_WorkState = 0;
        j++;
    }
   
    
    lpstationManag->tag_WorkStop = 0;
    ret = stationManageExe(lpstationManag, enum_station_type_stop);
    g_sConfig->tag_stationManage.tag_RestState = 0;
    if(ret == 0)
    {
        lpstationManag->tag_WorkStop = 2;
    }
    else
    {
        lpstationManag->tag_WorkStop = 1;
    }
    return 0;
}


int workWork(stationManage lpstationManag)
{
    int ret = 0;
    int count = 0;
    if(lpstationManag->tag_RestState == 1)
    {
        return enum_workState_resting;
    }
    if(lpstationManag->tag_RestState == 0)
    {
        return enum_workState_notRest;
    }
    if(lpstationManag->tag_WorkStop == 1)
    {
        return enum_workState_stopting;
    }
    if(lpstationManag->tag_WorkState == 1)
    {
        return enum_workState_working;
    }
    lpstationManag->tag_WorkState = 1;
    
    while(1)
    {
        if(stationManageExe(lpstationManag,enum_station_type_work) == 0)
        {
            if(count >= g_sConfig->tag_SysIni.tag_IsLoopTest)
            {
               // lpstationManag->tag_WorkState = 0;
               // break;
            }
        }
        count++;
        if(g_sConfig->tag_stationManage.tag_WorkStop == 1)
        {
                break;
        }
    }
    return enum_workState_work;
    
}
