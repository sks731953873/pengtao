//
//  PopUp_SubView.h
//  strongTest
//
//  Created by 客人用户 on 2018/3/9.
//  Copyright © 2018年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "step.h"
#include "Config.h"
@interface SRStepSettingView : NSView

@property(nonatomic,assign)LpStep tag_step;
@property(nonatomic,assign)pdcaValueManage tag_pdcaValueManage;
@property(nonatomic,assign)cSocket tag_socket;

@property(nonatomic,copy)NSMutableDictionary *(^getComboxItemStrArr)();

@end
