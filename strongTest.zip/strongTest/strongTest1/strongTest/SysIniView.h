//
//  SysIniView.h
//  strongTest
//
//  Created by strong on 2018/1/20.
//  Copyright © 2018年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface SysIniView : NSView
{
}
@property (weak) IBOutlet NSTextField *tag_UiSnLength;
@property (weak) IBOutlet NSComboBox *tag_UISFCGET;
@property (weak) IBOutlet NSTextField *tag_UilogFileName;
@property (weak) IBOutlet NSTextField *tag_UiCsvFileName;
@property (weak) IBOutlet NSTextField *tag_UiCsvPath;
@property (weak) IBOutlet NSTextField *tag_UIlogFilePath;
@property (weak) IBOutlet NSTextField *tag_UiSfc;
@property (weak) IBOutlet NSTextField *tag_UISubStation;
@property (weak) IBOutlet NSTextField *tag_UimitsVersion;
@property (weak) IBOutlet NSTextField *tag_UiCustomerBinPath;
@property (weak) IBOutlet NSTextField *tag_UiSoftwareVersion;
@property (weak) IBOutlet NSTextField *tag_UIStation_Id;
@property (weak) IBOutlet NSTextField *tag_UiScriptFilePath;
@property (weak) IBOutlet NSTextField *tag_UISoftwareName;
@property (weak) IBOutlet NSTextField *tag_ArmFileName;
@property (weak) IBOutlet NSTextField *tag_armPath;
@property (weak) IBOutlet NSTextField *tag_DutFileName;
@property (weak) IBOutlet NSTextField *tag_dutFilePath;
@property (weak) IBOutlet NSTextField *tag_UISfc2;



/*******************************************************************************************
 **函数名：initWithFrame
 **参数：:(CGRect)frame
 **功能：初始化 大小
 **返回值：
 *******************************************************************************************/
+ (instancetype)loadSysIniViewNib;
- (IBAction)SaveButtonAction:(id)sender;
@end
