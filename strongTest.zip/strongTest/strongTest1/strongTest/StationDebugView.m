//
//  StationDebugView.m
//  strongTest
//
//  Created by strong on 2017/12/16.
//  Copyright © 2017年 strong. All rights reserved.
//

#import "StationDebugView.h"

#import "StepView.h"
#import "Config.h"
#include "PDCA.h"
#import "pdcaView.h"
#import "IPValueView.h"
#import "stationView.h"
#import "portView.h"

#import "SysIniView.h"
#import "SRIOItemView.h"
#import "mainStationView.h"

@interface StationDebugView()<NSTableViewDelegate,NSTableViewDataSource,NSTabViewDelegate,SRIOItemViewDelegate>
{
    Station *tag_Station;//当前工位
    Station *tag_StationCopy;//用于拷贝工位备份
    SConfig *tag_SConfig;//整个工程的配置
    CSocket tag_csoc[IPCOUNT];//当前所有的socket
 
    NSMutableArray *tag_UIIPArray;//用于管理IP
    NSMutableArray *tag_UIStepArray;//用于管理步骤
    NSMutableArray *tag_UIStationArray;//用于管理工位
    NSMutableArray *tag_UIPdcaArray;//用于pdca管理
    NSMutableArray *tag_UIPPortArray;//用于pdca管理
    NSMutableArray *tag_UIPageArray;//用于pdca管理
    NSMutableArray *tag_UIIOReadArray;//用于pdca管理
    
    NSMutableArray *tag_UIStationArrayList;//用于管理工位
    
    
    Step tag_UICopyStepArray[20];//用于pdca管理
    int tag_UICopyStepCount;
    int tag_UITotaolStep;
    int tag_UiPageCount;
    int tag_UiPageIndex;
    int tag_UiPageStepCount;
    int tag_upSelectRow;
    int tag_uistepTableCount;
    NSThread *tag_myThread;
    SysIniView *tag_SysIniView;
    
   
}
@property (weak) IBOutlet NSTableView *tag_UIStationTableList;
@property (weak) IBOutlet NSTokenField *tag_uiNameDelayText;
@property (weak) IBOutlet NSButton *tag_UiMutIoSend;
@property (weak) IBOutlet NSTextField *tag_UIIOShowInitCommand;
@property (weak) IBOutlet NSTextField *tag_UiIoReadCommand;

@property (weak) IBOutlet NSView *tag_UiDebugStationView;
@property (weak) IBOutlet NSComboBox *tag_uiComandType;
@property (weak) IBOutlet NSScrollView *tag_UILogView;
@property (unsafe_unretained) IBOutlet NSTextView *tag_UIIOShowLogVIew;
@property (weak) IBOutlet NSView *tag_UiTestVew;
@property (unsafe_unretained) IBOutlet NSTextView *tag_UiTextView;
@property (weak) IBOutlet NSScrollView *tag_UITablePdcaView;
@property (weak) IBOutlet NSScrollView *tag_uiTablePort;
@property (weak) IBOutlet NSMenu *tag_MenuUI;
@property (weak) IBOutlet NSScrollView *tag_uiTableView;//步骤列表
@property (weak) IBOutlet NSScrollView *tag_uiTableStationView;//工位列表
@property (weak) IBOutlet NSScrollView *tag_UITableIPView;//ip列表
@property (weak) IBOutlet NSView *tag_UIPageView;
@property (weak) IBOutlet NSView *tag_UIIOContainerView;

@property (weak) IBOutlet NSComboBox *tag_UiStepCommandType;
@property (weak) IBOutlet NSTokenField *tag_UiDelayText;
@property (weak) IBOutlet NSButton *tag_UIEndCharCheck;


@end
@implementation StationDebugView
/*******************************************************************************************
 **函数名：initWithFrame
 **参数：:(CGRect)frame
 **功能：初始化 大小
 **返回值：
 *******************************************************************************************/
- (instancetype)initWithFrame:(CGRect)frame
{
    
    NSArray *arr = [NSArray array];

    [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([StationDebugView class]) owner:nil topLevelObjects:&arr];
    
    for(int i = 0;i < arr.count;i++)
     {
        if([arr[i] isKindOfClass:[self class]])
        {
            StationDebugView *stationDebugView = arr[i];
            CGRect frame1 = {frame.origin.x,frame.origin.y,stationDebugView.frame.size.width,stationDebugView.frame.size.height};

            stationDebugView.frame = frame1;
            
           // CALayer *viewLayer = [CALayer layer];
           // [viewLayer setBackgroundColor:CGColorCreateGenericRGB(0.8, 0.8, 0.8, 0.4)];
           // [stationDebugView setWantsLayer:YES];
           // [stationDebugView setLayer:viewLayer];
            self = stationDebugView;
            tag_UIIPArray =[[NSMutableArray alloc] init];
            tag_UIStepArray =[[NSMutableArray alloc] init];
            tag_UIStationArray =[[NSMutableArray alloc] init];
            tag_UIPdcaArray  = [[NSMutableArray alloc] init];
            tag_UIPPortArray  = [[NSMutableArray alloc] init];
            tag_UIPageArray  = [[NSMutableArray alloc] init];
           tag_UIStationArrayList = [[NSMutableArray alloc] init];
            
            memset(tag_UICopyStepArray,0,sizeof(tag_UICopyStepArray));
            
            tag_SConfig = g_sConfig;
            tag_Station = &tag_SConfig->tag_stationManage.tag_Station[0];
             [self IPListUpdate];
       
            tag_UiPageStepCount = 18;
            
            [self addIOShow];
            [self PdcaListUpdate];
            [self IPPortUpdate];
            [self StepUpdate2 ];
            [self StepUpdate];
            [self StationUpdate];
          
            tag_SysIniView = [SysIniView loadSysIniViewNib];
            
            tag_SysIniView.frame = NSMakeRect(250, 0, tag_SysIniView.sr_width, tag_SysIniView.sr_height);
            [self.tag_UiDebugStationView addSubview:tag_SysIniView];
            
            NSTableView *ns =   [self.tag_UITableIPView.contentView documentView];
            ns.dataSource = self;
             ns.delegate = self;
            ns = [self.tag_uiTableStationView.contentView documentView];
            ns.dataSource = self;
             ns.delegate = self;
            ns =  [self.tag_uiTableView.contentView documentView];
            ns.dataSource = self;
            ns.delegate = self;
            
            ns =  [self.tag_UITablePdcaView.contentView documentView];
            ns.dataSource = self;
            ns.delegate = self;
            
            ns =  [self.tag_uiTablePort.contentView documentView];
            ns.dataSource = self;
            ns.delegate = self;
            self.tag_UIStationTableList.dataSource = self;
            self.tag_UIStationTableList.delegate = self;
            NSTableView *table = [self.tag_uiTableView.contentView documentView];
            [table setRowHeight:25];
            break;
        }
     }
    NSTimer *timer;
    timer = [NSTimer scheduledTimerWithTimeInterval: 1
                                             target: self
                                           selector: @selector(StationhandleTimer:)
                                           userInfo: nil
                                            repeats: YES];
    [self StopStartButton];

    [self TextInit];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(StepUpdate) name:StepUpdateNotifcation object:nil];
    return self;
  
}

/**
 析构函数
 */
- (void)dealloc{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:StepUpdateNotifcation object:nil];
}

-(void)TextInit
{self.tag_UiIoReadCommand.stringValue = [[NSString alloc] initWithUTF8String:g_sConfig->tag_SysIni.tag_IoShowInputCommand];
   self.tag_UIIOShowInitCommand.stringValue = [[NSString alloc] initWithUTF8String:g_sConfig->tag_SysIni.tag_IoShowInputInitCommand];
  
}
- (void)addIOShow{
   
    if(tag_UIIOReadArray == nil)
        tag_UIIOReadArray = [[NSMutableArray alloc] init];
    [tag_UIIOReadArray removeAllObjects];
    //每行列数
    NSInteger rank = 15;
    //行间距
    NSInteger rowMargin = 15;
    for (int i = 0; i < 200; i ++) {
        NSNib *nib = [[NSNib alloc]initWithNibNamed:NSStringFromClass([SRIOItemView class]) bundle:nil];
        NSArray *arr;
        [nib instantiateWithOwner:nil topLevelObjects:&arr];
        for (NSObject *obj in arr) {
            if ([obj isKindOfClass:[SRIOItemView class]]) {
                SRIOItemView *ioItemView = (SRIOItemView *)obj;
                [tag_UIIOReadArray addObject:ioItemView];
                ioItemView.delegate = self;
                ioItemView.Num = i;
                ioItemView.active = NO;
                CGFloat W = ioItemView.frame.size.width;
                CGFloat H = ioItemView.frame.size.height;
                //每列间距
                CGFloat rankMargin = (self.tag_UIIOContainerView.frame.size.width - rank *W) / (rank - 1);
                //Item X轴
                CGFloat X = (i % rank) * (W + rankMargin);
                //Item Y轴
                NSUInteger Y = (i / rank) * (H +rowMargin) + 15;
                ioItemView.frame = NSMakeRect(X, Y, W, H);
               [self.tag_UIIOContainerView addSubview:ioItemView];
                
              
            }
        }
    };
}
- (IBAction)StepMomandDelayNameSetAction:(id)sender
{
    int type =  self.tag_UiStepCommandType.indexOfSelectedItem;
    int j = 0;
    while(j < g_sConfig->tag_stationManage.tag_totalCount)
    {
        int n = 0;
        while(n < g_sConfig->tag_stationManage.tag_Station[j].tag_totalCount)
        {
            

          if(strstr(g_sConfig->tag_stationManage.tag_Station[j].tag_step[n].tag_stepName,[_tag_uiNameDelayText.stringValue UTF8String]) && _tag_uiNameDelayText.stringValue.length >0)
          {
              g_sConfig->tag_stationManage.tag_Station[j].tag_step[n].tag_SleepDate  = atoi([self.tag_UiDelayText.stringValue UTF8String]);
          }
            
            n++;
        }
        j++;
    }

}
- (IBAction)stepCommandDelaySetAction:(id)sender {
    int type =  self.tag_UiStepCommandType.indexOfSelectedItem;
    int j = 0;
    while(j < g_sConfig->tag_stationManage.tag_totalCount)
    {
        int n = 0;
        while(n < g_sConfig->tag_stationManage.tag_Station[j].tag_totalCount)
        {
            if(g_sConfig->tag_stationManage.tag_Station[j].tag_step[n].tag_type == type)
            {
                if(self.tag_UIEndCharCheck.state == 1)
                {
                    int endLend = strlen(g_sConfig->tag_stationManage.tag_Station[j].tag_step[n].tag_ReadEndFlage);
                    if(g_sConfig->tag_stationManage.tag_Station[j].tag_step[n].tag_readEnterKey !=0 || endLend >0)
                    {
                        g_sConfig->tag_stationManage.tag_Station[j].tag_step[n].tag_SleepDate  = atoi([self.tag_UiDelayText.stringValue UTF8String]);
                    }
                }
                else
                {
                    int endLend = strlen(g_sConfig->tag_stationManage.tag_Station[j].tag_step[n].tag_ReadEndFlage);
                    if(g_sConfig->tag_stationManage.tag_Station[j].tag_step[n].tag_readEnterKey ==0 && endLend ==0)
                    {
                        g_sConfig->tag_stationManage.tag_Station[j].tag_step[n].tag_SleepDate  = atoi([self.tag_UiDelayText.stringValue UTF8String]);
                    }
                }
            }
            n++;
        }
        j++;
    }
    
}

- (void)SRIOItemViewUpdate
{
    
}

- (IBAction)logShowButtonAction:(id)sender
{
    NSButton *button = sender;
    if(button.state)
    {
        CGRect frame = {self.tag_uiTableView.frame.origin.x,
        self.tag_uiTableView.frame.origin.y,
        self.tag_uiTableView.frame.size.width +260,
        self.tag_uiTableView.frame.size.height
        };
        
        CGRect frame2 = {self.tag_UILogView.frame.origin.x+260,
            self.tag_UILogView.frame.origin.y,
            self.tag_UILogView.frame.size.width ,
            self.tag_UILogView.frame.size.height
        };
        
        self.tag_uiTableView.frame = frame;
        self.tag_UILogView.frame = frame2;
    }
    else
    {
        CGRect frame = {self.tag_uiTableView.frame.origin.x,
            self.tag_uiTableView.frame.origin.y,
            self.tag_uiTableView.frame.size.width -260,
            self.tag_uiTableView.frame.size.height};
        CGRect frame2 = {self.tag_UILogView.frame.origin.x-260,
            self.tag_UILogView.frame.origin.y,
            self.tag_UILogView.frame.size.width ,
            self.tag_UILogView.frame.size.height
        };
        self.tag_uiTableView.frame = frame;
 
          self.tag_UILogView.frame = frame2;
    }
}
- (IBAction)PdcaMenuDel:(id)sender {
    NSTableView *table =      [self.tag_UITablePdcaView.contentView documentView];
    if(table.selectedRow >=0)
    {
        pdcaDelete(&tag_SConfig->tag_pdcaValueManage, table.selectedRow);
    }
    
    [table reloadData];
    
   [self StepUpdate];
  }
- (IBAction)PdcaMenuAdd:(id)sender {
    
    NSTableView *table =      [self.tag_UITablePdcaView.contentView documentView];
    PdcaValue pdca = {0};
    pdcaInster(&tag_SConfig->tag_pdcaValueManage, table.selectedRow+1,&pdca);
    [self PdcaListUpdate ];
    [table reloadData];
    
    [self StepUpdate];
}
- (IBAction)PdcaMenuSage:(id)sender
{
    for(int i = 0;i < tag_UIPdcaArray.count;i++)
    {
        pdcaView *view =    tag_UIPdcaArray[i];
        [view GetParameter ];
    }
    Save();
    
    [self StepUpdate];
}
- (IBAction)MenuStepCleanAction:(id)sender {
    tag_UICopyStepCount = 0;
}
- (IBAction)MenuStepSaveAllAction:(id)sender
{
    for(int i = 0;i < tag_UIStepArray.count &&  i< tag_uistepTableCount;i++)
    {
        StepView *stepv =    tag_UIStepArray[i];
        [stepv GetParameter ];
    }
    Save();
}
/*******************************************************************************************
 **函数名：StationDelMenuAction
 **参数：(id)sender
 **功能：菜单相应事件，删除菜单。
 **返回值：
 *******************************************************************************************/
- (IBAction)StationDelMenuAction:(id)sender
{
 
    NSTableView *table =      [self.tag_uiTableStationView.contentView documentView];
    if(table.selectedRow >=0)
    {
    stationDelete(&tag_SConfig->tag_stationManage, table.selectedRow);
    }
    [table reloadData];
    [self StationSelectMenuAction:sender ];
}
/*******************************************************************************************
**函数名：StationSelectMenuAction
**参数：(id)sender
**功能：菜单相应事件，选择。
**返回值：
 *******************************************************************************************/
- (IBAction)StationSelectMenuAction:(id)sender
{
   
    NSTableView *tableView =   [self.tag_uiTableView.contentView documentView];
    
    [self StepUpdate];
    [self.tag_UIStationTableList reloadData ];
    [tableView reloadData];
}
/*******************************************************************************************
 **函数名：StationDelMenuAction
 **参数：(id)sender
 **功能：工位菜单相应事件，添加菜单。
 **返回值：
 *******************************************************************************************/
- (IBAction)StationAddMenuAction:(id)sender
{
   extern void  workInit(void *p);
    NSTableView *table =      [self.tag_uiTableStationView.contentView documentView];

    stationInster(&tag_SConfig->tag_stationManage, table.selectedRow+1);
     workInit(0);
    [self StepUpdate];
    [table reloadData];
    [self StationSelectMenuAction:sender ];
}



- (IBAction)StationSaveMenuAction:(id)sender
{
    
    for(int i = 0;i < tag_UIStationArray.count;i++)
    {
        stationView *view =    tag_UIStationArray[i];
        [view GetParameter ];
    }
    Save();

}



/*******************************************************************************************
 **函数名：MenuPasteAction
 **参数：(id)sender
 **功能：粘贴
 **返回值：
 *******************************************************************************************/
- (IBAction)MenuCopyAction:(id)sender
{
    NSTableView *table =      [self.tag_uiTableView.contentView documentView];
    Step step = {0};
    
    lpStation lps = &g_sConfig->tag_stationManage.tag_Station[ [self GetStationIndex: table.selectedRow]];
   // tag_
    int index = [self GetStationStepIndex :table.selectedRow];
   
   LpStep   tag_CopyStep =  &lps->tag_step[index ];
    int i = 0;
   if(tag_UICopyStepCount <20)
   {
    memcpy(&tag_UICopyStepArray[tag_UICopyStepCount],&lps->tag_step[index ],sizeof(Step));
       tag_UICopyStepCount++;
   }
  else
  {
    memset(&tag_UICopyStepArray[0],0,sizeof(Step));
    tag_UICopyStepCount = 0;
  }
}


/*******************************************************************************************
 **函数名：MenuPasteAction
 **参数：(id)sender
 **功能：粘贴
 **返回值：
 *******************************************************************************************/
- (IBAction)MenuPasteAction:(id)sender
{
    NSTableView *table =      [self.tag_uiTableView.contentView documentView];
    if(table.selectedRow == -1)
    {
        return ;
    }
    NSTableView *tableView =   [self.tag_uiTableView.contentView documentView];
    lpStation lps = &g_sConfig->tag_stationManage.tag_Station[ [self GetStationIndex: table.selectedRow]];
    lps->tag_user = &g_sConfig->tag_stationManage;
    // tag_

    NSString *  str;
    
    if(tag_UICopyStepCount>0)
    {
        str = [[NSString alloc] initWithFormat:@"确定粘贴"];
    }
    else
    {
        return ;
    }
    
    NSAlert *alert = [NSAlert new];
    [alert addButtonWithTitle:@"确定"];
    [alert addButtonWithTitle:@"取消"];
    [alert setMessageText:str];
    
    int i = 0;
    int row = [ self GetStationStepIndex :table.selectedRow ];
    while(i <20&&  i < tag_UICopyStepCount)
    {
        LpStep step = &tag_UICopyStepArray[i];
        stepInster(lps, row+i,step);
        i++;
    }
    [self StepUpdate];
    [tableView reloadData];
}



/*******************************************************************************************
 **函数名：MenuDelAction
 **参数：(id)sender
 **功能：工位步骤相应事件，删除菜单。
 **返回值：
 *******************************************************************************************/
- (IBAction)MenuDelAction:(id)sender
{
    
    NSAlert *alert = [NSAlert new];
    [alert addButtonWithTitle:@"确定"];
    [alert addButtonWithTitle:@"取消"];
    [alert setMessageText:@"确定删除"];
   // [alert setInformativeText:@"如果确定保存，之前的文本不能再找回!"];
    
    
    NSTableView *table =      [self.tag_uiTableView.contentView documentView];
    Step step = {0};
    
    lpStation lps = &g_sConfig->tag_stationManage.tag_Station[ [self GetStationIndex: table.selectedRow]];
    int index = [self GetStationStepIndex :table.selectedRow];

    stepDelete(lps, index);
    
    NSTableView *tableView =   [self.tag_uiTableView.contentView documentView];
    [self StepUpdate];
    [tableView reloadData];


}
/*******************************************************************************************
 **函数名：MenuStationPasteAction
 **参数：:(id)sender
 **功能：工位列表中菜单的粘贴事件
 **返回值：
 *******************************************************************************************/
- (IBAction)MenuStationPasteAction:(id)sender
{
    NSTableView *table =      [self.tag_uiTableStationView.contentView documentView];
    if(table.selectedRow == -1)
    {
        return ;
    }
    NSTableView *tableView =   [self.tag_uiTableView.contentView documentView];
    lpStation  _Station = &tag_SConfig->tag_stationManage.tag_Station[table.selectedRow];
    NSString *  str;
    if(tag_StationCopy)
    {
     str = [[NSString alloc] initWithFormat:@"确定粘贴%s到%s",tag_StationCopy->tag_Name,_Station->tag_Name];
    }
    else
    {
        str = [[NSString alloc] initWithFormat:@"确定粘贴%s到%s","",_Station->tag_Name];
    }
    
    NSAlert *alert = [NSAlert new];
    [alert addButtonWithTitle:@"确定"];
    [alert addButtonWithTitle:@"取消"];
    [alert setMessageText:str];

    
    [alert beginSheetModalForWindow:[self window] completionHandler:^(NSModalResponse returnCode)
     {
         if(returnCode == NSAlertFirstButtonReturn)
         {
                 if(tag_StationCopy)
             {
                 int i = 0;
                 while(i < tag_StationCopy->tag_totalCount)
                 {
                     memcpy(&_Station->tag_step[_Station->tag_totalCount],&tag_StationCopy->tag_step[i],
                            sizeof(Step));
                     _Station->tag_totalCount ++;
                     i++;
                 }
             }
             [self StepUpdate];
             [tableView reloadData];
         }
         else if(returnCode == NSAlertSecondButtonReturn)
         {
             
         }
     }];
}


/*******************************************************************************************
 **函数名：MenuStationCopyAction
 **参数：:(id)sender
 **功能：工位列表中菜单的拷贝事件
 **返回值：
 *******************************************************************************************/
- (IBAction)MenuStationCopyAction:(id)sender {
    
    NSTableView *table =      [self.tag_uiTableStationView.contentView documentView];
    if(table.selectedRow == -1)
    {
        return ;
    }
    NSTableView *tableView =   [self.tag_uiTableView.contentView documentView];
    tag_StationCopy = &tag_SConfig->tag_stationManage.tag_Station[table.selectedRow];
}


-(int)GetUiStepTotal
{
    int n = 0;
    int i = 0;
    int j = 0;
    int f = 0;
  
    while(j < tag_Station->tag_totalCount)
    {
        n++;
        j++;
    }

    return n;
}



-(int)GetPageIndex
{

    int n = tag_Station->tag_totalCount;
    int i = 0;

    n = n/tag_UiPageStepCount;
    if(n != tag_UiPageIndex)
    {
        tag_UiPageIndex = n;
        [self StepUpdate];
        NSTableView *table =      [self.tag_uiTableView.contentView documentView];
        [table reloadData];
    }
    return i;
}

-(int)GetStationIndex:(NSInteger )row
{
   
    StepView *  stw = tag_UIStepArray[row];
    if(stw.tag_lpStation )
    {
        for(int i=0;i < g_sConfig->tag_stationManage.tag_totalCount;i++)
        {
            if(stw.tag_lpStation  == &g_sConfig->tag_stationManage.tag_Station[i])
            {
                return i;
            }
        }
    }
    else
         if(stw.tag_step )
         {
             for(int i=0;i < g_sConfig->tag_stationManage.tag_totalCount;i++)
             {
                 for(int j = 0; j < g_sConfig->tag_stationManage.tag_Station[i].tag_totalCount;j++)
                 {
                     if(stw.tag_step  == &g_sConfig->tag_stationManage.tag_Station[i].tag_step[j])
                     {
                         return i;
                     }
                 }
             }
         }
    return 0;
   
}

-(int)GetStationStepIndex:(NSInteger )row
{

    StepView *  stw = tag_UIStepArray[row];
    if(stw.tag_lpStation )
    {
        return 0;
    }
    else
        if(stw.tag_step )
        {
            for(int i=0;i < g_sConfig->tag_stationManage.tag_totalCount;i++)
            {
                for(int j = 0; j < g_sConfig->tag_stationManage.tag_Station[i].tag_totalCount;j++)
                {
                    if(stw.tag_step  == &g_sConfig->tag_stationManage.tag_Station[i].tag_step[j])
                    {
                        return j;
                    }
                }
            }
        }

    return 0;
}
/*******************************************************************************************
 **函数名：MenuAddActionß
 **参数：(id)sender
 **功能：工位步骤相应事件，添加菜单。
 **返回值：
 *******************************************************************************************/
- (IBAction)MenuAddAction:(id)sender
{
    extern void workInit(void *p);
    if(!tag_Station)
    {
        return ;
    }
    NSTableView *table = [self.tag_uiTableView.contentView documentView];
    Step step = {0};
    
    lpStation lps = &g_sConfig->tag_stationManage.tag_Station[ [self GetStationIndex: table.selectedRow]];
    
    stepInster(lps, [self GetStationStepIndex:table.selectedRow]+1,&step);
     workInit(0);
 
    NSTableView *tableView =   [self.tag_uiTableView.contentView documentView];
    [self StepUpdate];
    [tableView reloadData];
}
/*******************************************************************************************
 **函数名：PdcaListUpdate
 **参数：(id)sender
 **功能：pdca 列表管理，初始化，初始化20个ip列表，把配置初始化到对应的
 **返回值：
 *******************************************************************************************/
-(void) PdcaListUpdate
{
    [tag_UIPdcaArray removeAllObjects];
    for(int i = 0; i< tag_SConfig->tag_pdcaValueManage.tag_totalCount;i++)
    {
        
        pdcaView *pdca = [[pdcaView alloc] init];
        [pdca InitUI:i+1 PDCA:&tag_SConfig->tag_pdcaValueManage.tag_PdcaValue[i]];
        [tag_UIPdcaArray addObject:pdca];
        
    }
}
/*******************************************************************************************
 **函数名：IPListUpdate
 **参数：(id)sender
 **功能：IP 列表管理，初始化，初始化20个ip列表，把配置初始化到对应的
 **返回值：
 *******************************************************************************************/
-(void) IPListUpdate
{
    for(int i = 0; i< IPCOUNT;i++)
    {
   
        tag_csoc[i].tag_ipConfig = &tag_SConfig->tag_IpBag.tag_ipConfig[i];
        IPValueView *ipv = [[IPValueView alloc] init];
        [ipv InitUI:i+1 IP:&tag_csoc[i]];
        [tag_UIIPArray addObject:ipv];
    }
}

/*******************************************************************************************
 **函数名：IPListUpdate
 **参数：(id)sender
 **功能：IP 列表管理，初始化，初始化20个ip列表，把配置初始化到对应的
 **返回值：
 *******************************************************************************************/
-(void) IPPortUpdate
{
    for(int i = 0; i< IPCOUNT;i++)
    {

        portView  *view = [[portView alloc] init];
        [view InitUI:i+1 PORT:&tag_SConfig->tag_PortValueManage.tag_PortValue[i]];
        [tag_UIPPortArray addObject:view];

    }
}

/*******************************************************************************************
 **函数名：MenuPasteAction
 **参数：(id)sender
 **功能：粘贴
 **返回值：
 *******************************************************************************************/
- (IBAction)ButtonPageAction:(id)sender
{
    NSButton *butt = (NSButton *)sender;
    tag_UiPageIndex = butt.tag;

  
    NSTableView *table =      [self.tag_uiTableView.contentView documentView];
    [self StepUpdate];
    [table reloadData];
    
}
-(void) StepUpdate2
{
    for(int i =0 ;i< tag_UiPageStepCount;i++)
    {
        StepView *sview1 = [[StepView alloc] init] ;
        [sview1 InitUI2];
        [tag_UIStepArray addObject:sview1];
    }
    
    
    
    
}

-(int)StepInitPage
{
    int n = 0;
    int mm = tag_Station ->tag_totalCount;
    int index =  tag_UiPageIndex*tag_UiPageStepCount;
    
 
    if(mm%tag_UiPageStepCount==0)
    {
        tag_UiPageCount = mm/tag_UiPageStepCount;
    }
    else
    {
        tag_UiPageCount = mm/tag_UiPageStepCount+1;
    }
    
    int m = 0;
    int q = 0;
    
    while(q < tag_UIPageArray.count)
    {
        [tag_UIPageArray[q] removeFromSuperview ];
        q++;
    }
    
    [tag_UIPageArray removeAllObjects];
    for(m = 0;m <tag_UiPageCount;m++)
    {
       
        NSRect rect = {120+150+(m%40)*25,2+m/40*20,20,20};
        NSButton *page = [[NSButton alloc] initWithFrame:rect];
            [page setBezelStyle:NSBezelStyleSmallSquare];
        [page setTitle:[[NSString alloc] initWithFormat:@"%d",m]];
        page.tag = m;
        [page  setTarget:self];
        [page setAction:@selector(ButtonPageAction:)];
        if(  tag_UiPageIndex == m)
        {
            int fontSize = 13;
            NSFont *font = [NSFont systemFontOfSize:fontSize];
            NSDictionary * attrs = [NSDictionary dictionaryWithObjectsAndKeys:font,
                                    NSFontAttributeName,
                                    NSColor.greenColor,
                                    NSForegroundColorAttributeName,
                                    nil];
            
            NSAttributedString* attributedString = [[NSAttributedString alloc] initWithString:[page title] attributes:attrs];
      
            
            [page setAttributedTitle:attributedString];
         
        }
        [tag_UIPageArray addObject:page];
        
        [self.tag_UIPageView addSubview:page];
    }
    return 0;
}

/*******************************************************************************************
 **函数名：StepUpdate
 **参数：(id)sender
 **功能：
 **返回值：
 *******************************************************************************************/
-(void) StepUpdate
{
    int n = 0;
    int mm = 0;
    int qq = 0;
    int p = 0;
    int stationIndex = 0;
    int stepIndex = 0;
    int stepCount = 0;
    int stepindex2 = 0;
    int index =  tag_UiPageIndex*tag_UiPageStepCount;
    [self StepInitPage ];

    mm = 0;
    stepindex2 = 0;
    
    while(mm < tag_UIStepArray.count && index < tag_Station->tag_totalCount)
     {
        StepView *sview1 = tag_UIStepArray[mm];
        [sview1 InitUI:[[NSString alloc]initWithFormat:@"%d",index+1] STEP:&tag_Station->tag_step[index] PDCA:&tag_SConfig->tag_pdcaValueManage STATION:nil  SUPER: self COMMANDTYPE:self.tag_uiComandType.indexOfSelectedItem];
            mm++;
            index++;
     }
    
    tag_uistepTableCount = mm;
}
/*******************************************************************************************
 **函数名：stationManageExe
 **参数：::(id)sender
 **功能：工位停止
 **返回值：
 *******************************************************************************************/
-(void)stationManageExe:(NSObject*) o
{
    
    if(g_sConfig->tag_stationManage.tag_WorkState == 0)
    {
        g_sConfig->tag_stationManage.tag_WorkState = 1;
        g_sConfig->tag_stationManage.tag_WorkStop = 0;
        g_sConfig->tag_stationManage.tag_currStation = 0;
        stationManageExe(&g_sConfig->tag_stationManage,tag_Station->tag_stationType);
    }
    if(tag_myThread)
    {
        [tag_myThread cancel];
    }
}

/*******************************************************************************************
 **函数名：MenuPasteAction
 **参数：(id)sender
 **功能：粘贴
 **返回值：
 *******************************************************************************************/
- (IBAction)ButtonStopAction:(id)sender
{
    int i = 0;
    int j = 0;
    extern int StopWork(stationManage lpstationManag,int type);
    StopWork(&g_sConfig->tag_stationManage,tag_Station->tag_stationType);
    if(tag_myThread)
    {
        [tag_myThread cancel];
    }
}
/*******************************************************************************************
 **函数名：stationManageExe
 **参数：::(id)sender
 **功能：工位停止
 **返回值：
 *******************************************************************************************/
-(void)stationManageNextExe:(NSObject*) o
{
   /* if(g_sConfig->tag_stationManage.tag_WorkState == 0)
    {
        g_sConfig->tag_stationManage.tag_WorkState = 1;
        g_sConfig->tag_stationManage.tag_WorkStop = 0;
        stationExeStepNext( &g_sConfig->tag_stationManage,tag_Station->tag_stationType);
        g_sConfig->tag_stationManage.tag_WorkState = 0;
    }*/
    if(tag_myThread)
    {
        [tag_myThread cancel];
    }
}



/*******************************************************************************************
 **函数名：MenuPasteAction
 **参数：(id)sender
 **功能：粘贴
 **返回值：
 *******************************************************************************************/
- (IBAction)ButtonStartAction:(id)sender
{

   if(g_sConfig->tag_stationManage.tag_WorkState  == 0)
    {
      
        tag_myThread = [[NSThread alloc] initWithTarget:self
                                                          selector:@selector(stationManageExe:)
                                                            object:nil];
        [tag_myThread start];
    }
   else
   {
       NSAlert *alert = [NSAlert new];
       [alert addButtonWithTitle:@"确定"];
       [alert setMessageText:@"运行中，请等待"];
       
       
       [alert beginSheetModalForWindow:[self window] completionHandler:^(NSModalResponse returnCode)
        {
            if(returnCode == NSAlertFirstButtonReturn)
            {
                
                
                
            }
            else if(returnCode == NSAlertSecondButtonReturn)
            {
                
            }
        }];
   }
}


/*******************************************************************************************
 **函数名：MenuPasteAction
 **参数：(id)sender
 **功能：粘贴
 **返回值：
 *******************************************************************************************/
- (IBAction)ButtonNextAction:(id)sender
{
   
    
  
    if(g_sConfig->tag_stationManage.tag_WorkState  == 0)
    {
        tag_myThread = [[NSThread alloc] initWithTarget:self
                                                          selector:@selector(stationManageNextExe:)
                                                            object:nil];
        [tag_myThread start];
    }
    else
    {
        NSAlert *alert = [NSAlert new];
        [alert addButtonWithTitle:@"确定"];
        [alert setMessageText:@"运行中，请等待"];
        
        
        [alert beginSheetModalForWindow:[self window] completionHandler:^(NSModalResponse returnCode)
         {
             if(returnCode == NSAlertFirstButtonReturn)
             {
                 
                 
                 
             }
             else if(returnCode == NSAlertSecondButtonReturn)
             {
                 
             }
         }];
    }

   
}
- (IBAction)IOReadShowSave:(id)sender
{
    memset(g_sConfig->tag_SysIni.tag_IoShowInputCommand,0,sizeof(g_sConfig->tag_SysIni.tag_IoShowInputCommand));
     memset(g_sConfig->tag_SysIni.tag_IoShowInputInitCommand,0,sizeof(g_sConfig->tag_SysIni.tag_IoShowInputInitCommand));
    
    strcat(g_sConfig->tag_SysIni.tag_IoShowInputCommand,[self.tag_UiIoReadCommand.stringValue UTF8String]);
    
    strcat(g_sConfig->tag_SysIni.tag_IoShowInputInitCommand,[self.tag_UIIOShowInitCommand.stringValue UTF8String]);
    Save();
    
    
}
-(void) StopStartButton
{
    NSRect rect = {100+20,5,40,20};
    NSButton *start = [[NSButton alloc] initWithFrame:rect];
    
    [start setTitle:[[NSString alloc] initWithFormat:@"%s","start"]];
    [start  setTarget:self];
    [start setAction:@selector(ButtonStartAction:)];
    
    NSRect rect1 = {100+70,5,40,20};
    NSButton *stop = [[NSButton alloc] initWithFrame:rect1];
    
    [stop setTitle:[[NSString alloc] initWithFormat:@"%s","stop"]];
    [stop  setTarget:self];
    [stop setAction:@selector(ButtonStopAction:)];
    
    NSRect rect13 = {100+120,5,40,20};
    NSButton *next = [[NSButton alloc] initWithFrame:rect13];
    
    [next setTitle:[[NSString alloc] initWithFormat:@"%s","next"]];
    [next  setTarget:self];
    [next setAction:@selector(ButtonNextAction:)];
    [stop setBezelStyle:NSBezelStyleSmallSquare];
     [start setBezelStyle:NSBezelStyleSmallSquare];
     [next setBezelStyle:NSBezelStyleSmallSquare];
    [self.tag_UIPageView addSubview:stop];
    [self.tag_UIPageView addSubview:start];
    [self.tag_UIPageView addSubview:next];

}
/*******************************************************************************************
 **函数名：StationUpdate
 **参数：:
 **功能：工位刷新
 **返回值：
 *******************************************************************************************/
-(void) StationUpdate
{
    for(int i = 0; i< MAXSTATION;i++)
    {
        stationView *sview = [[stationView alloc] init];
        
        [sview InitUI:i+1 STATION:(&tag_SConfig->tag_stationManage.tag_Station[i])];
        [tag_UIStationArray addObject:sview];
        
      
        mainStationView *msview = [[mainStationView alloc] init];
        
        [msview InitUI:i STATION:(&tag_SConfig->tag_stationManage.tag_Station[i])];
        [tag_UIStationArrayList addObject:msview];
  
    }
}


-(void)selectStationDelegate:(lpStation) obj
{
    tag_Station = (lpStation)obj;
    [self StationSelectMenuAction:nil];

}
/*******************************************************************************************
 **函数名：numberOfRowsInTableView
 **参数：:
 **功能：设置列表的函数，ip列表，步骤列表，工位列表
 **返回值：
 *******************************************************************************************/
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView
{
    
    
    
    if(tableView == self.tag_UIStationTableList)
    {
        return tag_SConfig->tag_stationManage.tag_totalCount;//;
    }
    
    if(tableView == [self.tag_UITableIPView.contentView documentView])
    {
        return IPCOUNT;//;
    }
    if(tableView == [self.tag_uiTableStationView.contentView documentView])
    {
       
        return tag_SConfig->tag_stationManage.tag_totalCount;
    }
    if(tableView == [self.tag_uiTableView.contentView documentView])
    {
        return tag_uistepTableCount;
       int n =  [self GetUiStepTotal];
       if((tag_UiPageIndex+1) *tag_UiPageStepCount <=n)
       return   tag_UiPageStepCount;
        else
        {
            return (n %tag_UiPageStepCount);
        }
     
     
    
    }
    if(tableView == [self.tag_UITablePdcaView.contentView documentView])
    {
        return tag_SConfig->tag_pdcaValueManage.tag_totalCount;
    }
    if(tableView == [self.tag_uiTablePort.contentView documentView])
    {
        return 1;
    }
    
    return 0;
}
/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：初始化列表中的内容
 **返回值：
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    id retid = nil;
    if(tableView == [self.tag_UITableIPView.contentView documentView])
    {
        IPValueView *ipv = tag_UIIPArray[row];
     
        return  [ipv tableView:tableView viewForTableColumn:tableColumn row:row];
     
    }
    if(tableView == [self.tag_uiTableStationView.contentView documentView] && row < tag_SConfig->tag_stationManage.tag_totalCount)
    {
        stationView *ipv = tag_UIStationArray[row];

        [ipv UIUpdata:row+1 STATION:&tag_SConfig->tag_stationManage.tag_Station[row]];
        return  [ipv tableView:tableView viewForTableColumn:tableColumn row:row];
    }
    
    
    if(tableView == self.tag_UIStationTableList && row < tag_SConfig->tag_stationManage.tag_totalCount)
    {
        mainStationView *ipv = tag_UIStationArrayList[row];
        
        [ipv UIUpdata:row+1 STATION:tag_Station];
        ipv.tag_Delegate = self;
        return  [ipv tableView:tableView viewForTableColumn:tableColumn row:row];
    }
    
    
    
    
    
    
    if(tableView == [self.tag_uiTableView.contentView documentView] )
    {
        StepView *view = tag_UIStepArray[ row];
        return  [view tableView:tableView viewForTableColumn:tableColumn row: row];
    }
    if(tableView == [self.tag_UITablePdcaView.contentView documentView] )
    {
        pdcaView *view = tag_UIPdcaArray[row];
        [view  UIUpdata:row+1 PDCA:&tag_SConfig->tag_pdcaValueManage.tag_PdcaValue[row]];
        return  [view tableView:tableView viewForTableColumn:tableColumn row:row];
    }
    
    if(tableView == [self.tag_uiTablePort.contentView documentView])
    {
        portView *view = tag_UIPPortArray[row];
       
       //s [view  InitUI: :row+1 PORT:&tag_SConfig->tag_pdcaValueManage.tag_PdcaValue[row]];
        return  [view tableView:tableView viewForTableColumn:tableColumn row:row];
    }
    return retid;
}
/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：初始化列表中高度
 **返回值：
 *******************************************************************************************/
- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row
{
    if(tableView == [self.tag_uiTableView.contentView documentView])
    {
        return 25;
        
        
    }
    else
    {
        return 25;
    }
}
- (void)drawRect:(NSRect)dirtyRect
{
    [super drawRect:dirtyRect];
       
    // Drawing code here.
}

- (void) StationhandleTimer: (NSTimer *) timer
{
    extern char *g_textLog;
    [self updateIOShow];
    if(g_sConfig->tag_stationManage.tag_WorkState == 1)
    {
        
      
        tag_upSelectRow = index;
        [self UpdataPdca];
        
    }
    if(g_textLog)
    {
   self.tag_UiTextView.string = [[NSString alloc] initWithCString: g_textLog encoding:NSASCIIStringEncoding];
        self.tag_UIIOShowLogVIew.string =[[NSString alloc]initWithCString:g_textLog encoding:NSUTF8StringEncoding];
        g_textLog = 0;
    }
}



-(void) UpdataPdca
{

 
    int i =0 ;
    int m = 0;
    NSTableView *  tableView = [self.tag_uiTableView.contentView documentView];
   
    while(i < tag_UIStepArray.count)
    {

        StepView *view = tag_UIStepArray[i];
        [view UIUpdata];
        i++;
    }
     i = 0;
    while(i < tag_UIStationArrayList.count)
    {
        
        mainStationView *view = tag_UIStationArrayList[i];
        [view UIUpdata:i STATION:tag_Station];
        i++;
    }
  
}
CSocket g_soc = {0};
IPConfig ipcong = {0};
int IoRead[200] = {1};
 extern void Wait(int wait);
-(void)IoRead:(int) begin
{
    //"[]io dir set(8,bit73=1,bit74=1,bit75=1,bit76=1,bit77=1,bit78=1,bit79=1,bit80=1)
    memset(g_soc.tag_sendBuffer,0,sizeof(g_soc.tag_sendBuffer));
    strcat(g_soc.tag_sendBuffer,g_sConfig->tag_SysIni.tag_IoShowInputInitCommand);
    strcat(g_soc.tag_sendBuffer,"\r\n");
     g_soc.tag_sendLen  = strlen(g_soc.tag_sendBuffer);
    g_soc.sockectSend(&g_soc);
    
    
    Wait(200);

    g_soc.sockectRead(&g_soc);
    memset(g_soc.tag_sendBuffer,0,sizeof(g_soc.tag_sendBuffer));

   // strcat(g_soc.tag_sendBuffer,"[]io read(8,bit73,bit74,bit75,bit76,bit77,bit78,bit79,bit80)\r\n");
    
    strcat(g_soc.tag_sendBuffer,g_sConfig->tag_SysIni.tag_IoShowInputCommand);
    strcat(g_soc.tag_sendBuffer,"\r\n");
    
     g_soc.tag_sendLen  = strlen(g_soc.tag_sendBuffer);
    g_soc.tag_sendBuffer[strlen(g_soc.tag_sendBuffer)-1] = 0;
    
    
    
    strcat(g_soc.tag_sendBuffer,")\r\n");
    g_soc.tag_sendLen= strlen(g_soc.tag_sendBuffer);
    g_soc.sockectSend(&g_soc);
    Wait(200);
    g_soc.sockectRead(&g_soc);
     for(int i = 0;i < 32;i++)
    {
        char ReadIoBit[10] = {0};
        char *io = 0;
        memset(ReadIoBit,0,10);
        sprintf(ReadIoBit,"bit%d=",i+begin);
        io = strstr(g_soc.tag_readBuffer,ReadIoBit);
        if(io)
        {
            char c = io[strlen(ReadIoBit)];
            IoRead[i+begin] = c -'0';
          
        }
        
    }

}


-(void)IoRead:(char*) ip PORT:(int) port
{
    
    g_soc.tag_ipConfig = &ipcong;
    if(strlen(g_soc.tag_ipConfig->tag_ip) == 0)
    {
        strcat( g_soc.tag_ipConfig->tag_ip,ip);
        g_soc.tag_ipConfig->tag_port=port;
        socketInit(&g_soc);
    }
    if(g_soc.tag_id <= 0)
    {
        g_soc.sockectConnect(&g_soc);
    }

    
    
    
    
    
}

- (void)updateIOShow{
    if (freshIOShow) {
        for (int i = 0; i < 200; i ++) {
            if(self.tag_UIIOContainerView.subviews.count >i)
            {
            SRIOItemView *ioView = tag_UIIOReadArray[i];
            ioView.active = (IoRead[i] == 1)?YES:NO;
            }
        }
    }
}
bool freshIOShow = NO;
bool recordOldfreshIOShow = NO;
bool ReadIoSwitch = false;
- (void)tabView:(NSTabView *)tabView didSelectTabViewItem:(NSTabViewItem *)tabViewItem{
    
    if([tabViewItem.identifier isEqualToString:@"IOShow"])
    {
        freshIOShow = YES;
        if (freshIOShow == recordOldfreshIOShow) {
   
        }else{
            recordOldfreshIOShow = freshIOShow;
        
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                memset(IoRead,0,sizeof(IoRead));
          
                while (freshIOShow) {
                    if(!ReadIoSwitch)
                    {
                         [NSThread sleepForTimeInterval:0.2];
                        continue ;
                    }
                
                    [self IoRead:g_sConfig->tag_IpBag.tag_ipConfig[0].tag_ip PORT:g_sConfig->tag_IpBag.tag_ipConfig[0].tag_port];
                  //  [self IoRead :0];
                  //  [self IoRead :32];
                    [self IoRead :64];
                    [self IoRead :64+32];
                    [self IoRead :64+32+32];
                    [self IoRead :64+32+32+32];
                    [self IoRead :64+32+32+32];
                    [self IoRead :64+32+32+32+32];

                    [NSThread sleepForTimeInterval:0.2];
                }
                
            });
        }
    }else{
        freshIOShow = NO;
        recordOldfreshIOShow = freshIOShow;
    }
}
- (IBAction)IoReadSwitchActon:(id)sender {
    NSButton *button = ( NSButton *)sender;
    ReadIoSwitch = button.state;
}

- (void)SRIOItemViewDidClick:(SRIOItemView *)itemView{
    
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        CSocket soc = {0};
        IPConfig ipconfig = {0};
        soc.tag_ipConfig = &ipconfig;
        strcat(ipconfig.tag_ip, g_sConfig->tag_IpBag.tag_ipConfig[0].tag_ip);
        ipconfig.tag_port = g_sConfig->tag_IpBag.tag_ipConfig[0].tag_port;
        socketInit(&soc);
        if (soc.tag_id <= 0) {
            soc.sockectConnect(&soc);
        }
        
        if (soc.tag_id >= 0) {
            memset(soc.tag_sendBuffer, 0, sizeof(soc.tag_sendBuffer));
            sprintf(soc.tag_sendBuffer, "[]io set(1,bit%d=%d)\r\n",itemView.Num,itemView.sendInt);
            itemView.sendInt = (itemView.sendInt+1)%2;
            soc.tag_sendLen  = strlen(soc.tag_sendBuffer);
            soc.sockectSend(&soc);
              Wait(100);
            soc.sockectRead(&soc);
            soc.sockectClose(&soc);
        }

        
    });
    
    
}
- (IBAction)mutioSendSwitchAction:(id)sender {
    NSButton *button = (NSButton *)sender;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        CSocket soc = {0};
        IPConfig ipconfig = {0};
        soc.tag_ipConfig = &ipconfig;
        strcat(ipconfig.tag_ip, g_sConfig->tag_IpBag.tag_ipConfig[0].tag_ip);
        ipconfig.tag_port = g_sConfig->tag_IpBag.tag_ipConfig[0].tag_port;
        socketInit(&soc);
        if (soc.tag_id <= 0) {
            soc.sockectConnect(&soc);
        }
        
        if (soc.tag_id >= 0) {
            memset(soc.tag_sendBuffer, 0, sizeof(soc.tag_sendBuffer));
            int count = 0;
            for(int i =0 ;i < tag_UIIOReadArray.count ; i++)
            {
                SRIOItemView *view = tag_UIIOReadArray[i];
                if(view.sendState == 1)
                {
                    count++;
                }
                
            }
            
            sprintf(soc.tag_sendBuffer, "[]io dir set(%d,",count);
            for(int i =0 ;i < tag_UIIOReadArray.count ; i++)
            {
                SRIOItemView *view = tag_UIIOReadArray[i];
                if(view.sendState == 1)
                {
                    sprintf(&soc.tag_sendBuffer[strlen(soc.tag_sendBuffer)],"bit%d=%d,",i,button.state);
                }
                
            }
            soc.tag_sendBuffer[strlen(soc.tag_sendBuffer)-1] = ')';
             strcat(soc.tag_sendBuffer,"\r\n");
            soc.tag_sendLen  = strlen(soc.tag_sendBuffer);
           

            soc.sockectSend(&soc);
            Wait(100);
             soc.tag_outReadTime =1000;
            soc.sockectRead(&soc);
            soc.sockectClose(&soc);
        }
        
        
    });

}



- (IBAction)IoSendButtonAction:(id)sender
{
    NSButton *button = (NSButton *)sender;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        CSocket soc = {0};
        IPConfig ipconfig = {0};
        soc.tag_ipConfig = &ipconfig;
        strcat(ipconfig.tag_ip, g_sConfig->tag_IpBag.tag_ipConfig[0].tag_ip);
        ipconfig.tag_port = g_sConfig->tag_IpBag.tag_ipConfig[0].tag_port;
        socketInit(&soc);
        if (soc.tag_id <= 0) {
            soc.sockectConnect(&soc);
        }
        
        if (soc.tag_id >= 0) {
            memset(soc.tag_sendBuffer, 0, sizeof(soc.tag_sendBuffer));
            int count = 0;
            for(int i =0 ;i < tag_UIIOReadArray.count ; i++)
            {
                SRIOItemView *view = tag_UIIOReadArray[i];
                if(view.sendState == 1)
                {
                    count++;
                }
                
            }
            
             sprintf(soc.tag_sendBuffer, "[]io set(%d,",count);
            for(int i =0 ;i < tag_UIIOReadArray.count ; i++)
            {
                SRIOItemView *view = tag_UIIOReadArray[i];
                if(view.sendState == 1)
                {
                    sprintf(&soc.tag_sendBuffer[strlen(soc.tag_sendBuffer)],"bit%d=%d,",i,button.state);
                }
           
            }
            soc.tag_sendBuffer[strlen(soc.tag_sendBuffer)-1] = ')';
            strcat(soc.tag_sendBuffer,"\r\n");
            soc.tag_sendLen  = strlen(soc.tag_sendBuffer);
            soc.tag_outReadTime =1000;
            soc.sockectSend(&soc);
             Wait(100);
            soc.sockectRead(&soc);
            soc.sockectClose(&soc);
        }
    });
}
void NSThreadsleep(int delay)
{
    double d = delay/1000.0;
    [NSThread sleepForTimeInterval:d];
}
@end
