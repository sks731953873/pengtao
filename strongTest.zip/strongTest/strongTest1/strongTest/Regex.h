//
//  Regex.h
//  Button-Switch
//
//  Created by tusm on 14-7-11.
//  Copyright (c) 2014年 tusm. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RegexKitLite.h"

@interface Regex : NSObject

+(Regex*)instance;
//-(void)ReadFile;
//-(int)RegexText:(NSString*)strSN;
//-(int)RegexText:(NSString*)strTemp andSN:(NSString*)strSN;
-(int)RegexText:(NSString*)strSN andFilePath:(NSString*)strPath;

@end
