//
//  FCTDLStationView.h
//  strongTest
//
//  Created by strong on 2018/1/10.
//  Copyright © 2018年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "FCTDLView.h"
@protocol FCTDLActionDelegate
-(void)FCTDLStartDelegate:(id) obj;
-(void)FCTDLStopButtonDelegate:(id) obj;

@end
@interface FCTDLStationView : NSView
{
    id<FCTDLActionDelegate> tag_ButtonDelegate;

    // SEL
}
@property (weak) IBOutlet NSButton *tag_Channel20;
@property (weak) IBOutlet NSButton *tag_Channel19;
@property (weak) IBOutlet NSButton *tag_Channel18;
@property (weak) IBOutlet NSButton *tag_Channel17;
@property (weak) IBOutlet NSButton *tag_Channel16;
@property (weak) IBOutlet NSButton *tag_Channel15;
@property (weak) IBOutlet NSButton *tag_Channel14;
@property (weak) IBOutlet NSButton *tag_Channel13;
@property (weak) IBOutlet NSButton *tag_Channel12;
@property (weak) IBOutlet NSButton *tag_Channel11;
@property (weak) IBOutlet NSButton *tag_Channel10;
@property (weak) IBOutlet NSButton *tag_Channel9;
@property (weak) IBOutlet NSButton *tag_Channel8;
@property (weak) IBOutlet NSButton *tag_Channel7;
@property (weak) IBOutlet NSButton *tag_Channel6;
@property (weak) IBOutlet NSButton *tag_Channel5;
@property (weak) IBOutlet NSButton *tag_Channel4;
@property (weak) IBOutlet NSButton *tag_Channel3;
@property (weak) IBOutlet NSButton *tag_Channel2;
@property (weak) IBOutlet NSButton *tag_Channel1;
@property(assign,nonatomic)id<FCTDLActionDelegate> tag_ButtonDelegate;
@property (weak) IBOutlet NSTextField *tag_UISN;
@property (weak) IBOutlet NSTextField *tag_UILineNO;
@property (weak) IBOutlet NSTextField *tag_UIFixtrueID;
- (IBAction)ChannelAtions:(id)sender;

@property (weak) IBOutlet NSTextField *tag_UIStationID;
- (IBAction)StartAction:(id)sender;
- (IBAction)StopAction:(id)sender;
/*******************************************************************************************
 **函数名：initWithFrame
 **参数：:(CGRect)frame
 **功能：初始化 大小
 **返回值：
 *******************************************************************************************/
- (instancetype)initWithFrame:(CGRect)frame FCTDLMANAGE:(fctDlValueManage)  fctDlmanage   CHANNEL:(int *) channel;
@end
