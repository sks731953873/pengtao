//
//  portView.h
//  strongTest
//
//  Created by strong on 2018/1/5.
//  Copyright © 2018年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "port.h"
#import "SerialPortList.h"
typedef enum _uiort_enum
{
    uiport_enum_index,//id
    uiport_enum_name,//名称
    uiport_enum_baudRate,//
    uiport_enum_dataBits,
    uiport_enum_stopBits,//
    uiport_enum_parity,
    uiport_enum_flowControl,
    uiport_enum_SendendFlage,//结束标记
    uiport_enum_endFlage,//结束标记
    uiport_enum_Save,//保存的

}uiort_enum;
@interface portView : NSView
{
    NSTextField *tag_UIIndex;//显示的id
    NSComboBox *tag_UIName;//命令类型
    NSTextField *tag_UIbaudRate;//显示的id
    NSComboBox *tag_dataBits;
    NSComboBox *tag_UIstopBits;//显示的id
    NSComboBox *tag_UIparity;//显示的id
    NSComboBox *tag_UIflowControl;//显示的id
    NSComboBox *tag_UIecho;//显示的id
    NSTextField *tag_UISendendFlage;//显示的id
    NSTextField *tag_UIendFlage;//显示的id
    NSButton *tag_UISave;
    portValue tag_portValue;

}
/*******************************************************************************************
 **函数名：InitUI
 **参数：:(int) index  显示的ID STEP:(LpStep) step 步骤
 **功能：初始化步骤
 **返回值：
 *******************************************************************************************/
-(void)InitUI:(int) index PORT:(portValue) port;


/*******************************************************************************************
 **函数名：ExeClick
 **参数：:xeClick:(id)sender
 **功能：单步运行
 **返回值：
 *******************************************************************************************/

- (void)ExeClick:(id)sender;
/*******************************************************************************************
 **函数名：SaveClick
 **参数：:xeClick:(id)sender
 **功能：单步保存事件
 **返回值：
 *******************************************************************************************/
- (IBAction)SaveClick:(id)sender;

/*******************************************************************************************
 **函数名：SaveClick
 **参数：:xeClick:(id)sender
 **功能：单步保存事件
 **返回值：
 *******************************************************************************************/
- (IBAction)GetParameter;


/*******************************************************************************************
 **函数名：tableView
 **参数：:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
 **功能：单步保存事件
 **返回值：一个ui 控件
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;

@end
