//
//  mainStationView.m
//  strongTest
//
//  Created by strong on 2017/12/31.
//  Copyright © 2017年 strong. All rights reserved.
//

#import "mainStationView.h"
int focse = 99999;
@implementation mainStationView
/*******************************************************************************************
 **函数名：InitUI
 **参数：::(int) index STATION:(lpStation) lpstation
 **功能：初始化
 **返回值：
 *******************************************************************************************/
-(void)InitUI:(int) index STATION:(lpStation) lpstation
{
    tag_Station = lpstation;
    
    NSString *name = [[NSString alloc] initWithFormat:@"%s",tag_Station->tag_Name];
    
    tag_UIselect = [[NSButton alloc] init];
    [tag_UIselect setTitle:@""];
    [tag_UIselect  setTarget:self];
    
    [tag_UIselect setButtonType:NSButtonTypeSwitch];
    [tag_UIselect setAction:@selector(SelectClick:)];
    
    
    tag_UIName = [[NSTextField alloc] init];
    tag_UIName.stringValue = name;
    tag_UIcurrStep = [[NSTextField alloc] init];
    tag_UICt = [[NSTextField alloc] init];
    tag_totalPcs = [[NSTextField alloc] init];
    tag_failedPcs = [[NSTextField alloc] init];
    tag_UISn = [[NSTextField alloc] init];
    tag_UISn.tag = index;
    tag_UISn.delegate =  self;
    
    
    tag_failedPcs.editable = NO;
    tag_totalPcs.editable = NO;
    tag_UICt.editable = NO;
    tag_UIcurrStep.editable = NO;
    
    if(tag_Station->tag_snIndex <20)
    {
        if(focse == 99999)
        {
            focse = index;
        }
    }
    
}
- (void)controlTextDidChange:(NSNotification *)obj
{
    extern char gloabe_sn[100][100];
    NSTextField *test =( NSTextField *) obj.object;
    memset(gloabe_sn[test.tag],0,100);
    if(strlen([test.stringValue UTF8String]) && test.stringValue.length > 0)
    {
        if(test.tag >=0)
        {
            strcat(gloabe_sn[test.tag],[test.stringValue UTF8String]);
        }
    }
}
- (void)controlTextDidBeginEditing:(NSNotification *)obj
{
    
}
- (void)controlTextDidEndEditing:(NSNotification *)obj
{
    isFocse = 0;
}

-(NSInteger)IsFail
{
    
    for(int i =0 ; i  < tag_Station->tag_totalCount;i++)
    {
        if(tag_Station->tag_step[i].tag_pdcaValue.tag_strPassFail[0] == 'F' && tag_Station->tag_step[i].tag_pdca_index > 0 )
        {
            return 1;
        }
    }
    return 0;
}
-(void)updateTotalAndFailedPcsAtIndex:(int)index Station:(lpStation)station{
    extern  int totalPcs[40]; //测试总数量
    extern  int failedPcs[40];
    
    int siteID_int =atoi(station->tag_Name);
    if (station->tag_snIndex<20 && station->tag_MainShow==1) {
        
        tag_totalPcs.stringValue = [NSString stringWithFormat:@"%d",totalPcs[siteID_int]];
        tag_failedPcs.stringValue = [NSString stringWithFormat:@"%d",failedPcs[siteID_int]];
    }
    else{
        tag_totalPcs.stringValue = [NSString stringWithFormat:@""];
        tag_failedPcs.stringValue = [NSString stringWithFormat:@""];
    }

}
/*******************************************************************************************
 **函数名：UIUpdata
 **参数：::(int) index STATION:(lpStation) lpstation
 **功能：刷新
 **返回值：
 *******************************************************************************************/
-(void)UIUpdata:(int) index STATION:(lpStation) station
{
    extern   long long getSystemTime();
    extern  char gloabe_sn[100][100];
 

    if(tag_Station == station)
    {
        [tag_UIselect setState:1];
        
    }
    else
    {
        [tag_UIselect setState:0];
    }
    if(tag_Station->tag_stepCurr)
    {
        tag_UIcurrStep.stringValue = [[NSString alloc] initWithFormat:@"%d",tag_Station->tag_Index];
    }
    
    if(tag_Station->tag_stepCurr && g_sConfig->tag_stationManage.tag_WorkState == 1 && tag_Station->tag_WorkState == 1)
    {
        long  long  endTime =  getSystemTime();
        int ct = 0;
        ct = (endTime - tag_Station->tag_logStartTime) / 1000;
        tag_UICt.stringValue = [[NSString alloc] initWithFormat:@"%d",ct];
    }
    if(tag_UISn.stringValue.length < g_sConfig->tag_SysIni.tag_SnLength)
    {
        if(tag_UISn.tag == focse)
        {
            if(isFocse == 0 && g_sConfig->tag_SysIni.tag_SnGetMethod != 0) //DFU不要自动跳格
            {
                [tag_UISn becomeFirstResponder];
                isFocse = 1;
            }
            if (g_sConfig->tag_SysIni.tag_SnGetMethod == 0) {    //DFU  SN填充
                NSString *snStr = [NSString stringWithUTF8String:gloabe_sn[station->tag_snIndex]];
                tag_UISn.stringValue = snStr;
            }
        }
    }
    else
    {
        focse = tag_UISn.tag +1;
    }
    
    if([self IsFail ] == 1)
    {
        
        [tag_UIName setBackgroundColor:[NSColor redColor]];
        [tag_UIName setTextColor:[NSColor whiteColor]];
        
    }
    else
    {
        [tag_UIName setBackgroundColor:[NSColor whiteColor]];
        [tag_UIName setTextColor:[NSColor blackColor]];
    }
    
}

/*******************************************************************************************
 **函数名：StopClick
 **参数：::(id)sender
 **功能：工位停止
 **返回值：
 *******************************************************************************************/
- (IBAction)SelectClick:(id)sender
{
    if(_tag_Delegate)
    {
        [_tag_Delegate selectStationDelegate:tag_Station];
        [tag_UISn  becomeFirstResponder];
    }
    
}

- (void)setTextColor:(NSColor *)textColor BUTTON:(NSButton *) button
{
    
    NSMutableAttributedString *attrTitle =
    
    [[NSMutableAttributedString alloc] initWithAttributedString:[button attributedTitle]];
    
    int len = [attrTitle length];
    
    NSRange range = NSMakeRange(0, len);
    
    [attrTitle addAttribute:NSForegroundColorAttributeName value:textColor range:range];
    
    [attrTitle fixAttributesInRange:range];
    
    [button setAttributedTitle:attrTitle];
}

/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：
 **返回值：
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    
    
    id retid = nil;
    
    
    if(tableView.tableColumns[uimainStation_enum_select] == tableColumn)
    {
        retid = tag_UIselect;
    }else
        if(tableView.tableColumns[uimainStation_enum_name] == tableColumn)
        {
            retid = tag_UIName;
        }else
            if(tableView.tableColumns[uimainStation_enum_currStep] == tableColumn)
            {
                retid = tag_UIcurrStep;
            }else
                if(tableView.tableColumns[uimainStation_enum_Ct] == tableColumn)
                {
                    retid = tag_UICt;
                }else
                    if([tableColumn.title isEqualToString:@"total"])
                    {
                        retid = tag_totalPcs;
                    }else
                        if([tableColumn.title isEqualToString:@"failed"])
                        {
                            retid = tag_failedPcs;
                        }
                else
                    if(tableView.tableColumns[uimainStation_enum_sn] == tableColumn)
                    {
                        retid = tag_UISn;
                        if(tag_Station->tag_snIndex >=20)
                        {
                            tag_UISn.enabled = false;
                        }
                    }
    return retid;
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
