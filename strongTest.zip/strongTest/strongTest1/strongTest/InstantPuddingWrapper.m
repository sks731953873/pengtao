//
//  InstantPuddingWrapper.m
//
//  Created by MS on 02/23/10.
//  Copyright 2010 Apple, Inc.. All rights reserved.
//

#import "InstantPuddingWrapper.h"
#import "TestAttributes.h"

#import <sys/types.h>
#import <sys/stat.h>

#include <dlfcn.h>
#import <pthread.h>
#import "Config.h"
#include "Log.h"
#import "SRFileTool.h"
char gloabe_sn[100][100];
// Instant Pudding

// Path to load pudding from
static const char INSTANT_PUDDING_DYLIB[] = "/usr/local/lib/libInstantPudding.dylib";
//static const char INSTANT_PUDDING_DYLIB[] = "/Users/strong/Desktop/南京出差资料/FCT_FWDL资料整理-01/PDCAinfo/pdca 脚本执行说明/libInstantPudding.dylib";
#define EXPORT __attribute__((visibility("default")))

/*
 * Structure to track everything InstantPudding related.  We load the dylib
 * at runtime if it is present and look up all the following functions
 */
static struct {
    Boolean functionsLoaded;
    
    bool (*IP_success)(IP_API_Reply reply);
    
    const char *(*IP_reply_getError)(IP_API_Reply reply);
    void (*IP_reply_destroy)(IP_API_Reply reply);
    
    IP_API_Reply (*IP_UUTStart)(IP_UUTHandle *outHandle);
    IP_API_Reply (*IP_UUTDone)(IP_UUTHandle inHandle);
    IP_API_Reply (*IP_UUTCommit)(IP_UUTHandle inHandle, enum IP_PASSFAILRESULT inPassFail);
    void (*IP_UID_destroy)(IP_UUTHandle UUTHandle);
    
    IP_API_Reply (*IP_addResult)(IP_UUTHandle inHandle, IP_TestSpecHandle testSpec, IP_TestResultHandle testResult);
    IP_API_Reply (*IP_addAttribute)(IP_UUTHandle inHandle, const char *name, const char *value);
    IP_API_Reply (*IP_addBlob)( IP_UUTHandle inHandle, const char* inBlobName, const char* inPathToBlobFile );
    IP_API_Reply (*IP_addBlobData)( IP_UUTHandle inHandle, const char* inBlobName, const void* inBlobPointer, long inBlobLength );
    IP_API_Reply (*IP_sendStationFailureReport)(IP_UUTHandle inHandle, const char* cppFailureStep, const char* cppFailureReason );
    IP_API_Reply (*IP_addModuleHistory)(IP_UUTHandle inHandle, const char* kcpModuleSerialNumber, const char* kcpVendorCode,const char* kcpDateCode,
                                        const char* kcpPartNum,const char* kcpDescription,const char* kcpLotCode );
    IP_API_Reply (*IP_getGHStationInfo)(IP_UUTHandle inHandle,enum IP_ENUM_GHSTATIONINFO eGHStationInfo,char** cppValue,size_t *sLength);
    
    IP_TestSpecHandle (*IP_testSpec_create)(void);
    bool (*IP_testSpec_setTestName)(IP_TestSpecHandle testSpecHandle, const char *name, size_t nameLength);
    bool (*IP_testSpec_setSubTestName)(IP_TestSpecHandle testSpecHandle, const char *name, size_t nameLength);
    bool (*IP_testSpec_setPriority)(IP_TestSpecHandle testSpecHandle, enum IP_PDCA_PRIORITY priority);
    bool (*IP_testSpec_setLimits)(IP_TestSpecHandle testSpecHandle, const char * lowerLimit, size_t lowerLimitLength, const char * upperLimit, size_t upperLimitLength);
    bool (*IP_testSpec_setUnits)( IP_TestSpecHandle testSpecHandle, const char* units, size_t unitsLength );
    void (*IP_testSpec_destroy)(IP_TestSpecHandle testSpecHandle);
    
    IP_TestResultHandle (*IP_testResult_create)(void);
    bool (*IP_testResult_setResult)(void *testResultHandle, enum IP_PASSFAILRESULT result);
    bool (*IP_testResult_setValue)(void *testResultHandle, const char *value, size_t valueLength);
    bool (*IP_testResult_setMessage)(void *testResultHandle, const char *message, size_t messageLength);
    void (*IP_testResult_destroy)(IP_TestResultHandle testResultHandle);
    IP_API_Reply (*IP_setDUTPos)(IP_UUTHandle handleDUTPosition,const char * cpFixId,const char * cpHeadId);
    const char * (*IP_getVersion)(void);
    IP_API_Reply(*IP_UUTCancel)(IP_UUTHandle inHandle);
    IP_API_Reply(*IP_amIOkay)(IP_UUTHandle inHandle, const char* inUUTSerialNumber);
    IP_API_Reply(*IP_setStartTime)(IP_UUTHandle uut, time_t rawTimeToUse );
    IP_API_Reply(*IP_setStopTime)(IP_UUTHandle uut, time_t rawTimeToUse );
    
    
} InstantPudding = {
    .functionsLoaded = false,
};

EXPORT void loadInstantPudding(void)
{
    void *lib = dlopen(INSTANT_PUDDING_DYLIB, RTLD_LAZY | RTLD_LOCAL);
    if (lib == NULL) {
        NSLog(@"unable to load %s: %s", INSTANT_PUDDING_DYLIB, dlerror());
        goto exit;
    }
    
#define LOAD_INSTANT_PUDDING_SYMBOL(x) \
if ((InstantPudding.x = dlsym(lib, #x)) == NULL) { NSLog(@"unable to load InstantPudding symbol '%s': %s", #x, dlerror()); goto exit; }
    
    LOAD_INSTANT_PUDDING_SYMBOL(IP_success);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_reply_getError);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_reply_destroy);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_UUTStart);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_UUTDone);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_UUTCommit);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_UID_destroy);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_addResult);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_addAttribute);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_addBlob);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_addBlobData);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_testSpec_create);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_testSpec_setTestName);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_testSpec_setSubTestName);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_testSpec_setPriority);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_testSpec_setLimits);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_testSpec_setUnits);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_testSpec_destroy);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_testResult_create);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_testResult_setResult);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_testResult_setValue);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_testResult_setMessage);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_testResult_destroy);
      LOAD_INSTANT_PUDDING_SYMBOL(IP_setDUTPos);
    
     //LOAD_INSTANT_PUDDING_SYMBOL(IP_sendStationFailureReport);
     //LOAD_INSTANT_PUDDING_SYMBOL(IP_addModuleHistory);
     LOAD_INSTANT_PUDDING_SYMBOL(IP_getGHStationInfo);
    
    LOAD_INSTANT_PUDDING_SYMBOL(IP_getVersion);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_UUTCancel);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_amIOkay);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_setStartTime);
    LOAD_INSTANT_PUDDING_SYMBOL(IP_setStopTime);
    
#undef LOAD_INSTANT_PUDDING_SYMBOL
    
    InstantPudding.functionsLoaded = true;
    
exit:
    /*
     * Currently, we leak the handle to the lib if we loaded successfully
     * because we're never going to clean up these pointers and unload the
     * library
     */
    if ((InstantPudding.functionsLoaded == false) && (lib != NULL)) {
        dlclose(lib);
    }
}



InstantPuddingWrapper *cftsInstantPuddingWrapper = nil;
static int count=0;
static NSLock *threadLock;

@implementation InstantPuddingWrapper
/* Looks for specifc plists from copyBurnLogs, and submits that data to Instant Pudding for PDCA trend analysis of Burnin results. */


- (id)init
{
    if ((self = [super init])) {
        
        ipStationName = nil;
        ipSoftwareLimits = nil;
        ipSoftwareVersion = nil;
        stationProperties = nil;
        testList = [[NSMutableArray alloc] init] ;
        stationAttributesExtra = [[NSMutableArray alloc] init] ;
        if(!threadLock)
            threadLock = [[NSLock alloc] init];
        
        if (InstantPudding.functionsLoaded == true) {
            IP_API_Reply reply = InstantPudding.IP_UUTStart(&UIDHandle);
            
            if ( !InstantPudding.IP_success(reply) )
            {
                NSLog(@"Error from UUTStart() for Unit : %s", InstantPudding.IP_reply_getError(reply));
                [[NSNotificationCenter defaultCenter] postNotificationName:kIPFatalError object:nil userInfo:[NSString stringWithFormat:@"%s",InstantPudding.IP_reply_getError(reply) ]];
                
            }
            NSLog(@"UID handle created successfully");
            InstantPudding.IP_reply_destroy(reply);
        }
        else{
            
            
        }
    }
    
    return self;
}

- (id)initWithStationName:(NSString*)stationName softwareVersion:(NSString *) softwareVersion softwareLimits:(NSString *)softwareLimits
{
    if ((self = [super init])) {
        
        ipStationName = [stationName copy] ;
        ipSoftwareLimits = [softwareLimits copy] ;
        ipSoftwareVersion = [softwareVersion copy] ;
        
    }
    
    return self;
}
@synthesize ipStationName;
@synthesize ipSoftwareLimits;
@synthesize ipSoftwareVersion;
@synthesize stationProperties;
@synthesize dutSerialNumber;
@synthesize testList;
@synthesize blobList;
@synthesize ipSubStationName;
@synthesize stationAttributes;
@synthesize stationAttributesExtra;

- (Boolean) logInstantPuddingCallWithReply:(IP_API_Reply) reply callName:( NSString*) callName
{
    bool success = InstantPudding.IP_success(reply);
    if (success == true) {
        // Only turn this on for debugging
        NSLog(@"Instant Pudding call succeeded: %s", [callName UTF8String]);
    } else {
        NSLog(@"Instant Pudding call failed: %s", [callName UTF8String]);
        NSLog(@"Instant Pudding Error: %s", InstantPudding.IP_reply_getError(reply));
        [[NSNotificationCenter defaultCenter] postNotificationName:kIPFatalError object:nil userInfo:[NSString stringWithFormat:@"SN: %@ InstantPuddingError: %s",[self dutSerialNumber] ,InstantPudding.IP_reply_getError(reply) ]];
        printf("XERR\t%s\n", [[NSString stringWithFormat:@"SN: %@ InstantPuddingError: %s",[self dutSerialNumber] ,InstantPudding.IP_reply_getError(reply) ] UTF8String]);
        fflush(stdout);
    }
    
    InstantPudding.IP_reply_destroy(reply);
    
    return success;
}
- (Boolean) logInstantPuddingCallBool: (Boolean) success callName: (NSString*) callName
{
    if (success == true) {
        // Only turn this on for debugging
        NSLog(@"LogCollector: Instant Pudding call succeeded: %s", [callName UTF8String]);
    } else {
        NSLog(@"LogCollector: Instant Pudding call failed: %s", [callName UTF8String]);
    }
    
    return success;
}
-(int)IP_addFile:(IP_UUTHandle) a_UID FILENAME: (NSString *)input Description: (NSString *)description
{
    const char *fileInput = [input UTF8String];
    const char *fileDescription = [description UTF8String];
    IP_API_Reply reply;
    AddLog("IP_addFile");
    
    if(a_UID == nil){
        
        AddLog("[IPWrapper] a_UID = nil");
        return -1;
    }
    // now, submit the blob
    reply = InstantPudding.IP_addBlob( a_UID, fileDescription, fileInput);
    if ( !InstantPudding.IP_success( reply ) )
    {
        AddLog("[IPWrapper] Error returned from IP_addBlob:");
        AddLog( InstantPudding.IP_reply_getError(reply));
        InstantPudding.IP_reply_destroy(reply);
        return -1;
    }
    AddLog([input UTF8String]);
    AddLog([description UTF8String]);
    // clean up
    InstantPudding.IP_reply_destroy(reply);
    return 0;
}
// 2. insert attributes
// return -1 if fail. 0 if OK.
// ap_name: please refer to "InstantPudding_API.h"
-(int) IP_insertAttribute: (IP_UUTHandle)a_UID name:(const char *)ap_name
                     attr: (NSString *)ap_attr
{
    const char *mATTR = [ap_attr UTF8String];
    const char *mName = ap_name;
    IP_API_Reply reply;

    AddLog("[IP_insertAttribute] Begin");
    if(a_UID == nil || ap_attr == nil || ap_name == nil)
    {
        AddLog("[IP_insertAttribute] Input nil");
        return -1;
    }
    if(strlen(ap_name) == 0 || [ap_attr length] == 0 ||  [ap_attr length]  >255)
    {
        AddLog("[IP_insertAttribute] Input nil");
        return -1;
    }
    AddLog(ap_name);
    AddLog(ap_attr.UTF8String);

    reply = InstantPudding.IP_addAttribute( a_UID, mName, mATTR);
    if ( !InstantPudding.IP_success(reply) )
    {
        AddLog("[IP_insertAttribute] Error from IP_insertAttribute()");
        AddLog(InstantPudding.IP_reply_getError(reply));
        InstantPudding.IP_reply_destroy(reply);
        return -1;
    }
    InstantPudding.IP_reply_destroy(reply);
    return 0;
}


void Tirm(char *newstr ,char *Old)
{
    int len = strlen(Old);
    int i = 0;
    int j = 0;
    while(i < len)
    {
        if(Old[i] != ' ')
        {
            newstr[j] = Old[i];
            j++;
        }
        i++;
    }
}
// 3. insert test item and result
// return -1 if fail. 0 if OK.
/************************
 ap_TestName:   test item name: MAX length: 48
 ap_LowLimit:   limit, accepted format: numberic value, NA, N/A
 ap_UpLimit:    limit, accepted format: numberic value, NA, N/A
 ap_testValue:  result, accepted format: numberic value only.
 //Modify ==> Benson modify NSString *ap_Priority --> int ap_Priority By 20140105 for Audit mode
 ************************/
-(int) IP_insertTestItemAndResult:(IP_UUTHandle) a_UID
                         TestName:  (NSString *)ap_TestName_
                         LowLimit:  (NSString *)       ap_LowLimit_
                          UpLimit:  (NSString *)       ap_UpLimit_
                            Units:  (  char *)                                ap_Units_
                         Priority:  (int)                                  ap_Priority_
                        testValue:  (NSString *) ap_testValue_
                      testMessage:  (NSString *)    ap_testMessage_
                           isPass:  (bool)  isPass
{
    
    IP_TestSpecHandle testSpec;
    IP_TestResultHandle testResult;
    IP_API_Reply reply;
    int mallocLen = 1024;
    char *strTestName = malloc(mallocLen);
    char *strLowLimit = malloc(mallocLen);
    char *strUpLimit = malloc(mallocLen);
    char *strUpUnits = malloc(mallocLen);
    char *strtestValue = malloc(mallocLen);
    
    memset(strTestName,0,mallocLen);
    memset(strLowLimit,0,mallocLen);
    memset(strUpLimit,0,mallocLen);
    memset(strUpUnits,0,mallocLen);
    memset(strtestValue,0,mallocLen);
    
    if(isPass == 0)
    {
        
    }
    
    if(a_UID == nil || ap_TestName_ == nil || ap_LowLimit_ == nil || ap_UpLimit_ == nil || ap_testValue_ == nil || ap_testMessage_ == nil
       || ap_Units_ == nil){
        free(strTestName);
        free(strLowLimit);
        free(strUpLimit);
        free(strUpUnits);
        free(strtestValue);
        AddLog("[IPWrapper] Input nil");
        return -1;
    }
    Tirm(strTestName,[ap_TestName_ UTF8String]);
    Tirm(strLowLimit,[ap_LowLimit_ UTF8String]);
    Tirm(strUpLimit,[ap_UpLimit_ UTF8String]);
    Tirm(strtestValue,[ap_testValue_ UTF8String]);
    Tirm(strUpUnits,ap_Units_);
    
    AddLog(strTestName);
    AddLog(strLowLimit);
    AddLog(strUpLimit);
    AddLog(strtestValue);
    AddLog(strUpUnits);
    if(1)
    {
        char ppppp[20] = {0};
        memset(ppppp,0,20);
        sprintf(ppppp,"%d",isPass);
        AddLog(ppppp);
    }
    
    
    
    const char *TEST_NAME = strTestName;
    const char *TEST_LOW_LIMIT = strLowLimit;
    const char *TEST_UP_LIMIT = strUpLimit;
    // TODO: currently the priority are all 0
    // const char *TEST_PRIORITY = "0";
    
    // create a test specification for our first test, Rubberband stretching
    testSpec = InstantPudding.IP_testSpec_create();
    if ( NULL != testSpec )
    {
        BOOL APIcheck = false;
        APIcheck = InstantPudding.IP_testSpec_setTestName( testSpec, TEST_NAME, strlen(TEST_NAME));
        if(!APIcheck)
        {
            AddLog("[IPWrapper] IP_testSpec_setTestName error");
            //IP_UUTCancel(a_UID);
            //IP_UID_destroy(a_UID);
            InstantPudding.IP_testSpec_destroy(testSpec);
            free(strTestName);
            free(strLowLimit);
            free(strUpLimit);
            free(strUpUnits);
            free(strtestValue);
            return -1;
        }
        
        //IP_testSpec_setSubTestName( testSpec, "Stretch\0", 8);
        //IP_testSpec_setSubSubTestName( testSpec, "Long Dimension\0", 15 );
        APIcheck = InstantPudding.IP_testSpec_setLimits( testSpec, TEST_LOW_LIMIT, strlen(TEST_LOW_LIMIT), TEST_UP_LIMIT, strlen(TEST_UP_LIMIT));
        if(!APIcheck)
        {
            AddLog("[IPWrapper] IP_testSpec_setLimits error");
            //IP_UUTCancel(a_UID);
            //IP_UID_destroy(a_UID);
            InstantPudding.IP_testSpec_destroy(testSpec);
            free(strTestName);
            free(strLowLimit);
            free(strUpLimit);
            free(strUpUnits);
            free(strtestValue);
            return -1;
        }
        
        // If units not set. skip it.
        if(strlen(strUpUnits) != 0){
            APIcheck = InstantPudding.IP_testSpec_setUnits( testSpec, strUpUnits, strlen(strUpUnits) );
            if(!APIcheck)
            {
                AddLog("[IPWrapper] IP_testSpec_setUnits error");
                //IP_UUTCancel(a_UID);
                //IP_UID_destroy(a_UID);
                free(strTestName);
                free(strLowLimit);
                free(strUpLimit);
                free(strUpUnits);
                free(strtestValue);
                InstantPudding.IP_testSpec_destroy(testSpec);
                return -1;
            }
        }
        if((ap_Priority_ == IP_PRIORITY_STATION_CALIBRATION_AUDIT) ||
           (ap_Priority_>=IP_PRIORITY_REALTIME_WITH_ALARMS && ap_Priority_<=IP_PRIORITY_ARCHIVE))
        {
            APIcheck = InstantPudding.IP_testSpec_setPriority( testSpec, ap_Priority_ );
        }
        else
        {
            AddLog("[IPWrapper] ap_Priority is out of enum");
            free(strTestName);
            free(strLowLimit);
            free(strUpLimit);
            free(strUpUnits);
            free(strtestValue);
            return -1;
        }
        if(!APIcheck)
        {
            AddLog("[IPWrapper] IP_testSpec_setPriority error");
            //IP_UUTCancel(a_UID);
            //IP_UID_destroy(a_UID);
            InstantPudding.IP_testSpec_destroy(testSpec);
            free(strTestName);
            free(strLowLimit);
            free(strUpLimit);
            free(strUpUnits);
            free(strtestValue);
            return -1;
        }
    }
    
    const char *TEST_VALUE = strtestValue;
    const char *TEST_MESSAGE = [ap_testMessage_ UTF8String];
    
    testResult = InstantPudding.IP_testResult_create();
    if(isPass)
    {
        BOOL APIcheck = false;
        APIcheck = InstantPudding.IP_testResult_setResult( testResult, IP_PASS );
        if(!APIcheck)
        {
            AddLog("[IPWrapper] IP_testResult_setResult error");
            //IP_UUTCancel(a_UID);
            //IP_UID_destroy(a_UID);
            InstantPudding.IP_testSpec_destroy(testSpec);
            InstantPudding.IP_testResult_destroy(testResult);
            return -1;
        }
        APIcheck = InstantPudding.IP_testResult_setValue( testResult, TEST_VALUE, strlen(TEST_VALUE));
        if(!APIcheck)
        {
            AddLog("[IPWrapper] IP_testResult_setValue error");
            //IP_UUTCancel(a_UID);
            //IP_UID_destroy(a_UID);
            InstantPudding.IP_testSpec_destroy(testSpec);
            InstantPudding.IP_testResult_destroy(testResult);
            free(strTestName);
            free(strLowLimit);
            free(strUpLimit);
            free(strUpUnits);
            free(strtestValue);
            return -1;
        }
        APIcheck = InstantPudding.IP_testResult_setMessage( testResult, TEST_MESSAGE, strlen(TEST_MESSAGE) );
        if(!APIcheck)
        {
            AddLog("[IPWrapper] IP_testResult_setMessage error");
            //IP_UUTCancel(a_UID);
            //IP_UID_destroy(a_UID);
            InstantPudding.IP_testSpec_destroy(testSpec);
            InstantPudding.IP_testResult_destroy(testResult);
            free(strTestName);
            free(strLowLimit);
            free(strUpLimit);
            free(strUpUnits);
            free(strtestValue);
            return -1;
        }
    }
    else
    {
        BOOL APIcheck = false;
        APIcheck = InstantPudding.IP_testResult_setResult( testResult, IP_FAIL );
        if(!APIcheck)
        {
            AddLog("[IPWrapper] IP_testResult_setResult error");
            //IP_UUTCancel(a_UID);
            //IP_UID_destroy(a_UID);
            InstantPudding.IP_testSpec_destroy(testSpec);
            InstantPudding.IP_testResult_destroy(testResult);
            free(strTestName);
            free(strLowLimit);
            free(strUpLimit);
            free(strUpUnits);
            free(strtestValue);
            return -1;
        }
        APIcheck = InstantPudding.IP_testResult_setValue( testResult, TEST_VALUE, strlen(TEST_VALUE));
        if(!APIcheck)
        {
            AddLog("[IPWrapper] IP_testResult_setValue error");
            //IP_UUTCancel(a_UID);
            //IP_UID_destroy(a_UID);
            InstantPudding.IP_testSpec_destroy(testSpec);
            InstantPudding.IP_testResult_destroy(testResult);
            free(strTestName);
            free(strLowLimit);
            free(strUpLimit);
            free(strUpUnits);
            free(strtestValue);
            return -1;
        }
        APIcheck = InstantPudding.IP_testResult_setMessage( testResult, TEST_MESSAGE, strlen(TEST_MESSAGE));
        if(!APIcheck)
        {
            AddLog("[IPWrapper] IP_testResult_setMessage error");
            //IP_UUTCancel(a_UID);
            //IP_UID_destroy(a_UID);
            InstantPudding.IP_testSpec_destroy(testSpec);
            InstantPudding.IP_testResult_destroy(testResult);
            return -1;
        }
    }
    
    //## required step #2:  IP_addResult()
    reply = InstantPudding.IP_addResult(a_UID, testSpec, testResult );
    if (!InstantPudding.IP_success( reply ) )
    {
        // handle the extremely unlikely even that the InstantPudding API just failed
        AddLog("[IPWrapper] Error from IP_addResult() ");
        AddLog( InstantPudding.IP_reply_getError(reply));
        
        InstantPudding.IP_testResult_destroy(testResult);
        InstantPudding.IP_testSpec_destroy(testSpec);
        InstantPudding.IP_reply_destroy(reply);
        //IP_UUTCancel(a_UID);
        //IP_UID_destroy(a_UID);
        return -1;
    }
    InstantPudding.IP_reply_destroy(reply);
    InstantPudding.IP_testResult_destroy(testResult);
    InstantPudding.IP_testSpec_destroy(testSpec);
    free(strTestName);
    free(strLowLimit);
    free(strUpLimit);
    free(strUpUnits);
    free(strtestValue);
    return 0;
}


- (void)GetStationInfo
{
    
    
    
    enum IP_PASSFAILRESULT deviceResult;
    int pass = 0;
    int fail = 0;
    int err = 0;
    int Priority = 1;
    // Load InstantPudding
    // need to guard against multiple threads trying to load InstantPudding at the same time
    [threadLock lock];
    loadInstantPudding();
    AddLog("submitTestResultsToInstantPudding");
    // UID represents one unit being tested for which we are reporting results
    if (InstantPudding.functionsLoaded == true)
    {
        // Create a UID for reporting data to Instant Pudding
        IP_UUTHandle UID;
        IP_API_Reply reply = InstantPudding.IP_UUTStart(&UIDHandle);
        
        if ( !InstantPudding.IP_success(reply) )
        {
            AddLog("Error from UUTStart() for Unit ");
            AddLog(InstantPudding.IP_reply_getError(reply));
            
        }
        InstantPudding.IP_reply_destroy(reply);

        [self getGHStationInfo:0  strValue:0 UID:UIDHandle];
        
    }
  [threadLock unlock];


}


- (int)submitTestResultsToInstantPudding:(NSMutableArray*)results stationProperties:(NSMutableDictionary*)properties FILEARRAY:(NSMutableArray *) fileNameArray
{
    
    
    
    enum IP_PASSFAILRESULT deviceResult;
    int pass = 0;
    int fail = 0;
    int err = 0;
    int Priority = 1;
    // Load InstantPudding
    // need to guard against multiple threads trying to load InstantPudding at the same time
    [threadLock lock];
    loadInstantPudding();
    AddLog("submitTestResultsToInstantPudding");
    // UID represents one unit being tested for which we are reporting results
    if (InstantPudding.functionsLoaded == true)
    {
        // Create a UID for reporting data to Instant Pudding
        IP_UUTHandle UID;
        IP_API_Reply reply = InstantPudding.IP_UUTStart(&UIDHandle);
        
        if ( !InstantPudding.IP_success(reply) )
        {
            AddLog("Error from UUTStart() for Unit ");
            AddLog(InstantPudding.IP_reply_getError(reply));
            
        }
        InstantPudding.IP_reply_destroy(reply);
        
        [self IP_insertAttribute:UIDHandle name:IP_ATTRIBUTE_SERIALNUMBER
                            attr:[properties  objectForKey: [[ NSString alloc] initWithUTF8String: IP_ATTRIBUTE_SERIALNUMBER]]];
        [self IP_insertAttribute:UIDHandle name:IP_ATTRIBUTE_STATIONSOFTWARENAME
                            attr:[properties  objectForKey: [[ NSString alloc] initWithUTF8String:IP_ATTRIBUTE_STATIONSOFTWARENAME]]];
        [self IP_insertAttribute:UIDHandle name:IP_ATTRIBUTE_STATIONSOFTWAREVERSION
                            attr:[properties  objectForKey: [[ NSString alloc] initWithUTF8String:IP_ATTRIBUTE_STATIONSOFTWAREVERSION]]];
        
        [self IP_insertAttribute:UIDHandle name:IP_ATTRIBUTE_STATIONIDENTIFIER
                            attr:[properties  objectForKey: [[ NSString alloc] initWithUTF8String:IP_ATTRIBUTE_STATIONIDENTIFIER]]];
        
        
         if([results count])
         {
             TestAttributes * testItem = results[0];
             char *Channel = malloc(512);
             memset(Channel,0,512);
             sprintf(Channel,"%s/%s",g_sConfig->tag_SysIni.tag_stationinfo[IP_STATION_NUMBER],[[testItem GetTestName] UTF8String]);
             NSString* strChannel = [[NSString alloc] initWithFormat:@"%s",Channel];

            InstantPudding.IP_setDUTPos(UIDHandle,(const char * )g_sConfig->tag_SysIni.tag_stationinfo[IP_STATION_NUMBER],[[testItem GetTestName] UTF8String]);
             free(Channel);
         }
        
      if([results count])
        {
            TestAttributes * testItem;
            for(testItem in results)
            {
                if(testItem == nil)
                    continue;
                if([testItem GetIsAttributesType] == 0 )
                {
                    continue;
                }
                [self IP_insertAttribute:UIDHandle name:[testItem GetSubTestName].UTF8String
                                    attr:[testItem GetTestValue]];
            }
        }
        int count = 0;
        if([results count])
        {
            TestAttributes * testItem;
            for(testItem in results)
            {
                if(testItem == nil)
                    continue;
                if([testItem GetIsAttributesType] == 1 )
                {
                    continue;
                }
                count = 1;
                if( [[testItem GetTestResult] isEqualToString:@"NA"])
                    continue;
                if([[testItem GetLowerLimit] isEqualToString:@"NA"] || [[testItem GetUpperLimit] isEqualToString:@"NA"])
                {
                    pass = 1;
                    Priority = 0;
                }
                else
                {
                    pass = (([[testItem GetTestValue]floatValue] >= [[testItem GetLowerLimit]floatValue]) && ([[testItem GetTestValue]floatValue] <= [[testItem GetUpperLimit]floatValue]))?1:0;
                    Priority = 1;
                }
                if(!pass) fail = 1;
                [self IP_insertTestItemAndResult:(IP_UUTHandle) UIDHandle
                                        TestName:  [testItem GetSubTestName]
                                        LowLimit:   [testItem GetLowerLimit]
                                         UpLimit:  [testItem GetUpperLimit]
                                           Units:       [testItem GetUutio].UTF8String
                                        Priority:   Priority
                                       testValue:  [testItem GetTestValue]
                                     testMessage:  @""
                                          isPass:  1];
                
                
            }
            NSString *FileName;
            for(FileName in fileNameArray)
            {
                char File[512] = {0};
                memset(File,0,512);
                [self GetFileName:File OrdFIleName:[FileName UTF8String]];
                [self IP_addFile:UIDHandle FILENAME:FileName Description:[[NSString alloc]initWithUTF8String: File ]];
                
            }
            if (!fail)
            {
                deviceResult = IP_PASS;
            }
            else
            {
                deviceResult = IP_FAIL;
            }
            if(count ==0)
            {
                [self IP_insertTestItemAndResult:(IP_UUTHandle) UIDHandle
                                        TestName:  @"Result"
                                        LowLimit:   @"NA"
                                         UpLimit:  @"NA"
                                           Units:  "NA"
                                        Priority:   1
                                       testValue:  @"1"
                                     testMessage:  @""
                                          isPass:  (bool) 1];
            }
           
            
            if([self logInstantPuddingCallWithReply:InstantPudding.IP_UUTDone(UIDHandle)
                                           callName:[NSString stringWithFormat:@"UUTDone"]])
            {
                [self logInstantPuddingCallWithReply:InstantPudding.IP_UUTCommit(UIDHandle, deviceResult)
                                            callName:[NSString stringWithFormat:@"UUTCommit"]];
            }
            else
            {
                AddLog("Error in calling IP_UUTDone, please fix the error and call the wrapper api again!");
                
            }
            InstantPudding.IP_UID_destroy(UIDHandle);
        }
        
        AddLog("Instant Pudding finished off my unit!");
    }
    [threadLock unlock];
    [testList removeAllObjects];
    
    return err;
}

- (int) getGHStationInfo:(enum IP_ENUM_GHSTATIONINFO)eGHStationInfo strValue:(NSString*)strValue UID:( IP_UUTHandle) uid
{
  
    
    
    
    size_t sLength = 1024;
    char *station = malloc(sLength);
    int ret = 0;
    memset(station,0,sLength);
    sLength = sLength -1;
    AddLog("getGHStationInfo");
    if(InstantPudding.functionsLoaded  && InstantPudding.IP_getGHStationInfo)
    {
          AddLog("getGHStationInfo2");
        for(int i = IP_SITE;i<IP_GHSTATIONINFO_COUNT ;i++ )
        {
            memset(station,0,sLength);
            sLength = 1023;
        ret = InstantPudding.IP_getGHStationInfo( uid, i,&station,&sLength );
            
            memset(g_sConfig->tag_SysIni.tag_stationinfo[i],0,512);
            if(strlen(station) >0)
            {
                strcat(g_sConfig->tag_SysIni.tag_stationinfo[i],station);
                AddLog(g_sConfig->tag_SysIni.tag_stationinfo[i]);
            }
           
            if(IP_STATION_ID == i)
            {
                memset(g_sConfig->tag_SysIni.tag_station_id,0,sizeof(g_sConfig->tag_SysIni.tag_station_id));
                 AddLog("g_sConfig->tag_SysIni.tag_station_id");
                
                if(strlen(station) >0)
                {
                    strcat(g_sConfig->tag_SysIni.tag_station_id,station);

                    
                }
                
            }
        AddLog(station);
        }
    }
    return ret;
}
- (void) dealloc
{
    
    
    
    
}

-(void) AddSnIndex:(int) index SNARRAY:(int*)sn LEN:(int) len
{
    
    for(int i =0;i < len;i++)
    {
        if(sn[i] ==index)
            return ;
        if(sn[i] == -1 && sn[i] < 20 && index <20 )
        {
            sn[i]  = index;
            return ;
        }
    }
}


-(TestAttributes*)PDCAStepToTestAttributes:(LpStep) step PDCA:(pdcaValue)pdca1 STATION:(lpStation) station
{
    
    TestAttributes *test;
    char *Result = "0";

    pdcaValue pdca = &step->tag_pdcaValue;
    char *pass = pdca->tag_strPassFail;//ISPass(pdca);
    
    if(pass[0] == 'P')
    {
        Result = "1";
    }
    switch(  pdca->tag_ValueType)
    {
            
        case  enum_pdcaValueType_double:
        {
           
            NSString *tag_Result =  [[NSString alloc] initWithFormat:@"%",pdca->tag_Value] ;
          //  [ self CreateStrDoubel3f:step->tag_Result];
         
            NSString *strVlue = [[NSString alloc ] initWithFormat:@"%s",pdca->tag_Value];
          
           
            
            test = [[TestAttributes alloc] initWithTestAttributes:[[NSString alloc] initWithUTF8String: station->tag_Name]
                                                      subTestName:[[NSString alloc] initWithUTF8String: step->tag_stepName]
                                                       lowerLimit:[[NSString alloc] initWithUTF8String: pdca->tag_Min]
                                                       upperLimit:[[NSString alloc] initWithUTF8String: pdca->tag_Max]
                                                       testResult:[[NSString alloc] initWithUTF8String: Result]
                                                        testValue:strVlue
                                                          message:@""
                                                         priority:@"1"
                                                 stationStartTime:[[NSString alloc] initWithUTF8String: step->tag_stratTime]
                                                   stationEndTime: [[NSString alloc] initWithUTF8String: step->tag_stopTime]
                                                            uutio:[[NSString alloc] initWithUTF8String: pdca->tag_uutio]
                                                    CSVTESTResult:strVlue
                                                 IsAttributesType:pdca->tag_IsAttribute];
            break;
        }
            
        default:
        {
            int i = 0;
            int len = strlen(step->tag_Result);
            int j = 0;
            char *Retust = malloc(len+1);
            memset(Retust,0,len+1);
            while(i < len && j < 256)
            {
                 if(step->tag_Result[i] != ' ')
                 {
                     Retust[j] = step->tag_Result[i];
                     j++;
                 }
                i++;
            }
            test = [[TestAttributes alloc] initWithTestAttributes:[[NSString alloc] initWithUTF8String: station->tag_Name]
                                                      subTestName:[[NSString alloc] initWithUTF8String: step->tag_stepName]
                                                       lowerLimit:[[NSString alloc] initWithUTF8String: "NA"]
                                                       upperLimit:[[NSString alloc] initWithUTF8String: "NA"]
                                                       testResult:[[NSString alloc] initWithUTF8String: Result]
                                                        testValue:[[NSString alloc] initWithUTF8String: Retust]
                                                          message:@""
                                                         priority:@"1"
                                                 stationStartTime:[[NSString alloc] initWithUTF8String: step->tag_stratTime]
                                                   stationEndTime: [[NSString alloc] initWithUTF8String: step->tag_stopTime]
                                                            uutio:[[NSString alloc] initWithUTF8String: pdca->tag_uutio]
                                                    CSVTESTResult:[[NSString alloc] initWithUTF8String: Retust]
                                                 IsAttributesType:pdca->tag_IsAttribute];
            free(Retust);
            break;
        }
            
            
    }
    return test;
}


-(TestAttributes*)CSVStepToTestAttributes:(LpStep) step PDCA:(pdcaValue)pdca1 STATION:(lpStation) station
{
    
    TestAttributes *test;
    char *Result = "0";
    char *pass = step->tag_pdcaValue.tag_strPassFail;//ISPass(pdca);

    pdcaValue pdca = &step->tag_pdcaValue;
    if(pass[0] == 'P')
    {
        Result = "1";
    }
    
    switch(  pdca->tag_ValueType)
    {
        
        case  enum_pdcaValueType_string_pass://返回结果的类型 串类型
        case  enum_pdcaValueType_bool:
        {
            test = [[TestAttributes alloc] initWithTestAttributes:[[NSString alloc] initWithUTF8String: station->tag_Name]
                                                      subTestName:[[NSString alloc] initWithUTF8String: step->tag_stepName]
                                                       lowerLimit:[[NSString alloc] initWithUTF8String: ""]//原先是“”
                                                       upperLimit:[[NSString alloc] initWithUTF8String: ""]//原先是“”
                                                       testResult:[[NSString alloc] initWithUTF8String: Result]//原先是 pass or ng
                                                        testValue:[[NSString alloc] initWithUTF8String: pass]
                                                          message:@""
                                                         priority:@"1"
                                                 stationStartTime:[[NSString alloc] initWithUTF8String: step->tag_stratTime]
                                                   stationEndTime:[[NSString alloc] initWithUTF8String: step->tag_stopTime]
                                                            uutio:[[NSString alloc] initWithUTF8String: ""]
                                                    CSVTESTResult:[[NSString alloc] initWithUTF8String: pass ]
                                                                    IsAttributesType:pdca->tag_IsAttribute
                    ];
            break;
        }
        case  enum_pdcaValueType_SnRead://返回结果的类型 串类型
        case  enum_pdcaValueType_string_Value:
        {
            test = [[TestAttributes alloc] initWithTestAttributes:[[NSString alloc] initWithUTF8String: station->tag_Name]
                                                      subTestName:[[NSString alloc] initWithUTF8String: step->tag_stepName]
                                                       lowerLimit:[[NSString alloc] initWithUTF8String: ""]//原先是“”
                                                       upperLimit:[[NSString alloc] initWithUTF8String: ""]//原先是“”
                                                       testResult:[[NSString alloc] initWithUTF8String: Result]//原先是 pass or ng
                                                        testValue:[[NSString alloc] initWithUTF8String: step->tag_Result]
                                                          message:@""
                                                         priority:@"1"
                                                 stationStartTime:[[NSString alloc] initWithUTF8String: step->tag_stratTime] stationEndTime:
                    [[NSString alloc] initWithUTF8String: step->tag_stopTime]
                                                            uutio:[[NSString alloc] initWithUTF8String: ""]
                                                    CSVTESTResult:[[NSString alloc] initWithUTF8String: step->tag_Result ]
                                                                    IsAttributesType:pdca->tag_IsAttribute
                    ];
            break;
        }
        case  enum_pdcaValueType_double:
    
        {
             NSString *strVlue = [[NSString alloc] initWithFormat:@"%s",pdca->tag_Value];
          
          
            test = [[TestAttributes alloc] initWithTestAttributes:[[NSString alloc] initWithUTF8String: station->tag_Name]
                                                      subTestName:[[NSString alloc] initWithUTF8String: step->tag_stepName]
                                                       lowerLimit:[[NSString alloc] initWithUTF8String: pdca->tag_Min]
                                                       upperLimit:[[NSString alloc] initWithUTF8String: pdca->tag_Max]
                                                       testResult:[[NSString alloc] initWithUTF8String: Result]
                                                        testValue: strVlue
                                                          message:@""
                                                         priority:@"1"
                                                 stationStartTime:[[NSString alloc] initWithUTF8String: step->tag_stratTime] stationEndTime:
                    [[NSString alloc] initWithUTF8String: step->tag_stopTime]
                                                            uutio:[[NSString alloc] initWithUTF8String: pdca->tag_uutio]
                                                    CSVTESTResult:strVlue
                                                  IsAttributesType:pdca->tag_IsAttribute];
            break;
        }
        
        case  enum_pdcaValueType_string_Set://返回结果的类型 串类型
            test = [[TestAttributes alloc] initWithTestAttributes:[[NSString alloc] initWithUTF8String: station->tag_Name]
                                                      subTestName:[[NSString alloc] initWithUTF8String: step->tag_stepName]
                                                       lowerLimit:[[NSString alloc] initWithUTF8String: ""]
                                                       upperLimit:[[NSString alloc] initWithUTF8String: ""]
                                                       testResult:[[NSString alloc] initWithUTF8String: Result]
                                                        testValue:[[NSString alloc] initWithUTF8String: pass]
                                                          message:@""
                                                         priority:@"1"
                                                 stationStartTime:[[NSString alloc] initWithUTF8String: step->tag_stratTime] stationEndTime:
                    [[NSString alloc] initWithUTF8String: step->tag_stopTime]
                                                            uutio:[[NSString alloc] initWithUTF8String: pdca->tag_uutio]
                                                    CSVTESTResult:[[NSString alloc] initWithUTF8String: pdca->tag_csvReslut]
                                                  IsAttributesType:pdca->tag_IsAttribute];
            break;
            
    }
    return test;
}

-(NSMutableArray*)CSVGetTestAttributesArray:(int)snIndex
{
    NSMutableArray *TestAttributesArray = [[NSMutableArray alloc] init];
    for(int i = 0;i < g_sConfig->tag_stationManage.tag_totalCount;i++)
    {
        lpStation lpst = &g_sConfig->tag_stationManage.tag_Station[i];
        if(lpst->tag_snIndex == snIndex && snIndex >=0 )
        {
            for(int j = 0; j < lpst->tag_totalCount;j++)
            {
                LpStep lpstep = &lpst->tag_step[j];
                if(lpstep->tag_isMainShow)
                {
                    if(lpstep->tag_pdca_index == 0)
                    {
                        continue;
                    }
                    pdcaValue pdca =  &g_sConfig->tag_pdcaValueManage.tag_PdcaValue[lpstep->tag_pdca_index-1];
                   
                    TestAttributes *test =   [self CSVStepToTestAttributes:lpstep PDCA:pdca STATION:lpst];
                    if(test != nil)
                    {
                        test.stationStartTime = [NSString stringWithUTF8String:lpst->tag_StartTime];
                        test.stationEndTime = [NSString stringWithUTF8String:lpst->tag_EndTime];
                        [TestAttributesArray addObject:test];
                    }
                    
                }
            }
        }
    }
    return TestAttributesArray;
}

-(NSMutableArray*)PDCAGetTestAttributesArray:(int)snIndex
{
    NSMutableArray *TestAttributesArray = [[NSMutableArray alloc] init];
    for(int i = 0;i < g_sConfig->tag_stationManage.tag_totalCount;i++)
    {
        lpStation lpst = &g_sConfig->tag_stationManage.tag_Station[i];
        if(lpst->tag_snIndex == snIndex && snIndex >=0 )
        {
            for(int j = 0; j < lpst->tag_totalCount;j++)
            {
                LpStep lpstep = &lpst->tag_step[j];
                if(lpstep->tag_isMainShow)
                {
                    if(lpstep->tag_pdca_index == 0)
                    {
                        continue;
                    }
                    pdcaValue pdca =  &g_sConfig->tag_pdcaValueManage.tag_PdcaValue[lpstep->tag_pdca_index-1];
                    if(pdca->tag_ValueType !=   enum_pdcaValueType_double && pdca->tag_IsAttribute == 0)
                    {
                         continue;
                    }
                    TestAttributes *test =   [self PDCAStepToTestAttributes:lpstep PDCA:pdca STATION:lpst];
                    if(test != nil)
                    {
                        
                        test.stationStartTime = [NSString stringWithUTF8String:lpst->tag_StartTime];
                        test.stationEndTime = [NSString stringWithUTF8String:lpst->tag_EndTime];
                        [TestAttributesArray addObject:test];
                    }
                    
                }
            }
        }
    }
    return TestAttributesArray;
}

-(void) InstantPuddingWrapper:(NSMutableArray *)results SN:(NSString*)sn FILEARRAY:(NSMutableArray *) fileNameArray
{
    InstantPuddingWrapper *PDCAIN = [[InstantPuddingWrapper alloc] init];
    
    
    
    /*
     n个结果
     */
    
    NSMutableDictionary* properties  =  [[NSMutableDictionary alloc] init];
    
    
    
    /*
     工位信息
     */
    
    properties =  [NSMutableDictionary dictionaryWithObjectsAndKeys:[NSString stringWithUTF8String:IP_ATTRIBUTE_SERIALNUMBER],
                   [NSString stringWithUTF8String:IP_ATTRIBUTE_STATIONSOFTWARENAME],
                   [NSString stringWithUTF8String:IP_ATTRIBUTE_STATIONIDENTIFIER],
                   [NSString stringWithUTF8String:IP_ATTRIBUTE_STATIONSOFTWAREVERSION],
                   [NSString stringWithUTF8String:IP_ATTRIBUTE_STATIONLIMITSVERSION],
                   [NSString stringWithUTF8String:IP_ATTRIBUTE_STATIONSUBIDENTIFIER],nil];
    
    [properties setValue:sn forKey:[NSString stringWithUTF8String:IP_ATTRIBUTE_SERIALNUMBER]];
    [properties setValue:[[NSString alloc]initWithUTF8String:  g_sConfig->tag_SysIni.tag_softwarename]
                  forKey:[NSString stringWithUTF8String:IP_ATTRIBUTE_STATIONSOFTWARENAME]];
    [properties setValue: [[NSString alloc]initWithUTF8String: g_sConfig->tag_SysIni.tag_station_id]
     forKey:[NSString stringWithUTF8String:IP_ATTRIBUTE_STATIONIDENTIFIER]];
    
   // [properties setValue:sn forKey:[NSString stringWithUTF8String:IP_ATTRIBUTE_FIXTURE_ID]];
  
  
    
    [properties setValue: [[NSString alloc]initWithUTF8String: g_sConfig->tag_SysIni.tag_softwareversion]
                  forKey:[NSString stringWithUTF8String:IP_ATTRIBUTE_STATIONSOFTWAREVERSION]];
    [properties setValue: [[NSString alloc]initWithUTF8String: g_sConfig->tag_SysIni.tag_limitsversion]
                  forKey:[NSString stringWithUTF8String:IP_ATTRIBUTE_STATIONLIMITSVERSION]];
    [properties setValue:[[NSString alloc]initWithUTF8String: g_sConfig->tag_SysIni.tag_sub_station]
                  forKey:[NSString stringWithUTF8String:IP_ATTRIBUTE_STATIONSUBIDENTIFIER]];
    
    //此函数为提交pdca函数
    
    [ PDCAIN submitTestResultsToInstantPudding:results stationProperties:(NSMutableDictionary*)properties FILEARRAY:fileNameArray ];
}

extern char *GetCurrentDataCtr();
extern char *GetCurrentTimeCtr();
extern  void csvwrite(char *file,char *buffer);

-(void) csvSave:(NSMutableArray *)results SN:(NSString*)sn
{
    
    NSString *fileName = [[NSString alloc] initWithFormat:@"%s%s.csv",g_sConfig->tag_SysIni.tag_csvDir ,GetCurrentDataCtr()];
    
    char *log = malloc(1024*10);
    int i = 0;
    if(!log)
        return ;
    memset(log,0,1024*10);
    
    strcat(log,GetCurrentTimeCtr());
    strcat(log,",");
    strcat(log,[sn  UTF8String]);
    strcat(log,",");
    strcat(log,g_sConfig->tag_SysIni.tag_station_id);
    strcat(log,",");
    
    if([results count])
    {
        TestAttributes * testItem;
        for(testItem in results)
        {
            // char *GetTestValue
            //   strcat(log,[[testItem GetTestValue ] UTF8String]);
            strcat(log,",");
        }
    }
    strcat(log,"\r\n");
    csvwrite([fileName UTF8String ],log);
    
    free(log);
    
}

void GetSfcSn(const char *sn,void *p)
{
    //8O2GMIW0216450
    //NSString *str_SN = [NSString stringWithUTF8String:sn];
    
    // return ;
        //NSURLRequest *requset = [NSURLRequest requestWithURL:[NSURL URLWithString:@""]];
//    http://172.16.1.139/BobcatService.svc/request?sn=8O2GMIW0216450&c=QUERY_RECOR
 //   D&tsid=CWNJ_C02-2FAP-28_1_DFU&p=unit_process_check
    
    //8O2GMIW0216450&c=QUERY_RECOR
    
    NSString *URL = [[NSString alloc] initWithFormat:@"http://172.16.1.139/BobcatService.svc/request?sn=%s&c=QUERY_RECORD&tsid=CWNJ_C02-2FAP-28_1_DFU&p=unit_process_check",gloabe_sn[21]];
    
    
    NSString *URL2 = [[NSString alloc] initWithFormat:@"http://172.16.1.139/BobcatService.svc/request?sn=%s&c=QUERY_RECORD&p=BNSN",gloabe_sn[21]];
    
    NSURLRequest *requset = [NSURLRequest requestWithURL:[NSURL URLWithString:URL] cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:5];
    NSData *data = [NSURLConnection sendSynchronousRequest:requset returningResponse:nil error:nil];
    NSString *str =[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    
    if ([str containsString:@"check=OK"])
    {
        requset = [NSURLRequest requestWithURL:[NSURL URLWithString:URL2]];
        data = [NSURLConnection sendSynchronousRequest:requset returningResponse:nil error:nil];
        str =[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSArray *arr = [[str componentsSeparatedByString:@"\n"].lastObject componentsSeparatedByString:@";"];
        NSMutableArray<NSString *> *arrM = [NSMutableArray arrayWithArray:arr];
        [arrM removeLastObject];
        
        
        
        for (int i = 0; i < arrM.count; i ++ )
        {
            memset(gloabe_sn[i], 0, 100);
            strcat(gloabe_sn[i], arrM[i].UTF8String);
            AddLog(gloabe_sn[i]);
        }
    }
    
    for (int i = 0; i < 20; i ++)
    {
        NSLog(@"======%s",gloabe_sn[i]);
    }
    
    
}

char g_temp_file [512];

int sysTestRead( FILE * f,char *buf,int len )
{
    int i = 0;
    while(i < len)
    {
        if(fread(&buf[i], 1, 1, f)>0)
        {
            
        }
        else
        {
            break;
        }
        i++;
    }
    return i;
}


void systemTest(char *array)
{
   // system("chmod -R 777 vault/scriptFile/scpreceive.sh");
    //system(array);
    //return ;//
    
    NSLog(@"%s",array);
    FILE * f =  popen(array, "r+");
    char buffer[1024] = {0};
    int readlen = 0;
  AddLog(array);
    if(f)
    {
        memset(buffer,0,1024);
        readlen = fread(buffer, 1024, 1, f);
        AddLog("11111");
        AddLog(buffer);
     
        if(readlen >0)
           {
               if(strstr(buffer,"password"))
               {
                   readlen = fwrite("123456\n", 1, 7, f);
                   memset(buffer,0,512);
                   readlen = fread(buffer, 1024, 1, f);
                   AddLog("22222");
                   AddLog(buffer);
                   
               }
               else
               {
                   
               }
           }
  
        pclose(f);
    }
   //  extern  void NSThreadsleep(int delay);
   // NSThreadsleep(10000);

   
   // system(array);
    //NSAppleScript *app = [[NSAppleScript alloc] initWithSource:[[NSString alloc] initWithUTF8String:array]];
    //NSDictionary<NSString *, id> *error = [[NSDictionary<NSString *, id> alloc] init];
    //[app executeAndReturnError:&error];
   
    
}

-(void) GetFileName:(char *)NewFile OrdFIleName:(char *)OldFile
{
    int len = strlen(OldFile);
    int m = 0;
    if(len <1)
        return ;
    for(int j =len-1; j >=0;j--)
    {
        if(OldFile[j] == '/')
        {
            m = j;
        }
    }
    for(int j =m; j < len;j++)
    {
        NewFile[j-m] = OldFile[j] ;
        
    }
    
}
-(NSString *)GetUpdataFileNameLog:(int) snindex
{
    char fileName[512] = {0};
    memset(fileName,0,512);
    for(int i = 0;i < g_sConfig->tag_stationManage.tag_totalCount;i++)
    {
        lpStation station = &g_sConfig->tag_stationManage.tag_Station[i];
        if (station->tag_snIndex == snindex)
        {
            int m = 0;
            // strcat(fileName, g_sConfig->tag_stationManage.tag_Station[i].tag_LogFile);
            [self GetFileName:fileName OrdFIleName:g_sConfig->tag_stationManage.tag_Station[i].tag_logFile];
            break;
            
        }
    }
    return [[NSString alloc] initWithUTF8String:fileName];
}
-(NSString *)GetUpdataFileNameArmTxt:(int) snindex
{
    char fileName[512] = {0};
    memset(fileName,0,512);
    for(int i = 0;i < g_sConfig->tag_stationManage.tag_totalCount;i++)
    {
        lpStation station = &g_sConfig->tag_stationManage.tag_Station[i];
        if (station->tag_snIndex == snindex)
        {
            int m = 0;
            // strcat(fileName, g_sConfig->tag_stationManage.tag_Station[i].tag_LogFile);
            [self GetFileName:fileName OrdFIleName:g_sConfig->tag_stationManage.tag_Station[i].tag_ArmFile];
            break;
            
        }
    }
    return [[NSString alloc] initWithUTF8String:fileName];
}
-(NSString *)GetUpdataFileNameDutTxt:(int) snindex
{
    char fileName[512] = {0};
    int i =0;
    memset(fileName,0,512);
    for(int i = 0;i < g_sConfig->tag_stationManage.tag_totalCount;i++)
    {
        lpStation station = &g_sConfig->tag_stationManage.tag_Station[i];
        if (station->tag_snIndex == snindex)
        {
            int m = 0;
            // strcat(fileName, g_sConfig->tag_stationManage.tag_Station[i].tag_LogFile);
            [self GetFileName:fileName OrdFIleName:g_sConfig->tag_stationManage.tag_Station[i].tag_DutFile];
            break;
            
        }
    }
    
    
    return [[NSString alloc] initWithUTF8String:fileName];
}
-(NSString *) ArrayfileToZip:(NSMutableArray *) ArrayFile  SN:(char *)Sn
{
    //"zip -j"
    extern char *GetCurrentTimeCtrA();
    char *strZipcomm = malloc(1024*10);
    memset(strZipcomm,0,1024*10);
    char * GetCurrentDataCtr_= (char*)GetCurrentDataCtr();
    char * GetCurrentTimeCtrA_= (char*)GetCurrentTimeCtrA();
    NSString *ZipCommand = [[NSString alloc] initWithFormat:@"zip -j %s/%s/%s_%s_log.zip  ",
                            g_sConfig->tag_SysIni.tag_logDir,
                            GetCurrentDataCtr_ ,
                            Sn,
                            GetCurrentTimeCtrA_];
    
    NSString *ZipFifle = [[NSString alloc] initWithFormat:@"%s/%s/%s_%s_log.zip",g_sConfig->tag_SysIni.tag_logDir,GetCurrentDataCtr_,Sn,GetCurrentTimeCtrA_];
    strcat(strZipcomm,[ZipCommand UTF8String]);
    NSString *Filename = nil;
    for( Filename in ArrayFile)
    {
        strcat(strZipcomm," ");
        strcat(strZipcomm,[Filename UTF8String]);
    }
    system(strZipcomm);
    free(strZipcomm);
    return ZipFifle;
}
-(void )ZipUpdataFileName:(char *)fileName
{
    return ;
    extern int FileIshave( char *file);
    memset(g_temp_file,0,512);
    strcat(g_temp_file,"zip -j ");
    strcat(g_temp_file, fileName);
    g_temp_file[strlen(g_temp_file) -3] = 'z';
    g_temp_file[strlen(g_temp_file) -2] = 'i';
    g_temp_file[strlen(g_temp_file) -1] = 'p';
    g_temp_file[strlen(g_temp_file) -0] = ' ';
    strcat(g_temp_file,"  ");
    if(FileIshave(fileName))
    {
        strcat(g_temp_file, fileName);
        system(g_temp_file);
    }
    
}
void  FileNameToZipName(char *newFile,int newFileLen, char *old)
{
    int i = 0;
    int len = strlen(old);
    while(i < len && i < newFileLen -4)
    {
        newFile[i] = old[i];
        /* if(old[i] == '.')
         {
         break;
         }*/
        i++;
    }
    //strcat(newFile,"zip");
    
}



void PdcaUpData()
{
    
    NSMutableArray *CSVTestArray = [[NSMutableArray alloc] init];
    NSMutableArray *PDVATestArray = [[NSMutableArray alloc] init];
    int n = 0; //int n = 0;  fch
    int sn[100] = {0};
    
    
    
    int j = 0;
    InstantPuddingWrapper *inpw =[[InstantPuddingWrapper alloc] init];
    
    
    if(g_sConfig->tag_stationManage.tag_WorkStop == 1)
    {
        return ;
    }
    
    for(int i =0 ;i < 100;i++)
    {
        sn[i] =-1;
    }
    
    for(int i = 0;i < g_sConfig->tag_stationManage.tag_totalCount;i++)
    {
        lpStation station = &g_sConfig->tag_stationManage.tag_Station[i];
        if (station->tag_stationType == enum_station_type_work &&  station->tag_snIndex<20 &&  station->tag_snIndex >= 0 && station->tag_isEnable)
        {
            [inpw AddSnIndex:g_sConfig->tag_stationManage.tag_Station[i].tag_snIndex SNARRAY:sn LEN:100];
        }
    }
    while(n <100 && sn[n] != -1)
    {
        NSMutableArray *CSVtest = [inpw  CSVGetTestAttributesArray:sn[n]];
        NSMutableArray *PDCAtest = [inpw  PDCAGetTestAttributesArray:sn[n]];
        [CSVTestArray addObject:CSVtest];
        [PDVATestArray addObject:PDCAtest];
        n++;
    }

    j = 0;
    if(PDVATestArray.count >0)
    {
        NSMutableArray *array;
        for( array in PDVATestArray)
        {
            if(sn[j] <20 && sn[j] >= 0)
            {
                [SRFileTool writeResultToCSV:CSVTestArray[j] SN:[[NSString alloc] initWithUTF8String: gloabe_sn[sn[j]]]];
                char *log  = [SRFileTool writeResultToFixtureLog:CSVTestArray[j] SN:gloabe_sn[sn[j]]];
                NSString *LogFile = [[NSString alloc] initWithUTF8String:log];
                NSString *ArmFile =  [inpw GetUpdataFileNameArmTxt: sn[j]];
                NSString *DutFile =  [inpw GetUpdataFileNameDutTxt: sn[j]];
                NSMutableArray *FileNameArray = [[NSMutableArray alloc ] init];
                if(LogFile.length >0)
                {
                    
                    char zipname[512] = {0};
                    memset(zipname,0,512);
                    [inpw ZipUpdataFileName:[LogFile UTF8String] ];
                    FileNameToZipName(zipname,511,[LogFile UTF8String]);
                    [FileNameArray addObject:[[NSString alloc] initWithUTF8String:zipname]];
                }
                if(ArmFile.length >0)
                {
                    
                    [FileNameArray addObject:ArmFile];
                }
                if(DutFile.length >0)
                {
                    char zipname[512] = {0};
                    memset(zipname,0,512);
                    [inpw ZipUpdataFileName:[DutFile  UTF8String]];
                    FileNameToZipName(zipname,511,[DutFile UTF8String]);
                    [FileNameArray addObject:[[NSString alloc] initWithUTF8String:zipname]];
                }
                NSString *file =  [inpw ArrayfileToZip:FileNameArray SN:gloabe_sn[sn[j]]];
                NSMutableArray *FileZipArray = [[NSMutableArray alloc] init];
                [FileZipArray addObject:file];
                if(strlen(gloabe_sn[sn[j]]) >0 &&  g_sConfig->tag_SysIni.tag_IsPdcaUpdata != 0)
                {
               [inpw InstantPuddingWrapper:array SN:[[NSString alloc] initWithUTF8String: gloabe_sn[sn[j]] ]  FILEARRAY:FileZipArray];
                }
            }
            j++;
        }
    }
    return ;
}

void PdcaUpDataTEST()
{

    NSMutableArray *PDVATestArray = [[NSMutableArray alloc] init];
   
    InstantPuddingWrapper *inpw =[[InstantPuddingWrapper alloc] init];

    [inpw GetStationInfo];
}



@end
