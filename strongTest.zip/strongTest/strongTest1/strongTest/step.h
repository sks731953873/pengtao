//
//  step.h
//  strongTest
//
//  Created by strong on 2017/12/15.
//  Copyright © 2017年 strong. All rights reserved.
//

#ifndef step_h
#define step_h

#include <stdio.h>
#include <pthread.h>
#include "PDCA.h"
#define MAXSTATION 25//工位的最大工位
#define MAXSTEP 512//步骤的最大条数
#define MAXNAME 128//名称的最大值
#define MAXRESULT 1024*10
#define MAXfiltration 128//拦截的最大值
#define COMMANDMAXLEN 1024//命令的最大长度

#include "socket.h"
typedef int (*_exe_fun)(void *objext);

typedef enum enum_step_run_result
{
    enum_step_run_result_ok,
    enum_step_run_result_no_Ip,
    enum_step_run_result_len_0,
    enum_step_run_result_SocErr,
    enum_step_run_result_ReadLen0,
    enum_step_run_result_Stop,
};

/*
 步骤执行的命令类型
 */
typedef enum _enum_commandType
{
    enum_commandType_SOCKET,//socket 通信命令
    enum_commandType_SCRIPT,//脚本命令
    enum_commandType_PORT,//串口命令
    enum_commandType_SOCKET_READIO_1,//io读socket 1有效
    enum_commandType_SOCKET_READIO_0,//io读socket 0有效
    enum_commandType_SOCKET_SETIO,//io设置
    enum_commandType_waitBeforeFinish,// 等待本步之前的所有步骤完成s
    enum_commandType_socketRead,// 读数据
    enum_commandType_socketCelan,//
    enum_commandType_SnWrite,//写
    enum_commandType_SnRead,//读
    enum_commandType_SFC_SN,//sfc获取sn数组
    enum_commandType_delay,//sfc获取sn数组
    enum_commandType_fileMove,//sfc获取sn数组
    enum_commandType_AlgorithmRead,//读取算法结果
    enum_commandType_SocketTemp//温度测试
    
}enum_commandType;

typedef enum _algorithmType
{
    enum_algorithmType_None,
    enum_algorithmType_avgX,
    enum_algorithmType_avgY,
    enum_algorithmType_avgZ,
    enum_algorithmType_sqrtX,
    enum_algorithmType_sqrtY,
    enum_algorithmType_sqrtZ,
}enum_algorithmType;

typedef struct _step
{
    unsigned char tag_Data1[COMMANDMAXLEN];//保护
    enum_commandType tag_type;//动作类型
    enum_algorithmType tag_algorithmType;//算法类型
    int tag_exctimes;//执行次数,真实的执行次数需要在此基础上加1
    _exe_fun tag_beginFun;//在之前执行的代码
    _exe_fun tag_Exe;//执行的代码
    _exe_fun tag_EndFun;//在之后执行的代码
    int tag_SleepDate;//延时时间
    void *tag_user;//
    int tag_SucNextStep;//成功后，跳转到那一步，
    int tag_failNextStep;//失败后跳转到哪一步
    int tag_enable;//是否屏蔽
    int tag_pdca_index;//pdca索引号
    int  tag_socket_index;//对应的socket id号，供选择默认位0，既是不选择;
    int tag_workState;//工作状态
    int tag_isThread;//是否线程执行 1，表示是线程执行
    int  tag_port_index;//对应的port id号，供选择默认位0，既是不选择;
    int tag_isMainShow;//主 界面是否显示
    int tag_readEnterKey;

    char tag_stepName[MAXNAME];//步名
    char tag_sendCommand[COMMANDMAXLEN];//发送的命令
    char tag_filtrationBegin[MAXfiltration];
    char tag_filtrationEnd[MAXfiltration];
    char tag_stratTime[MAXNAME];
    char tag_stopTime[MAXNAME];
    char tag_ReadEndFlage[MAXRESULT];
    char tag_Result[MAXRESULT];//读取的数据
    PdcaValue tag_pdcaValue;
    unsigned char tag_Data[COMMANDMAXLEN-4-4-4-4];//以后所有要加的保存参数，在这之前加，保证数据大小一样大ß
    
}Step,*LpStep;

/*******************************************************************************************
 **函数名：StepRun
 **参数：,(Step *step)
 ipConfig soc)
 **功能： 单步执行
 **返回值：< 0失败
 *******************************************************************************************/
int StepRun(Step *step);

#endif /* step_h */
