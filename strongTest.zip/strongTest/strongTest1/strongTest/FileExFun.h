//
//  FileBase.h
//  TestResistance
//
//  Created by TOD on 6/26/14.
//  Copyright (c) 2014 CeWay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FileExFun : NSObject
+(NSString *) getSendOfCh  :(NSString *) strCH:(NSString *) strType;

//void StringToInt();
+(BOOL) ContainStr:(NSString *) string BEGIN:(NSString *) begin;
+(NSString *) GetSubLast:(NSString *) string BEGIN:(NSString *) begin;
+(NSString *) GetSubPrevious:(NSString *) string BEGIN:(NSString *) begin LEN:(int ) len;
+(NSString *) GetSubLast:(NSString *) string BEGIN:(NSString *) begin;
+(NSString *) CtrGetSubLast:(char *) cStr BEGIN:(char *) cbegin;

+(NSString *) CtrGetSubLenght:(char *) cStr BEGIN:(char *) cbegin  LEN:(int) len;
+(NSString *) GetSubLenght:(NSString *) string BEGIN:(NSString *) begin  LEN:(int) len;
+(NSString *) CtrGetSub:(char *) cStr BEGIN:(char *) cbegin  END:(char *) cend;
+(NSString *) GetSub:(NSString *) string BEGIN:(NSString *) begin  END:(NSString *) end;
+(void) InitFWDL;


+(void)AFileDelete;
+(void)AFileMove;
+(void)ADiretoryCreate;
+(BOOL)ADiretoryExist :(NSString *) filePath;

@end
