//
//  work.h
//  strongTest
//
//  Created by strong on 2017/12/26.
//  Copyright © 2017年 strong. All rights reserved.
//

#ifndef work_h
#define work_h

#include <stdio.h>
#include "Config.h"
#include "step.h"
/*******************************************************************************************
 **函数名：workInit
 **参数：,(void *p)
 ipConfig soc)
 **功能： 初始化
 **返回值：< 0失败
 *******************************************************************************************/
extern void workInit(void *p);
#endif /* work_h */
