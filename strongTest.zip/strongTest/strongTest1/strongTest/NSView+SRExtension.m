//
//  UIView+srExtension.m
//  5期-百思不得姐
//
//  Created by xiaomage on 15/11/6.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "NSView+SRExtension.h"

@implementation NSView (SRExtension)

- (CGSize)sr_size
{
    return self.frame.size;
}

- (void)setSr_size:(CGSize)sr_size
{
    CGRect frame = self.frame;
    frame.size = sr_size;
    self.frame = frame;
}

- (CGFloat)sr_width
{
    return self.frame.size.width;
}

- (CGFloat)sr_height
{
    return self.frame.size.height;
}

- (void)setSr_width:(CGFloat)sr_width
{
    CGRect frame = self.frame;
    frame.size.width = sr_width;
    self.frame = frame;
}

- (void)setSr_height:(CGFloat)sr_height
{
    CGRect frame = self.frame;
    frame.size.height = sr_height;
    self.frame = frame;
}

- (CGFloat)sr_x
{
    return self.frame.origin.x;
}

- (void)setSr_x:(CGFloat)sr_x
{
    CGRect frame = self.frame;
    frame.origin.x = sr_x;
    self.frame = frame;
}

- (CGFloat)sr_y
{
    return self.frame.origin.y;
}
- (void)setSr_y:(CGFloat)sr_y
{
    CGRect frame = self.frame;
    frame.origin.y = sr_y;
    self.frame = frame;
}

- (CGFloat)sr_right
{
//    return self.sr_x + self.sr_width;
    return CGRectGetMaxX(self.frame);
}

- (CGFloat)sr_bottom
{
//    return self.sr_y + self.sr_height;
    return CGRectGetMaxY(self.frame);
}

- (void)setSr_right:(CGFloat)sr_right
{
    self.sr_x = sr_right - self.sr_width;
}

- (void)setSr_bottom:(CGFloat)sr_bottom
{
    self.sr_y = sr_bottom - self.sr_height;
}
@end
