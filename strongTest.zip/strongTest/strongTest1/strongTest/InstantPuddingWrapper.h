 //
//  InstantPuddingWrapper.h
//
//  Created by MS 02/23/10.
//  Copyright 2010 Apple, Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "TestAttributes.h"
#import "InstantPudding_API.h"

@protocol InstantPuddingWrapper

//-(InstantPuddingWrapper *)sharedInstance;
-(void) loadInstantPudding;

- (int) submitTestPassFailToInstantPudding:(NSMutableArray*)results stationProperties:(NSMutableDictionary*)properties result:(BOOL) inPassFail;
- (int) submitTestResultsToInstantPudding:(NSMutableArray*)results stationProperties:(NSMutableDictionary*)properties;
- (int) setAttributesForStation:(NSString*)stationIdentifier  subStation:(NSString*) subStationIdentifier softwareName:(NSString*)softwareName softwareVersion:(NSString *)softwareVersion stationLimitsVersion:(NSString*)stationLimitsVersion DUTSerialNumber:(NSString*)DUTSerialNumber;

- (int) setAttributesForStation:(NSString*)stationIdentifier  softwareName:(NSString*)softwareName softwareVersion:(NSString *)softwareVersion stationLimitsVersion:(NSString*)stationLimitsVersion DUTSerialNumber:(NSString*)DUTSerialNumber;
- (int) setAttributesSerialNumber:(NSString*)DUTSerialNumber;
//deprecated
- (int) addTestAttributes:(NSString*)testName subTestName:(NSString*)subTestName lowerLimit:(NSString*)lowerLimit upperLimit:(NSString*)upperLimit testResult:(NSString*)testResult testValue: (NSString*)testValue failMessage:(NSString*)failMessage priority:(NSString*)priority;

- (int) addTestAttributes:(NSString*)testName subTestName:(NSString*)subTestName lowerLimit:(NSString*)lowerLimit upperLimit:(NSString*)upperLimit testResult:(NSString*)testResult testValue: (NSString*)testValue message:(NSString*)message priority:(NSString*)priority;
- (int) addAttributesExtra:(NSDictionary*)inAttributesDict;

- (int) addBlobWithFileName:(NSString *) inBlobFileName pdcaBlobName: (NSString *) inPDCABlobName;
- (int) verifyFatalError;
- (int) commitResutsWithPassFail:(BOOL) inPassFail;
- (int) commitResuts;
- (int) sendStationFailureReport:(NSString*) strFailureStep strFailureReason: (NSString*)strFailureReason;
- (int) addModuleHistory:(NSString*) strModuleSerialNumber strVendorCode: (NSString*) strVendorCode strDateCode:(NSString*) strDateCode strPartNum:(NSString*)strPartNum strDescription:(NSString*) strDescription strLotCode:(NSString*) strLotCode;
- (int) getGHStationInfo:(enum IP_ENUM_GHSTATIONINFO)eGHStationInfo strValue:(NSString*)strValue UID:( IP_UUTHandle) uid;

- (int) getVersion:(NSString **) ipVersion;
- (int) UUTCancel;
- (int) amIOkay : (NSString *) serialNumber;
- (int) setStartTime: (time_t) rawTimeToUse ;
- (int) setStopTime:  (time_t) rawTimeToUse ;

- (void) dealloc;
// 2. insert attributes
// return -1 if fail. 0 if OK.
// ap_name: please refer to "InstantPudding_API.h"
-(int) IP_insertAttribute: (IP_UUTHandle)a_UID name:(const char *)ap_name
                     attr: (NSString *)ap_attr;
@end


#define kIPFatalError		@"IPFatalError"
#define kStationName		@"StationName"
#define kSoftwareVersion	@"SoftwareVersion"
#define kSoftwareLimits		@"SoftwareLimits"
#define kStationIdentifier	@"StationIdentifier"
#define kDUTSerialNumber	@"DUTSerialNumber"

#define kAttributeKey		@"AttributeKey"
#define kAttributeValue		@"AttributeValue"

@interface InstantPuddingWrapper : NSObject {
    NSString* ipStationName;
    NSString* ipSubStationName;
    NSString* ipSoftwareVersion;
    NSString* ipSoftwareLimits;
    NSString* stationProperties;
    NSString* dutSerialNumber;
    NSMutableDictionary * stationAttributes;
    NSMutableArray * stationAttributesExtra;
    
    NSMutableArray * testList;
    
    NSMutableArray * blobList;
    IP_UUTHandle UIDHandle;
    
    BOOL	testPass;
    
}


-(InstantPuddingWrapper *)sharedInstance;

@property (readwrite, copy)  NSString *ipStationName;
@property (readwrite, copy)  NSString *ipSubStationName;
@property (readwrite, copy)  NSString *ipSoftwareLimits;
@property (readwrite, copy)  NSString *ipSoftwareVersion;
@property (readwrite, copy)  NSString *stationProperties;
@property (readwrite, copy)  NSString *dutSerialNumber;
@property (readwrite, copy)  NSMutableArray * testList;
@property (readwrite, retain) NSMutableArray * blobList;
@property (readwrite, retain) NSMutableDictionary * stationAttributes;
@property (readwrite, retain) NSMutableArray * stationAttributesExtra;
- (id)init;
- (int)submitTestResultsToInstantPudding:(NSMutableArray*)results stationProperties:(NSMutableDictionary*)properties FILEARRAY:(NSMutableArray *) fileNameArray;

- (void) dealloc;
-(NSString *)GetUpdataFileNameLog:(int) snindex;
-(NSString *)GetUpdataFileNameArmTxt:(int) snindex;
-(NSString *)GetUpdataFileNameDutTxt:(int) snindex;
-(void )ZipUpdataFileNameDutTxt:(int) snindex;
-(void )ZipUpdataFileNameArmTxt:(int) snindex;
-(void )ZipUpdataFileNameLog:(int) snindex;
-(void )ZipUpdataFileName:(char *)fileName;

void PdcaUpData();
-(int) IP_insertTestItemAndResult:(IP_UUTHandle) a_UID
                         TestName:  (NSString *)ap_TestName
                         LowLimit:  (NSString *)       ap_LowLimit
                          UpLimit:  (NSString *)       ap_UpLimit
                            Units:  (  char *)                                ap_Units
                         Priority:  (int)                                  ap_Priority
                        testValue:  (NSString *) ap_testValue
                      testMessage:  (NSString *)    ap_testMessage
                           isPass:  (bool)  isPass;

-(int) IP_insertAttribute: (IP_UUTHandle)a_UID name:(const char *)ap_name
                     attr: (NSString *)ap_attr;
-(int)IP_addFile:(IP_UUTHandle) a_UID FILENAME: (NSString *)input Description: (NSString *)description;
-(NSString *) ArrayfileToZip:(NSMutableArray *) ArrayFile  SN:(char *)Sn;
@end
