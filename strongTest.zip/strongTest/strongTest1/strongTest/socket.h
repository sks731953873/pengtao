//
//  socket.h
//  strongTest
//
//  Created by strong on 2017/12/19.
//  Copyright © 2017年 strong. All rights reserved.
//

#ifndef socket_h
#define socket_h

#include <stdio.h>
#include <sys/socket.h> // AF_INET, AF_INET6
#include <netinet/in.h> // AF_INET, AF_INET6
#include <arpa/inet.h> // AF_INET, AF_INET6

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include   <netinet/tcp.h>
#include "IPConfig.h"
typedef  int *(_sockectAPi)(void  *ip);

typedef struct _CSocket
{
    int tag_id;
    ipConfig tag_ipConfig;
    int tag_sendLen;
    unsigned char tag_sendBuffer[1024*20];
    int tag_ReadLen;
    unsigned char tag_readBuffer[1024*20];
    int tag_outReadTime;
    int tag_ReadBufferIsClean;//buufer是否清零
    _sockectAPi  *sockectConnect;
    _sockectAPi *sockectSend;
    _sockectAPi *ReadDataNotClean;
    _sockectAPi *sockectRead;
    _sockectAPi *sockectReadLong;
    _sockectAPi *sockectClose;
    char *tag_sn;
    char tag_currentReadBuffer[1024*20];//用于socketreadClean，记录当前指针指向的位置
}CSocket,*cSocket;
void socketInit(cSocket soc);
#endif /* socket_h */
