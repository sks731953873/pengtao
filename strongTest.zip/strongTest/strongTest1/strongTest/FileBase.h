//
//  FileBase.h
//  TestResistance
//
//  Created by TOD on 6/26/14.
//  Copyright (c) 2014 CeWay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FileBase : NSObject

+(FileBase*)Instance;

//获取文件夹路径
-(NSString*)GetFolderPath;

//判断文件或文件夹是否存在
-(BOOL) IsExist:(NSString*)strPath isFolder:(BOOL)flag;

//判断文件是否存在
-(BOOL)isFileExist:(NSString*)strFilePath;

//判断文件夹是否存在
-(BOOL)isFileDirExist:(NSString*)strFileDirPath;

//删除文件及文件夹
-(void)RemoveFile:(NSString*)strFilePath;

//创建文件夹
-(void)CreateFolder:(NSString*)strFolder;

//创建文件
-(void)CreateLogFile:(NSString*)strFilePath;

//文件是否能够写
-(BOOL) FileCanWrite:(NSString*)strFullPath;

//判断文件是否可读
-(BOOL)FileCanRead:(NSString*)strFilePath;

//读取文件信息
-(NSString*) ReadFile:(NSString*)strFullPath;

//写字符串到文件
-(void)WriteFile:(NSString*)strFilePath andContent:(NSString*)contents IsAppend:(BOOL)isAppend;

//写字符串到文件
-(void) WriteFile:(NSString*)strFolderPath andFullPath:(NSString*)strFullPath andContent:(NSString*)contents IsAppend:(BOOL)isAppend;
@end
