//
//  SysIniView.m
//  strongTest
//
//  Created by strong on 2018/1/20.
//  Copyright © 2018年 strong. All rights reserved.
//

#import "SysIniView.h"
#include "Config.h"
@implementation SysIniView


/*******************************************************************************************
 **函数名：initWithFrame
 **参数：:(CGRect)frame
 **功能：初始化 大小
 **返回值：
 *******************************************************************************************/

+ (instancetype)loadSysIniViewNib{
    NSArray *arr = [NSArray array];
    
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([SysIniView class]) owner:nil topLevelObjects:&arr];
    
    for(id objVIew in arr)
    {
        if([objVIew isKindOfClass:[self class]])
        {
            return objVIew;
        }
    }
    return nil;
}

- (void)awakeFromNib{
    [super awakeFromNib];
    self.tag_UISfc2.stringValue = [[NSString alloc] initWithUTF8String:g_sConfig->tag_SysIni.tag_sfc];
    self.tag_UISubStation.stringValue = [[NSString alloc] initWithUTF8String:g_sConfig->tag_SysIni.tag_sub_station];;
    self.tag_UimitsVersion.stringValue = [[NSString alloc] initWithUTF8String:g_sConfig->tag_SysIni.tag_limitsversion];;
    self.tag_UiSoftwareVersion.stringValue = [[NSString alloc] initWithUTF8String:g_sConfig->tag_SysIni.tag_softwareversion];;
    self.tag_UIStation_Id.stringValue = [[NSString alloc] initWithUTF8String:g_sConfig->tag_SysIni.tag_station_id];;
    self.tag_UISoftwareName.stringValue = [[NSString alloc] initWithUTF8String:g_sConfig->tag_SysIni.tag_softwarename];;
    self.tag_UiCsvPath.stringValue = [[NSString alloc] initWithUTF8String:g_sConfig->tag_SysIni.tag_csvDir ];;
    self.tag_UIlogFilePath.stringValue = [[NSString alloc] initWithUTF8String:g_sConfig->tag_SysIni.tag_logDir ];;
    self.tag_UiScriptFilePath.stringValue = [[NSString alloc]initWithUTF8String:g_sConfig->tag_SysIni.tag_scriptDir];
    self.tag_UiCustomerBinPath.stringValue = [[NSString alloc]initWithUTF8String:g_sConfig->tag_SysIni.tag_customerBinDir];
    self.tag_armPath.stringValue = [[NSString alloc] initWithUTF8String:g_sConfig->tag_SysIni.tag_ArmDir ];
    self.tag_dutFilePath.stringValue = [[NSString alloc] initWithUTF8String:g_sConfig->tag_SysIni.tag_DutDir ];
    
    
    self.tag_UiCsvFileName.stringValue = [[NSString alloc]initWithUTF8String:g_sConfig->tag_SysIni.tag_csvFileName];
    self.tag_UilogFileName.stringValue = [[NSString alloc]initWithUTF8String:g_sConfig->tag_SysIni.tag_LogFileName];
    self.tag_ArmFileName.stringValue = [[NSString alloc]initWithUTF8String:g_sConfig->tag_SysIni.tag_ArmFileName];
    self.tag_DutFileName.stringValue = [[NSString alloc]initWithUTF8String:g_sConfig->tag_SysIni.tag_DutFileName];
    
    NSInteger index= g_sConfig->tag_SysIni.tag_SnGetMethod;
    
    if(g_sConfig->tag_SysIni.tag_SnLength == 0)
    {
        g_sConfig->tag_SysIni.tag_SnLength = 17;
    }
    
    self.tag_UiSnLength.stringValue = [[NSString alloc] initWithFormat:@"%d",g_sConfig->tag_SysIni.tag_SnLength];
    
    [ self.tag_UISFCGET selectItemAtIndex:index];
}
- (IBAction)SaveButtonAction:(id)sender
{
    memset(&g_sConfig->tag_SysIni,0,sizeof(SysIni));
    strcat(g_sConfig->tag_SysIni.tag_sfc,[self.tag_UISfc2.stringValue UTF8String]);
    strcat(g_sConfig->tag_SysIni.tag_station_id,[self.tag_UIStation_Id.stringValue UTF8String]);
    strcat(g_sConfig->tag_SysIni.tag_softwarename,[self.tag_UISoftwareName.stringValue UTF8String]);
    strcat(g_sConfig->tag_SysIni.tag_softwareversion,[self.tag_UiSoftwareVersion.stringValue UTF8String]);
    strcat(g_sConfig->tag_SysIni.tag_limitsversion,[self.tag_UimitsVersion.stringValue UTF8String]);
    strcat(g_sConfig->tag_SysIni.tag_sub_station,[self.tag_UISubStation.stringValue UTF8String]);
    strcat(g_sConfig->tag_SysIni.tag_logDir,[self.tag_UIlogFilePath.stringValue UTF8String]);
    strcat(g_sConfig->tag_SysIni.tag_csvDir,[self.tag_UiCsvPath.stringValue UTF8String]);
    strcat(g_sConfig->tag_SysIni.tag_scriptDir, [self.tag_UiScriptFilePath.stringValue UTF8String]);
    strcat(g_sConfig->tag_SysIni.tag_customerBinDir, [self.tag_UiCustomerBinPath.stringValue UTF8String]);
    
     strcat(g_sConfig->tag_SysIni.tag_DutDir,[self.tag_dutFilePath.stringValue UTF8String]);
     strcat(g_sConfig->tag_SysIni.tag_ArmDir,[self.tag_armPath.stringValue UTF8String]);
    
    
    
    strcat(g_sConfig->tag_SysIni.tag_csvFileName, [self.tag_UiCsvFileName.stringValue UTF8String]);
    strcat(g_sConfig->tag_SysIni.tag_ArmFileName, [self.tag_ArmFileName.stringValue UTF8String]);
    strcat(g_sConfig->tag_SysIni.tag_LogFileName, [self.tag_UilogFileName.stringValue UTF8String]);
    strcat(g_sConfig->tag_SysIni.tag_DutFileName, [self.tag_DutFileName.stringValue UTF8String]);
    
    
   // strcat(g_sConfig->tag_SysIni.tag_sfc, [self.tag_UiSfc.stringValue UTF8String]);
    g_sConfig->tag_SysIni.tag_SnLength = atoi([self.tag_UiSnLength.stringValue UTF8String]);
    g_sConfig->tag_SysIni.tag_SnGetMethod= self.tag_UISFCGET.indexOfSelectedItem;
    Save();
    
}


@end
