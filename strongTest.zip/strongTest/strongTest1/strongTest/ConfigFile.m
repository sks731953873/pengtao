//
//  ConfigFile.m
//  X322MotorTest
//
//  Created by CW-IT-MINI-001 on 13-12-14.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ConfigFile.h"

@implementation ConfigFile

@synthesize fixtureName;
@synthesize bufferParams;
@synthesize bauteRate;
@synthesize fixtureLogPath;
@synthesize timeout;
@synthesize PortParam;

/*singleton partern*/
static ConfigFile* configFile = nil;

+(ConfigFile*)Instance
{
    if (configFile == nil)
    {
        configFile = [[super allocWithZone:NULL] init];
    }
    
    return configFile;
}

+(id)allocWithZone:(NSZone*)zone
{
    return [self Instance];
}

-(id)copyWithZone:(NSZone*)zone
{
    return self;
}


/*singleton partern*/

-(id)init
{
    self = [super init];
    if (!self)
    {
        return nil;
    }
   
    bufferParams = [[NSMutableDictionary alloc] init];
    return self;
}

/*Research config file in app,and
 load test config property*/
-(void)Config
{
    
    NSString* resourcePath = [[NSBundle mainBundle] resourcePath];    
    NSMutableString* path = [NSMutableString stringWithString:resourcePath];
    [path appendString:@"/TestConfig.plist" ];
    configPath = [path copy];
    
    if (root != nil)
    {
        root = nil;

    }
    
    root = [[NSMutableDictionary alloc] initWithContentsOfFile:configPath];
    
    if (fixtureName != nil)
    {
        fixtureName = nil;
    }
    
    fixtureName = [[root objectForKey:@"FixtureName"] copy];
    
    if(fixtureLogPath != nil)
    {
        fixtureLogPath = nil;
    }
    
    fixtureLogPath = [[root objectForKey:@"FixtureLogPath"] copy];
    
    if(PortParam != nil)
    {
        PortParam = nil;
    }
    
    PortParam = [[root objectForKey:@"PortParam"] copy];
    

    timeout = [[root objectForKey:@"timeout"]intValue];
    
    bauteRate = [[root objectForKey:@"BauteRate"] intValue];
    
}


@end
