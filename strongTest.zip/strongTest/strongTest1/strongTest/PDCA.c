//
//  PDCA.c
//  strongTest
//
//  Created by strong on 2017/12/27.
//  Copyright © 2017年 strong. All rights reserved.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "PDCA.h"
/*******************************************************************************************
 **函数名：stepInster
 **参数：,Station  *station。运行的工位 ,int delIndex 第几个步骤，,Step *step 插入的步骤
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
int pdcaInster(pdcaValueManage pdcaManage,int index,pdcaValue pdca)
{
    PdcaValueManage s = {0};
    if(index == -1)
    {
        index = 0;
    }
    if(index < MAXCOUNTPDCA-1 && pdcaManage->tag_totalCount <MAXCOUNTPDCA-1)
    {
        memcpy(&s.tag_PdcaValue[0], &pdcaManage->tag_PdcaValue[0], (index+1)*sizeof(PdcaValue));
        memcpy(&s.tag_PdcaValue[index], pdca, sizeof(PdcaValue));
        memcpy(&s.tag_PdcaValue[index+1], &pdcaManage->tag_PdcaValue[index], (MAXCOUNTPDCA-1-index)*sizeof(PdcaValue));
        memcpy(&pdcaManage->tag_PdcaValue[0], &s.tag_PdcaValue[0],(MAXCOUNTPDCA-1)*sizeof(PdcaValue));
        pdcaManage->tag_totalCount++;
    }
    return 0;
}
/*******************************************************************************************
 **函数名：pdcaDelete
 **参数：,Station  *station。运行的工位 ,int delIndex 删除第几个工位
 **功能：删除一个步骤
 **返回值：< 0失败
 *******************************************************************************************/
int pdcaDelete(pdcaValueManage pdcaManage,int delIndex)
{
    PdcaValueManage s = {0};
    if(delIndex < MAXCOUNTPDCA-1 && pdcaManage->tag_totalCount <MAXCOUNTPDCA-1)
    {
        if(delIndex == 0)
        {
            memcpy( &s.tag_PdcaValue[0],&pdcaManage->tag_PdcaValue[1],MAXCOUNTPDCA*sizeof(PdcaValue));
            memcpy(&pdcaManage->tag_PdcaValue[0], &s.tag_PdcaValue[0],MAXCOUNTPDCA*sizeof(PdcaValue));
        }
        else
        {
            memcpy( &s.tag_PdcaValue[0],&pdcaManage->tag_PdcaValue[0],delIndex*sizeof(PdcaValue));
            memcpy( &s.tag_PdcaValue[delIndex],&pdcaManage->tag_PdcaValue[delIndex+1],(MAXCOUNTPDCA-delIndex)*sizeof(PdcaValue));
            memcpy(&pdcaManage->tag_PdcaValue[0], &s.tag_PdcaValue[0],MAXCOUNTPDCA*sizeof(PdcaValue));
        }
        pdcaManage->tag_totalCount--;
    }
    return 0;
}
/*******************************************************************************************
 **函数名：pdcaValueAdd
 **参数：,pdcaManage  修改第index的结果值，
 **功能：删除一个步骤
 **返回值：< 0失败
 *******************************************************************************************/
void pdcaValueSet(pdcaValueManage pdcaManage,int index,char *value)
{
    if(index < pdcaManage->tag_totalCount)
    {
        memset(pdcaManage->tag_PdcaValue[index].tag_Value,0,sizeof(pdcaManage->tag_PdcaValue[index].tag_Value));
        if(strlen(value) < sizeof(pdcaManage->tag_PdcaValue[index].tag_Value))
        {
            strcat(pdcaManage->tag_PdcaValue[index].tag_Value,value);
        }
        else
        {
            memcpy(pdcaManage->tag_PdcaValue[index].tag_Value,value,sizeof(pdcaManage->tag_PdcaValue[index].tag_Value)-1);
        }
    }
}
/*******************************************************************************************
 **函数名：pdcaValueAdd
 **参数：,pdcaManage  修改第index的结果值，
 **功能：删除一个步骤
 **返回值：< 0失败
 *******************************************************************************************/
void pdcaValueSet2(pdcaValue pdca,char *value)
{
   
        memset(pdca->tag_Value,0,sizeof(pdca->tag_Value));
        if(strlen(value) < sizeof(pdca->tag_Value))
        {
            strcat(pdca->tag_Value,value);
        }
        else
        {
            memcpy(pdca->tag_Value,value,sizeof(pdca->tag_Value)-1);
        }
    
}

void CreateStrDoubel3f(char  *var,char *ret,int RetLen)
{
    int i = 0;
    int len = strlen(var);
    int j = 0;
    int m = 0;
    memset(ret,0,RetLen);
    while(j < RetLen && i < len)
    {
        if((var[i] <='9' && var[i] >='0') ||  var[i] == '-')
        {
            ret[j] = var[i];
            if(m >0)
            {
                m++;
            }
            if(m >3)
            {
                break;
            }
            j++;
        }
        else
            if(var[i] == '.')
            {
                ret[j] = var[i];
                j++;
                m =1;
            }
        i++;
    }
    return ;
}

void CreateDoubel3f(double var,char *ret,int RetLen)

{
    int i = (int)var;
    double j = abs(var -i);
    
    int n1 = (int)(j*10);
    int n2 = ((int)(j*100))%10;
    int n3 =((int) (j*1000))%10;
    if(var <0)
    {
    sprintf(ret,"-%d.%d%d%d",i,n1,n2,n3);
    }
    else
    {
        sprintf(ret,"%d.%d%d%d",i,n1,n2,n3);
    }
    return ;
}

void CreateEnglishNumberCode(char *code)
{
    int len = strlen(code);
    int i = 0;
    int j = 0;
    char *buffer = malloc(len + 1);
    if(!buffer)
        return ;
    memset(buffer,0,len + 1);
    
    while(i < len)
    {
        if((code[i] <= 'Z' && code[i] >= 'A') || (code[i] <= 'z' && code[i] >= 'a' )||
           (code[i] <= '9' && code[i] >= '0') )
        {
            buffer[j] = code[i];
            j++;
        }

        i++;
    }
    
    i = 0;
    
    while(i < j)
    {
        code[i] = buffer[i];
        i++;
    }
    while(i < len)
    {
        code[i] = 0;
        i++;
    }
    free(buffer);
}
void ISPass(pdcaValue dcap)
{

    memset(dcap->tag_strPassFail,0,sizeof(dcap->tag_strPassFail));
   

    switch(  dcap->tag_ValueType)
    {
        case  enum_pdcaValueType_string_pass://返回结果的类型 串类型
        case  enum_pdcaValueType_string_Set://返回结果的类型 串类型
        case  enum_pdcaValueType_string_Value://返回结果的类型 串类型
        case  enum_pdcaValueType_bool:
        {
            char *begin = dcap->tag_Max;
            if(strlen(dcap->tag_Value) >0 && strstr(dcap->tag_Value, dcap->tag_Max) && strlen(dcap->tag_Max) >0 )
            {
       
                dcap->tag_intPassFail = 1;
                strcat(dcap->tag_strPassFail,"PASS");
            }
            else
            {
                dcap->tag_intPassFail = 2;
                strcat(dcap->tag_strPassFail,"FAIL");
            }
        }
        break;
        case  enum_pdcaValueType_SnRead:
        {
            CreateEnglishNumberCode(dcap->tag_Value);
            if(strcmp(dcap->tag_sn, dcap->tag_Value) == 0)
            {
                dcap->tag_intPassFail = 1;
                strcat(dcap->tag_strPassFail,"PASS");
            }
            else
            {
                dcap->tag_intPassFail = 2;
                strcat(dcap->tag_strPassFail,"FAIL");
            }
            return ;
        }
        break;
        case  enum_pdcaValueType_double:
        {
            char Result[100] = {0};
           
            double var =0;
            double max = 0;
            double min = 0;
            memset(Result,0,100);
            CreateStrDoubel3f(dcap->tag_Value,Result,30);
            
             var = atof(Result)*dcap->tag_Beishu;
             max = atof(dcap->tag_Max);
             min = atof(dcap->tag_Min);

            memset(dcap->tag_Value,0,sizeof(dcap->tag_Value));
            CreateDoubel3f(var,dcap->tag_Value,30);

            if(var >= min && var <= max)
            {
                 dcap->tag_intPassFail = 1;
                 strcat(dcap->tag_strPassFail,"PASS");
            }
            else
            {
               dcap->tag_intPassFail = 2;
               strcat(dcap->tag_strPassFail,"FAIL");
            }
        }
            break;
        case  enum_pdcaValueType_int:
        {
            char Result[100] = {0};
            
            double var =0;
            double max = 0;
            double min = 0;
            memset(Result,0,100);
            CreateStrDoubel3f(dcap->tag_Value,Result,30);
            
            var = atof(Result)*dcap->tag_Beishu;
            max = atof(dcap->tag_Max);
            min = atof(dcap->tag_Min);
            
            memset(dcap->tag_Value,0,sizeof(dcap->tag_Value));
           // CreateDoubel3f(var,dcap->tag_Value,30);
            int varInt = (int)var;
            sprintf(dcap->tag_Value, "%d",varInt);
            
            if(var >= min && var <= max)
            {
                dcap->tag_intPassFail = 1;
                strcat(dcap->tag_strPassFail,"PASS");
            }
            else
            {
                dcap->tag_intPassFail = 2;
                strcat(dcap->tag_strPassFail,"FAIL");
            }
        }
            break;
    }
    if(strstr(dcap->tag_Max,"NA") && strstr(dcap->tag_Min,"NA") )
    {
        
        if(strlen(dcap->tag_Value) >0)
        {
            dcap->tag_intPassFail = 1;
            memset(dcap->tag_strPassFail,0,sizeof(dcap->tag_strPassFail));
            strcat(dcap->tag_strPassFail,"PASS");
            
        }
        else
        {
            dcap->tag_intPassFail = 2;
            memset(dcap->tag_strPassFail,0,sizeof(dcap->tag_strPassFail));
            strcat(dcap->tag_strPassFail,"FAIL");
            
        }
        return ;
    }
}


