//
//  SendContentView.m
//  strongTest
//
//  Created by strong on 2018/1/16.
//  Copyright © 2018年 strong. All rights reserved.
//

#import "SendContentView.h"

@implementation SendContentView

/*******************************************************************************************
 **函数名：initWithFrame
 **参数：,(CGRect)frame 初始化 大小
 **功能：运行一个工位
 **返回值：< 0失败
 *******************************************************************************************/
- (instancetype)initWithFrame:(CGRect)frame STEP:(LpStep) step
{
    int i = 0;
    self =   [super initWithFrame:frame];
    tag_LpStep = step;
    NSRect rect = {(frame.size.width-500)/2,(frame.size.height-20)/2,500,200};
    NSRect rect2 = {(frame.size.width-120-20)/2,(frame.size.height-40)/2-40,60,30};
     NSRect rect3 = {(frame.size.width-120-20)/2+70,(frame.size.height-40)/2-40,60,30};
    
    tag_UITextView = [[NSTextView alloc] initWithFrame:rect];
    tag_UITextView.string =[ [NSString alloc] initWithFormat:@"%s",step->tag_sendCommand];
        [self addSubview: tag_UITextView];
    
    tag_UIOkButton = [[NSButton alloc] initWithFrame:rect2];
    
    [tag_UIOkButton setTitle:@"保存"];
    [tag_UIOkButton  setTarget:self];
    [tag_UIOkButton setAction:@selector(SaveClick:)];


    [self addSubview: tag_UIOkButton];

    tag_UIGoBackButton = [[NSButton alloc] initWithFrame:rect3];
    [tag_UIGoBackButton setTitle:@"返回"];
    [tag_UIGoBackButton  setTarget:self];
    [tag_UIGoBackButton setAction:@selector(GobackClick:)];
    [self addSubview: tag_UIGoBackButton];
    
    
    
    CALayer *viewLayer = [CALayer layer];
    [viewLayer setBackgroundColor:CGColorCreateGenericRGB(0.8, 0.8, 0.8, 0.4)];
    [self setWantsLayer:YES];
    [self setLayer:viewLayer];

    return self;
    
}

/*******************************************************************************************
 **函数名：GobackClick
 **参数：:xeClick:(id)sender
 **功能：单步运行
 **返回值：
 *******************************************************************************************/

- (void)SaveClick:(id)sender
{
    memset(tag_LpStep->tag_sendCommand,0,sizeof(tag_LpStep->tag_sendCommand));
    if(strlen([tag_UITextView.string UTF8String]) < sizeof(tag_LpStep->tag_sendCommand))
    {
        strcat(tag_LpStep->tag_sendCommand,[tag_UITextView.string UTF8String]);
    }
    else
    {
        
    }
     Save();
      [self removeFromSuperview];
    return  ;
  
    NSAlert *alert = [NSAlert new];
    [alert addButtonWithTitle:@"确定"];
    [alert addButtonWithTitle:@"取消"];
    [alert setMessageText:@"确定保存输入文本?"];
    [alert setInformativeText:@"如果确定保存，之前的文本不能再找回!"];
    CGRect frowm = {100,300,500,200};
  //  alert.window.frame = frowm;
    alert.accessoryView.frame = frowm ;
    [alert beginSheetModalForWindow:[self window] completionHandler:^(NSModalResponse returnCode)
    {
         if(returnCode == NSAlertFirstButtonReturn)
         {
             memset(tag_LpStep->tag_sendCommand,0,sizeof(tag_LpStep->tag_sendCommand));
             if(strlen([tag_UITextView.string UTF8String]) < sizeof(tag_LpStep->tag_sendCommand))
             {
                 strcat(tag_LpStep->tag_sendCommand,[tag_UITextView.string UTF8String]);
             }
             else
             {
                 
             }
             Save();
             [self removeFromSuperview];
         }
         else if(returnCode == NSAlertSecondButtonReturn)
         {
             
         }
     }];
    
}
/*******************************************************************************************
 **函数名：GobackClick
 **参数：:xeClick:(id)sender
 **功能：单步运行
 **返回值：
 *******************************************************************************************/

- (void)GobackClick:(id)sender
{
    
    
    [self removeFromSuperview];
    
    
}

@end
