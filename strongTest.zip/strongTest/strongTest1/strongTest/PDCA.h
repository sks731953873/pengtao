//
//  PDCA.h
//  strongTest
//
//  Created by strong on 2017/12/27.
//  Copyright © 2017年 strong. All rights reserved.
//

#ifndef PDCA_h
#define PDCA_h

#include <stdio.h>
#define MAXNAMEPDCA 128
#define MAXVALUEPDCA 1024*10
#define MAXLIMITPDCA 128
#define MAXCOUNTPDCA 128
typedef enum _enum_pdcaValueType
{
    enum_pdcaValueType_string_pass,//返回结果的类型 串类型
    enum_pdcaValueType_bool,
    enum_pdcaValueType_double,//
    enum_pdcaValueType_string_Value,//保存数据
    enum_pdcaValueType_string_Set,//设置
    enum_pdcaValueType_SnRead,//不上传
    enum_pdcaValueType_int,//
}enum_pdcaValueType;

typedef struct _pdcaValue
{
    enum_pdcaValueType tag_ValueType;//类型
    enum_pdcaValueType tag_IsAttribute;//类型//att
    double  tag_Beishu;
    char tag_Name[MAXNAMEPDCA];//名称
    char tag_Value[MAXVALUEPDCA];//结果
    char tag_Max[MAXLIMITPDCA];//最大值
    char tag_Min[MAXLIMITPDCA];//最小值
    char tag_uutio[MAXVALUEPDCA];
    char tag_csvReslut[MAXNAMEPDCA];//pdca设置的值
    char tag_strPassFail[MAXNAMEPDCA];
    char *tag_sn;
    int tag_intPassFail;//0 ，1成功，2失败不判断
    
}PdcaValue,*pdcaValue;
typedef struct _pdcaValueManage
{
    int tag_totalCount;//个数
    PdcaValue tag_PdcaValue[MAXCOUNTPDCA];//列表
}PdcaValueManage,*pdcaValueManage;
/*******************************************************************************************
 **函数名：stepInster
 **参数：,Station  *station。运行的工位 ,int delIndex 第几个步骤，,Step *step 插入的步骤
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
int pdcaInster(pdcaValueManage pdcaManage,int index,pdcaValue pdca);
/*******************************************************************************************
 **函数名：pdcaValueAdd
 **参数：,pdcaManage  修改第index的结果值，
 **功能：删除一个步骤
 **返回值：
 *******************************************************************************************/
void pdcaValueSet(pdcaValueManage pdcaManage,int index,char *value);
void pdcaValueSet2(pdcaValue pdca,char *value);
void ISPass(pdcaValue dcap);
#endif /* PDCA_h */
