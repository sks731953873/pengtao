//
//  Log.c
//  strongTest
//
//  Created by strong on 2018/1/17.
//  Copyright © 2018年 strong. All rights reserved.
//

#include "Log.h"
extern char *GetCurrentTimeCtr();
logHead *g_lpLog;
char *g_textLog;
char *g_textLog2;
char *g_textLog1;
int g_TextLen = 0;
pthread_mutex_t mutex;

void FreeLog(lpLog log )
{
    free((void *)(log)->tag_log);
}



void AddLog(char *Text)
{
    extern char* isLogFile();
    char *file =   isLogFile();
    char *tempText = 0;
    char *time = GetCurrentTimeCtr();
  
     pthread_mutex_lock(&mutex);
    if(file[0] >0 && strlen(file) >0)
        logwrite(file,Text);
    g_textLog = g_textLog1 ;
    g_textLog2 = g_textLog1;
    if(!g_textLog1)
    {
        return ;
    }
    if(g_TextLen >= 1024*10)
    {
        memset(g_textLog1,0,g_TextLen);
        g_TextLen = 0;
    }
    
    
 

    {
        strcat(g_textLog1,time);
        strcat(g_textLog1,": ");
        strcat(g_textLog1,Text);
        strcat(g_textLog1,"\r\n");
  
        g_TextLen = strlen(g_textLog1);

    }

    pthread_mutex_unlock(&mutex);
}

void CelanLog()
{
    memset(g_textLog1,0,g_TextLen);
    g_TextLen = 0;
}

void loginit()
{
    g_textLog1 = malloc(1024*100);
     pthread_mutex_init(&mutex,NULL);
}

