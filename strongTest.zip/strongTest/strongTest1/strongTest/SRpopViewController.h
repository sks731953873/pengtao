//
//  popViewController.h
//  Manual_Debug
//
//  Created by Strong-EE on 2017/9/18.
//  Copyright © 2017年 Strong-EE. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@protocol SRpopViewControllerDelegate <NSObject>
- (void)closePopover;

@end

@interface SRpopViewController : NSViewController

@property(nonatomic,assign)id<SRpopViewControllerDelegate> delegate;

@end
