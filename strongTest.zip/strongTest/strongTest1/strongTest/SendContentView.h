//
//  SendContentView.h
//  strongTest
//
//  Created by strong on 2018/1/16.
//  Copyright © 2018年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "Config.h"
@interface SendContentView : NSView

{
    NSTextField *tag_UIStepName;
    NSButton *tag_UIOkButton;
     NSButton *tag_UIGoBackButton;
    NSTextView *tag_UITextView;
    LpStep tag_LpStep;
}
/*******************************************************************************************
 **函数名：initWithFrame
 **参数：,(CGRect)frame 初始化 大小
 **功能：运行一个工位
 **返回值：< 0失败
 *******************************************************************************************/
- (instancetype)initWithFrame:(CGRect)frame STEP:(LpStep) step;
@end
