//
//  WaitView.m
//  strongTest
//
//  Created by strong on 2017/12/31.
//  Copyright © 2017年 strong. All rights reserved.
//

#import "WaitView.h"

@implementation WaitView
/*******************************************************************************************
 **函数名：initWithFrame
 **参数：,(CGRect)frame 初始化 大小
 **功能：运行一个工位
 **返回值：< 0失败
 *******************************************************************************************/
- (instancetype)initWithFrame:(CGRect)frame
{
    int i = 0;
    self =   [super initWithFrame:frame];
    NSRect rect = {(frame.size.width-300)/2,(frame.size.height-40)/2,300,40};
    NSRect rect2 = {(frame.size.width-60)/2,(frame.size.height-40)/2-40,60,30};
    tag_NSProgressIndicator = [[NSProgressIndicator alloc] initWithFrame:rect];
    tag_OkButton = [[NSButton alloc] initWithFrame:rect2];

    [tag_OkButton setTitle:@"取消"];
    [tag_OkButton  setTarget:self];
    [tag_OkButton setAction:@selector(ExeClick:)];
    [tag_NSProgressIndicator startAnimation:nil];
    [self addSubview: tag_NSProgressIndicator];
    [self addSubview: tag_OkButton];
    
    CALayer *viewLayer = [CALayer layer];
    [viewLayer setBackgroundColor:CGColorCreateGenericRGB(0.8, 0.8, 0.8, 0.4)];
    [self setWantsLayer:YES];
    [self setLayer:viewLayer];

    
   
    
    
    return self;
    
}
/*******************************************************************************************
 **函数名：ThreadRun
 **参数：:xeClick:(id)sender
 **功能：单步运行
 **返回值：
 *******************************************************************************************/
-(void)ThreadRun
{
    tag_myThread = [[NSThread alloc] initWithTarget:self
                                           selector:@selector(ThreadRun:)
                                             object:nil];
    [tag_myThread start];
}
/*******************************************************************************************
 **函数名：ExeClick
 **参数：:xeClick:(id)sender
 **功能：单步运行
 **返回值：
 *******************************************************************************************/
-(void)ThreadRun:(NSObject*) o
{

    [self.tag_WaitThreadDelegate WaitThreadDelegate:o];
    [tag_NSProgressIndicator stopAnimation:nil];
    [self removeFromSuperview];
}
/*******************************************************************************************
 **函数名：ExeClick
 **参数：:xeClick:(id)sender
 **功能：单步运行
 **返回值：
 *******************************************************************************************/

- (void)ExeClick:(id)sender
{
    [self.tag_WaitThreadDelegate cancelThreadDelegate:sender];
    [tag_NSProgressIndicator stopAnimation:nil];

    [self removeFromSuperview];
}
- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
