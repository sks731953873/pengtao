//
//  FCTDL.c
//  strongTest
//
//  Created by strong on 2018/1/10.
//  Copyright © 2018年 strong. All rights reserved.
//

#include "FCTDL.h"
FctDlValue s_FctDlValue = {0};
FctDlValueManage s_cftdlMaange = {0};

FctDlValueManage  s_FctDlValueManage_FCT;
FctDlValueManage  s_FctDlValueManage_FDL;


#define STRCAT(x) \
if (x && strlen(x) >0) {    strcat(s_FctDlValue.x,x); }

#define STRLPCAT(y,x) \
if (x && strlen(x) >0) {    strcat(y->x,x); }

/*******************************************************************************************
 **函数名：FctDlAdd
 **参数：,
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
int FctDlAdd(fctDlValueManage cftdlMaange,
            char *tag_TID,//名称
            char *tag_Value,//结果
            char *tag_LL,//最大值
            char *tag_UL,//最小值
            char *tag_Unit,//最小值
            char *tag_UUT0,//最小值
            char *tag_UUT1,//最小值
            char *tag_UUT2,//最小值
            char *tag_UUT3)//,//最小值)
{
    
    int index = cftdlMaange->tag_totalCount;
    
    
    memset(&s_FctDlValue,0,sizeof(s_FctDlValue));
    STRCAT(tag_TID)
    STRCAT(tag_Value)
    STRCAT(tag_LL)
    STRCAT(tag_UL)
    STRCAT(tag_Unit)
    STRCAT(tag_UUT0)
    STRCAT(tag_UUT1)
    STRCAT(tag_UUT2)
    STRCAT(tag_UUT3)
    
    if(index < MAXCOUNTPDCA-1 && cftdlMaange->tag_totalCount <MAXCOUNTPDCA-1)
    {
        memcpy(&s_cftdlMaange.tag_FctDlValue[0], &cftdlMaange->tag_FctDlValue[0], (index+1)*sizeof(FctDlValue));
        memcpy(&s_cftdlMaange.tag_FctDlValue[index], &s_FctDlValue, sizeof(FctDlValue));
        memcpy(&s_cftdlMaange.tag_FctDlValue[index+1], &cftdlMaange->tag_FctDlValue[index], (MAXCOUNTPDCA-1-index)*sizeof(FctDlValue));
        memcpy(&cftdlMaange->tag_FctDlValue[0], &s_cftdlMaange.tag_FctDlValue[0],(MAXCOUNTPDCA-1)*sizeof(FctDlValue));
        cftdlMaange->tag_totalCount++;
    }
    return 0;
}
/*******************************************************************************************
 **函数名：FctDlClean
 **参数：,fctDlValueManage 清
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
void FctDlClean(fctDlValueManage cftdlMaange)//,//最小值)
{
    memset(cftdlMaange,0,sizeof(FctDlValueManage));
}
/*******************************************************************************************
 **函数名：FCTADD
 **参数：,fctDlValueManage 清
 **功能：插向FCT加一列
 **返回值：
 *******************************************************************************************/
void  FCTADD(char *tag_TID, //名称
char *tag_Value, //结果
char *tag_LL, //最大值
char *tag_UL, //最小值
char *tag_Unit, //最小值
char *tag_UUT0, //最小值
char *tag_UUT1, //最小值
char *tag_UUT2, //最小值
char *tag_UUT3)
{
    FctDlAdd(&s_FctDlValueManage_FCT,
             tag_TID,//名称
             tag_Value,//结果
             tag_LL,//最大值
             tag_UL,//最小值
             tag_Unit,//最小值
             tag_UUT0,//最小值
             tag_UUT1,//最小值
             tag_UUT2,
             tag_UUT3);
    
}
/*******************************************************************************************
 **函数名：FCTClean
 **参数：,fctDlValueManage 清
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
void  FCTClean()
{
    FctDlClean(&s_FctDlValueManage_FCT);
    
}
/*******************************************************************************************
 **函数名：FDLADD
 **参数：,fctDlValueManage 清
 **功能：向FDL加一列
 **返回值：
 *******************************************************************************************/
void FDLADD(char *tag_TID, //名称
               char *tag_Value, //结果
               char *tag_LL, //最大值
               char *tag_UL, //最小值
               char *tag_Unit, //最小值
               char *tag_UUT0, //最小值
               char *tag_UUT1, //最小值
               char *tag_UUT2, //最小值
               char *tag_UUT3)
{
    FctDlAdd(&s_FctDlValueManage_FDL,
             tag_TID,//名称
             tag_Value,//结果
             tag_LL,//最大值
             tag_UL,//最小值
             tag_Unit,//最小值
             tag_UUT0,//最小值
             tag_UUT1,//最小值
             tag_UUT2,
             tag_UUT3);
    
}
/*******************************************************************************************
 **函数名：FDLClean
 **参数：,fctDlValueManage 清
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
void FDLClean()

{
    FctDlClean(&s_FctDlValueManage_FDL);
    
}

/*******************************************************************************************
 **函数名：FctDlSetRow
 **参数：,
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
int FctDlSetRow(fctDlValueManage cftdlMaange,
                int Row,
             char *tag_TID,//名称
             char *tag_Value,//结果
             char *tag_LL,//最大值
             char *tag_UL,//最小值
             char *tag_Unit,//最小值
             char *tag_UUT0,//最小值
             char *tag_UUT1,//最小值
             char *tag_UUT2,//最小值
             char *tag_UUT3)//,//最小值)
{
    
    int index = cftdlMaange->tag_totalCount;
    if(Row < cftdlMaange->tag_totalCount)
    {
        fctDlValue cftdl = &cftdlMaange->tag_FctDlValue[Row];
        memset(cftdl,0,sizeof(s_FctDlValue));
        STRLPCAT(cftdl,tag_TID)
        STRLPCAT(cftdl,tag_Value)
        STRLPCAT(cftdl,tag_LL)
        STRLPCAT(cftdl,tag_UL)
        STRLPCAT(cftdl,tag_Unit)
        STRLPCAT(cftdl,tag_UUT0)
        STRLPCAT(cftdl,tag_UUT1)
        STRLPCAT(cftdl,tag_UUT2)
        STRLPCAT(cftdl,tag_UUT3)
        return 1;
    }
    
   
    return 0;
}

/*******************************************************************************************
 **函数名：FCTSetRow
 **参数：,修改cft行数据
 **功能：插向FCT加一列
 **返回值：
 *******************************************************************************************/
void  FCTSetRow(int Row,char *tag_TID, //名称
             char *tag_Value, //结果
             char *tag_LL, //最大值
             char *tag_UL, //最小值
             char *tag_Unit, //最小值
             char *tag_UUT0, //最小值
             char *tag_UUT1, //最小值
             char *tag_UUT2, //最小值
             char *tag_UUT3)
{
    FctDlSetRow(&s_FctDlValueManage_FCT,Row,
             tag_TID,//名称
             tag_Value,//结果
             tag_LL,//最大值
             tag_UL,//最小值
             tag_Unit,//最小值
             tag_UUT0,//最小值
             tag_UUT1,//最小值
             tag_UUT2,
             tag_UUT3);
    
}
/*******************************************************************************************
 **函数名：FDLSetRow
 **参数：,修改cft行数据
 **功能：,修改cft行数据
 **返回值：
 *******************************************************************************************/
void  FDLSetRow(int Row,
                char *tag_TID, //名称
                char *tag_Value, //结果
                char *tag_LL, //最大值
                char *tag_UL, //最小值
                char *tag_Unit, //最小值
                char *tag_UUT0, //最小值
                char *tag_UUT1, //最小值
                char *tag_UUT2, //最小值
                char *tag_UUT3)
{
    FctDlSetRow(&s_FctDlValueManage_FDL,Row,
                tag_TID,//名称
                tag_Value,//结果
                tag_LL,//最大值
                tag_UL,//最小值
                tag_Unit,//最小值
                tag_UUT0,//最小值
                tag_UUT1,//最小值
                tag_UUT2,
                tag_UUT3);
    
}
/*******************************************************************************************
 **函数名：SetFctChannel
 **参数：,
 **功能：,设置fct通道选择
 **返回值：
 *******************************************************************************************/
void SetFctChannel(int index,int State)
{
   g_sConfig->tag_FctChannel[index] = State;
}
/*******************************************************************************************
 **函数名：SetFctChannel
 **参数：,
 **功能：,设置fdl通道选择
 **返回值：
 *******************************************************************************************/
void SetFDLChannel(int index,int State)
{
    g_sConfig->tag_FDLChannel[index] = State;
}
/*******************************************************************************************
 **函数名：GetFctChannel
 **参数：,
 **功能：,设置fct通道选择
 **返回值：
 *******************************************************************************************/
int GetFctChannel(int index)
{
   return g_sConfig->tag_FctChannel[index];
}
/*******************************************************************************************
 **函数名：SetFctChannel
 **参数：,
 **功能：,设置fdl通道选择
 **返回值：
 *******************************************************************************************/
int GetFDLChannel(int index)
{
   return g_sConfig->tag_FDLChannel[index] ;
}
