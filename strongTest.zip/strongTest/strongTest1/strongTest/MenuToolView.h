//
//  MainMenuView.h
//  strongTest
//
//  Created by strong on 2017/12/15.
//  Copyright © 2017年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@protocol ButtonActionDelegate
-(void)MainButtonDelegate:(id) obj;
-(void)DebugButtonDelegate:(id) obj;
-(void)LoginButtonDelegate:(id) obj;
-(void)LoginBtnDelegate:(id) obj;
@end

@interface MenuToolView : NSView
{
    id<ButtonActionDelegate> tag_mainButtonDelegate;
   // SEL
}

@property(assign,nonatomic)id<ButtonActionDelegate> tag_mainButtonDelegate;
- (instancetype)initWithFrame:(CGRect)frame ;
@end
