//
//  stationView.h
//  strongTest
//
//  Created by strong on 2017/12/20.
//  Copyright © 2017年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#include "Config.h"

typedef enum _uiStation_enum
{
    uiStation_enum_index,//id
    uiStation_enum_name,//名称
    uiStation_enum_SockectIndex,//保存
    uiStation_enum_SnIndex,//保存
    uiStation_enum_Thread,//保
    uiStation_enum_Wait,//保
    uiStation_enum_enable,//是否屏蔽
    uiStation_enum_mainShow,//是否屏蔽
    uiStation_enum_type,//是否屏蔽
    
}uiStation_enum;

@interface stationView : NSView
{
    NSTextField *tag_UIIndex;//id
    NSTextField *tag_UIName;//名称
    NSButton *tag_UISave;//保存按钮
    NSButton *tag_UIExe;//工位运行
    NSButton *tag_UIStop;//工位运行
    NSComboBox *tag_UISocketIndex ;//sockct索引号
    NSComboBox *tag_UISnIndex ;//sockct索引号
    NSComboBox *tag_UIThread ;//sockct索引号
    NSComboBox *tag_UITWait ;//sockct索引号
    
    NSComboBox *tag_UIWorkType ;//sockct索引号
    
    NSButton   *tag_UIEnableCheckBox;// 屏蔽按钮
    NSButton   *tag_UIMainshow;// 屏蔽按钮
    NSThread* tag_myThread;
    lpStation  tag_Station;//对应工位
 
}
-(void)InitUI:(int) index STATION:(lpStation) lpstation;
-(void)UIUpdata:(int) index STATION:(lpStation) station;
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;
/*******************************************************************************************
 **函数名：SaveClick
 **参数：:xeClick:(id)sender
 **功能：
 **返回值：
 *******************************************************************************************/
- (IBAction)GetParameter;
@end
