//
//  portView.m
//  strongTest
//
//  Created by strong on 2018/1/5.
//  Copyright © 2018年 strong. All rights reserved.
//

#import "portView.h"
#import "IPValueView.h"
static SerialPortList  *tag_SerialPortList ;
@implementation portView
/*******************************************************************************************
 **函数名：InitUI
 **参数：:(int) index  显示s的ID STEP:(LpStep) step 步骤
 **功能：初始化步骤
 **返回值：s
 *******************************************************************************************/
-(void)InitUI:(int) index PORT:(portValue) port
{
    if(port)
    tag_portValue = port;
if(!tag_UIIndex)
    tag_UIIndex = [[NSTextField alloc] init];
    tag_UIIndex.stringValue = [[NSString alloc] initWithFormat:@"%2d",index];

    
if(!tag_SerialPortList)
  tag_SerialPortList =    [[SerialPortList alloc] init];
    NSMutableArray *protList =    [tag_SerialPortList portArray];
    if(!tag_UIName)
      tag_UIName = [[NSComboBox alloc] init];
  
    int i = 0;
    while( i<protList.count )
    {
        [tag_UIName addItemWithObjectValue:protList[i]];
        i++;
    }
    if(strlen( tag_portValue->tag_Name))
    {
        [tag_UIName addItemWithObjectValue:[[NSString alloc] initWithFormat:@"%s", tag_portValue->tag_Name]];
    }
    else
    {
          [tag_UIName selectItemAtIndex:0];
    }

    
 
    

  if(!tag_UIbaudRate)
  {
    tag_UIbaudRate = [[NSTextField alloc] init];;//显示的id
      tag_UIbaudRate.stringValue = [[NSString alloc] initWithFormat:@"%d",tag_portValue->tag_baudRate];

  }
 


    
     if(!tag_UIstopBits)
     {
         tag_UIstopBits= [[NSComboBox alloc] init];;//显示的id
         [tag_UIstopBits addItemWithObjectValue:@"One"];
         [tag_UIstopBits addItemWithObjectValue:@"Two"];
           [tag_UIstopBits selectItemAtIndex:tag_portValue->tag_stopBits];
     }
    
    if(!tag_dataBits)
    {
        tag_dataBits= [[NSComboBox alloc] init];;//显示的id
        [tag_dataBits addItemWithObjectValue:@"5"];
        [tag_dataBits addItemWithObjectValue:@"6"];
        [tag_dataBits addItemWithObjectValue:@"7"];
        [tag_dataBits addItemWithObjectValue:@"8"];
           [tag_dataBits selectItemAtIndex:tag_portValue->tag_dataBits];
    }
    
    
     if(!tag_UIparity)
     {
        tag_UIparity = [[NSComboBox alloc] init];//显示的id
         [tag_UIparity addItemWithObjectValue:@"NONE"];
         [tag_UIparity addItemWithObjectValue:@"ODD"];
          [tag_UIparity addItemWithObjectValue:@"EVEN "];
          [tag_UIparity selectItemAtIndex:tag_portValue->tag_parity];
         
     }
    if(!tag_UIflowControl)
    {
        tag_UIflowControl = [[NSComboBox alloc] init];;//显示的id
         [tag_UIflowControl addItemWithObjectValue:@"HARD"];
        [tag_UIflowControl addItemWithObjectValue:@"SOFT"];
         [tag_UIflowControl addItemWithObjectValue:@"NONE"];
        [tag_UIflowControl selectItemAtIndex:tag_portValue->tag_flowControl];
    }
    if(!tag_UIecho)
    tag_UIecho= [[NSComboBox alloc] init];;//显示的id
 if(!tag_UISendendFlage)
    tag_UISendendFlage = [[NSTextField alloc] init];
    {
        int endFlagLen = strlen(tag_portValue->tag_SendendFlage);
        int n = 0;
        char endFlage[256] = {0};
        while(n < endFlagLen)
        {
            sprintf(&endFlage[strlen(endFlage)], "%d,",tag_portValue->tag_SendendFlage[n]);
            n++;
        }
        if(strlen(endFlage) >0)
            endFlage[strlen(endFlage)-1] = 0;
        tag_UISendendFlage.stringValue =[[NSString alloc] initWithFormat:@"%s",
                                     endFlage];
    }
 if(!tag_UIendFlage)
 {
    tag_UIendFlage = [[NSTextField alloc] init];
     int endFlagLen = strlen(tag_portValue->tag_ReadEndFlage);
     int n = 0;
     char endFlage[256] = {0};
     while(n < endFlagLen)
     {
         sprintf(&endFlage[strlen(endFlage)], "%d,",tag_portValue->tag_ReadEndFlage[n]);
         n++;
     }
     if(strlen(endFlage) >0)
         endFlage[strlen(endFlage)-1] = 0;
     tag_UIendFlage.stringValue =[[NSString alloc] initWithFormat:@"%s",
                                  endFlage];
 }
    if(!tag_UISave)
    tag_UISave = [[NSButton alloc] init];
    [tag_UISave setTitle:@"保存"];
    [tag_UISave  setTarget:self];
    [tag_UISave setAction:@selector(SaveClick:)];
[tag_UISave setBezelStyle:NSBezelStyleSmallSquare];

}



/*******************************************************************************************
 **函数名：ExeClick
 **参数：:xeClick:(id)sender
 **功能：单步运行
 **返回值：
 *******************************************************************************************/

- (void)ExeClick:(id)sender
{
  
    
    
}
/*******************************************************************************************
 **函数名：SaveClick
 **参数：:xeClick:(id)sender
 **功能：单步保存事件
 **返回值：
 *******************************************************************************************/
- (IBAction)SaveClick:(id)sender
{
    NSAlert *alert = [NSAlert new];
    [alert addButtonWithTitle:@"确定"];
    [alert addButtonWithTitle:@"取消"];
    [alert setMessageText:@"确定保存输入文本?"];
    [alert setInformativeText:@"如果确定保存，之前的文本不能再找回!"];
    
    [alert beginSheetModalForWindow:[tag_UIIndex window] completionHandler:^(NSModalResponse returnCode) {
        if(returnCode == NSAlertFirstButtonReturn)
        {
            
            memset( tag_portValue->tag_Name,0,sizeof( tag_portValue->tag_Name));
         strcat( tag_portValue->tag_Name,[tag_UIName.stringValue UTF8String]);
            
       
      
            
            tag_portValue->tag_baudRate = [tag_UIbaudRate.stringValue integerValue];
            
            
            if(!tag_UIstopBits)
            {
                tag_UIstopBits= [[NSComboBox alloc] init];;//显示的id
                [tag_UIstopBits addItemWithObjectValue:@"One"];
                [tag_UIstopBits addItemWithObjectValue:@"Two"];
                [tag_UIstopBits selectItemAtIndex:tag_portValue->tag_stopBits];
            }
            
            
            tag_portValue->tag_stopBits = tag_UIstopBits.indexOfSelectedItem;
            
        
            
            tag_portValue->tag_dataBits = tag_dataBits.indexOfSelectedItem;
            
          
            
              tag_portValue->tag_parity = tag_UIparity.indexOfSelectedItem;
        
            
            tag_portValue->tag_flowControl = tag_UIflowControl.indexOfSelectedItem;
         
            
            memset( tag_portValue->tag_SendendFlage,0,sizeof( tag_portValue->tag_Name));
             memset( tag_portValue->tag_ReadEndFlage,0,sizeof( tag_portValue->tag_Name));
            
            
           char * end = [tag_UISendendFlage.stringValue UTF8String];
      
            [IPValueView stringToAsc:end ASC:tag_portValue->tag_SendendFlage];
                  end = [tag_UIendFlage.stringValue UTF8String];
              [IPValueView stringToAsc:end ASC:tag_portValue->tag_ReadEndFlage];

       
            Save();
            

            
        }else if(returnCode == NSAlertSecondButtonReturn){
            
        }
    }];
}

/*******************************************************************************************
 **函数名：SaveClick
 **参数：:xeClick:(id)sender
 **功能：单步保存事件
 **返回值：
 *******************************************************************************************/
- (IBAction)GetParameter
{
    
    
    

    
}


/*******************************************************************************************
 **函数名：tableView
 **参数：:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
 **功能：单步保存事件
 **返回值：一个ui 控件
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    
    
    id retid = nil;
    NSString *title =  tableColumn.title;
    if(tableView.tableColumns[uiport_enum_index] == tableColumn)
    {
        
        retid = tag_UIIndex;
    }
    else
        if(tableView.tableColumns[uiport_enum_name] == tableColumn)
        {
            retid = tag_UIName;
            
        }
        else
            if(tableView.tableColumns[uiport_enum_baudRate] == tableColumn)
            {
                retid = tag_UIbaudRate;
                
            }
            else
                if(tableView.tableColumns[uiport_enum_stopBits] == tableColumn)
                {
                    retid = tag_UIstopBits;
                    
                }
                else
                    if(tableView.tableColumns[uiport_enum_parity] == tableColumn)
                    {
                        retid = tag_UIparity;
                        
                    }
                    else
                        if(tableView.tableColumns[uiport_enum_flowControl] == tableColumn)
                        {
                            retid = tag_UIflowControl;
                            
                        }
    
                            else
                                if(tableView.tableColumns[uiport_enum_SendendFlage] == tableColumn)
                                {
                                    retid = tag_UISendendFlage;
                                    
                                }
                                else
                                    if(tableView.tableColumns[uiport_enum_endFlage] == tableColumn)
                                    {
                                        retid = tag_UIendFlage;
                                        
                                    }
                                    else
                                        if(tableView.tableColumns[uiport_enum_Save] == tableColumn)
                                        {
                                            retid = tag_UISave;
                                            
                                        } else
                                            if(tableView.tableColumns[uiport_enum_dataBits] == tableColumn)
                                            {
                                                retid = tag_dataBits;
                                                
                                            }
                                      

    
    return retid;
}



@end
