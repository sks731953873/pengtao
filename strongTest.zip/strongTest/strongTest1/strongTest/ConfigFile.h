//
//  ConfigFile.h
//  X322MotorTest
//
//  Created by CW-IT-MINI-001 on 13-12-14.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ConfigFile : NSObject
{
    NSMutableDictionary* root;
    NSMutableDictionary* bufferParams;

    NSString* configPath;
    NSString* fixtureLogPath;
    NSString* fixtureName;
    NSString* PortParam;
    

    
    int timeout;
    int bauteRate;
    
}

@property (readonly, copy) NSString* fixtureName;
@property (readwrite, retain) NSMutableDictionary* bufferParams;
@property (readwrite,copy) NSString* fixtureLogPath;
@property (readonly,copy) NSString* PortParam;
@property int bauteRate;
@property int timeout;


+(ConfigFile*)Instance;
-(void)Config;


@end
