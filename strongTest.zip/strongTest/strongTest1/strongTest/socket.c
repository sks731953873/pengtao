//
//  socket.c
//  strongTest
//
//  Created by strong on 2017/12/19.
//  Copyright © 2017年 strong. All rights reserved.
//

#include "socket.h"
#include "Log.h"
/*******************************************************************************************
 **函数名：Close
 **参数：,(void *Soc)
 **功能： socket 关闭
 **返回值： < 0失败
 *******************************************************************************************/
int Close(void*  Soc)
{
    cSocket soc = (cSocket)Soc;
    if(soc->tag_id >0)
    {
        if(SocketIsColse(Soc) == 0)
        {
            close(soc->tag_id);
        }
    }
    soc->tag_id = -1;
    
    return 0;
}
/*******************************************************************************************
 **函数名：GetReadEndStr
 **参数：,(void *p)
 ipConfig soc)
 **功能： socket连接
 **返回值： < 0失败
 *******************************************************************************************/
int GetReadEndStr(void*  Soc,char *buffer)
{
     cSocket soc = (cSocket)Soc;
    if(strlen(soc->tag_ipConfig->tag_ReadEndFlage2) || soc->tag_ipConfig->tag_isReadEnterkey2)
    {
        if(strlen(soc->tag_ipConfig->tag_ReadEndFlage2) >0)
        {
            strcat(buffer,soc->tag_ipConfig->tag_ReadEndFlage2);
        }
        if(soc->tag_ipConfig->tag_isReadEnterkey2)
        {
            strcat(buffer,"\r\n");
        }
    }
    else
    {
        if(strlen(soc->tag_ipConfig->tag_ReadEndFlage) >0)
        {
            strcat(buffer,soc->tag_ipConfig->tag_ReadEndFlage);
        }
        if(soc->tag_ipConfig->tag_isReadEnterkey)
        {
            strcat(buffer,"\r\n");
        }
    }
    return 0;
}
/*******************************************************************************************
 **函数名：SockectConnect
 **参数：,(void *p)
 ipConfig soc)
 **功能： socket连接
 **返回值： < 0失败
 *******************************************************************************************/
int SocketIsColse(void*  Soc)
{
    cSocket soc = (cSocket)Soc;
    int error = -1;
    int len = sizeof(int);
    getsockopt(soc->tag_id, SOL_SOCKET, SO_ERROR, &error, (socklen_t *)&len);
    if(error != 0)
    {
        printf("函数:%s第：%d行 soc->tag_id = %d\r\n",__func__,__LINE__,soc->tag_id);
        return 1;
        
    }
    else
    {
        return 0;
    }
}
/*******************************************************************************************
 **函数名：SockectConnect
 **参数：,(void *p)
 ipConfig soc)
 **功能： socket连接
 **返回值： < 0失败
 *******************************************************************************************/
int SocketSetReadOutTime(void*  Soc)
{
     cSocket soc = (cSocket)Soc;
    struct timeval ti; ti.tv_sec = soc->tag_outReadTime+1; ti.tv_usec = 0; //定义超时时间
    if(setsockopt(soc->tag_id,SOL_SOCKET,SO_RCVTIMEO,(void*)&ti,sizeof(ti)) < 0)
    {
        Close(Soc);
        return 0;
    }
    return 0;
}

/*******************************************************************************************
 **函数名：SockectConnect
 **参数：,(void *p)
 ipConfig soc)
 **功能： socket连接
 **返回值： < 0失败
 *******************************************************************************************/
int SockectConnect(void*  Soc)
{
    cSocket soc = (cSocket)Soc;
    int error = -1;
    int clientSocketId = socket(AF_INET, SOCK_STREAM, 0);
    int success = (clientSocketId != -1);
    int nNetTimeout = 10;
    struct sockaddr_in addr = {0};
    int val =1,len = 4;
    unsigned long ul = 1;
    int tmp = 0;
    int opt = 1;
    struct timeval ti; ti.tv_sec = soc->tag_outReadTime+1; ti.tv_usec = 0; //定义超时时间
    soc->tag_id = clientSocketId;
    // 第二步：绑定端口号
    if (success)
    {
        // 初始化
        memset(&addr, 0, sizeof(addr));
        addr.sin_len = sizeof(addr);
        // 指定协议簇为AF_INET，比如TCP/UDP等
        addr.sin_family = AF_INET;
        // 监听任何ip地址
        addr.sin_addr.s_addr = INADDR_ANY;
        error = bind(clientSocketId, (const struct sockaddr *)&addr, sizeof(addr));
        success = (error == 0);
    }
    if (success)
    {
        // p2p
        struct sockaddr_in peerAddr;
        memset(&peerAddr, 0, sizeof(peerAddr));
        peerAddr.sin_len = sizeof(peerAddr);
        peerAddr.sin_family = AF_INET;
        peerAddr.sin_port = htons(soc->tag_ipConfig->tag_port);
        // 指定服务端的ip地址，测试时，修改成对应自己服务器的ip
        peerAddr.sin_addr.s_addr = inet_addr(soc->tag_ipConfig->tag_ip );
        socklen_t addrLen;
        addrLen = sizeof(peerAddr);

        if (ioctl(clientSocketId,FIONBIO , &ul) < 0)
        {
            Close(Soc);
            
            return soc->tag_id;
        }
        
        // 第三步：连接服务器
        error = connect(clientSocketId, (struct sockaddr *)&peerAddr, addrLen);
        success = (error == 0);
        if (1)
        {
              int error;
            int len = sizeof(int);
            fd_set set;
            ti.tv_sec  = 1;
            ti.tv_usec = 0;
            FD_ZERO(&set);
            FD_SET(clientSocketId, &set);
            if(select(clientSocketId + 1, NULL, &set, NULL, &ti) > 0)
            {
                getsockopt(clientSocketId, SOL_SOCKET, SO_ERROR, &error, (socklen_t *)&len);
                if(error != 0)
                {
                    
                    Close(Soc);
                    
                }
                else
                {
                    int   keepAlive = 1;       //设定KeepAlive
                    if(setsockopt(clientSocketId,SOL_SOCKET,SO_KEEPALIVE,(void*)&keepAlive,sizeof(keepAlive)) < 0)
                    {
                    }

                    
                }
            }
            else
            { //timeout or select error
                soc->tag_id = clientSocketId;
                Close(Soc);
            }
        }
        else
        {
            Close(Soc);
        }
    }
    opt = 0;
   /*  if (ioctl(clientSocketId, FIONBIO, &opt) < 0)
     {
         close(clientSocketId);
     
     }*/
    
    
    printf("函数:%s第：%d行 soc->tag_id = %d\r\n",__func__,__LINE__,soc->tag_id);
    return soc->tag_id;
}
/*******************************************************************************************
 **函数名：sendData
 **参数：,(void *Soc)
 **功能： socket 发送数据
 **返回值： < 0失败
 *******************************************************************************************/
int sendData(void*  Soc)
{

    cSocket soc = (cSocket)Soc;
    int fd, val,len = 0;
    int sendLen =   soc->tag_sendLen;
    int sendTotal = 0;
    long long tmBegin = getSystemTime();
    long long tmEnd = tmBegin;
  

    if(soc->tag_id <0)
    {
        return -1;
    }
    memset(soc->tag_readBuffer,0,sizeof(soc->tag_readBuffer));//lrz
    AddLog(soc->tag_sendBuffer);
    printf("发送：%s",soc->tag_sendBuffer);
    while(soc->tag_sendLen > 0 && sendTotal < soc->tag_sendLen && (tmEnd - tmBegin) <= soc->tag_outReadTime)
    {
        sendLen = soc->tag_sendLen - sendTotal;
        if(SocketIsColse(Soc) ==1)
        {
            Close(Soc);
            return -2;
        }
        sendLen =   send(soc->tag_id,soc->tag_sendBuffer + sendTotal ,sendLen,0);
       
        if(sendLen >0)
        {
            sendTotal = sendTotal + sendLen;
        }
        if(isStop())
        {
            
            Close(Soc);
            return -1;
        }
        tmEnd = getSystemTime();
    }
    return 1;
}

/*******************************************************************************************
 **函数名：ReadData
 **参数：,(void *Soc)
 **功能： socket 读数据数据
 **返回值： < 0失败
 *******************************************************************************************/

int ReadData(void*  Soc)
{
    cSocket soc = (cSocket)Soc;
    int tmp = 0;
    long long tmBegin = getSystemTime();
    long long tmEnd = tmBegin;
  
#pragma ReadEnd内存释放
    char *ReadEnd = malloc(1024);
    int OutTime = 0;
    memset(ReadEnd,0,1024);
  
    SocketSetReadOutTime(Soc);
    GetReadEndStr(Soc,ReadEnd);
    if(soc->tag_ReadBufferIsClean == 0)
    {
        soc->tag_ReadLen = 0;
           memset(soc->tag_readBuffer,0,sizeof(soc->tag_readBuffer));
    }
    else
    {
        soc->tag_ReadLen = strlen( soc->tag_readBuffer);
    }
 
  /*  if(strlen(ReadEnd) == 0) //屏蔽了该模块
    {
        if(SocketIsColse(Soc) ==1)
        {
            free(ReadEnd);
            Close(Soc);
            return 0;
        }
        soc->tag_ReadLen =  recv(soc->tag_id,&soc->tag_readBuffer[soc->tag_ReadLen],1024*4,0);
        printf("读取1：%s",soc->tag_readBuffer);
       // AddLog(soc->tag_readBuffer);
        free(ReadEnd);
        return soc->tag_ReadLen;
    }*/
    while(soc->tag_ReadLen < sizeof(soc->tag_readBuffer)-1 && OutTime<= soc->tag_outReadTime)
    {
        if(SocketIsColse(Soc) ==1)
        {
             free(ReadEnd);
            Close(Soc);
            return 0;
        }
        if(isStop())
        {
            free(ReadEnd);
            Close(Soc);
            return -1;
        }
        tmp =  recv(soc->tag_id,&soc->tag_readBuffer[soc->tag_ReadLen],1,0);
        if(tmp == 1)
        {
            if(strlen(ReadEnd) > 0 && strstr(soc->tag_readBuffer,ReadEnd))//加了strlen(ReadEnd) > 0 &&
            {
                if(soc->tag_readBuffer[soc->tag_ReadLen] != 255)
                    soc->tag_ReadLen++;
                break;
            }
            if(soc->tag_readBuffer[soc->tag_ReadLen] != 255)
                soc->tag_ReadLen++;
        }
        tmEnd = getSystemTime();
        OutTime = tmEnd - tmBegin;
        
      
      //  printf("OutTime：%d\r\n",OutTime);
    }
     printf("读取2：%s",soc->tag_readBuffer);

     AddLog(soc->tag_readBuffer);
     free(ReadEnd);
    return soc->tag_ReadLen;
}


int ReadDataClean2(void*  Soc)
{
    cSocket soc = (cSocket)Soc;
    int tmp = 0;
    long long tmBegin = getSystemTime();
    long long tmEnd = tmBegin;
    long long  OutTime = tmBegin;
    
#pragma ReadEnd内存释放
    char temp[1] ;
    
    while( OutTime<= 200)
    {
        if(SocketIsColse(Soc) ==1)
        {
            
            Close(Soc);
            return 0;
        }
        if(isStop())
        {
   
            Close(Soc);
            return -1;
        }
        tmp =  recv(soc->tag_id,&temp[0],1,0);
        tmEnd = getSystemTime();
        OutTime = tmEnd - tmBegin;
    }
    return soc->tag_ReadLen;
}
/*******************************************************************************************
 **函数名：socketInit
 **参数：,(cSocket soc)
 **功能： 初始化
 **返回值： 
 *******************************************************************************************/
void socketInit(cSocket soc)
{
    soc->tag_id = -1;
    soc ->tag_ReadLen = 0;
    soc ->tag_sendLen = 0;
    soc->sockectConnect = SockectConnect;
    soc->sockectSend = sendData;
    soc->sockectRead = ReadData;
     soc->sockectReadLong = ReadData;//lrz
    soc->ReadDataNotClean =  ReadData;
    soc->sockectClose = Close;
    
   
}
