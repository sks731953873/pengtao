//
//  Config.h
//  TestResistance
//
//  Created by TOD on 6/26/14.
//  Copyright (c) 2014 CeWay. All rights reserved.
//


#ifndef __CONFIG_H__
#define __CONFIG_H__
#include "step.h"

#include "IPConfig.h"
#include "PDCA.h"
#include "port.h"

#define URLMAX 512
#define TEXTLEN 512
#define SNCOUNTMAX 20
typedef  struct _sysIni
{
    char tag_softwarename[TEXTLEN];
    char tag_station_id[TEXTLEN];
    char tag_softwareversion[TEXTLEN];
    char tag_limitsversion[TEXTLEN];
    char tag_sub_station[TEXTLEN];
    char tag_sfc[URLMAX];
    char tag_csvDir[TEXTLEN];//目录路径
    char tag_logDir[TEXTLEN];//目录路径
    char tag_ArmDir[TEXTLEN];//目录路径
    char tag_DutDir[TEXTLEN];//目录路径
    char tag_csvFileName[TEXTLEN];//csv名称，需要拼接
    char tag_ArmFileName[TEXTLEN];//log名称，需要拼接
    char tag_DutFileName[TEXTLEN];//log名称，需要拼接
    char tag_LogFileName[TEXTLEN];//log名称，需要拼接
    char tag_scriptDir[TEXTLEN]; //生成脚本所在路径
    char tag_customerBinDir[TEXTLEN]; //客户bin文件所在路径
    //char tag_sn[SNCOUNTMAX][40];
    char tag_IoShowInputCommand[TEXTLEN];//初始化
    char tag_IoShowInputInitCommand[TEXTLEN];//初始化
    int tag_SnGetMethod;
    int tag_IsLoopTest;
     int tag_IsPdcaUpdata;
      int tag_parse;
    int tag_SnLength;
    char tag_logFile[512];
    
    char tag_stationinfo[100][TEXTLEN];
}SysIni,*sysIni;
#include "StationRun.h"
typedef struct _SConfig
{
    SysIni tag_SysIni;
    IpBag tag_IpBag;
  
    PdcaValueManage tag_pdcaValueManage;
    PortValueManage tag_PortValueManage;
    StationManage tag_stationManage;
    int tag_FctChannel[20];
    int tag_FDLChannel[20];

}SConfig,*sConfig;



extern   sConfig  g_sConfig;;

void Load();
void Save();
void FilecopyDel(char *destFile,char *srcFile);

#endif



