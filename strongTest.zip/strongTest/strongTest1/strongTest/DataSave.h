//
//  DataSave.h
//  strongTest
//
//  Created by strong on 2018/1/15.
//  Copyright © 2018年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "Config.h"
@interface DataSave : NSObject

-(void) Save;
-(void) Load;
@end
