//
//  pdcaView.h
//  strongTest
//
//  Created by strong on 2017/12/20.
//  Copyright © 2017年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "Config.h"
typedef enum _uiPdca_enum
{
    uiPdca_enum_index,//id
    uiPdca_enum_name,//名称
    uiPdca_enum_Uuto,//结果
    uiPdca_enum_Max,//最小值
    uiPdca_enum_Min,//最大值
    uiPdca_enum_type,//类型
       uiPdca_enum_csv_reslut,//保存
    uiPdca_enum_IsAttribute,//保存
     uiPdca_enum_Beishu,//保存
    
}uiPdca_enum;
@interface pdcaView : NSView
{
    NSTextField *tag_UIIndex;//id
    NSTextField *tag_UIName;//名称
    NSTextField *tag_UIUuto;//名称
    NSTextField *tag_UIMax;//名称
    NSTextField *tag_UIMin;//名称
    NSComboBox *tag_UICommandType;//命令类型
    NSTextField *tag_UIIsPass;//命令类型
    NSTextField *tag_UIcsv_reslut;//命令类型
    NSButton *tag_UISave;//保存按钮
    NSButton *tag_UIIsAttribute;//
    NSTextField *tag_UIBeishu;//
    pdcaValue  tag_pdcaValue;
    
}
/*******************************************************************************************
 **函数名：InitUI
 **参数：:(int) index PDCA:(pdcaValue) pdca
 **功能：初始化步骤
 **返回值：
 *******************************************************************************************/
-(void)InitUI:(int) index PDCA:(pdcaValue) pdca;
/*******************************************************************************************
 **函数名：UIUpdata
 **参数：:(int) index  显示的ID STEP:(LpStep) step 步骤
 **功能：刷新步骤
 **返回值：
 *******************************************************************************************/
-(void)UIUpdata:(int) index PDCA:(pdcaValue) pdca;
/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：
 **返回值：
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;
- (void)GetParameter;
@end
