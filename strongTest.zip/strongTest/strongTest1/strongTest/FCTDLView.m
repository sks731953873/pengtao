//
//  FCTDLView.m
//  strongTest
//
//  Created by strong on 2018/1/10.
//  Copyright © 2018年 strong. All rights reserved.
//

#import "FCTDLView.h"

@implementation FCTDLView

-(id)STextField:(NSString *)text
{
    NSTextField  *_UIIndex = [[NSTextField alloc] init];
    _UIIndex.stringValue = [[NSString alloc] initWithFormat:@"%@",text];
    _UIIndex.editable = NO;
    _UIIndex.drawsBackground = NO;
    _UIIndex.bordered = NO;
    
    return _UIIndex;
}
-(void)SetTextField:(NSString *)text ID:(NSTextField *)textField
{
    
    textField.stringValue = [[NSString alloc] initWithFormat:@"%@",text];
    
}
/*******************************************************************************************
 **函数名：InitUI
 **参数：::(int) index STATION:(lpStation) lpstation
 **功能：初始化
 **返回值：
 *******************************************************************************************/

-(void)InitUI:(int) index FCTDL:(fctDlValue) fctDl
{
    if(fctDl)
    {
        tag_fctDlValue = fctDl;
    }
    tag_UIIndex = [self STextField: [[NSString alloc] initWithFormat:@"%2d",index]];
    tag_UITID = [self STextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_TID]];
    tag_UILL = [self STextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_LL]];
    tag_UIUL = [self STextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_UL]];
    tag_UIUnit = [self STextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_Unit]];
    tag_UIUUT0 = [self STextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_UUT0]];
    tag_UIUUT1 = [self STextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_UUT1]];
    tag_UIUUT2 = [self STextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_UUT2]];
    tag_UIUUT3 = [self STextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_UUT3]];
    
    tag_UIValue = [self STextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_Value]];
}
/*******************************************************************************************
 **函数名：UIUpdata
 **参数：::(int) index STATION:(lpStation) lpstation
 **功能：刷新
 **返回值：
 *******************************************************************************************/
-(void)UIUpdata:(int) index
{
    
    [self SetTextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_TID] ID:tag_UITID];
    [self SetTextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_LL] ID:tag_UILL];
    [self SetTextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_UL] ID:tag_UIUL];
    [self SetTextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_Unit] ID:tag_UIUnit];
    [self SetTextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_UUT0] ID:tag_UIUUT0];
    [self SetTextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_UUT1] ID:tag_UIUUT1];
    [self SetTextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_UUT2] ID:tag_UIUUT2];
    [self SetTextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_UUT3] ID:tag_UIUUT3];
       [self SetTextField: [[NSString alloc] initWithFormat:@"%s",tag_fctDlValue->tag_Value] ID:tag_UIValue];

    
}
/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：
 **返回值：
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    
    id retid = nil;
    NSString *title =  tableColumn.title;
    if(tableView.tableColumns[uiFCTDL_enum_index] == tableColumn)
    {
        
        retid = tag_UIIndex;
    }
    else
        if(tableView.tableColumns[uiFCTDL_enum_TID] == tableColumn)
        {
            
            retid = tag_UITID;
        }
        else
            if(tableView.tableColumns[uiFCTDL_enum_LL] == tableColumn)
            {
                
                retid = tag_UILL;
            }
            else
                if(tableView.tableColumns[uiFCTDL_enum_UL] == tableColumn)
                {
                    
                    retid = tag_UIUL;
                }
                else
                    if(tableView.tableColumns[uiFCTDL_enum_Unit] == tableColumn)
                    {
                        
                        retid = tag_UIUnit;
                    }
                    else
                        if(tableView.tableColumns[uiFCTDL_enum_UUT0] == tableColumn)
                        {
                            
                            retid = tag_UIUUT0;
                        }
                        else
                            if(tableView.tableColumns[uiFCTDL_enum_UUT1] == tableColumn)
                            {
                                
                                retid = tag_UIUUT1;
                            }
                            else
                                if(tableView.tableColumns[uiFCTDL_enum_UUT2] == tableColumn)
                                {
                                    
                                    retid = tag_UIUUT2;
                                }
                                else
                                    if(tableView.tableColumns[uiFCTDL_enum_index] == tableColumn)
                                    {
                                        
                                        retid = tag_UIUUT3;
                                    }
    else
    if(tableView.tableColumns[uiFCTDL_enum_Value] == tableColumn)
    {
        
        retid = tag_UIValue;
    }
    
    return retid;
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}


@end
