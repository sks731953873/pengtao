//
//  mainStationView.h
//  strongTest
//
//  Created by strong on 2017/12/31.
//  Copyright © 2017年 strong. All rights reserved.
//
#ifndef _MAINStatION_H_
#define _MAINStatION_H_
#import <Cocoa/Cocoa.h>
#include "Config.h"
@protocol mainStationActionDelegate
-(void)selectStationDelegate:(lpStation) obj;

@end
typedef enum __uiStation_enum
{

    uimainStation_enum_select,//选择
    uimainStation_enum_name,//
    uimainStation_enum_currStep,//
    uimainStation_enum_Ct,//
     uimainStation_enum_sn,//

    
}uimainStation_enum;
@interface mainStationView : NSView
{
    NSButton *tag_UIselect;//工位运行
    NSTextField *tag_UIName;//工位运行
    NSTextField *tag_UIcurrStep;//工位运行
     NSTextField *tag_UICt;//工位运行
    NSTextField *tag_totalPcs;//测试总数
    NSTextField *tag_failedPcs;//failed总数
    NSTextField *tag_UISn;//工位运行
    int isFocse;
    lpStation  tag_Station;//对应工位
    id<mainStationActionDelegate> tag_Delegate;

}
@property(assign,nonatomic)id<mainStationActionDelegate> tag_Delegate;
/*******************************************************************************************
 **函数名：InitUI
 **参数：::(int) index STATION:(lpStation) lpstation
 **功能：初始化
 **返回值：
 *******************************************************************************************/

-(void)InitUI:(int) index STATION:(lpStation) lpstation;
/*******************************************************************************************
 **函数名：UIUpdata
 **参数：::(int) index STATION:(lpStation) lpstation
 **功能：刷新
 **返回值：
 *******************************************************************************************/
-(void)UIUpdata:(int) index STATION:(lpStation) station;

/**
 专门刷新total和failed数量

 @param index <#index description#>
 @param station <#station description#>
 */
-(void)updateTotalAndFailedPcsAtIndex:(int)index Station:(lpStation)station;
-(void)stationRun:(NSObject*) o;
/*******************************************************************************************
 **函数名：StopClick
 **参数：::(id)sender
 **功能：工位停止
 **返回值：
 *******************************************************************************************/
- (IBAction)NextClick:(id)sender;
/*******************************************************************************************
 **函数名：StopClick
 **参数：::(id)sender
 **功能：工位停止
 **返回值：
 *******************************************************************************************/
- (IBAction)StopClick:(id)sender;/*******************************************************************************************
  **函数名：ExeClick
  **参数：::(id)sender
  **功能：工位运行
  **返回值：
  *******************************************************************************************/
- (void)ExeClick:(id)sender;
/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：
 **返回值：
 *******************************************************************************************/

-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;


@end
#endif
