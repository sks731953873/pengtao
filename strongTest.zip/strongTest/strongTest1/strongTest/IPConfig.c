//
//  IPConfig.c
//  strongTest
//
//  Created by strong on 2017/12/19.
//  Copyright © 2017年 strong. All rights reserved.
//

#include "IPConfig.h"

/*******************************************************************************************
 **函数名：IpDel
 **参数：,IpDel(ipBag ipbag,int index) 第几个ip
 **功能： 删除一个ip配置
 **返回值：
 *******************************************************************************************/

int IpDel(ipBag ipbag,int index)
{
    IPConfig tag_ip[IPCOUNT];
    if(index >= IPCOUNT || index > ipbag->tag_count )
    {
        return 0;
    }
    else
    {
       
        ipbag->tag_count++;
    }
    return 0;
}

