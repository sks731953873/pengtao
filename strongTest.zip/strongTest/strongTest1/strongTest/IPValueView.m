//
//  IPValueView.m
//  strongTest
//
//  Created by strong on 2017/12/19.
//  Copyright © 2017年 strong. All rights reserved.
//

#import "IPValueView.h"

@implementation IPValueView
/*******************************************************************************************
 **函数名：InitUI
 **参数：:index IP:(cSocket) soc
 **功能：初始化步骤
 **返回值：
 *******************************************************************************************/
-(void)InitUI:(int) index IP:(cSocket) soc
{
            tag_cSocket = soc;
            socketInit(tag_cSocket);
            tag_UIIndex = [[NSTextField alloc] init];
            tag_UIIndex.stringValue = [[NSString alloc] initWithFormat:@"%2d",index];
         

            tag_UIIP = [[NSTextField alloc] init];
            if(strlen(tag_cSocket->tag_ipConfig->tag_ip) >0)
            {
                tag_UIIP.stringValue = [[NSString alloc] initWithFormat:@"%s",tag_cSocket->tag_ipConfig->tag_ip];
            }
    
            tag_UIName = [[NSTextField alloc] init];
            if(strlen(tag_cSocket->tag_ipConfig ->tag_name) >0)
            {
                tag_UIName.stringValue = [[NSString alloc] initWithFormat:@"%s",tag_cSocket->tag_ipConfig->tag_name];
            }
    
            tag_UIPort = [[NSTextField alloc] init];
            if(tag_cSocket->tag_ipConfig->tag_port >0)
            {
                tag_UIPort.stringValue = [[NSString alloc] initWithFormat:@"%2d",tag_cSocket->tag_ipConfig->tag_port];
            }

    
    
            tag_UISendBuffer = [[NSTextField alloc] init];
            if(strlen(tag_cSocket->tag_sendBuffer) >0)
            {
            tag_UISendBuffer.stringValue = [[NSString alloc] initWithFormat:@"%s",tag_cSocket->tag_sendBuffer];
            }
            tag_UIReAdBuffer = [[NSTextField alloc] init];
            if(strlen(tag_cSocket->tag_readBuffer) >0)
            {
                tag_UIReAdBuffer.stringValue = [[NSString alloc] initWithFormat:@"%s",tag_cSocket->tag_sendBuffer];
            }
            tag_UIConnect = [[NSButton alloc] init];
            [tag_UIConnect setTitle:@"连接"];
            [tag_UIConnect  setTarget:self];
            [tag_UIConnect setAction:@selector(ConnectClick:)];
    
    
    
            tag_UISend = [[NSButton alloc] init];
            [tag_UISend setTitle:@"发送"];
            [tag_UISend  setTarget:self];
            [tag_UISend setAction:@selector(SendClick:)];
    
    
            tag_UISave = [[NSButton alloc] init];
            [tag_UISave setTitle:@"保存"];
            [tag_UISave  setTarget:self];
            [tag_UISave setAction:@selector(SaveClick:)];
    [tag_UISave setBezelStyle:NSBezelStyleSmallSquare];
    
            tag_UIEndFlage = [[NSTextField alloc] init];
 
    tag_UIEndFlage.stringValue =[[NSString alloc] initWithFormat:@"%s",
   tag_cSocket->tag_ipConfig->tag_ReadEndFlage];
    
    tag_UISendEndFlage = [[NSTextField alloc] init];
    
    tag_UISendEndFlage.stringValue =[[NSString alloc] initWithFormat:@"%s",
                                 tag_cSocket->tag_ipConfig->tag_SendendFlage];
    
    
    tag_UIReadendEnterKey = [[NSButton alloc] init];
    [tag_UIReadendEnterKey setButtonType:NSButtonTypeSwitch];
    [tag_UIReadendEnterKey setTitle:@""];
    [tag_UIReadendEnterKey setState:tag_cSocket->tag_ipConfig->tag_isReadEnterkey];
    
    tag_UISendendEnterKey = [[NSButton alloc] init];
    [tag_UISendendEnterKey setButtonType:NSButtonTypeSwitch];
    [tag_UISendendEnterKey setTitle:@""];
    
    [tag_UISendendEnterKey setState:tag_cSocket->tag_ipConfig->tag_isSendEnterkey];
   
}
/*******************************************************************************************
 **函数名：stringToAsc
 **参数：::(id)数据转换
 **功能：保存步骤
 **返回值：
 *******************************************************************************************/
+ (void) stringToAsc:(char *) str ASC:(char*) asc
{
    
    if(str)
    {
        char *temp = ",";
        char *begin = str;
        int i = 0;
        temp = strstr(begin,temp);

        while(temp)
        {
           
            NSString *ns =  [[NSString alloc]initWithBytes:(void *)begin length:temp-begin encoding:NSASCIIStringEncoding];
            asc[i] = [ns integerValue];
            begin =temp +1;
            temp = strstr(begin,temp);
            i++;
        }
        if(begin[0])
        {
            NSString *ns =  [[NSString alloc]initWithBytes:(void *)begin length:strlen(begin) encoding:NSASCIIStringEncoding];
            asc[i] = [ns integerValue];
        }
        // memcpy(tag_cSocket->tag_ipConfig->tag_endFlage,end,strlen(end));
    }
    else
    {
      
    }
    

}
/*******************************************************************************************
 **函数名：SaveClick
 **参数：::(id)sender
 **功能：保存步骤
 **返回值：
 *******************************************************************************************/
- (IBAction)SaveClick:(id)sender
{
    char *end = 0;
  /*  if(tag_UIIP.stringValue.length ==0)
    {
        NSAlert *alert = [NSAlert new];
        [alert addButtonWithTitle:@"确定"];
        [alert setMessageText:@"Ip地址位空，请输入ip地址，再保存!"];
        [alert beginSheetModalForWindow:[tag_UIConnect window] completionHandler:^(NSModalResponse returnCode) {
            if(returnCode == NSAlertFirstButtonReturn)
            {
                
                
            }
        }];
        return ;
    }
    
    if(tag_UIName.stringValue.length ==0)
    {
        NSAlert *alert = [NSAlert new];
        [alert addButtonWithTitle:@"确定"];
        [alert setMessageText:@"ip名称为空，请输入名称，再保存!"];
        [alert beginSheetModalForWindow:[tag_UIConnect window] completionHandler:^(NSModalResponse returnCode) {
            if(returnCode == NSAlertFirstButtonReturn)
            {
                
                
            }
        }];
        return ;
    }*/
    memset(tag_cSocket->tag_ipConfig->tag_ip,0,IPMAXLEN);
    memset(tag_cSocket->tag_ipConfig->tag_name,0,IPNAMEMAXLEN);
    strcat(tag_cSocket->tag_ipConfig->tag_ip,[tag_UIIP.stringValue UTF8String]);
    strcat(tag_cSocket->tag_ipConfig->tag_name,[tag_UIName.stringValue UTF8String]);
    tag_cSocket->tag_ipConfig->tag_port =[tag_UIPort integerValue];
    end = [tag_UIEndFlage.stringValue UTF8String];
    
    memset(tag_cSocket->tag_ipConfig->tag_ReadEndFlage,0,sizeof(tag_cSocket->tag_ipConfig->tag_ReadEndFlage));
    
     strcat(tag_cSocket->tag_ipConfig->tag_ReadEndFlage,[tag_UIEndFlage.stringValue UTF8String]);
    
    

    
    memset(tag_cSocket->tag_ipConfig->tag_SendendFlage,0,sizeof(tag_cSocket->tag_ipConfig->tag_SendendFlage));
    strcat(tag_cSocket->tag_ipConfig->tag_SendendFlage,[tag_UISendEndFlage.stringValue UTF8String]);
    
    
    tag_cSocket->tag_ipConfig->tag_isReadEnterkey =tag_UIReadendEnterKey.state;
    tag_cSocket->tag_ipConfig->tag_isSendEnterkey =tag_UISendendEnterKey.state;

    [tag_UISendendEnterKey setState:tag_cSocket->tag_ipConfig->tag_isSendEnterkey];

    
    NSAlert *alert = [NSAlert new];
    [alert addButtonWithTitle:@"确定"];
    [alert addButtonWithTitle:@"取消"];
    [alert setMessageText:@"确定保存输入文本?"];
    [alert setInformativeText:@"如果确定保存，之前的文本不能再找回!"];

    [alert beginSheetModalForWindow:[tag_UISave window] completionHandler:^(NSModalResponse returnCode) {
        if(returnCode == NSAlertFirstButtonReturn){
            
            Save();
          
        }else if(returnCode == NSAlertSecondButtonReturn){
            
        }
    }];
}
/*******************************************************************************************
 **函数名：ConnectClick
 **参数：::(id)sender
 **功能：连接步骤
 **返回值：
 *******************************************************************************************/
- (IBAction)ConnectClick:(id)sender
{
    if(strlen(tag_cSocket->tag_ipConfig->tag_ip) ==0)
    {
        NSAlert *alert = [NSAlert new];
        [alert addButtonWithTitle:@"确定"];
        [alert setMessageText:@"Ip地址位空，请输入ip地址，再保存!"];
        [alert beginSheetModalForWindow:[tag_UIConnect window] completionHandler:^(NSModalResponse returnCode) {
            if(returnCode == NSAlertFirstButtonReturn)
            {
          

            }
        }];
        return ;
    }
    tag_cSocket->sockectConnect(tag_cSocket);
    if(tag_cSocket->tag_id >0)
    {
        [tag_UIConnect setTitle:@"关闭"];
    }
    else
    {
        [tag_UIConnect setTitle:@"连接"];
    }
  
}
/*******************************************************************************************
 **函数名：SendClick
 **参数：::(id)sender
 **功能：发送步骤
 **返回值：
 *******************************************************************************************/
- (IBAction)SendClick:(id)sender
{
    
    if(tag_UISendBuffer.stringValue.length ==0)
    {
        return ;
    }
    char *buffer = [tag_UISendBuffer.stringValue UTF8String];
    tag_cSocket->tag_sendLen = strlen(buffer);
    memcpy(tag_cSocket->tag_sendBuffer,buffer,tag_cSocket->tag_sendLen);
    
    if(tag_cSocket->tag_id >=0)
    {
        tag_cSocket->sockectSend(tag_cSocket);
    }
}
/*******************************************************************************************
 **函数名：tableView
 **参数：:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
 **功能：ip列表初始化控件
 **返回值：一个ui 控件
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
   
   
    id retid = nil;
    NSString *title =  tableColumn.title;
    if(tableView.tableColumns[uiip_enum_index] == tableColumn)
    {
        
        retid = tag_UIIndex;
    }
    else
        if(tableView.tableColumns[uiip_enum_ip ] == tableColumn)
        {
            retid = tag_UIIP;
            
        }
        else
            if(tableView.tableColumns[  uiip_enum_port ] == tableColumn)
            {
                retid = tag_UIPort;
               
                
            }
    
    
                            else
                                if(tableView.tableColumns[uiip_enum_Save] == tableColumn)
                                {
                                    retid = tag_UISave;
                                    
                                    
                                }
                                else
                                    if(tableView.tableColumns[uiip_enum_name] == tableColumn)
                                    {
                                        
                                        retid = tag_UIName;
                                        
                                    }
                                    else
                                        if(tableView.tableColumns[uiip_enum_endFlage] == tableColumn)
                                        {
                                            
                                            retid = tag_UIEndFlage;
                                            
                                        }
                                        else
                                            if(tableView.tableColumns[uiip_enum_SendendFlage] == tableColumn)
                                            {
                                                
                                                retid = tag_UISendEndFlage;
                                                
                                            }
  else  if(tableView.tableColumns[uiip_enum_SendendEnterKeyFlage] == tableColumn)
    {
        
        retid = tag_UISendendEnterKey;
        
    }
    else
        if(tableView.tableColumns[uiip_enum_ReadendEnterKeyFlage] == tableColumn)
        {
            
            retid = tag_UIReadendEnterKey;
            
        }
    
    
    
    
    return retid;
}

@end
