//
//  FCTFCTVal.m
//  strongTest
//
//  Created by strong on 2018/1/13.
//  Copyright © 2018年 strong. All rights reserved.
//

#import "FCTFCTVal.h"

@implementation FCTFCTVal

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

-(id)initWithName:(NSString *)name andAge:(int)age{
    if(self=[super init]){ //super代表父类

        
    }
    return self;
}

-(void) InitVal
{
    self._1Product1 = @"B332";//
    self._2SerialNumber = @"";//
    self._3PStation_ID = @"CWNJ_Cxx-2FAP-xx_3_MLB-FCT";//
    self._31SiteID=@"";
    self._8TestStartTime =@"" ;//
    self._9TestStopTime =@"";
    
    self._01Scorpius_2=@"";
    self._021ApplicationInfo=@"";
    self._022BT_info=@"";
    self._023AccelInfo=@"";
    self._024ChargeInfo=@"";
    self._025SN=@"";
    self._031PP_IKTARA_OUT_Volt=@"";
    self._032PP1V8_LDO_OUT_Volt=@"";
    self._034PP1V8_SYS_Volt=@"";
    self._035PP1V8_BLE_Volt=@"";
    self._036PP1V8_ROSWELL_PWR_Volt=@"";
    self._041PP1V8_FLASH_Volt=@"";
    self._042PP1V8_GRAPHITE_Volt=@"";
    self._043PP1V8_TANGO_Volt=@"";
    self._044PP1V8_HILO_ISO_Volt=@"";
    self._045PP3V0_4V3_HILO_ISO_Volt=@"";

    self._051cellVoltage=@"";
    self._052actualChargeCurrent=@"";
    self._053inputVoltage=@"";
    self._054inputCurrent=@"";
    
    self._055temp_decideg_0=@"";
    self._056temp_decideg_1=@"";
    self._057temp_decideg_2=@"";
    self._058desiredChargeCurrent=@"";
    self._059buckVoltage=@"";
    
    self._0600JakkuResult=@"";
    self._0601GraphiteResuot=@"";    
    self._061msiFreq=@"";
    self._062hsiFreq=@"";
    self._063lsiFreq=@"";
    self._064lseFreq=@"";
    
    self._071SYSCLK_MSI_FREQ_FAILED=@"";
    self._072SYSCLK_HSI_FREQ_FAILED=@"";
    self._073SYSCLK_LSI_FREQ_FAILED=@"";
    self._074SSYSCLK_LSE_FREQ_FAILED=@"";
    self._075SERIAL_MS=@"";
    self.SaveFileName=@"";
}
-(NSString*) GetCsvStr
{
    NSString * strret=@"";
    strret=[NSString stringWithFormat:@",%@,%@,%@,%@,%@,%@,%@,%@",self._1Product1,self._2SerialNumber,self._3PStation_ID,self._31SiteID,self._8TestStartTime,self._9TestStopTime,self._01Scorpius_2,self._021ApplicationInfo];//6 item
    
     strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,self._022BT_info,self._023AccelInfo,self._024ChargeInfo,self._025SN,self._031PP_IKTARA_OUT_Volt];//5
     strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,self._032PP1V8_LDO_OUT_Volt,self._034PP1V8_SYS_Volt,self._035PP1V8_BLE_Volt,self._036PP1V8_ROSWELL_PWR_Volt,self._041PP1V8_FLASH_Volt];
    
     strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,self._042PP1V8_GRAPHITE_Volt,self._043PP1V8_TANGO_Volt,self._044PP1V8_HILO_ISO_Volt,self._045PP3V0_4V3_HILO_ISO_Volt,self._051cellVoltage];
     strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,self._052actualChargeCurrent,self._053inputVoltage,self._054inputCurrent,self._055temp_decideg_0,self._056temp_decideg_1];
    
     strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,self._057temp_decideg_2,self._058desiredChargeCurrent,self._059buckVoltage,self._055temp_decideg_0,self._0600JakkuResult];
     strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,self._0601GraphiteResuot,self._061msiFreq,self._062hsiFreq,self._063lsiFreq,self._064lseFreq];
    
     strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,self._071SYSCLK_MSI_FREQ_FAILED,self._072SYSCLK_HSI_FREQ_FAILED,self._073SYSCLK_LSI_FREQ_FAILED,self._074SSYSCLK_LSE_FREQ_FAILED,self._075SERIAL_MS];
    
    return strret;
}
-(NSString*) GetCsvTitle
{
    NSString * strret=@"";
    strret=[NSString stringWithFormat:@",%@,%@,%@,%@,%@,%@,%@,%@",@"Product",@"SN",@"Station_ID",@"SiteID",@"TestStartTime",@"TestStopTime",@"Scorpius_2",@"ApplicationInfo"];//6 item
    
    strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,@"BT_info",@"AccelInfo",@"ChargeInfo",@"ReadSN",@"PP_IKTARA_OUT_Volt"];//5
    
    strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,@"PP1V8_LDO_OUT_Volt",@"PP1V8_SYS_Volt",@"PP1V8_BLE_Volt",@"PP1V8_ROSWELL_PWR_Volt",@"PP1V8_FLASH_Volt"];//5
    strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,@"PP1V8_GRAPHITE_Volt",@"PP1V8_TANGO_Volt",@"PP1V8_HILO_ISO_Volt",@"PP3V0_4V3_HILO_ISO_Volt",@"cellVoltage"];//5
    
    strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,@"actualChargeCurrent",@"inputVoltage",@"inputCurrent",@"temp_decideg_0",@"temp_decideg_1"];//5
    strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,@"temp_decideg_2",@"desiredChargeCurrent",@"buckVoltage",@"temp_decideg_0",@"JakkuResult"];//5
    
    strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,@"GraphiteResuot",@"msiFreq",@"hsiFreq",@"lsiFreq",@"lseFreq"];//5
    strret=[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",strret,@"SYSCLK_MSI_FREQ_FAILED",@"SYSCLK_HSI_FREQ_FAILED",@"SYSCLK_LSI_FREQ_FAILED",@"SSYSCLK_LSE_FREQ_FAILED",@"SERIAL_MS"];//5
    
    
    return strret;
}


@end
