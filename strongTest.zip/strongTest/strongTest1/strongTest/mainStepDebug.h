//
//  mainStepDebug.h
//  strongTest
//
//  Created by strong on 2017/12/30.
//  Copyright © 2017年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "Config.h"
typedef enum _uiPdca_enum
{
    uimainStepDebug_enum_index,//id
    uimainStepDebug_enum_name,//名称
    uimainStepDebug_enum_value,//结果
    uimainStepDebug_enum_Max,//最小值
    uimainStepDebug_enum_Min,//最大值
    uimainStepDebug_enum_uuto,//最大值
    

    uimainStepDebug_enum_IsPass,//是否ng

}uiPdca_enum;
@interface mainStepDebug : NSView
{
    NSTextField *tag_UIIndex;//id
    NSTextField *tag_UIName;//id
    NSTextField *tag_UIValue;//id
    NSTextField *tag_UIuuto;//id
    
    NSTextField *tag_UIMax;//id
    NSTextField *tag_UIMin;//id
    NSTextField *tag_UIIsPass;//id
    LpStep _tag_lpLpStep;
    pdcaValueManage tag_pdcaValueManage;
    lpStation _tag_lpStation;
    NSProgressIndicator *tag_NSProgressIndicator;

}
@property (readonly)  LpStep tag_lpLpStep;
@property (readonly)   lpStation tag_lpStation;
/*******************************************************************************************
 **函数名：InitUI
 **参数：::(int) index STATION:(lpStation) lpstation
 **功能：初始化
 **返回值：
 *******************************************************************************************/

-(void)InitUI:(int) index STEP:(LpStep) step PDCAMANAGE:(pdcaValueManage) pdcam STATION:(lpStation) station;
/*******************************************************************************************
 **函数名：UIUpdata
 **参数：::(int) index STATION:(lpStation) lpstation
 **功能：刷新
 **返回值：
 *******************************************************************************************/
-(void)UIUpdata:(int) index;
/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：
 **返回值：
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;
@end
