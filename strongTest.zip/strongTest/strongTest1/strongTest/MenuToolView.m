//
//  MainMenuView.m
//  strongTest
//
//  Created by strong on 2017/12/15.
//  Copyright © 2017年 strong. All rights reserved.
//

#import "MenuToolView.h"
#include "Config.h"
#import "NSImageView+extension.h"

@interface MenuToolView ()

@property (weak) IBOutlet NSButton *tag_MainUIButton;//按钮
@property (weak) IBOutlet NSButton *tag_DebugUiButton;//调试按钮
@property (weak) IBOutlet NSButton *tag_LoginUiButton;//登录按钮
@property (weak) IBOutlet NSButton *tag_ExitUiButton;//退出按钮
@property (weak) IBOutlet NSImageView *tag_LogoImageView;
@property (weak) IBOutlet NSTextFieldCell *label_userName;

@end
@implementation MenuToolView
/*******************************************************************************************
 **函数名：initWithFrame
 **参数：,(CGRect)frame 初始化 大小
 **功能：运行一个工位
 **返回值：< 0失败
 *******************************************************************************************/
- (instancetype)initWithFrame:(CGRect)frame 
{
    self = [super initWithFrame:frame];
    
    if (self) {
        
        //int i = 0;
        NSArray *arr = [NSArray array];
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([MenuToolView class]) owner:nil topLevelObjects:&arr];
        
        for(int i = 0;i < arr.count;i++)
        {
            
            //id tem = [self class];
            
            if([arr[i] isKindOfClass:[self class]])
            {
                MenuToolView *StepView = arr[i];
                CGRect frame1 = {frame.origin.x, frame.origin.y, StepView.frame.size.width, StepView.frame.size.height};
                StepView.frame = frame1;
                self = StepView;
                self.label_userName.stringValue =[[NSString alloc] initWithFormat:@"Station ID:%s", g_sConfig->tag_SysIni.tag_station_id];
                break;
            }
        }
    }
    return self;
}



- (void)viewDidMoveToWindow
{
    [super viewDidMoveToWindow];
    [self.tag_LogoImageView rotateImageWithAxisX:0 AxisY:1 AxisZ:0 Angle:M_PI Duration:1];
}


- (void)receiveNotificationAct:(NSNotification *)note
{
    self.label_userName.stringValue = note.object;
}

- (void)awakeFromNib
{
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center addObserver:self selector:@selector(receiveNotificationAct:) name:@"SRLoginNotification" object:nil];
}

- (void)dealloc
{
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center removeObserver:self];
}


- (IBAction)loginBtnDidClick:(id)sender
{
    [_tag_mainButtonDelegate LoginBtnDelegate:self];  
}




/*******************************************************************************************
 **函数名：ExitAction
 **参数：,id)sender
 **功能：按钮事件 tag_ExitUiButton
 **返回值：< 0失败
 *******************************************************************************************/
- (IBAction)ExitAction:(id)sender
{
    exit(0);
}




/*******************************************************************************************
 **函数名：MainAction
 **参数：,id)sender
 **功能：按钮事件
 **返回值：< 0失败
 *******************************************************************************************/
- (IBAction)MainAction:(id)sender
{
    [_tag_mainButtonDelegate MainButtonDelegate:self];
}



/*******************************************************************************************
 **函数名：DebugAction
 **参数：,id)sender
 **功能：按钮事件
 **返回值：< 0失败
 *******************************************************************************************/
- (IBAction)DebugAction:(id)sender
{
    [_tag_mainButtonDelegate DebugButtonDelegate:self];
}




/*******************************************************************************************
 **函数名：LoginAction
 **参数：,id)sender
 **功能：按钮事件 
 **返回值：< 0失败
 *******************************************************************************************/
- (IBAction)LoginAction:(id)sender
{
    [_tag_mainButtonDelegate LoginButtonDelegate:self];
}



- (void)drawRect:(NSRect)dirtyRect
{
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
