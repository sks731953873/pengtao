//
//  IPValueView.h
//  strongTest
//
//  Created by strong on 2017/12/19.
//  Copyright © 2017年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "Config.h"
typedef enum _uiip_enum
{
    uiip_enum_index,//id
    uiip_enum_name,//名称
    uiip_enum_ip,//ip
    uiip_enum_port,//端口 

     uiip_enum_SendendFlage,//结束标记
     uiip_enum_SendendEnterKeyFlage,//结束标记
    uiip_enum_endFlage,//结束标记
 uiip_enum_ReadendEnterKeyFlage,//结束标记
    uiip_enum_Save,//保存的

    
    
}uiip_enum;

@interface IPValueView : NSView
{
    NSTextField *tag_UIName;//名称
    NSTextField *tag_UIIndex;//id
    NSTextField *tag_UIIP;//ip
    NSTextField *tag_UIPort;//端口
    NSTextField *tag_UISendBuffer;//发送的数据
    NSTextField *tag_UIEndFlage;//结束标记
    NSTextField *tag_UISendEndFlage;//结束标记
    NSTextField *tag_UIReAdBuffer;//读入的数据
    NSButton   *tag_UIConnect;//连接的按钮
    NSButton   *tag_UISend;//发送按钮
    NSButton   *tag_UIReadendEnterKey;//保存啊扭
    NSButton   *tag_UISendendEnterKey;//保存啊扭
    NSButton   *tag_UISave;//保存啊扭
    cSocket tag_cSocket;//socket
}
/*******************************************************************************************
 **函数名：InitUI
 **参数：:index IP:(cSocket) soc
 **功能：初始化步骤
 **返回值：
 *******************************************************************************************/
-(void)InitUI:(int) index IP:(cSocket) soc;
/*******************************************************************************************
 **函数名：SaveClick
 **参数：::(id)sender
 **功能：保存步骤
 **返回值：
 *******************************************************************************************/
- (IBAction)SaveClick:(id)sender;
/*******************************************************************************************
 **函数名：ConnectClick
 **参数：::(id)sender
 **功能：连接步骤
 **返回值：
 *******************************************************************************************/
- (IBAction)ConnectClick:(id)sender;
/*******************************************************************************************
 **函数名：SendClick
 **参数：::(id)sender
 **功能：发送步骤
 **返回值：
 *******************************************************************************************/
- (IBAction)SendClick:(id)sender;
/*******************************************************************************************
 **函数名：tableView
 **参数：:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
 **功能：ip列表初始化控件
 **返回值：一个ui 控件
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;
+ (void) stringToAsc:(char *) str ASC:(char*) asc;


@end
