//
//  Regex.m
//  Button-Switch
//
//  Created by tusm on 14-7-11.
//  Copyright (c) 2014年 tusm. All rights reserved.
//

#import "Regex.h"
static Regex* regex=nil;

@implementation Regex

+(Regex*)instance
{
    if(regex==nil)
    {
        regex=[[Regex alloc] init];
    }
    
    return regex;
}

-(id)init
{
    if(self=[super init])
    {
        
    }
    
    return self;
}

-(void)dealloc
{
    [regex release];
    [super dealloc];
}

//
//-(void)ReadFile
//{
//    NSString* strPath=@"/Users/tusm/Desktop/button csv/7-11 －02/Button.csv";
//    NSString* strLogContent=[NSString stringWithContentsOfFile:strPath usedEncoding:nil error:nil];
//    [self RegexText:strLogContent];
//}

//-(void)RegexText:(NSString*)strTemp
//{
//    NSString* strRegex=@"(?<=)(DV3424403ZCFT2W61SIP)(?=,)";
//    NSArray* arrayTemp= [strTemp componentsMatchedByRegex:strRegex];
//
//    int count=(int)[arrayTemp count];
//
//    NSLog(@"%d",count);
//}


//
//-(int)RegexText:(NSString*)strSN
//{
//    NSString* strPath=@"/Users/tusm/Desktop/button csv/7-11 －02/Button.csv";
//    NSString* strLogContent=[NSString stringWithContentsOfFile:strPath usedEncoding:nil error:nil];
//
//    NSString* strRegex=[NSString stringWithFormat:@"%@%@%@",@"(?<=)(",strSN,@")(?=,)"];
//
//    NSArray* arrayTemp= [strLogContent componentsMatchedByRegex:strRegex];
//
//    int count=(int)[arrayTemp count];
//
//    NSLog(@"%d",count);
//
//    return count;
//}

-(int)RegexText:(NSString*)strSN andFilePath:(NSString*)strPath
{
    //    NSString* strPath=@"/Users/tusm/Desktop/button csv/7-11 －02/Button.csv";
    NSString* strLogContent=[NSString stringWithContentsOfFile:strPath usedEncoding:nil error:nil];
    
    NSString* strRegex=[NSString stringWithFormat:@"%@%@%@",@"(?<=\n)(",strSN,@")(?=,)"];
    
    NSArray* arrayTemp= [strLogContent componentsMatchedByRegex:strRegex];
    
    int count=(int)[arrayTemp count];
    
    NSLog(@"%d",count);
    
    return count;
}


@end
