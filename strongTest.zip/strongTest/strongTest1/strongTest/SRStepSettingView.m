//
//  PopUp_SubView.m
//  strongTest
//
//  Created by 客人用户 on 2018/3/9.
//  Copyright © 2018年 strong. All rights reserved.
//

#import "SRStepSettingView.h"
#import "StepView.h"

@interface SRStepSettingView ()<NSComboBoxDelegate>

@property (weak) IBOutlet  NSComboBox *tag_UiCoBoxThread;
@property (weak) IBOutlet NSComboBox *tag_UiCoBoxCommadType;
@property (weak) IBOutlet NSComboBox *tag_UiTextAlgorithmType;
@property (weak) IBOutlet NSComboBox *tag_UiCoBoxExcTimes;
@property (weak) IBOutlet NSTextField *tag_UiTextSleepData;

@property (weak) IBOutlet NSButton *tag_UiBtnEnable;
@property (weak) IBOutlet NSTextField *tag_UiTextcommand;
@property (weak) IBOutlet NSTextField *tag_UiTextResult;


//StepFilteration
@property (weak) IBOutlet NSTextField *tag_UITextReadEndFlag;
@property (weak) IBOutlet NSTextField *tag_UITextfiltrationEnd;
@property (weak) IBOutlet NSTextField *tag_UITextfiltrationBegin;
@property (weak) IBOutlet NSButton *tag_UiBtnEnter;

//PDCA
@property (weak) IBOutlet   NSComboBox *tag_UiCoBoxPDCA;
@property (weak) IBOutlet NSTextField *tag_UiTextMultiple;
@property (weak) IBOutlet NSTextField *tag_UiTextUpLimit;
@property (weak) IBOutlet NSTextField *tag_UiTextLowLimit;
@property (weak) IBOutlet NSTextField *tag_UiTextUuid;
@property (weak) IBOutlet NSTextField *tag_UiTextUuidType;
@property (weak) IBOutlet NSTextField *tag_UiTextCSVWrite;
@property (weak) IBOutlet NSButton *tag_UiBtnAttribute;
@property (weak) IBOutlet NSButton *tag_UiBtnShow;

//Socket
@property (weak) IBOutlet NSComboBox *tag_UiCoBoxSocket;
@property (weak) IBOutlet NSTextField *tag_UiTextSocketName;
@property (weak) IBOutlet NSTextField *tag_UiTextIP;
@property (weak) IBOutlet NSTextField *tag_UiTextPort;
@end

@implementation SRStepSettingView


- (IBAction)saveBtnDidClick:(id)sender {
    [self GetParameter];
    Save();
    [[NSNotificationCenter defaultCenter]postNotificationName:StepUpdateNotifcation object:nil];

}


- (IBAction)cancelBtnDidClick:(id)sender
{
     [NSApp stopModal];
}



-(void)awakeFromNib
{
    [super awakeFromNib];
    self.tag_UiCoBoxPDCA.delegate = self;
    self.tag_UiCoBoxSocket.delegate = self;
}



- (void)setTag_step:(LpStep)tag_step{
    _tag_step = tag_step;
    
    //加载combox的itemStr
    if (self.getComboxItemStrArr) {
        NSMutableDictionary *dictM = self.getComboxItemStrArr();
        
        NSMutableArray *arrM_AlgorithmType = dictM[@"arrM_AlgorithmType"];
        NSMutableArray *arrM_PDCATpye = dictM[@"arrM_PDCATpye"];
        NSMutableArray *arrM_SocketIndex = dictM[@"arrM_SocketIndex"];
        NSMutableArray *arrM_ThreadIndex = dictM[@"arrM_ThreadIndex"];
        NSMutableArray *arrM_commandTpye = dictM[@"arrM_commandTpye"];
        NSMutableArray *arrM_arrM_excTimes = dictM[@"arrM_excTimes"];
        
        [_tag_UiTextAlgorithmType removeAllItems];
        for (NSString *itemStr in arrM_AlgorithmType)
        {
            [_tag_UiTextAlgorithmType addItemWithObjectValue:itemStr];
        }
        
        [_tag_UiCoBoxPDCA removeAllItems];
        for (NSString *itemStr in arrM_PDCATpye)
        {
            [_tag_UiCoBoxPDCA addItemWithObjectValue:itemStr];
        }
        
        [_tag_UiCoBoxSocket removeAllItems];
        for (NSString *itemStr in arrM_SocketIndex)
        {
            [_tag_UiCoBoxSocket addItemWithObjectValue:itemStr];
        }
        
        [_tag_UiCoBoxThread removeAllItems];
        for (NSString *itemStr in arrM_ThreadIndex)
        {
            [_tag_UiCoBoxThread addItemWithObjectValue:itemStr];
        }
        
        [_tag_UiCoBoxCommadType removeAllItems];
        for (NSString *itemStr in arrM_commandTpye)
        {
            [_tag_UiCoBoxCommadType addItemWithObjectValue:itemStr];
        }
        
        [_tag_UiCoBoxExcTimes removeAllItems];
        for (NSString *itemStr in arrM_arrM_excTimes)
        {
            [_tag_UiCoBoxExcTimes addItemWithObjectValue:itemStr];
        }
        
    }
    
    [self.tag_UiCoBoxSocket selectItemAtIndex:tag_step->tag_socket_index];
    [self.tag_UiCoBoxThread  selectItemAtIndex:tag_step->tag_isThread];
    [self.tag_UiCoBoxPDCA selectItemAtIndex:tag_step->tag_pdca_index];
    [self.tag_UiCoBoxCommadType selectItemAtIndex:tag_step->tag_type];
    [self.tag_UiTextAlgorithmType selectItemAtIndex:tag_step->tag_algorithmType];

    [self.tag_UiCoBoxExcTimes selectItemAtIndex:tag_step->tag_exctimes];
    
    self.tag_UiBtnEnter.state =tag_step->tag_readEnterKey;
    self.tag_UiBtnShow.state = tag_step->tag_isMainShow;
    self.tag_UiBtnEnable.state = tag_step->tag_enable;
    
    self.tag_UiTextSleepData.stringValue = [NSString stringWithFormat:@"%d",tag_step->tag_SleepDate];
    self.tag_UITextReadEndFlag.stringValue = [NSString stringWithFormat:@"%s",tag_step->tag_ReadEndFlage];
    self.tag_UITextfiltrationEnd.stringValue = [NSString stringWithFormat:@"%s",tag_step->tag_filtrationEnd];
    self.tag_UITextfiltrationBegin.stringValue = [NSString stringWithFormat:@"%s",tag_step->tag_filtrationBegin];
    self.tag_UiTextcommand.stringValue = [NSString stringWithFormat:@"%s",tag_step->tag_sendCommand];
    self.tag_UiTextResult.stringValue = [NSString stringWithFormat:@"%s",tag_step->tag_Result];
    
    
}

- (void )GetParameter
{
    memset(_tag_step->tag_sendCommand,0,sizeof(_tag_step->tag_sendCommand));
    strcat(_tag_step->tag_sendCommand, _tag_UiTextcommand.stringValue.UTF8String);
    
    _tag_step->tag_type = (enum_commandType)_tag_UiCoBoxCommadType.indexOfSelectedItem;
    
    _tag_step->tag_enable = (int)_tag_UiBtnEnable.state;
    
    _tag_step->tag_SleepDate = [_tag_UiTextSleepData.stringValue intValue];
    
    memset(_tag_step->tag_filtrationBegin,0,sizeof(_tag_step->tag_filtrationBegin));
    strcat(_tag_step->tag_filtrationBegin,[_tag_UITextfiltrationBegin.stringValue UTF8String]);
    
    memset(_tag_step->tag_filtrationEnd,0,sizeof(_tag_step->tag_filtrationEnd));
    strcat(_tag_step->tag_filtrationEnd,[_tag_UITextfiltrationEnd.stringValue UTF8String]);
    
    memset(_tag_step->tag_ReadEndFlage,0,sizeof(_tag_step->tag_ReadEndFlage));
    strcat(_tag_step->tag_ReadEndFlage,[_tag_UITextReadEndFlag.stringValue UTF8String]);
    
    _tag_step->tag_pdca_index = (int)_tag_UiCoBoxPDCA.indexOfSelectedItem;
    
    _tag_step->tag_socket_index = (int)_tag_UiCoBoxSocket.indexOfSelectedItem;

    _tag_step->tag_isThread =  (int)_tag_UiCoBoxThread.indexOfSelectedItem;
    
    _tag_step->tag_algorithmType =  (int)_tag_UiTextAlgorithmType.indexOfSelectedItem;
    
    _tag_step->tag_exctimes =  (int)_tag_UiCoBoxExcTimes.indexOfSelectedItem;
    
    _tag_step->tag_isMainShow = (int)_tag_UiBtnShow.state;
    
    _tag_step->tag_readEnterKey = (int)_tag_UiBtnEnter.state;
    
}

#pragma mark ---NSComboBoxDelegate---
- (void)comboBoxSelectionDidChange:(NSNotification *)notification{
    NSComboBox *combox = notification.object;
    
    if (combox == self.tag_UiCoBoxPDCA) {
        NSInteger index = [combox indexOfSelectedItem] - 1;
        if (index < 0)
        {
            self.tag_UiTextUpLimit.stringValue = @"";
            self.tag_UiTextLowLimit.stringValue = @"";
            self.tag_UiTextMultiple.stringValue = @"";
            
            self.tag_UiTextUuid.stringValue = @"";
            self.tag_UiTextCSVWrite.stringValue = @"";
            self.tag_UiBtnAttribute.state = 0;//有什么用？？
            self.tag_UiTextUuidType.stringValue = @"";
            return;
        }
        
        PdcaValue tag_PdcaValue = _tag_pdcaValueManage->tag_PdcaValue[index];
        
        self.tag_UiTextUpLimit.stringValue = [NSString stringWithFormat:@"%s",tag_PdcaValue.tag_Max];
        self.tag_UiTextLowLimit.stringValue = [NSString stringWithFormat:@"%s",tag_PdcaValue.tag_Min];
        self.tag_UiTextMultiple.stringValue = [NSString stringWithFormat:@"%f",tag_PdcaValue.tag_Beishu];
        
        self.tag_UiTextUuid.stringValue = [NSString stringWithFormat:@"%s",tag_PdcaValue.tag_uutio];
        self.tag_UiTextCSVWrite.stringValue = [NSString stringWithFormat:@"%s",tag_PdcaValue.tag_csvReslut];
        
        self.tag_UiBtnAttribute.state = tag_PdcaValue.tag_IsAttribute;//有什么用？？
        NSArray *UuidTypeStrArr = @[@"String_pass",
                                    @"Bool",
                                    @"Double",
                                    @"String_value",
                                    @"String_Set",
                                    @"SnRead"];
        self.tag_UiTextUuidType.stringValue = UuidTypeStrArr[tag_PdcaValue.tag_ValueType];
    }
    
    else if (combox == self.tag_UiCoBoxSocket){
        NSInteger index = [combox indexOfSelectedItem];
        IPConfig Ipc = g_sConfig->tag_IpBag.tag_ipConfig[index];
        self.tag_UiTextIP.stringValue = [NSString stringWithFormat:@"%s",Ipc.tag_ip];
        self.tag_UiTextPort.stringValue = [NSString stringWithFormat:@"%d",Ipc.tag_port];
        self.tag_UiTextSocketName.stringValue = [NSString stringWithFormat:@"%s",Ipc.tag_name];
    }
    
 
}

@end

