//
//  SRLogInViewControlloer.h
//  Manual_Debug
//
//  Created by Strong-EE on 2017/9/16.
//  Copyright © 2017年 Strong-EE. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface SRLogInViewControlloer : NSViewController

@property(nonatomic,copy) void(^optionBlock)(NSString *);
@end
