//
//  StepView.h
//  strongTest
//
//  Created by strong on 2017/12/15.
//  Copyright © 2017年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "Config.h"
#import "WaitView.h"

@protocol StepViewActionDelegate
-(void)OpenSpreadOutDelegate:(id) obj;
@end
@interface StepView : NSView
{
    id tag_UIIndex;//显示的id
    NSTextField *tag_UIName;//名称
    NSButton *tag_UISet;//setting
    NSTextField *tag_UIResult;//返回的结果
    NSTextField *tag_UISleepTime;//延迟时间
    NSButton   *tag_UIExe;//执行按钮
    NSButton   *tag_UISave;//保存按钮
    NSComboBox *tag_UICommandType;//命令类型
    
    NSButton   *tag_UIEnableCheckBox;// 屏蔽按钮
    NSComboBox *tag_UIPDCAType;//命令类型    
    NSTextField *tag_UIfiltrationBegin;//结果过滤
    NSTextField *tag_UIfiltrationEnd;        //结果过滤
    
    NSTextField *tag_UITEst;        //结果过滤
    
    NSTextField *tag_UIReadEnd;        //读结束呼号
    
    
    NSComboBox * tag_UISocketIndex;
    
    
    NSProgressIndicator *tag_NSProgressIndicator;
    
    NSComboBox * tag_UIThreadIndex;
    
    
    NSButton *tag_UIIsMainShow;//命令类型
    
    NSButton *  tag_UIButtonIndex ;
    NSButton *  tag_UITextIndex ;
    
    NSButton *  tag_UIReadEndEnterIndex ;
     NSComboBox * tag_UiExcTimes; //执行次数
    NSComboBox * tag_UIAlgorithmType; //算法类型
    int tag_IsShowCommandOrResult;//收否显示命令，结果，还是都显示 0，只显示发送命令，1只显示结果，2 都显示
    
    WaitView * tag_wait ;
   // NSce
    
    LpStep _tag_step;//步骤
    cSocket tag_cSocket;//socket
    pdcaValueManage tag_pdcaValueManage;//pdca

    lpStation _tag_lpStation;
      id<StepViewActionDelegate> tag_StepViewActionDelegate;
    id tagt_super;
}
@property (readonly)  LpStep tag_step;
@property (readonly)  lpStation tag_lpStation;
@property(assign,nonatomic)id<StepViewActionDelegate> tag_StepViewActionDelegate;
/*******************************************************************************************
 **函数名：InitUI
 **参数：:(int) index  显示的ID STEP:(LpStep) step 步骤
 **功能：初始化步骤
 **返回值：
 *******************************************************************************************/
-(void)InitUI:(NSString*) index STEP:(LpStep) step PDCA:(pdcaValueManage) pcda STATION:(lpStation) station SUPER:(id) super_ COMMANDTYPE:(int) commandType;


/*******************************************************************************************
  **函数名：ExeClick
  **参数：:xeClick:(id)sender
  **功能：单步运行
  **返回值：
  *******************************************************************************************/

- (IBAction)ExeClick:(id)sende;
/*******************************************************************************************
 **函数名：SaveClick
 **参数：:xeClick:(id)sender
 **功能：单步保存事件
 **返回值：
 *******************************************************************************************/
- (IBAction)SaveClick:(id)sender;
/*******************************************************************************************
 **函数名：tableView
 **参数：:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
 **功能：单步保存事件
 **返回值：一个ui 控件
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;
/*******************************************************************************************
 **函数名：GetParameter
 **参数：:xeClick:(id)sender
 **功能：单步保存事件
 **返回值：
 *******************************************************************************************/
- (IBAction)GetParameter;
-(void)UIUpdata;
-(void)InitUI2;
-(void)UIUpdata:(NSString*) index STEP:(LpStep) step COMMANDTYPE:(int) commandType;
@end
