//
//  SRLogInViewControlloer.m
//  Manual_Debug
//
//  Created by Strong-EE on 2017/9/16.
//  Copyright © 2017年 Strong-EE. All rights reserved.
//

#import "SRLogInViewControlloer.h"
#import "SRpopViewController.h"
#define pwdInfoPath [[NSBundle mainBundle]pathForResource:@"PasswordInfo" ofType:@"plist"]
@interface SRLogInViewControlloer ()<SRpopViewControllerDelegate>
@property (weak) IBOutlet NSSecureTextField *secureTF_pwd;
@property (strong) IBOutlet SRpopViewController *popContentViewController;
@property (strong) IBOutlet NSPopover *popover;
@property (weak) IBOutlet NSButton *pwdBtn;
@property (weak) IBOutlet NSPopUpButton *popUpBtn_user;
@end



@implementation SRLogInViewControlloer

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"用户登录";
    [self.popUpBtn_user selectItemAtIndex:0];//默认adnimistrator登录
    self.popContentViewController.delegate = self;
    // Do view setup here.
}

- (IBAction)changePwdBtnClick:(NSButton *)sender {
    
    [self.popover showRelativeToRect:sender.bounds ofView:sender preferredEdge:NSRectEdgeMaxY];
    
}

- (IBAction)logInBtnClick:(id)sender {
    
    NSDictionary *pwdInfo = [NSDictionary dictionaryWithContentsOfFile:pwdInfoPath];
    
    NSString *pwdStr = [pwdInfo valueForKey:self.popUpBtn_user.selectedItem.title];
    
    if ([self.secureTF_pwd.stringValue isEqualToString:pwdStr])
    {
        self.optionBlock(self.popUpBtn_user.selectedItem.title);
        
        [self dismissController:nil];
    }
    else
    {
        NSAlert *alert = [[NSAlert alloc]init];
        
        [alert addButtonWithTitle:@"确认"];
        
        [alert setMessageText:@"当前帐号密码错误！"];
        
        [alert setInformativeText:[NSString stringWithFormat:@"你当前所选的帐号等级为%@，如忘记密码请登录Adnimistrator帐号进行修改或清除～",self.popUpBtn_user.selectedItem.title]];
        
        [alert runModal];

     //   [alert beginSheetModalForWindow:self.view.window completionHandler:nil];
       
    }
    
   
    
}
- (IBAction)cancelBtnClick:(id)sender {
    
    [self dismissController:nil];
    
}


#pragma mark  ***********SRpopViewControllerDelegate**************
- (void)closePopover{
    [self.popover close];
}

@end
