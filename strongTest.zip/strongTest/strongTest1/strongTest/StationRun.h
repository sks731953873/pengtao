//
//  DownLoadStation.h
//  strongTest
//
//  Created by strong on 2017/12/26.
//  Copyright © 2017年 strong. All rights reserved.
//

#ifndef DownLoadStation_h
#define DownLoadStation_h

#include <stdio.h>
typedef enum enum_station_type
{
    enum_station_type_work,
    enum_station_type_rest,
    enum_station_type_stop,
};
typedef enum enum_workState
{
    enum_workState_work = 1,
    enum_workState_working = 2,
    enum_workState_notRest = 3,
    enum_workState_resting = 4,
    enum_workState_stopting = 5,
};


typedef struct _station
{
    int tag_stationType;
    int tag_totalCount;//步总📖
    int tag_Index;//当前有哪些步
    char tag_Name[MAXNAME];//工位名
    Step tag_step[MAXSTEP];
    LpStep tag_stepCurr;;
    int tag_WorkState;//工作状态
    long long tag_logStartTime;
    int tag_socket_index;//对应的socket id号，供选择默认位0，既是不选择;
    int tag_isOpenSpreadOut;//是否展开默认不展开
    int tag_isEnable;
    int tag_MainShow;//主界面是否显示
    int tag_snIndex;
    int tag_isThread;//线程是否支持
    int tag_isWait;//是否等待
    char tag_StartTime[MAXNAME];
    char tag_EndTime[MAXNAME];
    void *tag_user;
    char tag_logFile[512];
    char tag_DutFile[512];
    char tag_ArmFile[512];
}Station,*lpStation;



typedef struct _stationManage
{
    int tag_totalCount;//步总📖
    int tag_StepIndex;//当前步索引
    int tag_WorkStop;//是否急停
    int tag_WorkState;//工作状态
    int tag_RestState;//状态
    int tag_isRest;
    Station tag_Station[MAXSTATION];
    LpStep tag_CurrStep;
    lpStation tag_currStation;
}StationManage,*stationManage;
/*
 一个工位管理
 */
typedef struct _StationRun
{
    lpStation  tag_station;//一个工位
    CSocket     tag_cSocket[IPCOUNT];//通信
    pdcaValueManage tag_pdcaValueManage;
    portValueManage tag_portValueManage;
    sysIni tag_sysIni;
}StationRun,*lpStationRun;
/*******************************************************************************************
 **函数名：stationExe
 **参数：,Station  *station。运行的工位
 **功能：运行一个工位
 **返回值：< 0失败
 *******************************************************************************************/
int stationExe(Station  *station);
/*******************************************************************************************
 **函数名：stepDelete
 **参数：,Station  *station。运行的工位 ,int delIndex 删除第几个工位
 **功能：删除一个步骤
 **返回值：< 0失败
 *******************************************************************************************/
int stepDelete(Station *station,int delIndex);
/*******************************************************************************************
 **函数名：stepInster
 **参数：,Station  *station。运行的工位 ,int delIndex 第几个步骤，,Step *step 插入的步骤
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
int stepInster(Station *station,int index,Step *step);

/*******************************************************************************************
 **函数名：stationDelete
 **参数：,StationManage *station,int delIndex 第几个工位
 **功能：删除一个工位
 **返回值：
 *******************************************************************************************/
int stationDelete(StationManage *station,int delIndex);
/*******************************************************************************************
 **函数名：stationInster
 **参数：,StationManage *station,int delIndex 第几个工位
 **功能：插入一个工位
 **返回值：
 *******************************************************************************************/
int stationInster(StationManage *station,int index);
/*******************************************************************************************
 **函数名：SocketSend
 **参数：,void *p。数据指针
 **参数：char *sendBuffer。发送的数据
 **功能：
 **返回值：< 0失败
 *******************************************************************************************/
int SocketSend(char *sendBuffer,void *p);
/*******************************************************************************************
 **函数名：SocketStepExe
 **参数：,void *p。数据指针
 **功能：socket 数据发送,发送配置的指令
 **返回值：< 0失败
 *******************************************************************************************/
int SocketStepExe(void *p);
/*******************************************************************************************
 **函数名：IOSocketReadIo
 **参数：,void *p。数据指针
 **功能：socketIO 读
 **返回值：< 0失败
 *******************************************************************************************/
 int IOSocketReadIo(void *p,char var);
/*******************************************************************************************
 **函数名：IOSocketSetIo
 **参数：,void *p。数据指针
 **功能：socketIO 设置
 **返回值：< 0失败
 *******************************************************************************************/
int IOSocketSetIo(void *p);
/*******************************************************************************************
 **函数名：ScriptStepExe
 **参数：,void *p。数据指针
 **功能：脚本执行
 **返回值：< 0失败
 *******************************************************************************************/
int ScriptStepExe(void *p);
/*******************************************************************************************
 **函数名：PortStepExe
 **参数：,void *p。数据指针
 **功能： 通过串口发送指令
 **返回值：< 0失败
 *******************************************************************************************/
int PortStepExe(void *p);
/*******************************************************************************************
 **函数名：StepExe
 **参数：,void *p。数据指针
 **功能： 单步执行的指令
 **返回值：< 0失败
 *******************************************************************************************/
int StepExe(void *p);
/*******************************************************************************************
 **函数名：StationInit
 **参数：,(lpStation station,  初始化一个工位
 ipConfig soc)
 **功能： 单步执行的指令
 **返回值：< 0失败
 *******************************************************************************************/
int StationInit(stationManage lpstationManage,lpStationRun lps, lpStation station,ipBag ip,pdcaValueManage lppdca,portValueManage port);
/*******************************************************************************************
 **函数名：GetSocket
 **参数：,
 **参数：
 **功能：获取一个csocket指针
 **返回值：< 0失败
 *******************************************************************************************/
cSocket GetSocket (void *p);
/*******************************************************************************************
 **函数名：stationExe
 **参数：,Station  *station。运行的工位
 **功能：运行一个工位
 **返回值：< 0失败
 *******************************************************************************************/
int stationManageExe(StationManage  *stationManage,int ExeStationType);

#endif /* DownLoadStation_h */
