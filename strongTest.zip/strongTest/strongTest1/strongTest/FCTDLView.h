//
//  FCTDLView.h
//  strongTest
//
//  Created by strong on 2018/1/10.
//  Copyright © 2018年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "FCTDL.h"
typedef enum _uiFCTDL_enum
{
    uiFCTDL_enum_index,//id
    
    uiFCTDL_enum_TID,//名称
    uiFCTDL_enum_Value,//结果
    uiFCTDL_enum_LL,//结果
    uiFCTDL_enum_UL,//最小值
    uiFCTDL_enum_Unit,//最大值
    uiFCTDL_enum_UUT0,//是否ng
    uiFCTDL_enum_UUT1,//,结果过滤2
    uiFCTDL_enum_UUT2,//,结果过滤2
    uiFCTDL_enum_UUT3,//,结果过滤2
    
}uiPdca_enum;
@interface FCTDLView : NSView
{
    NSTextField *tag_UIIndex;//id
    NSTextField *tag_UITID;//id
     NSTextField *tag_UIValue;//id
    NSTextField *tag_UILL;//id
    NSTextField *tag_UIUL;//id
    NSTextField *tag_UIUnit;//id
    NSTextField *tag_UIUUT0;//id
    NSTextField *tag_UIUUT1;//id
    NSTextField *tag_UIUUT2;//id
    NSTextField *tag_UIUUT3;//id
   // LpStep tag_lpLpStep;
    fctDlValue tag_fctDlValue;
}
/*******************************************************************************************
 **函数名：InitUI
 **参数：::(int) index STATION:(lpStation) lpstation
 **功能：初始化
 **返回值：
 *******************************************************************************************/

-(void)InitUI:(int) index FCTDL:(fctDlValue) fctDl;
/*******************************************************************************************
 **函数名：UIUpdata
 **参数：::(int) index STATION:(lpStation) lpstation
 **功能：刷新
 **返回值：
 *******************************************************************************************/
-(void)UIUpdata:(int) index;
/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：
 **返回值：
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;


@end
