//
//  SRIOItemView.m
//  strongTest
//
//  Created by strong on 2018/1/23.
//  Copyright © 2018年 strong. All rights reserved.
//

#import "SRIOItemView.h"

@interface SRIOItemView ()
//@property (weak) IBOutlet NSTextFieldCell *label_IOName;
//@property (weak) IBOutlet NSImageCell *image_IOimage;
@property (weak) IBOutlet NSButton *btn;

@end

@implementation SRIOItemView


- (void)awakeFromNib{
    self.btn.image = [NSImage imageNamed:@"led-off-16"];
    self.layer.backgroundColor = [NSColor cyanColor].CGColor;
    [self setWantsLayer:YES];
}

-(void)setNum:(int)Num{
    _Num = Num;
    self.btn.title = [@"IO_" stringByAppendingString:[NSString stringWithFormat:@"%d",Num]];
}
- (void)setActive:(BOOL)active{
    _active = active;
    if (self.isActive) {
        self.btn.image = [NSImage imageNamed:@"led-green-on-16"];
        
    }else{
        self.btn.image = [NSImage imageNamed:@"led-off-16"];
    }
}
- (IBAction)btnDidClick:(id)sender {
    NSButton *button = ( NSButton *)sender;
    self.sendState = button.state;
    if ([self.delegate respondsToSelector:@selector(SRIOItemViewDidClick:)]) {
        [self.delegate SRIOItemViewDidClick:self];
     
        if (self.sendInt == 1)
        {
            self.btn.image = [NSImage imageNamed:@"led-green-on-16"];
            
        }else{
            self.btn.image = [NSImage imageNamed:@"led-off-16"];
        
    }
     
    }
}


//- (void)awakeFromNib{
//    self.image_IOimage.image = [NSImage imageNamed:@"led-off-16"];
//    self.layer.backgroundColor = [NSColor cyanColor].CGColor;
//    [self setWantsLayer:YES];
//}
//
//-(void)setNum:(int)Num{
//    _Num = Num;
//    self.label_IOName.stringValue = [@"IO_" stringByAppendingString:[NSString stringWithFormat:@"%d",Num]];
//}
//- (void)setActive:(BOOL)active{
//    _active = active;
//    if (self.isActive) {
//        self.image_IOimage.image = [NSImage imageNamed:@"led-green-on-16"];
//        
//    }else{
//        self.image_IOimage.image = [NSImage imageNamed:@"led-off-16"];
//    }
//}
//- (IBAction)btnDidClick:(id)sender {
//    NSButton *btn = [[NSButton alloc]init];
//    btn.image
//    if ([self.delegate respondsToSelector:@selector(SRIOItemViewDidClick:)]) {
//        [self.delegate SRIOItemViewDidClick:self];
//        self.sendInt != self.sendInt;
//        
//    }
//}
@end
