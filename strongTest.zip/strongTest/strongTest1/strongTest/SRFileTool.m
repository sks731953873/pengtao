//
//  SRFileTool.m
//  strongTest
//
//  Created by strong on 2018/2/4.
//  Copyright © 2018年 strong. All rights reserved.
//

#import "SRFileTool.h"
#include "Config.h"
#import "TestAttributes.h"

char logCmdfilePath[512] = {0};
char logCmdfilePathZip[512] = {0};
int totalPcs[40] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19}; //测试总数量
int failedPcs[40] = {0};//failed数量

@interface SRFileTool ()

/**
 用于打印csv头信息
 */
@property(nonatomic,strong)NSMutableArray *headArr;
@end
@implementation SRFileTool
static id headArrM;
extern

void mkdirFile(char *pathname)
{
    char temp[512] = {0};
    int i = 0;
    int index = 0;
    int len = strlen(pathname);
    memset(temp,0,512);
    while(i < len)
    {
     if(pathname[i] == '/')
     {
         index = i;
     }
        i++;
    }
    i =0;
    while(i < index)
    {
        temp[i] =    pathname[i] ;
        
        i++;
    }
    if(strlen(temp) >0)
    {
      
        NSFileManager *nsfile = [[ NSFileManager alloc] init];
   [  nsfile  createDirectoryAtPath:[[NSString alloc ] initWithUTF8String:temp]
        withIntermediateDirectories:true
                         attributes:nil error:nil] ;
        

    }
    
}



void csvFileWrite( char *file, char *buffer)
{
    FILE * f =   fopen(file, "a+");
    mkdirFile(file);
    if(!f )
    {
        
        return ;
    }
    
    fwrite(buffer,1, strlen(buffer), f);
    fclose(f);
}
int FileIshave( char *file)
{
    FILE * f =   fopen(file, "r");
    if(!f )
    {
        
        return 0 ;
    }
    
   
    fclose(f);
    return 1;
}
/**
 cvs头信息

 @return 返回头信息字符串
 */

/**
 获取文件路径，按每天创建，如果已经存在则不创建
 
 @param fileName 文件名
 @param folderPath 所保存的路径∫
 @param type 类型
 @return 文件全路径
 */
const char* getFilePath(char *fileName,char *folderPath,char *type)
{
    NSString *OC_FolerPath = [NSString stringWithUTF8String:folderPath];
    NSFileManager *mgr = [NSFileManager defaultManager];
    NSDateFormatter *dfmt = [[NSDateFormatter alloc]init];
    dfmt.dateFormat = @"yyyy-MM-dd";
    NSDate *currentDate = [NSDate date];
    NSString *currentDateStr = [dfmt stringFromDate:currentDate];
    NSString *targetFileName =  [[[NSString stringWithUTF8String:fileName] stringByAppendingString:currentDateStr] stringByAppendingString:[NSString stringWithUTF8String:type]];
    NSDirectoryEnumerator<NSString *> *Enum = [mgr enumeratorAtPath:OC_FolerPath];
    bool isExit = NO;
    for (NSString *exitFileName in Enum) {
        if ([exitFileName isEqualToString:targetFileName]) {
            isExit = YES;
            break;
        }
    }
    if (!isExit) {
        [mgr createFileAtPath:[OC_FolerPath stringByAppendingPathComponent:targetFileName] contents:nil attributes:nil];
        /**************判断如果是csv文件，就加入头信息***************/
      
        /****************/
    }
    return [OC_FolerPath stringByAppendingPathComponent:targetFileName].UTF8String;
}

//NSString *fileName = [[NSString alloc] initWithFormat:@"%s%s.csv",g_sConfig->tag_SysIni.tag_csvDir ,GetCurrentDataCtr()];
//
//char *log = malloc(1024*10);
//int i = 0;
//if(!log)
//return ;
//memset(log,0,1024*10);
//
//strcat(log,GetCurrentTimeCtr());
//strcat(log,",");
//strcat(log,[sn  UTF8String]);
//strcat(log,",");
//strcat(log,g_sConfig->tag_SysIni.tag_station_id);
//strcat(log,",");
//
//if([results count])
//{
//    TestAttributes * testItem;
//    for(testItem in results)
//    {
//        strcat(log,[testItem.testResult UTF8String]);
//        strcat(log,",");
//    }
//}
//strcat(log,"\r\n");
//csvwrite([fileName UTF8String ],log);
//
//free(log);

//void writeResultToCSV(lpStation station){
extern char *GetCurrentDataCtr();
char headTitle[1024*10] = {0};
char Product[1024*10] = {0};
char UpperLmt[1024*10] = {0};
char LowerLmt[1024*10] = {0};
char MeasurementUnit[1024*10] = {0};
char *createCSVHead(NSMutableArray *arrM)
{

    char *Product1 = "Product,SerialNumber,Station_ID,Site_ID,PASS/FAIL,Error_Message,Failed_List,Test Start Time,Test Stop Time,";
    char *UpperLmt1 = "Upper Limited----->,,,,,,,,,";
    char *LowerLmt1 = "Lower Limited----->,,,,,,,,,";
    char *MeasurementUnit1= "Measurement unit----->,,,,,,,,,";
    
    memset(headTitle,0,1024*10);
    memset(Product,0,1024*10);
    memset(UpperLmt,0,1024*10);
    memset(LowerLmt,0,1024*10);
    memset(MeasurementUnit,0,1024*10);
    strcat(Product, Product1);
    strcat(UpperLmt, UpperLmt1);
    strcat(LowerLmt, LowerLmt1);
    strcat(MeasurementUnit, MeasurementUnit1);
    
    for (TestAttributes *attr in arrM)
    {
        
        strcat(Product, [[attr GetSubTestName] UTF8String]);
        strcat(Product, ",");
        
        strcat(UpperLmt, [[attr GetUpperLimit] UTF8String]);
        strcat(UpperLmt, ",");
        
        strcat(LowerLmt, [[attr GetLowerLimit] UTF8String]);
        strcat(LowerLmt, ",");
        
        strcat(MeasurementUnit, [[attr GetUutio] UTF8String]);
        strcat(MeasurementUnit, ",");
    }
    
    strcat(headTitle, Product);
    strcat(headTitle, "\r\n");
    strcat(headTitle, UpperLmt);
    strcat(headTitle, "\r\n");
    strcat(headTitle, LowerLmt);
    strcat(headTitle, "\r\n");
    strcat(headTitle, MeasurementUnit);
    strcat(headTitle, "\r\n");
    
    return headTitle;
}
extern int FileIshave( char *file);
extern char *GetCurrentTimeCtrA();
extern char *GetCurrentDataCtr();
+(void)writeResultToCSV:(NSMutableArray *)results SN:(NSString*)sn{
    //如果文件存在久不会继续生成
    headArrM = results;  //用于csv文件头打印
    char filePath[512] = {0};
    char CmdfilePath[512] = {0};
    char *ngpass = "PASS";

    char *noFailList = malloc(1024*10);
    memset(filePath,0,512);
    memset(noFailList,0,1024*10);
    memset(CmdfilePath,0,512);
    
    
    //zip -0 /Users/strong/Desktop/log/B332_FCT_COMBINED2018-02-09.zip  /Users/strong/Desktop/log/B332_FCT_COMBINED-2018-02-09.csv
    
    
    sprintf(filePath,"%s/%s-%s", g_sConfig->tag_SysIni.tag_csvDir,g_sConfig->tag_SysIni.tag_csvFileName,GetCurrentDataCtr());
    strcat(CmdfilePath,"zip '");//-q
    
    strcat(CmdfilePath,g_sConfig->tag_SysIni.tag_csvDir);
    strcat(CmdfilePath,"/");
    strcat(CmdfilePath,g_sConfig->tag_SysIni.tag_csvFileName);
    strcat(CmdfilePath,GetCurrentDataCtr());
    
    strcat(CmdfilePath,".zip'  '");
   // strcat(CmdfilePath,".zip'");
    
    strcat(CmdfilePath,filePath);
    
   // strcat(CmdfilePath,g_sConfig->tag_SysIni.tag_csvFileName);
   // strcat(CmdfilePath,GetCurrentDataCtr());
    

    strcat(CmdfilePath,".csv'");

    
    strcat(filePath,".csv");
    
    
    
    if(FileIshave(filePath) == 0)
    {

        csvFileWrite(filePath,createCSVHead(results));
    }
    
    TestAttributes * testItemT;
    for(testItemT in results)
    {
        if(!strstr( [[testItemT GetTestResult] UTF8String],"1"))
        {
            
            strcat(noFailList,[[testItemT GetSubTestName] UTF8String]);
            strcat(noFailList,"#");
        
        }
    }
    for(testItemT in results)
    {
        if(!strstr( [[testItemT GetTestResult] UTF8String],"1"))
        {
            ngpass = "FAIL";
            break;
            
        }
    }
    char sn_temp[100] = {0};
    memset(sn_temp,0,100);
    char *ch = sn.UTF8String;
    int sn_len = strlen(ch);
    int m = 0;
    int n = 0;
    while(m < sn_len && m < 100)
    {
        if((ch[m]<='9' && ch[m]>='0')
           || (ch[m]>='A' && ch[m]<='Z')
           || (ch[m]>='a' && ch[m]<='z')
           
           )
        {
            sn_temp[n] = ch[m];
            n++;
        }
        m++;
    }
    
  
    if([results count])
    {
        TestAttributes * testItem=results.firstObject;
        char *result = malloc(1024*20);
        memset(result,0,1024*20);
        strcat(result, "B332,");
        strcat(result, sn_temp);
        strcat(result, ",");
        strcat(result, g_sConfig->tag_SysIni.tag_station_id);
        strcat(result, ",");
        strcat(result, [testItem GetTestName].UTF8String);
        strcat(result, ",");
        strcat(result, ngpass);
        strcat(result, ",");
        strcat(result, "");
        strcat(result, ",");
        strcat(result, noFailList);
        strcat(result, ",");
        
       
        //统计failed和total总数用于mainStationView刷新
        int siteID = [testItem GetTestName].intValue;
        totalPcs[siteID]++;
        if (strcmp(ngpass, "FAIL") == 0) {
            failedPcs[siteID] ++;
        }
        
            TestAttributes * getStationTime = results.firstObject;
            strcat(result, [getStationTime GetstationStartTime].UTF8String);
            strcat(result, ",");
            strcat(result, [getStationTime GetstationEndTime].UTF8String);
            strcat(result, ",");
           
            
            for(testItem in results)
            {
                int i = 0;
                int len = strlen([[testItem GettestCsvResult] UTF8String]) +1;
              /*testItem.testResult = [[testItem GetTestValue ] stringByReplacingOccurrencesOfString:@"," withString:@"'"];
                testItem.testResult = [[testItem GetTestValue ] stringByReplacingOccurrencesOfString:@"\r\n" withString:@" "];
                testItem.testResult = [[testItem GetTestValue ] stringByReplacingOccurrencesOfString:@"\n" withString:@" "];
               */
                
                char *TestValue = malloc(len);
                memset(TestValue,0,len);
                strcat(TestValue,[[testItem GettestCsvResult] UTF8String]);
                len =strlen( TestValue);
                for(i = 0; i < len;i++ )
                {
                    if(TestValue[i] == ',')
                    {
                        TestValue[i] = '#';
                    }
                    if(TestValue[i] == '\r')
                    {
                        TestValue[i] = '#';
                    }
                    if(TestValue[i] == '\n')
                    {
                        TestValue[i] = '#';
                    }
                }
                strcat(result,TestValue);
                free(TestValue);
                strcat(result,",");
            }
        result[strlen(result)] = '\n';
        NSLog(@"%s",result);
        csvFileWrite(filePath, result);
        free(result);
        }
    
       // system(CmdfilePath);
    
    
        free(noFailList);
 
}


void replaceStr(char *new ,char *olrd,char *Sub)
{
    int j = 0;
    int  index = 0;
    for(int i= 0;i < strlen(olrd);i++)
    {
        if( olrd[i] == '%')
        {
            j = i;
            j ++;
            break;
            
        }
        else
        {
            new[index] = olrd[i];
            index++;
        }
    }
    strcat(new, Sub);
    index =strlen(new);
    
    while(j <strlen(olrd))
    {
        new[index] = olrd[j];
        j ++;
        index++;
    }

}

/**
 FixtureLog文件

 @param results <#results description#>
 @param sn <#sn description#>
 @return <#return value description#>
 */
+(char*)writeResultToFixtureLog:(NSMutableArray *)results SN:(char*)sn
{
    //如果文件存在久不会继续生成
    
    char fileName[512] = {0};

    memset(fileName,0,512);
    memset(logCmdfilePathZip,0,512);
    memset(logCmdfilePath,0,512);
    sprintf(fileName,"%s/%s/%s%s",g_sConfig->tag_SysIni.tag_logDir,GetCurrentDataCtr(),sn,g_sConfig->tag_SysIni.tag_LogFileName);
    char time[128] = {0};
    memset(time,0,128);
       if([results count])
       {
           
           TestAttributes * testItem = results[0];
           sprintf(time,"%s_%s",[[testItem GetTestName] UTF8String],GetCurrentTimeCtrA());
       }
    else
    {
        sprintf(time,"%s_",GetCurrentTimeCtrA());
    }
    
    replaceStr(logCmdfilePathZip,fileName,time);
 
    if([results count])
    {
        
        TestAttributes * testItem;
        for(testItem in results)
        {
            csvFileWrite(logCmdfilePathZip, "==Test: Programming\r\n");
            csvFileWrite(logCmdfilePathZip, " ==SubTest: ");
            csvFileWrite(logCmdfilePathZip, [[testItem GetSubTestName] UTF8String]);
            csvFileWrite(logCmdfilePathZip, "\r\n");
            csvFileWrite(logCmdfilePathZip, "lower:");
            csvFileWrite(logCmdfilePathZip,   [[testItem GetLowerLimit] UTF8String]);
            csvFileWrite(logCmdfilePathZip, "; upper:");
            csvFileWrite(logCmdfilePathZip,   [[testItem GetUpperLimit] UTF8String]);
            csvFileWrite(logCmdfilePathZip, "; value: ");
            csvFileWrite(logCmdfilePathZip,   [[testItem GettestCsvResult] UTF8String]);
            csvFileWrite(logCmdfilePathZip, "\r\n");
            csvFileWrite(logCmdfilePathZip,   [[testItem GetstationEndTime] UTF8String]);
            csvFileWrite(logCmdfilePathZip,  "     ");
            if ([[testItem GetTestResult] isEqualToString:@"0"]) {
                csvFileWrite(logCmdfilePathZip,   "Failed");
            }else{
                csvFileWrite(logCmdfilePathZip,   "Pass");
            }
            
            csvFileWrite(logCmdfilePathZip, "\r\n");
        }
    }

    Wait(2000);
    return logCmdfilePathZip;
}


+(void)writeDUTTolog:(char*)sn{
    //如果文件存在久不会继续生成

  
    
    


   
}

@end
