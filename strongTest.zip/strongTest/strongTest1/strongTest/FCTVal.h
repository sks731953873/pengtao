//
//  FCTVal.h
//  strongTest
//
//  Created by strong on 2018/1/11.
//  Copyright © 2018年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface FCTVal : NSView
@property NSString *_1Product1;
@property NSString *_2SerialNumber;
@property NSString *_3PStation_ID;
@property NSString *_31SiteID;
@property NSString *_4PassFailResult;
@property NSString *_5ErrorMessage;
@property NSString *_6FailedList;
@property NSString *_7TestStartTime;
@property NSString *_8TestStopTime;
@property NSString *_9L0Result;
@property NSString *_10L4Result_1;
@property NSString *_11L4Result_2;
@property NSString *_12BLEResult;

@property NSString *SaveFileName;//文件的保存附加名字


-(id)initWithName:(NSString *)name andAge:(int)age;
-(void) InitVal;


-(NSString*) GetCsvStr;
-(NSString*) GetCsvTitle;

@end

