//
//  NSImageView+extension.m
//  strongTest
//
//  Created by strong on 2018/3/28.
//  Copyright © 2018年 strong. All rights reserved.
//

#import "NSImageView+extension.h"
#import <Quartz/Quartz.h>

@implementation NSImageView (extension)

- (void)rotateImageWithAxisX:(CGFloat)X AxisY:(CGFloat)Y AxisZ:(CGFloat)Z Angle:(CGFloat)angle Duration:(double)duration
{
    self.layer.anchorPoint = CGPointMake(0.5, 0.5);
    self.layer.position = CGPointMake(self.frame.origin.x + self.frame.size.width * 0.5, self.frame.origin.y + self.frame.size.height * 0.5);
    CABasicAnimation *animation = [ CABasicAnimation animationWithKeyPath: @"transform" ];
    
    animation.fromValue = [NSValue valueWithCATransform3D:CATransform3DIdentity];
    
    //围绕轴旋转，垂直与屏幕
    animation.toValue = [NSValue valueWithCATransform3D:CATransform3DMakeRotation(angle, X, Y, Z)];
    
    animation.duration = duration;
    
    //旋转效果累计，先转180度，接着再旋转180度，从而实现360旋转
    animation.cumulative = YES;
    animation.repeatCount = INTMAX_MAX;
    
    [self.layer addAnimation:animation forKey:nil];
    self.wantsLayer = YES;
}
@end
