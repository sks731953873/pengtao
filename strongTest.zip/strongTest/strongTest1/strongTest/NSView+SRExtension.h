//
//  UIView+SRExtension.h
//  5期-百思不得姐
//
//  Created by xiaomage on 15/11/6.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface NSView (SRExtension)
@property (nonatomic, assign) CGSize sr_size;
@property (nonatomic, assign) CGFloat sr_width;
@property (nonatomic, assign) CGFloat sr_height;
@property (nonatomic, assign) CGFloat sr_x;
@property (nonatomic, assign) CGFloat sr_y;

@property (nonatomic, assign) CGFloat sr_right;
@property (nonatomic, assign) CGFloat sr_bottom;
@end
