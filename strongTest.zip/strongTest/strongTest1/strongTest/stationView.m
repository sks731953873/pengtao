//
//  stationView.m
//  strongTest
//
//  Created by strong on 2017/12/20.
//  Copyright © 2017年 strong. All rights reserved.
//

#import "stationView.h"
#include "Config.h"
@implementation stationView
/*******************************************************************************************
 **函数名：InitUI
 **参数：::(int) index STATION:(lpStation) lpstation
 **功能：初始化
 **返回值：
 *******************************************************************************************/

-(void)InitUI:(int) index STATION:(lpStation) lpstation
{
  
    tag_Station = lpstation;

    tag_UIIndex = [[NSTextField alloc] init];
    tag_UIIndex.stringValue = [[NSString alloc] initWithFormat:@"%2d",index];
  
    
    
    tag_UIName = [[NSTextField alloc] init];
    if(strlen(tag_Station->tag_Name) >0)
    {
        tag_UIName.stringValue = [[NSString alloc] initWithUTF8String:tag_Station->tag_Name];
    }

    tag_UIThread = [[NSComboBox alloc] init];
    [tag_UIThread addItemWithObjectValue:(@"main")];
    [tag_UIThread addItemWithObjectValue:(@"subThread")];
    tag_UITWait = [[NSComboBox alloc] init];
    [tag_UITWait addItemWithObjectValue:(@"not wait")];
    [tag_UITWait addItemWithObjectValue:(@"wait")];
    [tag_UITWait selectItemAtIndex:tag_Station->tag_isWait];
    [tag_UIThread selectItemAtIndex:tag_Station->tag_isThread];

    
    tag_UISocketIndex = [[NSComboBox alloc] init];
     [tag_UISocketIndex setBezelStyle:NSTextFieldRoundedBezel];
    
    for(int i = 0; i < IPCOUNT;i++)
    {
        [tag_UISocketIndex addItemWithObjectValue:([[NSString alloc] initWithFormat:@"%d",i+1 ])];
    }
   /* [tag_UISocketIndex addItemWithObjectValue:(@"2")];
    [tag_UISocketIndex addItemWithObjectValue:(@"3")];
    [tag_UISocketIndex addItemWithObjectValue:(@"4")];
    [tag_UISocketIndex addItemWithObjectValue:(@"5")];
    [tag_UISocketIndex addItemWithObjectValue:(@"6")];
    [tag_UISocketIndex addItemWithObjectValue:(@"7")];
    [tag_UISocketIndex addItemWithObjectValue:(@"8")];
    [tag_UISocketIndex addItemWithObjectValue:(@"9")];
    [tag_UISocketIndex addItemWithObjectValue:(@"10")];
    [tag_UISocketIndex addItemWithObjectValue:(@"11")];
    [tag_UISocketIndex addItemWithObjectValue:(@"12")];
    [tag_UISocketIndex addItemWithObjectValue:(@"13")];
    [tag_UISocketIndex addItemWithObjectValue:(@"14")];*/
    [tag_UISocketIndex selectItemAtIndex:tag_Station->tag_socket_index];
    
    tag_UISnIndex = [[NSComboBox alloc] init];
    [tag_UISnIndex setBezelStyle:NSTextFieldRoundedBezel];
    [tag_UISnIndex addItemWithObjectValue:(@"0")];
    [tag_UISnIndex addItemWithObjectValue:(@"1")];
    [tag_UISnIndex addItemWithObjectValue:(@"2")];
    [tag_UISnIndex addItemWithObjectValue:(@"3")];
    [tag_UISnIndex addItemWithObjectValue:(@"4")];
    [tag_UISnIndex addItemWithObjectValue:(@"5")];
    [tag_UISnIndex addItemWithObjectValue:(@"6")];
    [tag_UISnIndex addItemWithObjectValue:(@"7")];
    [tag_UISnIndex addItemWithObjectValue:(@"8")];
    [tag_UISnIndex addItemWithObjectValue:(@"9")];
    [tag_UISnIndex addItemWithObjectValue:(@"10")];
    [tag_UISnIndex addItemWithObjectValue:(@"11")];
    [tag_UISnIndex addItemWithObjectValue:(@"12")];
    [tag_UISnIndex addItemWithObjectValue:(@"13")];
    [tag_UISnIndex addItemWithObjectValue:(@"14")];
    [tag_UISnIndex addItemWithObjectValue:(@"15")];
    [tag_UISnIndex addItemWithObjectValue:(@"16")];
    [tag_UISnIndex addItemWithObjectValue:(@"17")];
    [tag_UISnIndex addItemWithObjectValue:(@"18")];
    [tag_UISnIndex addItemWithObjectValue:(@"19")];
    [tag_UISnIndex addItemWithObjectValue:(@"20")];
    if(tag_Station->tag_snIndex >=0)
    [tag_UISnIndex selectItemAtIndex:tag_Station->tag_snIndex];
    
    tag_UIEnableCheckBox =   [[NSButton alloc] init];
        [tag_UIEnableCheckBox setTitle:@""];
    [tag_UIEnableCheckBox setButtonType:NSButtonTypeSwitch];
     [tag_UIEnableCheckBox setState:tag_Station->tag_isEnable];
    tag_UIMainshow =   [[NSButton alloc] init] ;
                              [tag_UIMainshow setTitle:@""];
    [tag_UIMainshow setButtonType:NSButtonTypeSwitch];
    [tag_UIMainshow setState:tag_Station->tag_MainShow];
    
    
    tag_UIWorkType = [[NSComboBox alloc] init];
    [tag_UIWorkType addItemWithObjectValue:(@"work")];
    [tag_UIWorkType addItemWithObjectValue:(@"rest")];
    [tag_UIWorkType addItemWithObjectValue:(@"stop")];
    [tag_UIWorkType selectItemAtIndex:tag_Station->tag_stationType];
    
}
/*******************************************************************************************
 **函数名：UIUpdata
 **参数：::(int) index STATION:(lpStation) lpstation
 **功能：刷新
 **返回值：
 *******************************************************************************************/
-(void)UIUpdata:(int) index STATION:(lpStation) station
{
    tag_Station = station;
    tag_UIIndex.stringValue = [[NSString alloc] initWithFormat:@"%2d",index];
    // if(strlen(tag_step->tag_stepName) >0)
    {
        tag_UIName.stringValue = [[NSString alloc] initWithUTF8String:tag_Station->tag_Name];
    }
  
  
}
-(void)stationRun:(NSObject*) o
{
    
    stationExe(tag_Station);
}
/*******************************************************************************************
 **函数名：StopClick
 **参数：::(id)sender
 **功能：工位停止
 **返回值：
 *******************************************************************************************/
- (IBAction)NextClick:(id)sender
{
   
    
}
/*******************************************************************************************
**函数名：StopClick
**参数：::(id)sender
**功能：工位停止
**返回值：
*******************************************************************************************/
- (IBAction)StopClick:(id)sender
{

    
    
}/*******************************************************************************************
 **函数名：ExeClick
 **参数：::(id)sender
 **功能：工位运行
 **返回值：
 *******************************************************************************************/
- (void)ExeClick:(id)sender
{

  
}
/*******************************************************************************************
 **函数名：SaveClick
 **参数：:
 **功能：工位保存
 **返回值：
 *******************************************************************************************/
- (IBAction)SaveClick:(id)sender
{
    
    
    NSAlert *alert = [NSAlert new];
    [alert addButtonWithTitle:@"确定"];
    [alert addButtonWithTitle:@"取消"];
    [alert setMessageText:@"确定保存输入文本?"];
    [alert setInformativeText:@"如果确定保存，之前的文本不能再找回!"];
    
    [alert beginSheetModalForWindow:[tag_UISave window] completionHandler:^(NSModalResponse returnCode) {
        if(returnCode == NSAlertFirstButtonReturn){
            
            Save();
            
        }else if(returnCode == NSAlertSecondButtonReturn){
            
        }
    }];
}


/*******************************************************************************************
 **函数名：SaveClick
 **参数：:xeClick:(id)sender
 **功能：
 **返回值：
 *******************************************************************************************/
- (IBAction)GetParameter
{
    
    
    
    
    memset(tag_Station->tag_Name,0,sizeof(tag_Station->tag_Name));
    
    strcat(tag_Station->tag_Name,[tag_UIName.stringValue UTF8String]);
    tag_Station->tag_socket_index =  tag_UISocketIndex.indexOfSelectedItem ;
    tag_Station->tag_snIndex =  tag_UISnIndex.indexOfSelectedItem;
    
    tag_Station->tag_isWait =  tag_UITWait.indexOfSelectedItem ;
    tag_Station->tag_isThread =  tag_UIThread.indexOfSelectedItem ;
    tag_Station->tag_isEnable = tag_UIEnableCheckBox.state;
    tag_Station->tag_MainShow = tag_UIMainshow.state;
    tag_Station->tag_stationType =  tag_UIWorkType.indexOfSelectedItem ;
    
}
/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：
 **返回值：
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    

    id retid = nil;
    NSString *title =  tableColumn.title;
    if(tableView.tableColumns[uiStation_enum_index] == tableColumn)
    {
        retid = tag_UIIndex;
    }
    else
        if(tableView.tableColumns[uiStation_enum_name] == tableColumn)
        {
            retid = tag_UIName;
            
        }
         else
            if(tableView.tableColumns[uiStation_enum_SockectIndex] == tableColumn)
            {
                            retid = tag_UISocketIndex;
            }
            else
                if(tableView.tableColumns[uiStation_enum_SnIndex] == tableColumn)
                    {
                                retid = tag_UISnIndex;
                    }
                    else
                        if(tableView.tableColumns[uiStation_enum_Wait] == tableColumn)
                        {
                            retid = tag_UITWait;
                        }
                        else
                            if(tableView.tableColumns[uiStation_enum_Thread] == tableColumn)
                            {
                                retid = tag_UIThread ;
                            }
   else if(tableView.tableColumns[uiStation_enum_enable] == tableColumn)
    {
        retid = tag_UIEnableCheckBox;
    }
    else
        if(tableView.tableColumns[uiStation_enum_mainShow] == tableColumn)
        {
            retid = tag_UIMainshow ;
        }
        else
            if(tableView.tableColumns[uiStation_enum_type] == tableColumn)
            {
                retid = tag_UIWorkType ;
            }
   
    return retid;
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
