//
//  SRFileTool.h
//  strongTest
//
//  Created by strong on 2018/2/4.
//  Copyright © 2018年 strong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SRFileTool : NSObject
+(void)writeResultToCSV:(NSMutableArray *)results SN:(NSString*)sn;
+(char*)writeResultToFixtureLog:(NSMutableArray *)results SN:(char*)sn;
+(char*)createCSVHead:(NSMutableArray *)arrM;
@end
