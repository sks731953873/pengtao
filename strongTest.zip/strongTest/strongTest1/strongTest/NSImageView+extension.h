//
//  NSImageView+extension.h
//  strongTest
//
//  Created by strong on 2018/3/28.
//  Copyright © 2018年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSImageView (extension)
- (void)rotateImageWithAxisX:(CGFloat)X AxisY:(CGFloat)Y AxisZ:(CGFloat)Z Angle:(CGFloat)angle Duration:(double)duration;
@end
