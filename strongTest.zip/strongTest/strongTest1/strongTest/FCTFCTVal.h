//
//  FCTFCTVal.h
//  strongTest
//
//  Created by strong on 2018/1/13.
//  Copyright © 2018年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface FCTFCTVal : NSView
@property NSString *_1Product1  ;//
@property NSString *_2SerialNumber  ;//
@property NSString *_3PStation_ID  ;//
@property NSString *_31SiteID ;

@property NSString *_8TestStartTime  ;//
@property NSString *_9TestStopTime ;
//_8TestStopTime

@property NSString *_01Scorpius_2;
@property NSString *_021ApplicationInfo;
@property NSString *_022BT_info;
@property NSString *_023AccelInfo;
@property NSString *_024ChargeInfo;
@property NSString *_025SN;
@property NSString *_031PP_IKTARA_OUT_Volt;
@property NSString *_032PP1V8_LDO_OUT_Volt;
@property NSString *_034PP1V8_SYS_Volt;
@property NSString *_035PP1V8_BLE_Volt;
@property NSString *_036PP1V8_ROSWELL_PWR_Volt;
@property NSString *_041PP1V8_FLASH_Volt;
@property NSString *_042PP1V8_GRAPHITE_Volt;
@property NSString *_043PP1V8_TANGO_Volt;
@property NSString *_044PP1V8_HILO_ISO_Volt;
@property NSString *_045PP3V0_4V3_HILO_ISO_Volt;

@property NSString *_051cellVoltage;
@property NSString *_052actualChargeCurrent;
@property NSString *_053inputVoltage;
@property NSString *_054inputCurrent;

@property NSString *_055temp_decideg_0;
@property NSString *_056temp_decideg_1;
@property NSString *_057temp_decideg_2;
@property NSString *_058desiredChargeCurrent;
@property NSString *_059buckVoltage;

@property NSString *_0600JakkuResult;
@property NSString *_0601GraphiteResuot;
@property NSString *_061msiFreq;
@property NSString *_062hsiFreq;
@property NSString *_063lsiFreq;
@property NSString *_064lseFreq;

@property NSString *_071SYSCLK_MSI_FREQ_FAILED;
@property NSString *_072SYSCLK_HSI_FREQ_FAILED;
@property NSString *_073SYSCLK_LSI_FREQ_FAILED;
@property NSString *_074SSYSCLK_LSE_FREQ_FAILED;
@property NSString *_075SERIAL_MS;



@property NSString *SaveFileName;//文件的保存附加名字
-(void) InitVal;

-(id)initWithName:(NSString *)name andAge:(int)age;
-(NSString*) GetCsvStr;
-(NSString*) GetCsvTitle;

@end
