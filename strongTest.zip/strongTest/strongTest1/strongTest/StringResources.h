//
//  StringResources.h
//  OAO
//
//  Created by strong on 17/12/1.
//  Copyright © 2017年 strong. All rights reserved.
//

#ifndef StringResources_h
#define StringResources_h
#import <Cocoa/Cocoa.h>
#include <stdio.h>
typedef  enum _country_type
{
    country_china,
    country_english,
}country_type;

typedef  enum _string_id
{
    string_id_inputName,
  

    
}string_id;

typedef struct _uct_ResouresStr
{
    char * strCountent[20];
}uct_ResouresStr;

extern uct_ResouresStr strResources[100];
extern NSString *GetStringResouces(int stringId);
extern void setCountryID(int country_ID);
#endif /* StringResources_h */
