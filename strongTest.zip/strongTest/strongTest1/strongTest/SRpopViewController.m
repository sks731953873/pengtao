//
//  popViewController.m
//  Manual_Debug
//
//  Created by Strong-EE on 2017/9/18.
//  Copyright © 2017年 Strong-EE. All rights reserved.
//

#import "SRpopViewController.h"

#define pwdInfoPath [[NSBundle mainBundle]pathForResource:@"PasswordInfo" ofType:@"plist"]
@interface SRpopViewController ()
@property (weak) IBOutlet NSPopUpButton *popUpBtn_user;
@property (weak) IBOutlet NSSecureTextField *secureTF_pwd;
@property (weak) IBOutlet NSSecureTextField *secure_comfirm;
@property (weak) IBOutlet NSLayoutConstraint *subViewLeading
;
@property (weak) IBOutlet NSSecureTextField *secureTF_adminPwd;
@property (weak) IBOutlet NSView *subView;

@end

@implementation SRpopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"修改密码";

    
    
    // Do view setup here.
}
- (IBAction)comfirmBtnClick:(id)sender {
   
    if (![self.secureTF_pwd.stringValue isEqualToString:self.secure_comfirm.stringValue]) {
        NSAlert *alert = [[NSAlert alloc]init];
        alert.alertStyle = NSWarningAlertStyle;
        alert.messageText = @"密码不一致";
        alert.informativeText = @"你两次输入的密码不一致，请区分大小写，再次确认！";
        [alert addButtonWithTitle:@"确定"];
        [alert runModal];
        return;
    }
    
    NSDictionary *pwdInfo = [NSDictionary dictionaryWithContentsOfFile:pwdInfoPath];
    
    [pwdInfo setValue:self.secure_comfirm.stringValue forKey:self.popUpBtn_user.selectedItem.title];
    
    [pwdInfo writeToFile:pwdInfoPath atomically:YES];
    
    if ([self.delegate respondsToSelector:@selector(closePopover)]){
        
        [self.delegate closePopover];
    }
}



//changepwdView的btn
- (IBAction)cancelBtnClick:(id)sender {
    
    if ([self.delegate respondsToSelector:@selector(closePopover)]){
        [self.delegate closePopover];
    }
}



- (IBAction)adminBtnClick:(id)sender {
    NSDictionary *pwdInfo = [NSDictionary dictionaryWithContentsOfFile:pwdInfoPath];
   NSString *adminPwd = [pwdInfo valueForKey:@"Administrator"];
    if (![self.secureTF_adminPwd.stringValue isEqualToString:adminPwd]) {
        NSAlert *alert = [[NSAlert alloc]init];
        alert.alertStyle = NSAlertStyleWarning;
        alert.messageText = @"密码错误！";
        [alert addButtonWithTitle:@"确定"];
        [alert runModal];
        return;
    }
    
    self.subViewLeading.constant = -375;
 //   [self.subViewLeading layoutSublayersOfLayer:self.view.layer];
    
}
//adminView的btn
- (IBAction)adminCancelClick:(id)sender {
    if ([self.delegate respondsToSelector:@selector(closePopover)]){
        [self.delegate closePopover];
    }
}

@end
