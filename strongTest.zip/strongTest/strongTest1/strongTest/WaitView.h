//
//  WaitView.h
//  strongTest
//
//  Created by strong on 2017/12/31.
//  Copyright © 2017年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
@protocol WaitThreadDelegate
-(void)WaitThreadDelegate:(id) obj;
-(void) cancelThreadDelegate:(id) obj;

@end
@interface WaitView : NSView
{
    NSProgressIndicator *tag_NSProgressIndicator;
    NSButton *tag_OkButton;
     id<WaitThreadDelegate> tag_WaitThreadDelegate;
    NSThread* tag_myThread;
}
@property(assign,nonatomic)id<WaitThreadDelegate> tag_WaitThreadDelegate;
-(void)ThreadRun;
@end
