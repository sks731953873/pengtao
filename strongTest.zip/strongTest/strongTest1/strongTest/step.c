//
//  step.c
//  strongTest
//
//  Created by strong on 2017/12/15.
//  Copyright © 2017年 strong. All rights reserved.
//

#include "step.h"

/*******************************************************************************************
 **函数名：StepRunObj
 **参数：,(Step *step)
 ipConfig soc)
 **功能： 单步执行
 **返回值：< 0失败
 *******************************************************************************************/
int StepRunObj(Step *step)
{
    
    int ret = 0;
    extern char *GetCurrentTimeCtr();
    step->tag_workState = 1;
    memset(step->tag_stratTime,0,sizeof(step->tag_stratTime));
    memset(step->tag_stopTime,0,sizeof(step->tag_stopTime));
    strcat(step->tag_stratTime,GetCurrentTimeCtr());
    AddLog(step->tag_stepName);
    if(step->tag_enable)
    {
        strcat(step->tag_stopTime,GetCurrentTimeCtr());
        step->tag_workState = 2;
        return enum_step_run_result_ok;
    }
    while(isPause() != 0 && isStop() == 0)
    {
           extern  void NSThreadsleep(int delay);
           NSThreadsleep(100);
        
    }
    memset(step->tag_Result,0,sizeof(step->tag_Result));
    step->tag_pdcaValue.tag_intPassFail = 0;

    if(step->tag_Exe)
    {
        int len = 0;
        ret = step->tag_Exe(step);
        
        memset(step->tag_pdcaValue.tag_Value,0,sizeof(step->tag_pdcaValue.tag_Value));
        len =  strlen(step->tag_Result);
        if(len > sizeof(step->tag_pdcaValue.tag_Value))
        {
            len = sizeof(step->tag_pdcaValue.tag_Value)-1;
        }
        
        memcpy(step->tag_pdcaValue.tag_Value,
               step->tag_Result,
               len);
        ISPass(&step->tag_pdcaValue);
        
        if(ret != 0)
        {
            step->tag_workState = 2;
            strcat(step->tag_stopTime,GetCurrentTimeCtr());
            return ret ;
        }
    }
    step->tag_workState = 2;
    strcat(step->tag_stopTime,GetCurrentTimeCtr());
    return enum_step_run_result_ok;
}
/*******************************************************************************************
 **函数名：StepRun
 **参数：,(Step *step)
 ipConfig soc)
 **功能： 单步执行
 **返回值：< 0失败
 *******************************************************************************************/
int StepThread_Run(Step *step)
{
    pthread_t t1;
    pthread_create(&t1,NULL,StepRunObj,(void *)step);
    
    
   //ß pthread_join(t1,NULL);
    
    return 0;
}
/*******************************************************************************************
 **函数名：StepRun
 **参数：,(Step *step)
 ipConfig soc)
 **功能： 单步执行
 **返回值：< 0失败
 *******************************************************************************************/
int StepRun(Step *step)
{
   
    if(step->tag_isThread == 1)
    {
        StepThread_Run(step);
    }
    else
    {
        return  StepRunObj(step);
    }
    
    return 0;
}

void CreateStepIntString(Step *step,char *OutStr)
{
    
}
char *FCTCOMMAND[] =
{
    ""//
};

char *FWDLCOMMAND[] =
{
""
};
