//
//  StepView.m
//  strongTest
//
//  Created by strong on 2017/12/15.
//  Copyright © 2017年 strong. All rights reserved.
//

#import "StepView.h"
#import "WaitView.h"
#include "Config.h"
#import "DataSave.h"
#import "SendContentView.h"
#import "SRStepSettingView.h"
#define FONTSIZE 12



@implementation StepView


/*******************************************************************************************
 **函数名：InitUI
 **参数：:(int) index  显示的ID STEP:(LpStep) step 步骤
 **功能：初始化步骤
 **返回值：
 *******************************************************************************************/
-(void)InitUI2
{
    
    tag_UIName =  [[NSTextField alloc] init];//名称
  
    tag_UIResult =  [[NSTextField alloc] init];//返回的结果
    tag_UISleepTime =  [[NSTextField alloc] init];//延迟时间
   
    
    tag_UIfiltrationBegin =  [[NSTextField alloc] init];//结果过滤
    tag_UIfiltrationEnd =  [[NSTextField alloc] init];        //结果过滤
    
    tag_UITEst =  [[NSTextField alloc] init];        //结果过滤

     tag_NSProgressIndicator =  [[NSProgressIndicator alloc] init];

    tag_UIThreadIndex =  [[NSComboBox alloc] init];
    tag_UISocketIndex =  [[NSComboBox alloc] init];
    tag_UICommandType =  [[NSComboBox alloc] init];//命令类型
    
    tag_UiExcTimes = [[NSComboBox alloc] init];//执行次数
    tag_UIAlgorithmType = [[NSComboBox alloc] init];//算法类型
    
    tag_UIPDCAType =  [[NSComboBox alloc] init];//命令类型
    tag_UIIsMainShow =  [[NSButton alloc] init];//命令类型
    tag_UIExe =  [[NSButton alloc] init];//执行按钮
    tag_UISave =  [[NSButton alloc] init];//保存按钮
    tag_UISet =  [[NSButton alloc] init];//settingBtn
    tag_UIButtonIndex =  [[NSButton alloc] init] ;
    [tag_UIButtonIndex  setTarget:self];
    [tag_UIButtonIndex setAction:@selector(OpenStationClick:)];
    [tag_UIButtonIndex setButtonType:NSButtonTypeOnOff];
    //     _UIIndex.bezelStyle =  ;
    [tag_UIButtonIndex setBezelStyle:NSBezelStyleSmallSquare];
    
    
     tag_UITextIndex =  [[NSButton alloc] init] ;
    [tag_UITextIndex  setTarget:self];
    [tag_UITextIndex setButtonType:NSButtonTypeOnOff];
    
    [tag_UITextIndex setBezelStyle:NSBezelStyleSmallSquare];
    

 //   [tag_UITextIndex setAction:@selector(ExeClick:)];

    tag_UIEnableCheckBox =  [[NSButton alloc] init];// 屏蔽按钮
    
    [tag_UICommandType addItemWithObjectValue:(@"Socket")];
    [tag_UICommandType addItemWithObjectValue:(@"Script")];
    [tag_UICommandType addItemWithObjectValue:(@"Port")];
    [tag_UICommandType addItemWithObjectValue:(@"IoRead_1")];
    [tag_UICommandType addItemWithObjectValue:(@"IoRead_0")];
    [tag_UICommandType addItemWithObjectValue:(@"IoSet")];
    [tag_UICommandType addItemWithObjectValue:(@"wait")];
    [tag_UICommandType addItemWithObjectValue:(@"SocRead")];
    [tag_UICommandType addItemWithObjectValue:(@"SocReadClean")];
    [tag_UICommandType addItemWithObjectValue:(@"SnWrite")];
    [tag_UICommandType addItemWithObjectValue:(@"SnRead")];
    [tag_UICommandType addItemWithObjectValue:(@"SFC_GetSn")];
    [tag_UICommandType addItemWithObjectValue:(@"dealy")];
    [tag_UICommandType addItemWithObjectValue:(@"filename")];
    [tag_UICommandType addItemWithObjectValue:(@"AlgorithmRead")];
    [tag_UICommandType addItemWithObjectValue:(@"SocketTemp")];
    
    [tag_UiExcTimes addItemWithObjectValue:@"1"];
    [tag_UiExcTimes addItemWithObjectValue:@"2"];
    [tag_UiExcTimes addItemWithObjectValue:@"3"];
    [tag_UiExcTimes addItemWithObjectValue:@"4"];
    [tag_UiExcTimes addItemWithObjectValue:@"5"];
    
    [tag_UIAlgorithmType addItemWithObjectValue:(@"None")];
    [tag_UIAlgorithmType addItemWithObjectValue:(@"avgX")];
    [tag_UIAlgorithmType addItemWithObjectValue:(@"avgY")];
    [tag_UIAlgorithmType addItemWithObjectValue:(@"avgZ")];
    [tag_UIAlgorithmType addItemWithObjectValue:(@"sqrtX")];
    [tag_UIAlgorithmType addItemWithObjectValue:(@"sqrtY")];
    [tag_UIAlgorithmType addItemWithObjectValue:(@"sqrtZ")];
    
    [tag_UIIsMainShow setButtonType:NSButtonTypeSwitch];
    [tag_UIIsMainShow setTitle:@""];
    
    [tag_UIPDCAType addItemWithObjectValue:(@"NoPdca")];
    
    [tag_UISocketIndex addItemWithObjectValue:(@"0")];
    for(int i = 0; i < IPCOUNT;i++)
    {
        [tag_UISocketIndex addItemWithObjectValue:([[NSString alloc] initWithFormat:@"%d",i+1 ])];
    }
    
    
    [tag_UIThreadIndex addItemWithObjectValue:(@"main")];
    [tag_UIThreadIndex addItemWithObjectValue:(@"thread")];
    
    tag_UIReadEnd =[[NSTextField alloc] init];
    
    tag_UIReadEndEnterIndex =[[NSButton alloc] init];
    [tag_UIReadEndEnterIndex setButtonType:NSButtonTypeSwitch];
    [tag_UIReadEndEnterIndex setTitle:@""];
}


/*******************************************************************************************
**函数名：InitUI
**参数：:(int) index  显示的ID STEP:(LpStep) step 步骤
**功能：初始化步骤
**返回值：
*******************************************************************************************/
-(void)InitUI:(NSString*) index STEP:(LpStep) step PDCA:(pdcaValueManage) pcda STATION:(lpStation) station SUPER:(id) super_ COMMANDTYPE:(int) commandType
{
    _tag_step = step;
   
    tag_pdcaValueManage = pcda;
    _tag_lpStation = station;

    tagt_super = super_;
    _tag_StepViewActionDelegate = super_;

    
    if(!_tag_step)
    {
 
      tag_UIIndex = tag_UIButtonIndex;

      if(_tag_lpStation->tag_isOpenSpreadOut ==0)
      {
            [tag_UIButtonIndex setTitle:@"+"];
      }
        else
        {
             [tag_UIButtonIndex setTitle:@"-"];
        }
   
       tag_UIName.font = [NSFont fontWithName:@"Arial" size:14.0f];
        [tag_UIName setTextColor:NSColor.blueColor];
        NSString *atr = [[NSString alloc] initWithUTF8String:station->tag_Name];
        tag_UIName.stringValue = atr;
        

        [tag_UIExe setTitle:@"run"];
        [tag_UIExe  setTarget:self];
        [tag_UIExe setBezelStyle:NSBezelStyleSmallSquare];
        [tag_UIExe setAction:@selector(ExeClick:)];
        


        [tag_UIEnableCheckBox setState:_tag_lpStation->tag_isEnable];
        [tag_UIEnableCheckBox setButtonType:NSButtonTypeSwitch];
        [tag_UIEnableCheckBox setTitle:@""];
        
        
        [tag_UIEnableCheckBox  setTarget:self];
        [tag_UIEnableCheckBox setAction:@selector(EnableCheckBoxClick:)];
      return ;
    }
    else
    {
 
        tag_UIIndex = (id)tag_UITextIndex;
     
        tag_UIName.font = [NSFont fontWithName:@"Arial" size:10.0f];
        [tag_UIName setTextColor:NSColor.blackColor];
        
        [tag_UIExe setTarget:self];
        [tag_UIExe setAction:@selector(ExeClick:)];
        [tag_UIExe setTitle:@"run"];
        [tag_UIExe setBezelStyle:NSBezelStyleSmallSquare];
        
    
        [tag_UIEnableCheckBox setState:0];
        
        [tag_UIEnableCheckBox setButtonType:NSButtonTypeSwitch];
        [tag_UIEnableCheckBox setTitle:@""];
    }

    [tag_UISet setTitle:@"Set"];
    [tag_UISet  setTarget:self];
    [tag_UISet setBezelStyle:NSBezelStyleSmallSquare];
    [tag_UISet setAction:@selector(SetBtnDidClick)];
    
    
  


    [self UIUpdata:index STEP:step  COMMANDTYPE:commandType ];
    
 
}

/*******************************************************************************************
 **函数名：UIUpdata
 **参数：:(int) index  显示的ID STEP:(LpStep) step 步骤
 **功能：刷新步骤
 **返回值：
 *******************************************************************************************/
-(void)UIUpdata:(NSString*) index STEP:(LpStep) step COMMANDTYPE:(int) commandType
{
    tag_IsShowCommandOrResult = commandType;
    if(step)
    _tag_step = step;
    if(!_tag_step)
    {
        tag_UIName.stringValue = [[NSString alloc] initWithFormat:@"%s",_tag_lpStation->tag_Name];
        return ;
    }
    else
    {
        
    }
   [tag_UITextIndex setTitle:[[NSString alloc] initWithFormat:@"%@",index]];
   // tag_UITextIndex.stringValue = ;
   //if(strlen(tag_step->tag_stepName) >0)
    {
        tag_UIName.stringValue = [[NSString alloc] initWithUTF8String:_tag_step->tag_stepName];
    }
    
    tag_UIReadEnd.stringValue = [[NSString alloc] initWithUTF8String:_tag_step->tag_ReadEndFlage];
 
   // if(strlen(tag_step->tag_Result) >0)
    {
        [self UIUpdata ];
    }
    tag_UISleepTime.stringValue = [[NSString alloc] initWithFormat:@"%d",_tag_step->tag_SleepDate];
    [tag_UIEnableCheckBox setState:_tag_step->tag_enable];
    tag_UIfiltrationBegin.stringValue = [[NSString alloc] initWithFormat:@"%s",_tag_step->tag_filtrationBegin];
    tag_UIfiltrationEnd.stringValue = [[NSString alloc] initWithFormat:@"%s",_tag_step->tag_filtrationEnd];
    
    
    
   // tag_UIOKNextStep.stringValue = [[NSString alloc] initWithFormat:@"%d",_tag_step->tag_SucNextStep];
    [tag_UIPDCAType removeAllItems];
    
    [tag_UIPDCAType addItemWithObjectValue:(@"NoPdca")];
    
    for(int i = 0;tag_pdcaValueManage && i < tag_pdcaValueManage->tag_totalCount;i++)
    {
        NSString *vau =[[NSString alloc] initWithFormat:@"%s",tag_pdcaValueManage->tag_PdcaValue[i].tag_Name];
        [tag_UIPDCAType addItemWithObjectValue:vau];
    }
    
    if(tag_pdcaValueManage && _tag_step->tag_pdca_index >0 && _tag_step->tag_pdca_index <=tag_pdcaValueManage->tag_totalCount  &&  tag_pdcaValueManage->tag_totalCount >0)
    {
        [tag_UIPDCAType selectItemAtIndex:_tag_step->tag_pdca_index];
    }
    else
    {
        [tag_UIPDCAType selectItemAtIndex:0];
    }
    
    
    if(_tag_step->tag_workState == 1)
    {
        [tag_NSProgressIndicator setIndeterminate:YES];
        [tag_NSProgressIndicator startAnimation:nil];
    }
    else
    {
        [tag_NSProgressIndicator setIndeterminate:NO];
        [tag_NSProgressIndicator stopAnimation:nil];
    }
    
    
    
    [tag_UICommandType selectItemAtIndex:_tag_step->tag_type];
    [tag_UIAlgorithmType selectItemAtIndex:_tag_step->tag_algorithmType];
  
    [tag_UiExcTimes selectItemAtIndex:_tag_step->tag_exctimes];
  
    [tag_UISocketIndex selectItemAtIndex:_tag_step->tag_socket_index];
    tag_UIfiltrationBegin.stringValue = [[NSString alloc] initWithFormat:@"%s",_tag_step->tag_filtrationBegin];
    tag_UIfiltrationEnd.stringValue = [[NSString alloc] initWithFormat:@"%s",_tag_step->tag_filtrationEnd];
    [tag_UIThreadIndex selectItemAtIndex:_tag_step->tag_isThread];
    [tag_UIIsMainShow setState:_tag_step->tag_isMainShow];
    [tag_UIEnableCheckBox setState:_tag_step->tag_enable];
    [tag_UIEnableCheckBox setState:_tag_step->tag_enable];
    [tag_UIReadEndEnterIndex setState:_tag_step->tag_readEnterKey];
}
/*******************************************************************************************
 **函数名：UIUpdata
 **参数：:(int) index  显示的ID STEP:(LpStep) step 步骤
 **功能：刷新步骤
 **返回值：
 *******************************************************************************************/
-(void)UIUpdata
{
    
    if(!_tag_step)
        return ;
    if(_tag_step->tag_workState == 1)
    {
        [tag_NSProgressIndicator setIndeterminate:YES];
        [tag_NSProgressIndicator startAnimation:nil];
    }
    else
    {
        [tag_NSProgressIndicator setIndeterminate:NO];
        [tag_NSProgressIndicator stopAnimation:nil];
    }
    switch (tag_IsShowCommandOrResult)
    {
        case 2:
           tag_UIResult.stringValue =[[NSString alloc] initWithFormat:@"%s",_tag_step->tag_sendCommand];
            break;
        case 0:
            tag_UIResult.stringValue =[[NSString alloc] initWithFormat:@"Answer:%s",_tag_step->tag_Result];
            break;
        case 1:
            tag_UIResult.stringValue =[[NSString alloc] initWithFormat:@"%s\r\nAnswer:%s",_tag_step->tag_sendCommand,_tag_step->tag_Result];
            break;
            
        default:
            break;
    }
}


/*******************************************************************************************
 **函数名：WaitThreadDelegate
 **参数：:
 **功能：单步运行
 **返回值：
 *******************************************************************************************/
-(void)WaitThreadDelegate:(id) obj
{
    if(_tag_lpStation)
    {
        stationManage lpsm = _tag_lpStation->tag_user;
        
        lpsm->tag_WorkStop = 0;
        lpsm->tag_WorkState = 1;
        stationExe(_tag_lpStation);
        lpsm->tag_WorkState = 0;
        [tag_NSProgressIndicator setIndeterminate:NO];
        [tag_NSProgressIndicator stopAnimation:nil];
  
    }
    else
    {
        lpStationRun   dls = (lpStationRun)_tag_step->tag_user;
        stationManage lpsm = dls->tag_station->tag_user;
    
        lpsm->tag_WorkStop = 0;
         lpsm->tag_WorkState = 1;
        StepRunObj(_tag_step);
         lpsm->tag_WorkState = 0;
        [self UIUpdata];
        [tag_NSProgressIndicator setIndeterminate:NO];
        [tag_NSProgressIndicator stopAnimation:nil];

    }
}
/*******************************************************************************************
 **函数名：cancelThreadDelegate
 **参数：:xeClick:(id)sender
 **功能：单步运行取消
 **返回值：
 *******************************************************************************************/
-(void) cancelThreadDelegate:(id) obj
{
 if(_tag_lpStation)
 {
     int i = 0;
     while(i < _tag_lpStation->tag_totalCount)
     {
         cSocket soc = GetSocket(&_tag_lpStation->tag_step[i]);
         if(soc->sockectClose)
             soc->sockectClose(soc);
         i++;
     }
     _tag_lpStation->tag_WorkState = 0;
 }
 else
 {
    lpStationRun   dls = (lpStationRun)_tag_step->tag_user;
    stationManage lpsm = dls->tag_station->tag_user;
     
    lpsm->tag_WorkStop = 1;
    cSocket lpsoc = (cSocket)GetSocket(_tag_step);
    if(lpsoc->sockectClose)
    lpsoc->sockectClose(lpsoc);
 }
    [tag_NSProgressIndicator setIndeterminate:NO];
    [tag_NSProgressIndicator stopAnimation:nil];
}
/*******************************************************************************************
  **函数名：ExeClick
  **参数：:xeClick:(id)sender
  **功能：单步运行
  **返回值：
  *******************************************************************************************/

- (void)ExeClick:(id)sender
{
    if(!tag_wait)
    {
        tag_wait = [[WaitView alloc] initWithFrame:tag_UIName.superview.superview.superview.frame];
    }
    
    
    [tag_NSProgressIndicator setIndeterminate:YES];
    [tag_NSProgressIndicator startAnimation:nil];
    [tag_wait ThreadRun];
    tag_wait.tag_WaitThreadDelegate = self;
    [tag_UIName.superview.superview.superview addSubview:tag_wait];
}

/**
 set按钮点击，弹框
 */
- (void)SetBtnDidClick{
    NSArray *arr = [NSArray array];
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([SRStepSettingView class]) owner:nil topLevelObjects:&arr];
    SRStepSettingView *stepSetingView = nil;
    for (id objView in arr) {
        if ([objView isKindOfClass:[SRStepSettingView class]]) {
            stepSetingView = objView;
        }
    }
    //获取每个combox的itemStr，用于自动填充stepSetingView里面的combox
    stepSetingView.getComboxItemStrArr = ^NSMutableDictionary *{
        NSMutableDictionary *dictM = [NSMutableDictionary dictionary];
        
        NSMutableArray *arrM_commandTpye = [NSMutableArray array];
        for (int i = 0; i < tag_UICommandType.numberOfItems; i ++) {
            NSString *itemStr = [tag_UICommandType itemObjectValueAtIndex:i];
            [arrM_commandTpye addObject:itemStr];
        }
        dictM[@"arrM_commandTpye"] = arrM_commandTpye;
        
        NSMutableArray *arrM_PDCATpye = [NSMutableArray array];
        for (int i = 0; i < tag_UIPDCAType.numberOfItems; i ++) {
            NSString *itemStr = [tag_UIPDCAType itemObjectValueAtIndex:i];
            [arrM_PDCATpye addObject:itemStr];
        }
        dictM[@"arrM_PDCATpye"] = arrM_PDCATpye;
        
        NSMutableArray *arrM_AlgorithmType = [NSMutableArray array];
        for (int i = 0; i < tag_UIAlgorithmType.numberOfItems; i ++) {
            NSString *itemStr = [tag_UIAlgorithmType itemObjectValueAtIndex:i];
            [arrM_AlgorithmType addObject:itemStr];
        }
        dictM[@"arrM_AlgorithmType"] = arrM_AlgorithmType;
        
        NSMutableArray *arrM_ThreadIndex = [NSMutableArray array];
        for (int i = 0; i < tag_UIThreadIndex.numberOfItems; i ++) {
            NSString *itemStr = [tag_UIThreadIndex itemObjectValueAtIndex:i];
            [arrM_ThreadIndex addObject:itemStr];
        }
        dictM[@"arrM_ThreadIndex"] = arrM_ThreadIndex;
        
        NSMutableArray *arrM_SocketIndex = [NSMutableArray array];
        for (int i = 0; i < tag_UISocketIndex.numberOfItems; i ++) {
            NSString *itemStr = [tag_UISocketIndex itemObjectValueAtIndex:i];
            [arrM_SocketIndex addObject:itemStr];
        }
        dictM[@"arrM_SocketIndex"] = arrM_SocketIndex;
        
        NSMutableArray *arrM_excTimes = [NSMutableArray array];
        for (int i = 0; i < tag_UiExcTimes.numberOfItems; i ++) {
            NSString *itemStr = [tag_UiExcTimes itemObjectValueAtIndex:i];
            [arrM_excTimes addObject:itemStr];
        }
        dictM[@"arrM_excTimes"] = arrM_excTimes;
        
        return dictM;
        
    };
    stepSetingView.tag_pdcaValueManage = tag_pdcaValueManage;
    stepSetingView.tag_step = _tag_step;
    stepSetingView.tag_socket = tag_cSocket;
    
    NSWindow *win = [[NSWindow alloc]init];
    [win setFrame:stepSetingView.frame display:YES];
    win.title = [NSString stringWithUTF8String:_tag_step->tag_stepName];
    win.contentView = stepSetingView;
    [NSApp runModalForWindow:win];
}



/*******************************************************************************************
 **函数名：ExeClick
 **参数：::(id)sender
 **功能：工位运行
 **返回值：
 *******************************************************************************************/
- (void)OpenStationClick:(id)sender
{
    if(_tag_lpStation->tag_isOpenSpreadOut ==0)
    {
        _tag_lpStation->tag_isOpenSpreadOut = 1;
        NSButton *button = (NSButton *)tag_UIIndex;
        [button setTitle:@"-"];
    }
    else
    {
        NSButton *button = (NSButton *)tag_UIIndex;
        [button setTitle:@"+"];
        _tag_lpStation->tag_isOpenSpreadOut = 0;
    }
    if(_tag_StepViewActionDelegate)
    {
        [_tag_StepViewActionDelegate OpenSpreadOutDelegate:self ];
    }
}


/*******************************************************************************************
 **函数名：ExeClick
 **参数：::(id)sender
 **功能：工位运行
 **返回值：
 *******************************************************************************************/

- (void)EnableCheckBoxClick:(id)sender
{
    if(_tag_lpStation)
    {
        int i = 0;
        _tag_lpStation->tag_isEnable =  tag_UIEnableCheckBox.state;
        while(i < _tag_lpStation->tag_totalCount)
        {
            _tag_lpStation->tag_step[i].tag_enable = tag_UIEnableCheckBox.state;
            i++;
        }
    }
    else
    {
        _tag_step->tag_enable = tag_UIEnableCheckBox.state;

    }
  
    if(_tag_StepViewActionDelegate)
    {
        [_tag_StepViewActionDelegate OpenSpreadOutDelegate:self ];
    }
}


/*******************************************************************************************
 **函数名：SaveClick
 **参数：:xeClick:(id)sender
 **功能：单步保存事件
 **返回值：
 *******************************************************************************************/
- (IBAction)GetParameter
{
    
    if(_tag_step)
    {
   
        memset(_tag_step->tag_stepName,0,sizeof(_tag_step->tag_stepName));
        strcat(_tag_step->tag_stepName,[tag_UIName.stringValue UTF8String]);
        if(tag_IsShowCommandOrResult == 2)
        {
             memset(_tag_step->tag_sendCommand,0,sizeof(_tag_step->tag_sendCommand));
            strcat(_tag_step->tag_sendCommand,[tag_UIResult.stringValue UTF8String]);
        }
        _tag_step->tag_SleepDate =[tag_UISleepTime integerValue];
        _tag_step->tag_type = tag_UICommandType.indexOfSelectedItem;
        _tag_step->tag_algorithmType = tag_UIAlgorithmType.indexOfSelectedItem;
        _tag_step->tag_exctimes = tag_UiExcTimes.indexOfSelectedItem;
   
        _tag_step->tag_enable = tag_UIEnableCheckBox.state;
            
        _tag_step->tag_SleepDate = [tag_UISleepTime.stringValue integerValue];
            
        _tag_step->tag_enable =tag_UIEnableCheckBox.state;
        memset(_tag_step->tag_filtrationBegin,0,sizeof(_tag_step->tag_filtrationBegin));
        strcat(_tag_step->tag_filtrationBegin,[tag_UIfiltrationBegin.stringValue UTF8String]);
            
        memset(_tag_step->tag_filtrationEnd,0,sizeof(_tag_step->tag_filtrationEnd));
        strcat(_tag_step->tag_filtrationEnd,[tag_UIfiltrationEnd.stringValue UTF8String]);
        
        memset(_tag_step->tag_ReadEndFlage,0,sizeof(_tag_step->tag_ReadEndFlage));
        strcat(_tag_step->tag_ReadEndFlage,[tag_UIReadEnd.stringValue UTF8String]);
        

        
        _tag_step->tag_socket_index = tag_UISocketIndex.indexOfSelectedItem;
  
        _tag_step->tag_pdca_index = tag_UIPDCAType.indexOfSelectedItem;
        _tag_step->tag_socket_index = tag_UISocketIndex.indexOfSelectedItem;
        _tag_step->tag_pdca_index = tag_UIPDCAType.indexOfSelectedItem;
        
        
        _tag_step->tag_isThread =  tag_UIThreadIndex.indexOfSelectedItem;
        
        _tag_step->tag_isMainShow = tag_UIIsMainShow.state;
        
        _tag_step->tag_readEnterKey = tag_UIReadEndEnterIndex.state;
        
    }
}
/*******************************************************************************************
 **函数名：tableView
 **参数：:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
 **功能：单步保存事件
 **返回值：一个ui 控件
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    
    id retid = nil;
    if([tableColumn.title isEqualToString:@"ID"])
    {
        
        retid = tag_UIIndex;
    }
    else if([tableColumn.title isEqualToString:@"setting"] && _tag_step)
    {
        retid = tag_UISet;
        
    }
    else if([tableColumn.title isEqualToString:@"stepName"])
    {
        retid = tag_UIName;
    }
    else if([tableColumn.title isEqualToString:@"delay"] && _tag_step)
    {
        retid = tag_UISleepTime;
    }
    else if([tableColumn.title isEqualToString:@"run"])
    {
        
        retid = tag_UIExe;
        
    }
    else if([tableColumn.title isEqualToString:@"command"] && _tag_step)
    {
        
        {
            retid = tag_UIResult;
        }
    }
    else if([tableColumn.title isEqualToString:@"type"] && _tag_step)
    {
        retid = tag_UICommandType;
    }
    else if([tableColumn.title isEqualToString:@"enable"])// && _tag_step
    {
        retid = tag_UIEnableCheckBox;
    }
    else if([tableColumn.title isEqualToString:@"pdca"] && _tag_step)
    {
        retid = tag_UIPDCAType;
    }
    
    else if([tableColumn.title isEqualToString:@"filtrationEnd"] && _tag_step)
    {
        retid = tag_UIfiltrationEnd;
    }
    else if([tableColumn.title isEqualToString:@"filtrationBegin"] && _tag_step)
    {
        retid = tag_UIfiltrationBegin;
    }
    else if([tableColumn.title isEqualToString:@"Soc"] && _tag_step)
    {
        retid = tag_UISocketIndex;
    }
    else if([tableColumn.title isEqualToString:@"thread"]&& _tag_step)
    {
        retid = tag_UIThreadIndex;
    }
    
    else if([tableColumn.title isEqualToString:@"show"] && _tag_step)
    {
        retid = tag_UIIsMainShow;
    }
    else if([tableColumn.title isEqualToString:@"readEndFlag"] && _tag_step)
    {
        retid = tag_UIReadEnd;
    }
    else if([tableColumn.title isEqualToString:@"Enter"] && _tag_step)
    {
        retid = tag_UIReadEndEnterIndex;
    }
    else if([tableColumn.title isEqualToString:@"Algorithm"] && _tag_step)
    {
        retid = tag_UIAlgorithmType;
    }
    
    else if([tableColumn.title isEqualToString:@"exctimes"] && _tag_step)
    {
        retid = tag_UiExcTimes;
    }
    return retid;
}

@end
