//
//  MainView.h
//  strongTest
//
//  Created by strong on 2017/12/30.
//  Copyright © 2017年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MainView : NSView
@property (weak) IBOutlet NSView *tag_UiCoustPageView;
@property (weak) IBOutlet NSTabView *tag_UiNsTabView;
@property (unsafe_unretained) IBOutlet NSTextView *tag_UiLogView;
/*******************************************************************************************
 **函数名：initWithFrame
 **参数：:(CGRect)frame
 **功能：初始化 大小
 **返回值：
 *******************************************************************************************/
- (instancetype)initWithFrame:(CGRect)frame;
@end
