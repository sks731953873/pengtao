//
//  Config.m
//  TestResistance
//
//  Created by TOD on 6/26/14.
//  Copyright (c) 2014 CeWay. All rights reserved.
//

#include "Config.h"

//#define ConfigFile "/Users/strong/Library/Developer/Xcode/DerivedData/strongTest-dkamvpgspjglimexcmazjsbtpmer/Build/Products/Debug/sconfig.dat"

#define ConfigFile "/Users/strong/Library/Developer/Xcode/DerivedData/strongTest-hjxjltmyiczkfxgmosxzafdtqcog/Build/Products/Debug/sconfig.dat"


  sConfig  g_sConfig;

/*******************************************************************************************
**函数名：Load
**参数：,加载一个配置文件(
ipConfig soc)
**功能： 单步执行
**返回值：< 0失败
*******************************************************************************************/
void Load()
{
    
    g_sConfig = malloc(sizeof(SConfig));
    extern   void DataLoad();
    DataLoad();
 

}
/*******************************************************************************************
 **函数名：Save
 **参数：,加载一个配置文件(
 **功能： 单步执行
 **返回值：< 0失败
 *******************************************************************************************/
void Save()
{
    SaveData();
  
}


/*******************************************************************************************
 **函数名：logwrite
 **参数：,加载一个配置文件(
 **功能： 单步执行
 **返回值：< 0失败
 *******************************************************************************************/
void logwrite(char *file,char *buffer)
{
    
  //  char buf[0] = {0};
    time_t createdAt = 0;
    struct tm *created;
    uint32_t size = 0;
    extern void mkdirFile(char *pathname);
    mkdirFile(file);
    extern char *getTime();
    FILE * f =   fopen(file, "a+");
    char *time = getTime();
    
    if(!f )
    {
        
        return ;
    }
    fwrite(time, 1, strlen(time), f);
    fwrite(buffer,1, strlen(buffer), f);
    fwrite("\r\n", 1, strlen("\r\n"), f);
    fclose(f);
}

///Users/strong/Desktop/DFU_Log_Data/fwdl2.txt

void FilecopyDel(char *destFile,char *srcFile)
{
    int c;
    FILE *fpSrc, *fpDest;  //定义两个指向文件的指针
    fpSrc = fopen(srcFile, "a");    //以读取二进制的方式打开源文件
    if(fpSrc==NULL)
    {
      
        return ;
    }
    fpDest = fopen(destFile, "wb+");  // //以写入二进制的方式打开目标文件
    if(fpDest==NULL)
    {

        return ;
    }
    while((c=fgetc(fpSrc))!=EOF)
    {   //从源文件中读取数据知道结尾
        fputc(c, fpDest);
    }
    fclose(fpSrc);  //关闭文件指针，释放内存
    fclose(fpDest);
   // remove(srcFile);
    return ;
   
}

/*******************************************************************************************
 **函数名：logwrite
 **参数：,加载一个配置文件(
 **功能： 单步执行
 **返回值：< 0失败
 *******************************************************************************************/
void csvwrite(char *file,char *buffer)
{
    char buf[0] = {0};
    time_t createdAt = 0;
    struct tm *created;
    uint32_t size = 0;
    
    extern char *getTime();
    
    FILE * f =   fopen(file, "a+");
    char *time = getTime();
    if(!f )
    {
        
        return ;
    }

    fwrite(buffer,1, strlen(buffer), f);
    fclose(f);
}




