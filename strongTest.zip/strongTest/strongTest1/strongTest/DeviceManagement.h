//
//  DeviceManagement.h
//  X322MotorTest
//
//  Created by CW-IT-MINI-001 on 14-1-8.
//  Copyright (c) 2014年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SerialPort.h"
#import "ConfigFile.h"
//#import "Device.h"


@interface DeviceManagement : NSObject
{
    
    SerialPort* fixturePort;
    

    //pudding* PDCA;
    NSMutableArray* failDeviceNames;
    BOOL isOpen;
}


@property (readwrite, retain) SerialPort* fixturePort;

@property (readwrite, retain) NSMutableArray* failDeviceNames;

+(DeviceManagement*)Instance;
-(BOOL)openDevice;
-(void)CloseDevice;

@end
