//
//  work.c
//  strongTest
//
//  Created by strong on 2017/12/26.
//  Copyright © 2017年 strong. All rights reserved.
//

#include "work.h"
StationRun g_StationRun[MAXSTATION] = {0};
int testRun0(void *b)
{
    return 0;
}
/*******************************************************************************************
 **函数名：workInit
 **参数：,(void *p)
 ipConfig soc)
 **功能： 初始化
 **返回值：< 0失败
 *******************************************************************************************/
void workInit(void *p)
{
    for(int i = 0; i <MAXSTATION;i++)
    {
        StationInit(&g_sConfig->tag_stationManage,&g_StationRun[i],&g_sConfig->tag_stationManage.tag_Station[i],&g_sConfig->tag_IpBag,&g_sConfig->tag_pdcaValueManage,&g_sConfig->tag_PortValueManage);
   
    }
   // g_sConfig->tag_stationManage.tag_Station[0].tag_step[0].tag_Exe = testRun0;
    
}


