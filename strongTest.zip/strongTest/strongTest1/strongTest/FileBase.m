//
//  FileBase.m
//  TestResistance
//
//  Created by TOD on 6/26/14.
//  Copyright (c) 2014 CeWay. All rights reserved.
//

#import "FileBase.h"

static FileBase* fileBase=nil;

@implementation FileBase

+(FileBase*)Instance
{
    if(fileBase==nil)
    {
        fileBase=[[FileBase alloc] init];
    }
 
    return fileBase;
}

-(id)init
{
    if(self=[super init])
    {
        
    }
    
    return self;
}



//获取系统debug文件夹名称
-(NSString*)GetFolderPath
{
    NSFileManager* fileManager=[NSFileManager defaultManager];
    NSString* strFloder= [fileManager currentDirectoryPath];
    return strFloder;
}

//判断所给文件路径是否存在
-(BOOL) IsExist:(NSString*)strPath isFolder:(BOOL)flag
{
    if(strPath.length<1)
        return NO;
    
    NSFileManager* fileManager=[NSFileManager defaultManager];
    
    if([fileManager fileExistsAtPath:strPath isDirectory:&flag])
    {
        return YES;
    }
    return NO;
}

//判断文件是否存在
-(BOOL)isFileExist:(NSString*)strFilePath
{
    NSFileManager* file=[NSFileManager defaultManager];

    if([file fileExistsAtPath:strFilePath isDirectory:NO])
    {
        return YES;
    }
    
    return false;
}

//判断文件及文件夹是否存在
-(BOOL)isFileDirExist:(NSString*)strFileDirPath
{
    NSFileManager* fileDir=[NSFileManager defaultManager];
    BOOL flag=YES;
    
    if([fileDir fileExistsAtPath:strFileDirPath isDirectory:&flag])
    {
        return YES;
    }
    
    return false;
}

//删除文件及文件夹
-(void)RemoveFile:(NSString*)strFilePath
{
    if([self IsExist:strFilePath isFolder:NO])
    {
        NSFileManager* fileManager=[NSFileManager defaultManager];
        [fileManager removeItemAtPath:strFilePath error:NULL];
    }
}

//创建文件夹
-(void)CreateFolder:(NSString*)strFolder
{
    if(![self IsExist:strFolder isFolder:YES])
    {
        NSFileManager* fileManager=[NSFileManager defaultManager];
        
        [fileManager createDirectoryAtPath:strFolder withIntermediateDirectories:YES attributes:nil error:nil];
    }
}

//创建文件
-(void)CreateLogFile:(NSString*)strFilePath
{
    if(![self IsExist:strFilePath isFolder:NO])
    {
        NSFileManager* fileManager=[NSFileManager defaultManager];
        
        [fileManager createFileAtPath:strFilePath contents:nil attributes:nil];
    }
}

//文件是否能够写
-(BOOL) FileCanWrite:(NSString*)strFullPath
{
    BOOL readFlag=NO;
    
    NSFileManager* file=[NSFileManager defaultManager];
    
    if([file isWritableFileAtPath:strFullPath])
        readFlag= YES;
    return readFlag;
}

//判断文件是否可读
-(BOOL)FileCanRead:(NSString*)strFilePath
{
    NSFileManager* file=[NSFileManager defaultManager];
    
    if([file isReadableFileAtPath:strFilePath])
    {
        return YES;
    }
    
    return NO;
}

//读取文件信息返回字符串
-(NSString*) ReadFile:(NSString*)strFullPath
{
	NSString* fileContent = [NSString stringWithContentsOfFile:strFullPath usedEncoding:nil error:nil];
	return fileContent;
}

//读取文件信息返回字典类型
-(NSDictionary*)ReadFileDictionary:(NSString*)strFilePath
{
    NSDictionary* dicTemp=[NSDictionary dictionaryWithContentsOfFile:strFilePath];
    
    return dicTemp ;
}

//写字符串到文件
-(void)WriteFile:(NSString*)strFilePath andContent:(NSString*)contents IsAppend:(BOOL)isAppend
{
    if(![self IsExist:strFilePath isFolder:NO])
    {
        [self CreateLogFile:strFilePath];
    }
    
    if(![self FileCanWrite:strFilePath])
    {
        return;
    }
    
    NSMutableString* fileContents=[[NSMutableString alloc]init];
    
    if (isAppend)
    {
        [fileContents setString:[self ReadFile:strFilePath]];
        [fileContents appendString:contents];
    }
    else
    {
        [fileContents setString:contents];
    }
    
	[fileContents writeToFile:strFilePath atomically:NO encoding:NSUTF8StringEncoding error:nil];
  
}

//写log文件，要注意log文件的格式，逗号表示下一格，\n表示换行
-(void) WriteFile:(NSString*)strFolderPath andFullPath:(NSString*)strFullPath andContent:(NSString*)contents IsAppend:(BOOL)isAppend
{
	NSMutableString* fileContents=[[NSMutableString alloc]init];
   
    if([strFolderPath length]>0 && ![self IsExist:strFolderPath isFolder:YES])
        [self CreateFolder:strFolderPath];
	if (![self IsExist:strFullPath isFolder:NO])
		[self CreateLogFile:strFullPath];
    if(![self FileCanWrite:strFullPath])
    {
        
        return;
    }
    
    if (isAppend)
    {
        [fileContents setString:[self ReadFile:strFullPath]];
        [fileContents appendString:contents];
    }
    else
    {
        [fileContents setString:contents];
    }
    
	[fileContents writeToFile:strFullPath atomically:NO encoding:NSUTF8StringEncoding error:nil];

}

@end
