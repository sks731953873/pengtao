//
//  FCTDL.h
//  strongTest
//
//  Created by strong on 2018/1/10.
//  Copyright © 2018年 strong. All rights reserved.
//

#ifndef FCTDL_h
#define FCTDL_h

#include <stdio.h>
#include "Config.h"
#define MAXIFCTDL 1024
#define MAXTEXTFCTDL 40
#define MAXCOUNTPDCA 256

typedef struct _FctDlValue
{
    char tag_TID[MAXIFCTDL];//名称
    char tag_Value[MAXTEXTFCTDL];//结果
    char tag_LL[MAXTEXTFCTDL];//最大值
    char tag_UL[MAXTEXTFCTDL];//最小值
    char tag_Unit[MAXTEXTFCTDL];//最小值
    char tag_UUT0[MAXTEXTFCTDL];//最小值
    char tag_UUT1[MAXTEXTFCTDL];//最小值
    char tag_UUT2[MAXTEXTFCTDL];//最小值
    char tag_UUT3[MAXTEXTFCTDL];//最小值
    
}FctDlValue,*fctDlValue;
typedef struct _FctDlValueManage
{
    int tag_totalCount;//个数
    FctDlValue tag_FctDlValue[MAXCOUNTPDCA];//列表
}FctDlValueManage,*fctDlValueManage;
extern FctDlValueManage  s_FctDlValueManage_FCT;
extern FctDlValueManage  s_FctDlValueManage_FDL;
/*******************************************************************************************
 **函数名：stepInster
 **参数：,Station  *station。运行的工位 ,int delIndex 第几个步骤，,Step *step 插入的步骤
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
int FctDlAdd(fctDlValueManage cftdlMaange,
             char *tag_TID,//名称
             char *tag_Value,//结果
             char *tag_LL,//最大值
             char *tag_UL,//最小值
             char *tag_Unit,//最小值
             char *tag_UUT0,//最小值
             char *tag_UUT1,//最小值
             char *tag_UUT2,//最小值
             char *tag_UUT3);
/*******************************************************************************************
 **函数名：FctDlClean
 **参数：,fctDlValueManage 清
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
void FctDlClean(fctDlValueManage cftdlMaange);
/*******************************************************************************************
 **函数名：FctDlClean
 **参数：,fctDlValueManage 清
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
void FctDlClean(fctDlValueManage cftdlMaange);
/*******************************************************************************************
 **函数名：FCTADD
 **参数：,fctDlValueManage 清
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
void  FCTADD(char *tag_TID, //名称
             char *tag_Value, //结果
             char *tag_LL, //最大值
             char *tag_UL, //最小值
             char *tag_Unit, //最小值
             char *tag_UUT0, //最小值
             char *tag_UUT1, //最小值
             char *tag_UUT2, //最小值
             char *tag_UUT3);
/*******************************************************************************************
 **函数名：FCTClean
 **参数：,fctDlValueManage 清
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
void  FCTClean();
/*******************************************************************************************
 **函数名：FDLADD
 **参数：,fctDlValueManage 清
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
void FDLADD(char *tag_TID, //名称
            char *tag_Value, //结果
            char *tag_LL, //最大值
            char *tag_UL, //最小值
            char *tag_Unit, //最小值
            char *tag_UUT0, //最小值
            char *tag_UUT1, //最小值
            char *tag_UUT2, //最小值
            char *tag_UUT3);
/*******************************************************************************************
 **函数名：FDLClean
 **参数：,fctDlValueManage 清
 **功能：插入一个步骤
 **返回值：
 *******************************************************************************************/
void FDLClean();

/*******************************************************************************************
 **函数名：FCTSetRow
 **参数：,修改cft行数据
 **功能：插向FCT加一列
 **返回值：
 *******************************************************************************************/
void  FCTSetRow(int Row,char *tag_TID, //名称
                char *tag_Value, //结果
                char *tag_LL, //最大值
                char *tag_UL, //最小值
                char *tag_Unit, //最小值
                char *tag_UUT0, //最小值
                char *tag_UUT1, //最小值
                char *tag_UUT2, //最小值
                char *tag_UUT3);
/*******************************************************************************************
 **函数名：FDLSetRow
 **参数：,修改cft行数据
 **功能：,修改cft行数据
 **返回值：
 *******************************************************************************************/
void  FDLSetRow(int Row,
                char *tag_TID, //名称
                char *tag_Value, //结果
                char *tag_LL, //最大值
                char *tag_UL, //最小值
                char *tag_Unit, //最小值
                char *tag_UUT0, //最小值
                char *tag_UUT1, //最小值
                char *tag_UUT2, //最小值
                char *tag_UUT3);

#endif /* FCTDL_h */
