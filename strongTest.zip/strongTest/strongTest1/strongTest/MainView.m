//
//  MainView.m
//  strongTest
//
//  Created by strong on 2017/12/30.
//  Copyright © 2017年 strong. All rights reserved.
//

#import "MainView.h"

#import "Config.h"
#import "mainStationView.h"
#import "mainStepDebug.h"
#import "InstantPuddingWrapper.h"
@interface MainView()<NSTableViewDelegate,NSTableViewDataSource>
{
    
    sConfig tag_SConfig;//整个工程的配置
    NSMutableArray *tag_UITableRight;//
    int tag_upRightSelectRow;
    NSMutableArray *tag_UITableLeft;//
    int tag_upLeftSelectRow;
    NSMutableArray *tag_UIStationArray;//用于管理工位
    
    NSMutableArray *tag_UIPageButton;
    NSMutableArray *tag_UISnText;
    lpStation tag_lpStation;
    int tag_UITotaolStep;
    int tag_UiPageCount;
    int tag_UiPageIndex;
    int tag_UiPageStepCount;
    int tag_upSelectRow;
}



@property (weak) IBOutlet NSTextFieldCell *tag_UiStationWorkState;
@property (weak) IBOutlet NSTableView *tag_UiStationTable;
@property (weak) IBOutlet NSView *tag_UILowerNavigator;
@property (weak) IBOutlet NSTextField *tag_UISNTextField;

@property (weak) IBOutlet NSTableView *tag_UirightTable;
@property (weak) IBOutlet NSTableView *tag_UiLeftTable;

@property (weak) IBOutlet NSTableView *tag_UiTableViewFail;
@property (weak) IBOutlet NSTableView *tag_UiTableViewPass;

@end



@implementation MainView
static id selfObj;
const char * GetMainViewSN(){
    MainView *selfView = (MainView *)selfObj;
    return selfView.tag_UISNTextField.stringValue.UTF8String;
}
/*******************************************************************************************
 **函数名：initWithFrame
 **参数：:(CGRect)frame
 **功能：初始化 大小
 **返回值：
 *******************************************************************************************/

- (instancetype)initWithFrame:(CGRect)frame
{
    NSArray *arr = [NSArray array];
    
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([MainView class]) owner:nil topLevelObjects:&arr];
    
    self = [super initWithFrame:frame];
    
    if (self) {
        
        for(int i = 0;i < arr.count;i++)
        {
            if([arr[i] isKindOfClass:[self class]])
            {
                MainView *stationView = arr[i];
                
                CGRect frame1 = {frame.origin.x,frame.origin.y,stationView.frame.size.width,stationView.frame.size.height};
                // stationView.frame = frame1;
                
                // CALayer *viewLayer = [CALayer layer];
                // [viewLayer setBackgroundColor:CGColorCreateGenericRGB(0.9, 0.9, 0.9, 1)];
                [stationView setWantsLayer:YES];
                // [stationView setLayer:viewLayer];
                self = stationView;
                
                tag_UITableLeft = [[NSMutableArray alloc] init];
                tag_UIPageButton = [[NSMutableArray alloc] init];
                tag_UISnText = [[NSMutableArray alloc] init];
                tag_UIStationArray = [[NSMutableArray alloc] init];
                
                tag_UiPageStepCount = 20;
                tag_SConfig = g_sConfig;
                
                
                [self UiInit];
                
                [self InitSnText];
                [self SnTextInit];
                self.tag_UiLeftTable.dataSource = self;
                self.tag_UiLeftTable.delegate = self;
                
                
                [self.tag_UiLeftTable setGridStyleMask:NSTableViewDashedHorizontalGridLineMask | NSTableViewSolidVerticalGridLineMask];
                // [self.tag_UiLeftTable setGridStyleMask:NSTableViewSolidHorizontalGridLineMask];
                
                self.tag_UiStationTable.dataSource = self;
                self.tag_UiStationTable.delegate = self;
                self.tag_UiNsTabView.delegate = self;
                
                self.tag_UiTableViewFail.delegate = self;
                self.tag_UiTableViewFail.dataSource = self;
    
                
                self.tag_UiTableViewPass.delegate = self;
                self.tag_UiTableViewPass.dataSource = self;
                break;
            }
        }
    }
    
    
    
    NSTimer *timer;
    timer = [NSTimer scheduledTimerWithTimeInterval: 1
                                             target: self
                                           selector: @selector(TimehandleTimer:)
                                           userInfo: nil
                                            repeats: YES];

    selfObj = self;
    return self;
    
}


- (IBAction)LoopTestAction:(id)sender
{
    NSButton *butt = (NSButton * )sender;
    g_sConfig->tag_SysIni.tag_IsLoopTest = butt.state;
    
}


/*
 获取sn索引
 */
void GetSnIndex(int *snArray,int len)
{
    for(int i =0 ;i < len;i++)
    {
        snArray[i] =-1;
    }
    for(int i = 0;i < g_sConfig->tag_stationManage.tag_totalCount;i++)
    {
        for(int j =0;j < len;j++)
        {
            if(snArray[j] == g_sConfig->tag_stationManage.tag_Station[i].tag_snIndex)
            {
                break;
            }
            if(snArray[j] == -1 && g_sConfig->tag_stationManage.tag_Station[i].tag_snIndex <20 && g_sConfig->tag_stationManage.tag_Station[i].tag_snIndex >= 0)
            {
                snArray[j]  = g_sConfig->tag_stationManage.tag_Station[i].tag_snIndex;
                break;
            }
        }
    }
}



- (void)controlTextDidChange:(NSNotification *)obj
{
    extern char gloabe_sn[20][100];
    NSTextField *test =( NSTextField *) obj.object;
    memset(gloabe_sn[test.tag],0,100);
    if(strlen([test.stringValue UTF8String]))
    {
        if(test.tag >=0)
        {
            strcat(gloabe_sn[test.tag],[test.stringValue UTF8String]);
        }
    }
}



- (IBAction)pauseAction:(id)sender {
    NSButton * bt = (NSButton*) sender;
    g_sConfig->tag_SysIni.tag_parse = bt.state;
}


-(void)SnTextInit
{
    int snIndex[100] =  {0};
    GetSnIndex(snIndex,100);

    if(tag_SConfig->tag_SysIni.tag_SnGetMethod == 0)
    {
        CGRect rect = {80+0*160,5,150,20};
        NSTextField *tag_UIIP = [[NSTextField alloc] initWithFrame:rect];
        [_tag_UILowerNavigator addSubview:tag_UIIP];
        tag_UIIP.delegate =  self;
        tag_UIIP.tag = 21;
        return ;
    }
   /* for(int i = 0; i < 100;i++)
    {
        CGRect rect = {80+i*160,5,150,20};
        if(snIndex[i] >-1)
        {
            NSTextField *tag_UIIP = [[NSTextField alloc] initWithFrame:rect];
            [_tag_UILowerNavigator addSubview:tag_UIIP];
            tag_UIIP.delegate =  self;
            tag_UIIP.tag = snIndex[i];
        }

    }*/
}
-(void)selectStationDelegate:(lpStation) obj
{
    tag_lpStation = obj;
    [self UiInitStep];
    [self.tag_UiLeftTable reloadData];
    [self.tag_UiStationTable reloadData];
}


- (IBAction)refreshButtonAction:(id)sender
{
    g_sConfig->tag_stationManage.tag_WorkStop = 0;
    [self UiInit];
    [self.tag_UiLeftTable reloadData];
     [self.tag_UiStationTable reloadData];
}



/*******************************************************************************************
 **函数名：stationManageExe
 **参数：::(id)sender
 **功能：工位停止
 **返回值：
 *******************************************************************************************/
-(void)stationManageExe:(NSObject*) o
{
    extern   int workWork(stationManage lpstationManag);
    int ret = workWork(&g_sConfig->tag_stationManage);
    
}

/*******************************************************************************************
 **函数名：stationManageExe
 **参数：::(id)sender
 **功能：工位停止
 **返回值：
 *******************************************************************************************/
-(void)stationManageRest:(NSObject*) o
{
    extern   int RestWork(stationManage lpstationManag);
    int ret = RestWork(&g_sConfig->tag_stationManage);
    
}



- (IBAction)CleanLogButtonAction:(id)sender {
    
    CelanLog();

}



- (IBAction)RestButtonAction:(id)sender
{
   /* if(g_sConfig->tag_stationManage.tag_WorkStop == 1)
    {
        NSAlert *alert = [NSAlert new];
        [alert addButtonWithTitle:@"提示"];
        [alert setMessageText:@"急停中"];
        [alert beginSheetModalForWindow:[self window] completionHandler:nil];
        
        return ;
    }*/
    if(g_sConfig->tag_stationManage.tag_RestState == 1)
    {
        NSAlert *alert = [NSAlert new];
        [alert addButtonWithTitle:@"提示"];
        [alert setMessageText:@"复位中"];
        [alert beginSheetModalForWindow:[self window] completionHandler:nil];
        
        return ;
    }
    g_sConfig->tag_stationManage.tag_WorkStop = 0;
    if(g_sConfig->tag_stationManage.tag_WorkState != 0)
    {
        NSAlert *alert = [NSAlert new];
        [alert addButtonWithTitle:@"提示"];
        [alert setMessageText:@"工作中"];
        [alert beginSheetModalForWindow:[self window] completionHandler:nil];;
         return ;
    }
    NSThread * tag_myThread = [[NSThread alloc] initWithTarget:self
                                                      selector:@selector(stationManageRest:)
                                                        object:nil];
    [tag_myThread start];
    
}



- (IBAction)PdcaSelectAction:(id)sender
{
    NSButton *but = (NSButton*)sender;
    g_sConfig->tag_SysIni.tag_IsPdcaUpdata = but.state;
}

- (IBAction)StartButtonAction:(id)sender
{

    if(g_sConfig->tag_stationManage.tag_RestState == 1)
    {
        NSAlert *alert = [NSAlert new];
        [alert addButtonWithTitle:@"提示"];
        [alert setMessageText:@"复位中"];
        [alert beginSheetModalForWindow:[self window] completionHandler:nil];
        
        return ;
    }
    if(g_sConfig->tag_stationManage.tag_RestState == 0)
    {
        NSAlert *alert = [NSAlert new];
        [alert addButtonWithTitle:@"提示"];
        [alert setMessageText:@"没有复位，请复位"];
        [alert beginSheetModalForWindow:[self window] completionHandler:nil];

        return ;
    }
    if(g_sConfig->tag_stationManage.tag_WorkStop == 1)
    {
        NSAlert *alert = [NSAlert new];
        [alert addButtonWithTitle:@"提示"];
        [alert setMessageText:@"急停中"];
        [alert beginSheetModalForWindow:[self window] completionHandler:nil];
        
        return ;
    }
    if(g_sConfig->tag_stationManage.tag_WorkState == 1)
    {
        NSAlert *alert = [NSAlert new];
        [alert addButtonWithTitle:@"提示"];
        [alert setMessageText:@"工作中"];
        [alert beginSheetModalForWindow:[self window] completionHandler:nil];
        
        return ;
    }
    if(g_sConfig->tag_stationManage.tag_WorkState  == 0)
    {
        NSThread * tag_myThread = [[NSThread alloc] initWithTarget:self
                                                          selector:@selector(stationManageExe:)
                                                            object:nil];
        [tag_myThread start];
    }
}


/*******************************************************************************************
 **函数名：stationManageExe
 **参数：::(id)sender
 **功能：工位停止
 **返回值：
 *******************************************************************************************/

-(void)stationManageStop:(NSObject*) o
{
    extern   int StopWork(stationManage lpstationManag,int type);
    if(tag_lpStation)
    {
        StopWork(&g_sConfig->tag_stationManage,tag_lpStation->tag_stationType);
    }
    
}


- (IBAction)StopButtonAction:(id)sender
{

    NSThread * tag_myThread = [[NSThread alloc] initWithTarget:self
                                                      selector:@selector(stationManageStop:)
                                                        object:nil];
    [tag_myThread start];
 
    
}



/*******************************************************************************************
 **函数名：MenuPasteAction
 **参数：(id)sender
 **功能：粘贴
 **返回值：
 *******************************************************************************************/
- (IBAction)ButtonPageAction:(id)sender
{
    NSButton *butt = (NSButton *)sender;
    tag_UiPageIndex = butt.tag;
    [self.tag_UiLeftTable reloadData];
    
}



/*******************************************************************************************
 **函数名：StepUpdate
 **参数：(id)sender
 **功能：
 **返回值：
*******************************************************************************************/
-(void) UiInit
{
    int n = 0;
    int mm = 0;
    int q = 0;
    
    [tag_UIStationArray removeAllObjects];
    
    int temp1 = g_sConfig->tag_stationManage.tag_Station[0].tag_MainShow;
    
    int temp = g_sConfig->tag_stationManage.tag_totalCount;
    
    for(int i = 0; i< g_sConfig->tag_stationManage.tag_totalCount;i++)
    {
        
        if(g_sConfig->tag_stationManage.tag_Station[i].tag_MainShow)
        {
            if(!tag_lpStation)
            {
                tag_lpStation = &g_sConfig->tag_stationManage.tag_Station[i];
            }
            
            mainStationView *sview = [[mainStationView alloc] init];
            sview.tag_Delegate = self;
            [sview InitUI:i STATION:&g_sConfig->tag_stationManage.tag_Station[i]];
            
            
            [tag_UIStationArray addObject:sview];
            n++;
            mm++;
            q = 1;
        }
    }
    
    [tag_UITableLeft removeAllObjects];
    int p = 1;
    q = 0;
    if(!tag_lpStation)
        return ;
    for(int i = 0; i< tag_lpStation->tag_totalCount;i++)
    {
        if(tag_lpStation->tag_step[i].tag_isMainShow)
        {
            mainStepDebug *sview = [[mainStepDebug alloc] init];
            [sview InitUI:p STEP:&tag_lpStation->tag_step[i] PDCAMANAGE:&tag_SConfig->tag_pdcaValueManage STATION:nil];
            [sview UIUpdata: i];
            [tag_UITableLeft addObject:sview];
            n++;
            mm++;
            p++;
            q = 1;
        }
    }
    
    
   
    return ;
    
}

/*******************************************************************************************
 **函数名：StepUpdate
 **参数：(id)sender
 **功能：
 **返回值：
 *******************************************************************************************/
-(void) UiInitStep
{
    int n = 0;
    int mm = 0;
    int q = 0;
    
  
    
    [tag_UITableLeft removeAllObjects];
    int p = 1;
    q = 0;
    if(!tag_lpStation)
        return ;
    for(int i = 0; i< tag_lpStation->tag_totalCount;i++)
    {
        if(tag_lpStation->tag_step[i].tag_isMainShow)
        {
            mainStepDebug *sview = [[mainStepDebug alloc] init];
            [sview InitUI:p STEP:&tag_lpStation->tag_step[i] PDCAMANAGE:&tag_SConfig->tag_pdcaValueManage STATION:nil];
            [sview UIUpdata: i];
            [tag_UITableLeft addObject:sview];
            n++;
            mm++;
            p++;
            q = 1;
        }
    }
    
    return ;
    
}



/*******************************************************************************************
 **函数名：numberOfRowsInTableView
 **参数：:
 **功能：设置列表的函数，ip列表，步骤列表，工位列表
 **返回值：
 *******************************************************************************************/
-(int) GetStepTotal
{
    int n = 0;
    for(int i = 0;i < g_sConfig->tag_stationManage.tag_totalCount;i++)
    {
        if(g_sConfig->tag_stationManage.tag_Station[i].tag_isOpenSpreadOut)
        {
            n = n + g_sConfig->tag_stationManage.tag_Station[i].tag_totalCount;
        }
    }
    n =  n+g_sConfig->tag_stationManage.tag_totalCount;
    return n;
}




/*******************************************************************************************
 **函数名：numberOfRowsInTableView
 **参数：:
 **功能：设置列表的函数，ip列表，步骤列表，工位列表
 **返回值：
 *******************************************************************************************/
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView
{
    if(tableView == self.tag_UiLeftTable)
    {
       

        int m =  tag_UITableLeft.count;
        return m;
       
    }

    if(tableView == self.tag_UiStationTable)
    {
           int m =  tag_UIStationArray.count;
       
        return m;
    }
    return 0;
}


/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：初始化列表中的内容
 **返回值：
 *******************************************************************************************/
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    id retid = nil;
    if(tableView == self.tag_UiLeftTable)
    {
        
        
        mainStepDebug *mainStepView1 = tag_UITableLeft[tag_UiPageIndex*tag_UiPageStepCount + row];
      
        return  [mainStepView1 tableView:tableView viewForTableColumn:tableColumn row:row];
        
    }

    if(tableView == self.tag_UiStationTable)
    {
        
        
       mainStationView *mainStepView1 = tag_UIStationArray[ row];
        
        return  [mainStepView1 tableView:tableView viewForTableColumn:tableColumn row:row];
        
    }
    return retid;
}



/*******************************************************************************************
 **函数名：tableView
 **参数：:
 **功能：初始化列表中高度
 **返回值：
 *******************************************************************************************/
- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row
{
    return 20;
}



int g_indexTemp[10000] = {0};
- (void) TimehandleTimer: (NSTimer *) timer
{
    int f = 0;
  
    NSTableRowView *cellView;
    
    int i =0;
    {
        extern char *g_textLog2;
        if(g_textLog2)
        {
            self.tag_UiLogView.string = [[NSString alloc] initWithCString: g_textLog2 encoding:NSASCIIStringEncoding];
            g_textLog2 = 0;
        }
    }
    
    
    [self UpdataPdca];
    [self ShowWorkState];
}



-(void) UpdataPdca
{
    int i =0 ;
    
    while(i < tag_UITableLeft.count)
    {

        mainStepDebug *stepv = tag_UITableLeft[i];
        [stepv UIUpdata:i];
        i++;
    }
    i = 0;
    while(i < tag_UIStationArray.count)
    {
        mainStationView *stepv = tag_UIStationArray[i];
        [stepv UIUpdata:i STATION:tag_lpStation];
        [stepv updateTotalAndFailedPcsAtIndex:i Station:&g_sConfig->tag_stationManage.tag_Station[i]];
        i++;
    }

}


-(void) InitSnText
{
    CGRect f = {0,0,100,20};
    NSTextField *text = [[NSTextField alloc] initWithFrame:f];
    [self.tag_UiStationTable addSubview:text];
}


- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}



-(void)ShowWorkState
{
    if(g_sConfig->tag_stationManage.tag_WorkStop == 1 || g_sConfig->tag_stationManage.tag_WorkStop == 2 )
    {
        self.tag_UiStationWorkState.stringValue = @"Stop";
        return ;
    }
    if(g_sConfig->tag_stationManage.tag_RestState == 1)
    {
       self.tag_UiStationWorkState.stringValue = @"Resting";
        
        
        return ;
    }
    if(g_sConfig->tag_stationManage.tag_RestState == 0)
    {
         self.tag_UiStationWorkState.stringValue = @"Wait Rest";
        return ;
    }
    if(g_sConfig->tag_stationManage.tag_RestState == 2)
    {
        if(g_sConfig->tag_stationManage.tag_WorkState == 1)
        {
            self.tag_UiStationWorkState.stringValue = @"working";
            return ;
        }
        self.tag_UiStationWorkState.stringValue = @" Rest OK";
        return ;
    }
   
    if(g_sConfig->tag_stationManage.tag_WorkState == 1)
    {
         self.tag_UiStationWorkState.stringValue = @"working";
        return ;
    }
}




- (void)tabView:(NSTabView *)tabView willSelectTabViewItem:(nullable NSTabViewItem *)tabViewItem
{
    int i = 0;
    for(int i = 0; i < tabView.tabViewItems.count;i++)
    {
        if(tabView.tabViewItems[i] == tabViewItem)
        {
            break;
        }
    }
    
}
@end
