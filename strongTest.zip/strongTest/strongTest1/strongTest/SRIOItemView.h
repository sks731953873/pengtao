//
//  SRIOItemView.h
//  strongTest
//
//  Created by strong on 2018/1/23.
//  Copyright © 2018年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
@class SRIOItemView;

@protocol SRIOItemViewDelegate <NSObject>

- (void)SRIOItemViewDidClick:(SRIOItemView *)itemView;

@end

@interface SRIOItemView : NSView
@property(nonatomic,assign)int sendInt;
@property(nonatomic,assign)int sendState;
@property(nonatomic,assign)int Num;
@property(nonatomic,assign,getter=isActive)BOOL active;
@property(nonatomic,assign)id<SRIOItemViewDelegate> delegate;

@end
