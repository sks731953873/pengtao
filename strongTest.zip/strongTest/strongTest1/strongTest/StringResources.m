//
//  StringResources.c
//  OAO
//
//  Created by strong on 17/12/1.
//  Copyright © 2017年 strong. All rights reserved.
//

#include "StringResources.h"




int g_countryID = 0;

uct_ResouresStr strResources[100] =
{
    {"请输入名称","input name"},
   

};
/*
 获取字体的国别
 */
NSString *GetStringResouces(int stringId)
{
    char *str =strResources[stringId].strCountent[g_countryID] ;
    return [[NSString alloc] initWithUTF8String:str];
}

/*
 获取字体的国别
 */
void setCountryID(int country_ID)
{
    g_countryID = country_ID;
}
