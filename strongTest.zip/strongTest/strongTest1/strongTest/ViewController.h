//
//  ViewController.h
//  strongTest
//
//  Created by strong on 2017/12/15.
//  Copyright © 2017年 strong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "FileExFun.h"
#import "StepView.h"
#import "StationDebugView.h"
//#import "FileExFun.h"
@interface ViewController : NSViewController

@property (strong) IBOutlet NSView *MainView;

@end

