//
//  CFTSTestAttributes.m
//
//  Created by MS on 02/23/10.
//  Copyright 2010 Apple, Inc.. All rights reserved.
//

//

#import "TestAttributes.h"


@implementation TestAttributes

- (id)init {
    if (self = [super init]) {
    }
    return self;
}

- (id) initWithTestAttributes:(NSString *)_testName subTestName:(NSString *)_subTestName lowerLimit:(NSString *)_lowerLimit upperLimit:(NSString *)_upperLimit testResult:(NSString *)_testResut testValue:(NSString *)_testValue message:(NSString*)_message priority:(NSString *)_priority   stationStartTime:(NSString *) _stationStartTime   stationEndTime:(NSString *) _stationEndTime   uutio:(NSString *) _uutioe
   CSVTESTResult:(NSString*) _csvTESTResult
             IsAttributesType :(NSInteger) _IsAttributesType
{
 
    if (self = [super init]) {
		[self setTestName:(_testName)? _testName:@" "];
		[self setSubTestName:(_subTestName)? _subTestName:@" "];
		[self setLowerLimit:(_lowerLimit)? _lowerLimit:@" "];
		[self setUpperLimit:(_upperLimit)? _upperLimit:@" "];
		[self setPriority:(_priority)? _priority:@" "];
		[self setTestResult:(_testResut)?_testResut:@" "];
		[self setTestValue:(_testValue)?_testValue:@" "];
		[self setMessage:(_message)?_message:@" "];
        	[self setStationStartTime:(_stationStartTime)?_stationStartTime:@" "];
        [self setStationEndTime:(_stationStartTime)?_stationEndTime:@" "];
        [self setUutio:(_uutioe)?_uutioe:@" "];
          [self settestCsvValue:(_csvTESTResult)?_csvTESTResult:@" "];
 [self setIsAttributesType:_IsAttributesType];
        
    }
    return self;	
}


- (void)setIsAttributesType:(NSInteger)value {
    IsAttributesType = value ;
}



- (void)setTestName:(NSString *)value {
    if (testName != value) {
    
        testName = [[NSString alloc] initWithString:value];
    }
}

- (void)setSubTestName:(NSString *)value {
    if (subTestName != value) {
        
        subTestName =  [[NSString alloc] initWithString:value];
    }
}

- (void)setTestResult:(NSString *)value {
    if (testResult != value) {
    
        testResult =  [[NSString alloc] initWithString:value];
    }
}
- (void)setPriority:(NSString *)value {
    if (priority != value) {
        
        priority =  [[NSString alloc] initWithString:value];
    }
}
- (void)setTestValue:(NSString *)value {
    if (testValue != value) {
        
        testValue =  [[NSString alloc] initWithString:value];
    }
}

- (void)setLowerLimit:(NSString *)value {
    if (lowerLimit != value) {
    
        lowerLimit =  [[NSString alloc] initWithString:value];
    }
}

- (void)setUpperLimit:(NSString *)value {
    if (upperLimit != value) {
    
        upperLimit =  [[NSString alloc] initWithString:value] ;;
    }
}

- (void)setMessage:(NSString *)value {
    if (message != value) {
      
        message =  [[NSString alloc] initWithString:value] ;;
    }
}
- (void)setStationStartTime:(NSString *)value {
    if (stationStartTime != value) {
        
        stationStartTime =  [[NSString alloc] initWithString:value] ;;
    }
}
- (void)setStationEndTime:(NSString *)value {
    if (stationEndTime != value) {
        
        stationEndTime =  [[NSString alloc] initWithString:value] ;;
    }
}
- (void)setUutio:(NSString *)value {
    if (uutio != value) {
        
        uutio =  [[NSString alloc] initWithString:value] ;;
    }
}
- (void)settestCsvValue:(NSString *)value
{
    if (testCsvResult != value) {
        
        testCsvResult =  [[NSString alloc] initWithString:value] ;;
    }
}


- (NSString *)GetTestName {
    
       return   [[NSString alloc] initWithString:testName] ;
 
}

- (NSString *)GetSubTestName {
     return   [[NSString alloc] initWithString:subTestName] ;
}

- (NSString *)GetTestResult {
     return   [[NSString alloc] initWithString:testResult] ;
}

- (NSString *)GetTestValue {
     return   [[NSString alloc] initWithString:testValue] ;
}

- (NSString *)GetLowerLimit {
      return   [[NSString alloc] initWithString:lowerLimit] ;
}

- (NSString *)GetUpperLimit {
      return   [[NSString alloc] initWithString:upperLimit] ;
}- (NSString *)GetPriority {
    return   [[NSString alloc] initWithString:priority] ;
}

- (NSString *)GetMessßage {
      return   [[NSString alloc] initWithString:message] ;
}
- (NSString *)GetstationStartTime {
      return   [[NSString alloc] initWithString:stationStartTime] ;
}
- (NSString *)GetstationEndTime {
      return   [[NSString alloc] initWithString:stationEndTime] ;
}
- (NSString *)GetUutio {
    return   [[NSString alloc] initWithString:uutio] ;
}
- (NSInteger)GetIsAttributesType {
   return IsAttributesType  ;
}

- (NSString*)GettestCsvResult
{

        
      return   [[NSString alloc] initWithString:testCsvResult] ;
}

@end
