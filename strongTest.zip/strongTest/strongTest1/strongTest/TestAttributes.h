//
//  CFTSTestAttributes.h
//
//  Created by MS on 02/23/10.
//  Copyright 2010 Apple, Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface TestAttributes : NSObject
{

	NSString *testName;
	NSString *subTestName;
	NSString *lowerLimit;
	NSString *upperLimit;
	NSString *priority;
	NSString *testResult;   
	NSString *testValue;
	NSString *message;
    NSString *stationStartTime;
	NSString *stationEndTime;
    NSString *uutio;
    NSString *testCsvResult;
    NSInteger IsAttributesType;
   
}

- (id) initWithTestAttributes:(NSString *)_testName subTestName:(NSString *)_subTestName lowerLimit:(NSString *)_lowerLimit upperLimit:(NSString *)_upperLimit testResult:(NSString *)_testResut testValue:(NSString *)_testValue message:(NSString*)_message priority:(NSString *)_priority   stationStartTime:(NSString *) _stationStartTime   stationEndTime:(NSString *) _stationEndTime   uutio:(NSString *) _uutioe
                CSVTESTResult:(NSString*) _csvTESTResult
            IsAttributesType :(NSInteger) _IsAttributesType
;
- (void) dealloc;

- (void)setIsAttributesType:(NSInteger)value ;
- (void)setTestName:(NSString *)value ;

- (void)setSubTestName:(NSString *)value;

- (void)setTestResult:(NSString *)value ;

- (void)setTestValue:(NSString *)value ;
- (void)settestCsvValue:(NSString *)value ;

- (void)setLowerLimit:(NSString *)value ;

- (void)setUpperLimit:(NSString *)value ;

- (void)setMessage:(NSString *)value ;
- (void)setStationStartTime:(NSString *)value ;
- (void)setStationEndTime:(NSString *)value ;

- (NSString *)GetTestName ;
- (NSString *)GetSubTestName ;
- (NSString *)GetTestResult ;
- (NSString *)GetTestValue ;
- (NSString *)GetLowerLimit ;
- (NSString *)GetUpperLimit ;
- (NSString *)GetMessage ;
- (NSString *)GetstationStartTime ;
- (NSString *)GetstationEndTime ;
- (NSString *)GetPriority;
- (NSString *)GetUutio;

- (NSString*)GettestCsvResult ;
- (NSInteger)GetIsAttributesType;

@end
