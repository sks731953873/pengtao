#!/usr/bin/expect -f
#author=zhongwenpan
set hostip [lindex $argv 0]
set sendfile [lindex $argv 1]
set sendpath [lindex $argv 2]

spawn scp root@$hostip:/opt/seeing/log/$sendpath $sendfile
expect {
"*(yes/no)?" {
send "yes\n"
expect "* password:"
send "123456\n"
}
"* password:" {
send "123456\n"
}
}
interact
