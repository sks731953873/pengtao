//
//  PythonTool.m
//  QT
//
//  Created by test on 13/06/2018.
//  Copyright © 2018 macjinlongpiaoxu. All rights reserved.
//

#import "PythonTool.h"
#import "Lock.h"

@interface PythonTool(){
    
    Lock    *_lock;
}

@end


@implementation PythonTool
{
//    NSTask* task;
//    NSPipe* pipe;
}


static PythonTool *_pythonTool = nil;

+(instancetype)shareInstance
{
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        
        _pythonTool = [[self alloc] init];
        
    });
    return _pythonTool;
}


-(id)init
{
    
    if (self = [super init])
    {
//        task = [[NSTask alloc] init];
//        pipe = [[NSPipe alloc] init];
        //[task setLaunchPath:@"/usr/bin/python"];
        
        //[task launch];
    }
    return self;
}

-(void)addGlobalLock{
    
    
    _lock = [Lock shareInstance];
    
}


//-(instancetype)initWithParams:(NSArray*)array{
//    
//    if(self == [super init]){
//        
//        NSString* toolPath = [self getRadarPath];
//        task = [[NSTask alloc] init];
//        pipe = [[NSPipe alloc] init];
//        [task setLaunchPath:@"/bin/python"];
//        NSArray* params = [NSArray arrayWithObjects:toolPath, nil];
//        NSArray* paraArr = [params arrayByAddingObjectsFromArray:array];
//        
//        self.arrPara = paraArr;
//    }
//    return  self;
//    
//}


-(NSString *)getToolPath
{
    NSString *bundle = [[NSBundle mainBundle] resourcePath];
    NSString *radarToolPath = [bundle stringByAppendingPathComponent:@"hidreport"];
    return radarToolPath;
}


-(NSString*)excuteTask:(NSString*)stringCmd
{
    [_lock lock];
    
    NSMutableString* retString;
    
   // @synchronized (self) {
        //[task launch];
        
        NSTask *task = [[NSTask alloc] init];
        [task setLaunchPath:@"/bin/sh"];
        NSPipe *pipe = [[NSPipe alloc] init];
        
        //NSString* toolPath = [self getToolPath];
        
        //NSArray* array1 = [[NSMutableArray arrayWithObject:toolPath] arrayByAddingObjectsFromArray:array];
        
        //NSString* commandString = [toolPath stringByAppendingString:stringCmd];
        
        NSArray* array = [NSArray arrayWithObjects:@"-c", stringCmd,nil];
        
        [task setArguments:array];
        [task setStandardOutput:pipe];
        NSFileHandle* file = [pipe fileHandleForReading];
        [task launch];
        
        
        NSData* data = [file readDataToEndOfFile];
        retString = [[NSMutableString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"py线程%@====文件操作完毕;dataString: %@",[NSThread currentThread], retString);
        
    //}
    
    [_lock unlock];
    return retString;
}


@end
