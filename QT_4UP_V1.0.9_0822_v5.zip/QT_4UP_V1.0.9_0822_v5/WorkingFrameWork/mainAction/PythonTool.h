//
//  PythonTool.h
//  QT
//
//  Created by test on 13/06/2018.
//  Copyright © 2018 macjinlongpiaoxu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PythonTool : NSObject


@property(nonatomic, strong) NSArray* arrPara;


+(instancetype)shareInstance;

-(NSString*)excuteTask:(NSString*)stringCmd;
- (void)addGlobalLock;

@end
