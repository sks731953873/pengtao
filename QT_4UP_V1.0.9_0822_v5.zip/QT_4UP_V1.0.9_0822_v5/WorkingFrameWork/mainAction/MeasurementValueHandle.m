//
//  MeasurementValueHandle.m
//  QT
//
//  Created by test on 18/07/2018.
//  Copyright © 2018 macjinlongpiaoxu. All rights reserved.
//

#import "MeasurementValueHandle.h"
#import "Lock.h"

static MeasurementValueHandle *measureTool = nil;

@implementation MeasurementValueHandle
{
    Lock*   measureLock;
    
}

-(id)init{
    
    if (self = [super init])
    {
        
    }
    return self;
}


+(instancetype)shareInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        measureTool = [[self alloc] init];
    });
    return measureTool;
}

-(void)addGlobalLock
{
    measureLock = [Lock shareInstance];
    
}



-(NSMutableArray*)RegexDeviceDigitalValue:(NSString*)strResult andRegex:(NSString*)strRegex andTerminalType:(enum TerminalType)terminalType{
    
    NSMutableArray* arrayValue = [[NSMutableArray alloc] init];
    
    switch (terminalType) {
            
        case Terminal_adb_Read_PMIC0_Voltage_BUCK0_PP1V8:
        case Terminal_adb_Read_PMIC0_Voltage_BUCK1_PP_GPU_DVFS:
        case Terminal_adb_Read_PMIC0_BUCK2_PP_CPU_DVFS:
        case Terminal_adb_Read_PMIC0_Voltage_BUCK3_PP0V8_CORE:
        case Terminal_adb_Read_PMIC1_Voltage_BUCK0_PP3V3_WLBT:
        case Terminal_adb_Read_PMIC1_Voltage_BUCK1_PP1V15_WLBT:
        case Terminal_adb_Read_PMIC1_Voltage_BUCK2_PP3V3_WLBT:
        case Terminal_adb_Read_PMIC1_Voltage_BUCK3_PP1V1_SOC_DDR:
        {
            
            int hexString = [self HexStrToInt:[strResult stringByReplacingOccurrencesOfString:@"\n" withString:@""]];
            
            [arrayValue addObject:[NSString stringWithFormat:@"%d",hexString]];
            
            if (arrayValue.count > 0) {
                break;
            }
        }
            break;
            
        case Terminal_adb_print_s_biuld_file:
        case Terminal_adb_print_sysconfig_swdl_txt:
            
        case Terminal_adb_Read_SOC_Temp_Sensor:
        case Terminal_adb_Read_Keystone_Temp_Sensor:
        
        case Terminal_adb_Start_logging:
        case Terminal_adb_Verify_data_qt_folder_is_created:
        case Terminal_adb_Check_NAND_fw_Checksum:
        case Terminal_adb_Check_NAND_SerialNumber:
        case Terminal_adb_Check_NAND_HW_MAJOR_REV:
        case Terminal_adb_Check_NAND_Part_Number:
        case Terminal_adb_Check_NAND_Manufacturer_ID:
            
        case Terminal_adb_Check_PMIC0_HW_Part_Rev:
        case Terminal_adb_Check_PMIC1_HW_Part_Rev:
        case Terminal_adb_Check_Bleach_FW_Major_Rev:
        case Terminal_adb_Characterize_Colorbars_For_RGB:    
        case Terminal_adb_Check_Bleach_Device_ID:
        case Terminal_adb_Read_Nand_Top_Temp_Sensor:
        case Terminal_adb_Read_Nand_Bottom_Temp_Sensor:
        case Terminal_adb_Check_Keystone_fw_minor_rev:
        case Terminal_adb_Check_Keystone_fw_checksum:
        case Terminal_adb_Check_Keystone_fw_major_rev:
        case Terminal_adb_Check_Keystone_Checksum:
        case Terminal_adb_print_test_planversion:
        
        {
            arrayValue = [self parseTxt:strResult withPattern:strRegex];
            
            if (arrayValue.count > 0 )
            {
                break;
            }
            
            
        }
            
            break;
        default:
            break;
    }
    
    return arrayValue;
}


-(BOOL)RegexDeviceNoDigitalValue:(NSString*)strResult andRegex:(NSString*)strRegex andTerminalType:(enum TerminalType)terminalType
{
    
    BOOL flagResult = NO;
    
    switch (terminalType) {
        
        case Terminal_adb_Run_DRAM_Stress_Test_memtester:
        {
            
            if (![[strResult uppercaseString] containsString:strResult] )
            {
                flagResult = YES;
            }
        }
            break;

            
            
        case Terminal_adb_Characterize_Colorbars_For_720p60_8bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_1080p60_8bpc_RGB:
        case Terminal_adb_Characterize_Colorbars_For_1080p60_8bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k24_8bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k30_8bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k60_8bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k60_8bpc_YCbCr_1:
        case Terminal_adb_Characterize_Colorbars_For_4k60_12bpc_YCbCr_1:
        case Terminal_adb_Characterize_Colorbars_For_4k60_12bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k60_8bpc_RGB:
        case Terminal_adb_Characterize_Colorbars_For_480p60_12bpc_YCbCr :
        case Terminal_adb_Characterize_Colorbars_For_720p60_12bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_1080p60_12bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k24_12bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k30_12bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_720p60_8bpc_RGB:
        case Terminal_adb_Characterize_Colorbars_For_480p60_8bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_480p60_8bpc_RGB:
        case Terminal_adb_Characterize_Colorbars_For_RGB:
            
        case Terminal_adb_Enable_Colorbar_Output:
        {
            
            if (![strResult containsString:@"Failed"] )
            {
                flagResult = YES;
            }
            
        }
            break;
            
            
            
#pragma mark strResult = '0\n'
        case Terminal_adb_Reboot_device_into_factory_mode_always:
        
        case Terminal_adb_Dump_SerialNumber:
        case Terminal_adb_Stop_logging:
        case Terminal_adb_Write_serial_number_to_both_files:
        case Terminal_adb_Write_to_soc_PASS:
        case Terminal_adb_Write_QT_Station_Finish_Message_to_file:
        case Terminal_adb_Write_Quick_Tests_Message_to_file:
        case Terminal_adb_Write_HDMI_Functional_Tests_Message_to_file:
        case Terminal_adb_Check_Board_ID_BIT3:
        case Terminal_adb_Check_Board_ID_BIT2:
        case Terminal_adb_Check_Board_ID_BIT1:
        case Terminal_adb_Check_Board_ID_BIT0:
            
        case Terminal_adb_Check_Board_Rev_bit0:
        case Terminal_adb_Check_Board_Rev_bit1:
        case Terminal_adb_Check_Board_Rev_bit2:
        case Terminal_adb_Check_Board_Rev_bit3://有待进一步解决
            
        case Terminal_adb_Write_timestamp_to_qtresults:
        case Terminal_adb_Delete_timestamp_log:
        case Terminal_adb_Write_Initial_Os_Setup:
        case Terminal_adb_write_component_check_message_to_file:
        case Terminal_adb_Create_andor_Clear_QT_File:
        case Terminal_adb_write_station_check_message:
        case Terminal_adb_write_test_planversion_to_both_file:
        case Terminal_adb_wait_device:
        case Terminal_adb_write_timestamp_to_both_file:
        case Terminal_adb_chmod_777_i2cdetect:
        case Terminal_adb_Change_permission_for_i2c:
        {
            if ([strResult isEqualToString:@"0\n"] )
            {
                flagResult = YES;
            }
        }
            break;
        
            
            
        case Terminal_adb_Dump_results_of_SOC_station:
        case Terminal_adb_Read_SOC_Temp_Sensor:
        case Terminal_adb_Check_Keystone_Manufacture_ID:
        case Terminal_adb_Check_Keystone_fw_Device_ID:
        case Terminal_adb_Check_Keystone_HW_Part_Number:
            
        case  Terminal_adb_Check_Bleach_Manufacture_ID:
        
        case  Terminal_adb_Check_Bleach_HW_Part_Number:
        
        case  Terminal_adb_Check_DRAM_Manufacturer_ID:
        case  Terminal_adb_Check_DRAM_HW_Major_Rev:
        case  Terminal_adb_Check_DRAM_HW_Minor_Rev:
        case  Terminal_adb_Check_DRAM_Size://等待新需求
        
        
        case Terminal_adb_Dump_Results_Of_FCT_Station:
        case Terminal_adb_Dump_Results_Of_DFU_Station:
        case Terminal_adb_Dump_Results_Of_ICT_Station:
        
        case Terminal_adb_Write_SerialNumber_To_Both_Files:
        //case Terminal_adb_Check_Board_Rev_bit3:
        case Terminal_adb_Check_Board_ID:
        {
            if ([strResult isEqualToString:@"1\n"] )
            {
                //flagResult = YES;
            }
            
        }
            break;
            
        case Terminal_adb_Check_if_DUT_has_entered_QT_station_previously:
        case Terminal_adb_Check_DUT_entered_SOC_station_previously:
        case Terminal_adb_Dump_results_of_SWDL_station:
        case Terminal_adb_Unlock_sysconfig_partition:
        case Terminal_adb_shell_partition_lock:
        case Terminal_adb_root:
        {
            NSArray* array = [strRegex componentsSeparatedByString:@","];
            
            for (id obj in array) {
                
                if ([strResult containsString:obj]) {
                    flagResult = YES;
                    break;
                }
                
            }
        }
            break;
            
#pragma mark regex = result
        case Terminal_adb_Load_BurninTester_onto_DUT:
        case Terminal_adb_Set_clock_rate_for_480p60:
        case Terminal_adb_Read_and_write_over_SDIO:
        case Terminal_adb_write_serialnumber:
        case Terminal_adb_Lock_sysconfig_partition:
        case Terminal_adb_Print_QT_Station_Finish_Message:
        case Terminal_adb_Retrive_timestamp_log:
        
        case Terminal_adb_Print_Quick_Tests_Message:
        case Terminal_adb_Create_QT_folder_in_data_folder:
        case Terminal_adb_Check_NAND_fw_version:
        case Terminal_adb_Check_NAND_Device_Version:
        case Terminal_adb_Check_NAND_MFG_Date_Time:///等待新需求
            
        case Terminal_adb_Retrive_data_qt:
        case Terminal_adb_Retrive_qtresults_log:
         
        case Terminal_adb_Print_HDMI_Functional_Tests_Message:
        case Terminal_adb_Dump_Voltage_Vs_Frequency_Table_CPU:
        case Terminal_adb_Dump_Voltage_Vs_Frequency_Table_GPU:
        case Terminal_adb_Print_Initial_Os_Setup_Message:
            
        case Terminal_adb_Check_Keystone_Info:
        case Terminal_adb_Check_NAND_SerialNumber:
        case Terminal_adb_Check_NAND_HW_MAJOR_REV:
        case Terminal_adb_Check_NAND_Part_Number:
        case Terminal_adb_Check_NAND_Manufacturer_ID:
        case Terminal_adb_print_station_check_message:
        case Terminal_adb_print_component_check_message:
        case Terminal_adb_create_QT_Results_file:
        case Terminal_adb_Create_QT_folder_in_sysconfig_folder:
        case Terminal_adb_remount:
        case Terminal_adb_create_SOC_folder:
        case Terminal_adb_create_timestamped_log_file:
        case Terminal_adb_Reset_clock_rate_to_original:
        {
            if ([strResult containsString:strRegex])
            {
                flagResult = YES;
            }
        }
            break;
        
            
        default:
            break;
    }
    
    return flagResult;
}


-(NSArray*)parseDmmTxt:(NSString*)parseString withPattern:(NSString*)pattern{
    
    NSArray* regexArr;
    NSString* regexString;
    if ([parseString containsString:@"\n"])
    {
        
        regexString = [parseString stringByReplacingOccurrencesOfString:@"\n\n" withString:@""];
        regexString = [regexString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        regexString = [regexString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        
        NSArray* regexArr = [self parseTxt:regexString withPattern:pattern];
        NSLog(@"[self parseTxt:regexString]: %@", regexArr);
    }
    
    return regexArr;
}


-(NSMutableArray*)parseTxt:(NSString*)content withPattern:(NSString*)pattern{
    
    NSMutableArray* stringArray = [[NSMutableArray alloc] init];
    
//    @synchronized (self)
//    {
        NSRegularExpression *regex = [[NSRegularExpression alloc] initWithPattern:pattern options:NSRegularExpressionCaseInsensitive error:nil];
        
        NSArray *results = [regex matchesInString:content options:0 range:NSMakeRange(0, content.length)];
    
        if (results.count != 0) {
            for (NSTextCheckingResult* result in results) {
                for (int i=1; i<[result numberOfRanges]; i++)
                {
                    [stringArray addObject:[content substringWithRange:[result rangeAtIndex:i]]];
                }
            }
        }
 //   }
    
    return stringArray;
}

-(int)HexStrToInt:(NSString*)hexStr
{
    int result = 0;
    NSString* str = [[hexStr uppercaseString] stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    for (int i = 0; i < [str length]; i++)
    {
        int charValue = [str characterAtIndex:i];
        
        if ((charValue >= '0') && (charValue <= '9'))
        {
            result += (charValue - '0') * pow(16, ([str length] - 1 -i));
        }
        else if ((charValue >= 'A') && (charValue <= 'F'))
        {
            result += (charValue - 'A' + 10) * pow(16, ([str length] - 1 -i));
        }
    }
    
    return result;
}



@end
