//
//  TestAction.m
//  WorkingFrameWork
//
//  Created by mac on 2017/10/27.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
//

#import "TestAction.h"
#import "PythonTool.h"
#import "TerminalTool.h"
#import "MeasurementValueHandle.h"


#define SNChangeNotice  @"SNChangeNotice"
NSString  *param_path=@"Param";

@interface TestAction ()
{
    
    //************ testItems ************
    NSString* num;
    
    NSInteger testNum;
    
    NSString        *unitReadString;
    NSMutableArray  *txtLogMutableArr;
    NSString        *agilentReadString;
    NSDictionary    *dic;
    NSString        *SonTestName;
    
    NSMutableArray  *testResultArr;                           // 返回的结果数组
    NSMutableArray  *testItemTitleArr;                        //每个测试标题都加入数组中,生成数据文件要用到
    NSMutableArray  *testItemValueArr;                        //每个测试结果都加入数组中,生成数据文件要用到
    NSMutableArray  *testItemMinLimitArr;                     //每个测试项最小值数组
    NSMutableArray  *testItesmMaxLimitArr;                    //每个测试项最大值数组
    NSMutableArray  *testItemUnitArr;
    NSMutableArray  *TestItemArr;                             //软件测试总结果
    NSMutableArray  *testFailArr;
    NSMutableString *testAppendString;                        //软件测试所有值
    NSMutableString *testResultAppendStr;                     //存取测试对象的结果
    NSMutableString  *TestItemResult;                          //存取测试对象的结果

    
    NSThread        * thread;                                   //开启的线程
//    AgilentE4980A   * agilentE4980A;                            //LCR表
//    AgilentB2987A   * agilentB2987A;                            //静电计
//    SerialPort      * serialport;                               //串口通讯类
    UpdateItem      * updateItem;                               //
    Plist           * plist;                                    //plist文件处理类
//    enum AgilentB2987ACommunicateType  AgilentB2987A_USB_Type;
    //Param           * param;                                    // param参数类
    PythonTool      *pythonTool;
    TerminalTool* terminalTool;
    MeasurementValueHandle* measureTool;
    
    
    int        delayTime;
    int        index;                                         // 测试流程下标
    int        item_index;                                    // 测试项下标
    int        row_index;                                     // table 每一行下标
    Item     * testItem;                                      //测试项
    Item     * showItem;                                      //显示的测试项
    
    
    NSString * fixtureBackString;                             //治具返回来的数据
    NSString * testvalue;                                   //测试项的字符串
   
    
    AppDelegate  * app;                                       //存储测试的次数
    Folder       * fold;                                      //文件夹的类
    FileCSV      * csv_file;                                  //csv文件的类
    FileCSV      * total_file;                                //写csv总文件
    FileTXT      * txt_file;                                  //txt文件
    
    //************* timer *************
    NSString            * start_time;                         //启动测试的时间
    NSString            * end_time;                           //结束测试的时间
    GetTimeDay          * timeDay;                            //创建日期类
    
    //csv数据相关处理
    NSMutableArray * ItemArr;                                 //存测试对象的数组
    NSMutableString     * txtContentString;                   //打印txt文件中的log
    NSMutableString     * listFailItemString;                 //测试失败的项目
    NSMutableString     * ErrorMessageString;                 //失败测试项的原因
    
    //检测PDCA和SFC的BOOL//测试结果PASS、FAIL
    BOOL       PF;
    
    //存储生成文件的具体地址
    NSString   * eachCsvDir;
    NSString   * totalPath;
    NSString   * singleFloder;
    int          fix_type;
    
    //所有的测试项均存入字典中
    NSMutableDictionary  * store_Dic;                          //所有的测试项存入字典中

    BOOL    nulltest;                                          //产品进行空测试
    float   nullTimes;                                         //空测试的次数
    double  B_E_Sum;                                           //产品测试nullTimes的总和
    double  B2_E2_Sum;                                         //产品测试B2_E2
    double  B4_E4_Sum;                                         //产品测试B4_E4
    double  ABC_DEF_Sum;                                       //产品测试ABC_DEF
    double  Cap_Sum;                                           //治具的容抗值
    
    //处理SFC相关的类
    BYDSFCManager          * sfcManager;                         //处理sfc的类
    TestStep               * teststep;                           //处理上传的方法
    NSString               * FixtureID;                          //治具的ID
    
    BOOL                   is_LRC_Collect;                       //LCR表是否连接
    BOOL                   is_JDY_Collect;                       //静电仪是否连接
    NSMutableString               * dcrAppendString;             //DCR拼接的数据
    BOOL                   addDcr;                               //40组DCR数据
    NSString               * companyName;                        //公司名称
    
    BOOL                    Instrument;                          //仪器是否连接OK
    BOOL                    isDebug;                             //debug模式
    float                   totalTime;
    NSMutableArray*         itemTimeArr;
    NSString*               timeStamp;
    NSString*               deviceNumber;
    NSString*               usb;
}
@end

@implementation TestAction

/**相关的说明
  1.Fixture ID 返回的值    Fixture ID?\r\nEW011X*_*\r\n       其中x代表治具中A,B,C,D

 
 
*/

-(id)initWithTable:(Table *)tab withFixParam:(Param *)param withType:(int)type_num
{
    
    isDebug      = param.isDebug;

    if (self == [super init]) {
        
        deviceNumber = [[NSString alloc] init];
        
        
        terminalTool = [TerminalTool shareInstance];
        [terminalTool addGlobalLock];
        
        singleFloder = param.SingleFolder;
        
        NSDictionary  * fix;
        if (type_num == 1) fix = param.Fix1;
        if (type_num == 2) fix = param.Fix2;
        if (type_num == 3) fix = param.Fix3;
        if (type_num == 4) fix = param.Fix4;
        
        
        //初始化各种数据及其设备消息
        self.fixture_uart_port_name = [fix objectForKey:@"fixture_uart_port_name"];
        self.fixture_uart_baud      = [fix objectForKey:@"fixture_uart_baud"];
        self.product_uart_port_name = [fix objectForKey:@"product_uart_port_name"];
        self.device_uart_port_name  = [fix objectForKey:@""];
        usb                = [fix objectForKey:@"usb_port_name"];
        
        
        
        
        
        
                
        companyName = @"BYD";
        
        //初始化各种的整型变量
        self.tab =tab;
        fix_type = type_num;
        index = 0;
        item_index   = 0;
        row_index    = 0;
        nullTimes    = 0;
        B_E_Sum      = 0;
        B2_E2_Sum    = 0;
        B4_E4_Sum    = 0;
        ABC_DEF_Sum  = 0;
        Cap_Sum      = 0;
        
        PF =  YES;
        addDcr  = NO;
        Instrument = NO;
        
        //初始化各类数组和可变字符串
        ItemArr             = [[NSMutableArray alloc] initWithCapacity:10];
        TestItemArr         = [[NSMutableArray  alloc] initWithCapacity:10];
        txtContentString    =[[NSMutableString alloc] initWithCapacity:10];
        listFailItemString  =[[NSMutableString alloc] initWithCapacity:10];
        ErrorMessageString  =[[NSMutableString alloc] initWithCapacity:10];
        dcrAppendString     = [[NSMutableString alloc] initWithCapacity:10];
        store_Dic = [[NSMutableDictionary alloc] initWithCapacity:10];
        testAppendString    = [[NSMutableString alloc] initWithCapacity:10];
        testResultAppendStr = [[NSMutableString alloc] initWithCapacity:10];
        testFailArr         = [[NSMutableArray alloc] initWithCapacity:10];
        
        timeStamp           = [[NSString alloc] init];
        
        //初始化各种串口
        plist = [Plist shareInstance];
        timeDay     =  [GetTimeDay shareInstance];
        sfcManager  =  [BYDSFCManager Instance];
//        serialport  =  [[SerialPort alloc]init];
        updateItem  =  [[UpdateItem alloc] init];
//        agilentE4980A = [[AgilentE4980A alloc]init];
//        agilentB2987A = [[AgilentB2987A alloc]init];
//        [serialport setTimeout:1 WriteTimeout:1];
        
        
        
        
        //赋值
        updateItem.fix_ABC_DEF_Res  = [fix objectForKey:@"fix_ABC_DEF_Res"];
        updateItem.fix_B2_E2_Res    = [fix objectForKey:@"fix_B2_E2_Res"];
        updateItem.fix_B4_E4_Res    = [fix objectForKey:@"fix_B4_E4_Res"];
        updateItem.fix_B_E_Res      = [fix objectForKey:@"fix_B_E_Res"];
        updateItem.fix_Cap          = [fix objectForKey:@"fix_Cap"];
        
        
        //初始化文件处理类
        csv_file  = [[FileCSV alloc] init];
        [csv_file addGlobalLock];
        
        txt_file  = [[FileTXT  alloc]init];
        
        total_file= [[FileCSV alloc] init];
        [total_file addGlobalLock];
        
        
        fold     =  [[Folder  alloc] init];
        teststep = [TestStep Instance];
        [teststep addGlobalLock];
        
        pythonTool = [PythonTool shareInstance];
        [pythonTool addGlobalLock];
        
        
        
        measureTool = [MeasurementValueHandle shareInstance];
        
        //=======================定义通知
        //监听启动
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(NSThreadStart_Notification:) name:@"NSThreadStart_Notification" object:nil];
        //监听测试结束通知
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(NSThreadEnd_Notification:) name:@"NSThreadEnd_Notification" object:nil];
        //监听空测试
        [[NSNotificationCenter defaultCenter]  addObserver:self selector:@selector(selectNullTestNoti:) name:kTestModeNotice object:nil];
        
        //Test数据选择
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(selectTestDataNoti:) name:kTest40DataNotice object:nil];
        //test num choose
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(select_testnum:) name:kTestNum object:nil];
        
        //获取全局变量
        thread = [[NSThread alloc]initWithTarget:self selector:@selector(TestAction) object:nil];
        [thread start];
    }
    
    return  self;
}





-(void)TestAction
{
    while ([[NSThread currentThread] isCancelled]==NO) //线程未结束一直处于循环状态
    {
        
#pragma mark--------连接治具
        if (index == 0) {
            
            [NSThread sleepForTimeInterval:0.5];
            NSLog(@"isTest: %d", _isTest);
            if (isDebug) {
                 NSLog(@"%@==index= 0,连接治具%@,debug模式中",[NSThread currentThread],self.fixture_uart_port_name);
                [txtContentString appendFormat:@"%@:index=0,进入debug模式\n",[timeDay getFileTime]];
                [self UpdateTextView:@"index=0," andClear:YES andTextView:self.Log_View];
                
                
                index =1;
            }
            else
            {
                
//                BOOL isCollect = [serialport Open:self.fixture_uart_port_name];
//                if (isCollect) {
//                     //发送指令获取ID的值
//                    [NSThread sleepForTimeInterval:0.2];
//                    [serialport WriteLine:@"Fixture ID?"];
//                    [NSThread sleepForTimeInterval:0.5];
//                     FixtureID = [serialport ReadExisting];
//                    if ([FixtureID containsString:@"\r\n"]&&[FixtureID containsString:@"\r\n"]) {
//                        
//                        FixtureID = [[FixtureID componentsSeparatedByString:@"\r\n"] objectAtIndex:1];
//                        FixtureID = [FixtureID stringByReplacingOccurrencesOfString:@"*_*" withString:@""];
//                    }
//                    
//                     NSLog(@"index= 0,连接治具%@",self.fixture_uart_port_name);
//                    [txtContentString appendFormat:@"%@:index=0,治具已经连接\n",[timeDay getFileTime]];
//                    [self UpdateTextView:@"index=0,治具已经连接" andClear:NO andTextView:self.Log_View];
//                    
//                    index =1;
//                }
            }
        }
        
#pragma mark--------进入OS模式
        if (index == 1) {
            
            [NSThread sleepForTimeInterval:0.5];
            if (isDebug) {
                
                NSLog(@"index= 1,仿仪器出口已连接%@,debug模式中",self.instrument_name);
                [txtContentString appendFormat:@"%@:index=1,debug模式中\n",[timeDay getFileTime]];
               
                [self UpdateTextView:@"index=1,进入debug模式" andClear:NO andTextView:self.Log_View];
                
                
//                NSString* retString = [terminalTool ReadTerminal:adb_wait_for_device andTerminalType:(enum TerminalType)Terminal_adb_wait_device andRegexStr:@"" deviceNumber:self.device_number andDelayTime:1000];
//                if (![retString containsString:@"unknown"]&&[retString length] == 0) {
//                    
//                    NSString* retString = [terminalTool ReadTerminal:adb_wait_for_device andTerminalType:(enum TerminalType)Terminal_adb_root andRegexStr:@"" deviceNumber:self.device_number andDelayTime:1000];
//                    
//                    if ([retString containsString:@"restarting adbd as root"]) {
//                        
//                        NSString* retString = [terminalTool ReadTerminal:adb_wait_for_device andTerminalType:(enum TerminalType)Terminal_adb_root andRegexStr:@"" deviceNumber:self.device_number andDelayTime:1000];
//                        if ([retString containsString:@"remount succeeded"]) {
//                            
//                            [txtContentString appendFormat:@"%@:index=1,debug模式中\n",[timeDay getFileTime]];
//                            
//                            [self UpdateTextView:@"index=1,进入os mode" andClear:NO andTextView:self.Log_View];
//                            
//                        }
//                        
//                    }
//                    
//                }
                
                
                index =1000;
            }
            else
            {
               
                
                
            }
        }
#pragma mark--------获取输入框中的SN
        if (index == 2)
        {
            //通过通知抛过来SN，以及气缸的状态
            [NSThread sleepForTimeInterval:0.5];
             NSLog(@"index =2,等待SN");
            
            if (_dut_sn.length == 17)
            {
                
                HiperTimer* timer = [[HiperTimer alloc] init];
                [timer Start];
                
                while ([timer durationMillisecond] < 60000)
                {
                    
                    NSString* returnString = [terminalTool ReadTerminal:@"/usr/local/bin/platform-tools/adb devices -l" andTerminalType:Terminal_adb_Check_Bleach_Device_ID andRegexStr:@"" deviceNumber:@"" andDelayTime:1000];
                    
                    NSArray* deviceArr = [returnString componentsSeparatedByString:@"\n"];
                    
                    if (deviceArr.count == 3 +testNum)
                    {
                        for (int i = 1; i < deviceArr.count -2; i++) {
                            
                            if ([deviceArr[i] containsString:usb])
                            {
                                self.device_number  = [deviceArr[i] substringToIndex:16];
                            }
                        }
                        break;
                    }
                    
                    [NSThread sleepForTimeInterval:0.5];
                }
                
                
                
                testAppendString       = [NSMutableString string];
                testResultAppendStr    = [NSMutableString string];
                testFailArr           = [NSMutableArray array];
                totalTime            = 0;
                itemTimeArr         = [NSMutableArray array];
                
                
                NSLog(@"index= 2,检测SN,并打印SN的值%@",_dut_sn);
                index =3;
                
                //启动测试的时间,csv里面用
                start_time = [[GetTimeDay shareInstance] getFileTime];
                [txtContentString appendFormat:@"%@:index=2,SN已经检验成功\n",[timeDay getFileTime]];
                [self UpdateTextView:@"index=2,SN已经检验成功" andClear:NO andTextView:self.Log_View];
                
            }
        }
        
#pragma mark--------检测SN是否上传
        if (index == 3)
        {
            [NSThread sleepForTimeInterval:0.2];
            if (isDebug)
            {
                NSLog(@"index = 3,检测SN是否上传,debug");
                [txtContentString appendFormat:@"%@:index=3,debug模式\n",[timeDay getFileTime]];
                [self UpdateTextView:@"index=3,进入debug模式,检测SN上传" andClear:NO andTextView:self.Log_View];
                
                NSString * path = [[NSUserDefaults standardUserDefaults] objectForKey:kTotalFoldPath];
                totalPath  = [NSString stringWithFormat:@"%@",path];
                NSLog(@"打印总文件的位置%d=========%@",fix_type,totalPath);
                
                [fold Folder_Creat:totalPath];
                
                @synchronized (self) {
                    
                    eachCsvDir = [NSString stringWithFormat:@"%@/%@_%@",totalPath,self.dut_sn,[timeDay getCurrentMinuteAndSecond]];
                    
                    
                    [fold Folder_Creat:eachCsvDir];
                    
                }

                
                
                index = 4;
            }
            else
            {
                index = 4;//进入正常测试中
            }
        }
        
#pragma mark--------进入正常测试中
        if (index == 4)
        {
            
            [NSThread sleepForTimeInterval:0.3];
            
            NSLog(@"index= 4,进入测试%@",self.fixture_uart_port_name);
            [txtContentString appendFormat:@"%@:index=4,正式进入测试\n",[timeDay getFileTime]];
            NSLog(@"打印tab中数组中的值%lu",(unsigned long)[self.tab.testArray count]);
            
            testItem = [[Item alloc] initWithItem:self.tab.testArray[item_index]];
            
            BOOL isPass =[self TestItem:testItem];
            
            [TestItemArr addObject:testItem];
            
            if (isPass)
            {//测试成功
                
                [self UpdateTextView:[NSString stringWithFormat:@"index=4:%@ 测试OK",testItem.testName] andClear:NO andTextView:self.Log_View];
                
            }
            else//测试结果失败
            {
                 [self UpdateTextView:[NSString stringWithFormat:@"index=4:%@ 测试NG",testItem.testName] andClear:NO andTextView:self.Log_View];
                 [self UpdateTextView:[NSString stringWithFormat:@"FailItem:%@\n",testItem.testName] andClear:NO andTextView:self.Fail_View];
                            }
    
            //刷新界面
            [txtContentString appendFormat:@"%@:index=4,准备刷新界面\n",[timeDay getFileTime]];
            [self.tab flushTableRow:testItem RowIndex:row_index with:fix_type withItemName:testItem.testName];
            [txtContentString appendFormat:@"%@:index=4,刷新界面成功\n",[timeDay getFileTime]];

            
            item_index++;
            row_index++;
            //走完测试流程,进入下一步
            if (item_index == [self.tab.testArray count])
            {
                //给设备复位
                [txtContentString appendFormat:@"%@:index=4,测试项测试结束\n",[timeDay getFileTime]];
                [self UpdateTextView:@"index=4,测试项测试结束" andClear:NO andTextView:self.Log_View];
                index = 5;
                
            }
        }
        
#pragma mark--------生成本地数据
        if (index == 5)
        {
           //测试结束的时间,csv里面用
            end_time = [[GetTimeDay shareInstance] getFileTime];
            [NSThread sleepForTimeInterval:0.2];
//            NSString * path = [[NSUserDefaults standardUserDefaults] objectForKey:kTotalFoldPath];
//            totalPath  = [NSString stringWithFormat:@"%@",path];
//            NSLog(@"打印总文件的位置%d=========%@",fix_type,totalPath);
//            
//            [fold Folder_Creat:totalPath];
            
             NSString   * configCSV = [self backTotalFilePathwithFloder:totalPath];
            
            if (total_file!=nil) {
                
                BOOL need_title = [total_file CSV_Open:configCSV];//need_title == no,file exit
                [txtContentString appendFormat:@"%@:index=5,打开总csv文件->%@\n",[timeDay getFileTime],configCSV];
                [self SaveCSV:total_file withBool:need_title];
                [txtContentString appendFormat:@"%@:index=5,添加数据到totalCSV文件->%@\n",[timeDay getFileTime],configCSV];
                [self UpdateTextView:@"index=5,往总文件中添加数据" andClear:NO andTextView:self.Log_View];
            }
            
            
            //2.============================生成总文件夹下面的单个文件
            @synchronized (self)
            {
                //生成单个产品的value值csv文件
                [NSThread sleepForTimeInterval:0.2];
//                eachCsvDir = [NSString stringWithFormat:@"%@/%@_%@",totalPath,self.dut_sn,[timeDay getCurrentMinuteAndSecond]];
//                [fold Folder_Creat:eachCsvDir];
                 NSString * eachCsvFile = [NSString stringWithFormat:@"%@/%@_%@_%u.csv",eachCsvDir,self.dut_sn,end_time,arc4random()%100];
                if (csv_file!=nil)
                {
                    BOOL need_title = [csv_file CSV_Open:eachCsvFile];
                    [self SaveCSV:csv_file withBool:need_title];
                    [txtContentString appendFormat:@"%@:index=5,生成单个csv文件%@\n",[timeDay getFileTime],eachCsvFile];
                    [self UpdateTextView:@"index=5,生成单个CSV文件" andClear:NO andTextView:self.Log_View];
                }
            }
            
            //生成log文件
            NSString * logFile = [NSString stringWithFormat:@"%@/log.txt",eachCsvDir];
            if (txt_file!=nil)
            {
                [txt_file TXT_Open:logFile];
                [txt_file TXT_Write:txtContentString];
            }
            
            @synchronized (self) {
                //生成每一项对应Item的时间的csv文件
                NSString* eachItemTimeCsv = [NSString stringWithFormat:@"%@/%@_itemTime.csv", eachCsvDir, self.dut_sn];
                NSMutableString* itemTime = [NSMutableString string];
                NSString* itemTimeCsvTitle = [NSString stringWithFormat:@"SerialNumber:,%@\nItem,ItemName,CosTime\n", self.dut_sn];
                [itemTime appendString:itemTimeCsvTitle];
                
                for(id obj in itemTimeArr){
                    
                    [itemTime appendString:[NSString stringWithFormat:@"%@\n", obj]];
                }
                [itemTime appendString:[NSString stringWithFormat:@"Total Time:,%f",totalTime]];
                
                [itemTime writeToFile:eachItemTimeCsv atomically:YES encoding:NSUTF8StringEncoding error:nil];
            }
            
                        
           //===============================
            [NSThread sleepForTimeInterval:0.2];
            NSLog(@"index= 5,本地数据生成完成%@",self.fixture_uart_port_name);
            [self UpdateTextView:@"index=5,本地数据生成完成" andClear:NO andTextView:self.Log_View];
            index = 6;
        }
        
#pragma mark--------上传sfc
        if (index == 6)
        {            
            //上传PDCA和SFC
            
            [NSThread sleepForTimeInterval:0.3];
            [txtContentString appendFormat:@"%@:index=7,准备上传sfc\n",[timeDay getFileTime]];
            [self UpdateTextView:@"index=7,准备上传sfc" andClear:NO andTextView:self.Log_View];
        
            index = 7;
            

        }

        
        
#pragma mark--------上传pdca
        //将结果显示在界面上
        if (index == 7)
        {
            
            [NSThread sleepForTimeInterval:0.3];
            [txtContentString appendFormat:@"%@:index=7,准备上传PDCA\n",[timeDay getFileTime]];
            [self UpdateTextView:@"index=7,准备上传PDCA" andClear:NO andTextView:self.Log_View];
            
            //清空字符串
            NSMutableDictionary  * resultdic = [[NSMutableDictionary alloc] initWithCapacity:10];
            txtContentString =[NSMutableString stringWithString:@""];
            listFailItemString = [NSMutableString stringWithString:@""];
            ErrorMessageString = [NSMutableString stringWithString:@""];
            dcrAppendString    = [NSMutableString stringWithString:@""];
            [ItemArr removeAllObjects];
        
            //设置传送的数据
            [resultdic setObject:_dut_sn forKey:@"dut_sn"];
            [resultdic setObject:eachCsvDir forKey:@"eachCsvDir"];
            [resultdic setObject:totalPath forKey:@"totalPath"];
            [resultdic setObject:testAppendString forKey:@"value"];
            [resultdic setObject:testResultAppendStr forKey:@"result"];
            [resultdic setObject:testFailArr forKey:@"testFailArr"];
            [resultdic setObject:start_time forKey:@"start_time"];
            [resultdic setObject:end_time forKey:@"end_time"];
            
            
            dispatch_sync(dispatch_get_main_queue(), ^{
                
                [self.resultTF setStringValue:PF?@"PASS":@"FAIL"];
                if (PF)
                {
                    
                    [self.resultTF setTextColor:[NSColor greenColor]];
                }
                else
                {
                    [self.resultTF setTextColor:[NSColor redColor]];
                    
                }
                
                
               if (PF)
               {
                   
                   [[NSNotificationCenter defaultCenter] postNotificationName:SNChangeNotice object:[NSString stringWithFormat:@"%dP",fix_type] userInfo:resultdic];
                }
                else
                {
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:SNChangeNotice object:[NSString stringWithFormat:@"%dF",fix_type] userInfo:resultdic];
                }
            });
            
            index = 8;
        }
        
        //刷新结果，重新等待SN
        if (index == 8)
        {
            
            [NSThread sleepForTimeInterval:0.1];
            
            //发送复位的指令
//            [serialport WriteLine:@"reset"];
//            [NSThread sleepForTimeInterval:0.5];
//            [serialport ReadExisting];

            
            //仪器仪表释放掉
//            [agilentB2987A CloseDevice];
//            [agilentE4980A CloseDevice];
            is_LRC_Collect = NO;
            is_JDY_Collect = NO;
            Instrument     = NO;
            
            //清空SN
             _dut_sn=@"";
            if (nulltest) {
                nullTimes++;
            }
           
            index = 1000;
            item_index =0;
            row_index = 0;
            PF = YES;
            [TestItemArr removeAllObjects];
            
        }
     
#pragma mark===================发送消息，防止休眠
        if (index == 1000)
        {
            //[NSTimer scheduledTimerWithTimeInterval:500 target:self selector:@selector(timewake) userInfo:nil repeats:YES];
            [NSThread sleepForTimeInterval:0.01];
            if (!isDebug) {
                 index = 1;
            }
        }
    }
}



//================================================
//测试项指令解析
//================================================
-(BOOL)TestItem:(Item*)testitem
{
    BOOL ispass=NO;
    NSDictionary  * dict;
    NSString      * subTestDevice;
    NSString      * subTestCommand;
    NSString      * subFailTestCommmand;
    double          DelayTime;
    NSString      * startTime;
    NSString      * endTime;
    NSString      * subBackValueRegex;
    BOOL            isSubDigitalResult;
    
    
    startTime = [timeDay getCurrentSecond];

    [txtContentString appendFormat:@"%@:index=7,开始测试： %@\n",[timeDay getFileTime],startTime];
    
    //计算开始测试的时间点
    NSDateFormatter* df = [[NSDateFormatter alloc] init];
    df.dateFormat = @"yyyy-MM-dd HH:mm:ss.SSS";
    NSString* beforeTestTime = [[GetTimeDay shareInstance] getLogTime];
    
    
    for (int i=0; i<[testitem.testAllCommand count]; i++)
    {
        dict =[testitem.testAllCommand objectAtIndex:i];
        subTestDevice = dict[@"TestDevice"];
        subTestCommand=dict[@"TestCommand"];
        subFailTestCommmand = dict[@"TestFailCommand"];
        DelayTime = [dict[@"TestDelayTime"] floatValue]/1000.0;
        subBackValueRegex = dict[@"TestBackValueRegex"];
        isSubDigitalResult = [dict[@"TestResultIsDigital"] boolValue];
        NSString* retString = [[NSString alloc] init];
        
        NSLog(@"治具%@发送指令%@",subTestDevice,subTestCommand);
    
        [self UpdateTextView:[NSString stringWithFormat:@"subTestDevice%@====subTestCommand:%@",subTestDevice,subTestCommand] andClear:NO andTextView:self.Log_View];
        

        
        if ([subTestDevice isEqualToString:@"adb_wait-for-device"])
        {
            
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_wait_device andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_wait_device];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        //治具中收发指令
        if ([subTestDevice isEqualToString:@"adb_root"])
        {
            
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_root andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            int count = 0;
            
            
            //restarting adbd as root,adbd is already running as root
            if (![retString containsString:@"restarting adbd as root"]||![retString containsString:@"adbd is already running as root"]) {
                
                while (true) {
                    
                    retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_root andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
                    
                    if ([retString containsString:@"restarting adbd as root"]||[retString containsString:@"adbd is already running as root"]|| count == 2) {
                        break;
                    }
                    count++;
                    [NSThread sleepForTimeInterval:0.5];
                }
                
            }
            
            
            
            
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_root];
            
            num = [NSString stringWithFormat:@"%d", isOK];
            
        }
        
        if ([subTestDevice isEqualToString:@"slot number"])
        {
                        
            num = [NSString stringWithFormat:@"%d", fix_type];
            
        }

        
        if ([subTestDevice isEqualToString:@"adb_remount"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_remount andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            int count = 0;
            
            if ([[retString uppercaseString] containsString:@"FAILED"]) {
                
                while (true)
                {
                    
                    retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_remount andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
                    
                    if (![[retString uppercaseString] containsString:@"FAILED"]||count == 2) {
                        break;
                    }
                    count++;
                    [NSThread sleepForTimeInterval:0.5];
                }
            }
            
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_remount];
            
            num = [NSString stringWithFormat:@"%d", isOK];
            
        }
        if ([subTestDevice isEqualToString:@"Check Bleach Device ID"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];

            
            retString = [NSString stringWithFormat:@"%@", self.device_number];
            
            
            num = [NSString stringWithFormat:@"%@", retString];
            
        }
        
        
        if ([subTestDevice isEqualToString:@"Verify timestamp"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_verify_timestamp andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            timeStamp = [NSString stringWithFormat:@"%@", [retString stringByReplacingOccurrencesOfString:@"\n" withString:@""]];
            
            num = [NSString stringWithFormat:@"%@", retString];
            
        }
        
        //print s-biuld file
        if ([subTestDevice isEqualToString:@"print s-biuld file"])
        {
            
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];

            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_print_s_biuld_file andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_print_s_biuld_file];
            
            num = [NSString stringWithFormat:@"%@", retString];
            
//            if (array.count > 0) {
//                num = [NSString stringWithFormat:@"%@", @"error"];
//            }
//            else
//            {
//                num = @"error";
//            }
            
        }
        //case Terminal_adb_print_s_biuld_file:case Terminal_adb_print_sysconfig_swdl_txt:
        if ([subTestDevice isEqualToString:@"print swdl result"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];

            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_print_sysconfig_swdl_txt andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_print_sysconfig_swdl_txt];
            
            num = [NSString stringWithFormat:@"%@", [retString stringByReplacingOccurrencesOfString:@"\n" withString:@""]];
            
//            if (array.count > 0)
//            {
//                num = [NSString stringWithFormat:@"%@", @"error"];
//            }
//            else
//            {
//                num = @"error";
//            }
            
        }
        
        //write serialnumber
        if ([subTestDevice isEqualToString:@"write serialnumber"])
        {
            @synchronized (self) {
                
                subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
                subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
                
                
                subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"dut_sn" withString:_dut_sn];
                
                retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_write_serialnumber andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
                BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_write_serialnumber];
                
                num = [NSString stringWithFormat:@"%hhd", isOK];
            }
        }
        
        
        if ([subTestDevice isEqualToString:@"Create QT folder in data folder"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];

            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Create_QT_folder_in_data_folder andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Create_QT_folder_in_data_folder];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
            
        }
        
        //Verify /data/qt folder is created
        if ([subTestDevice isEqualToString:@"Verify /data/qt folder is created"])
        {
            
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];

            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Verify_data_qt_folder_is_created andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Verify_data_qt_folder_is_created];
            
            num = [array count] > 0 ? [NSString stringWithFormat:@"%@", array[0]]: @"error";
            
            
        }
        
        if ([subTestDevice isEqualToString:@"Create SOC folder"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];

            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_create_SOC_folder andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_create_SOC_folder];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
//        if ([subTestDevice isEqualToString:@"Touch timestamped log file"])
//        {
//            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
//            
//            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_create_timestamped_log_file andRegexStr:subBackValueRegex deviceNumber:deviceNumber andDelayTime:1000];
//            
//            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_create_timestamped_log_file];
//            
//            num = [NSString stringWithFormat:@"%hhd", isOK];
//        }
        
        if ([subTestDevice isEqualToString:@"Create timestamped log file"])
        {
            @synchronized (self) {
                
                subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
                subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
                retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_create_timestamped_log_file andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
                
                BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_create_timestamped_log_file];
                
                num = [NSString stringWithFormat:@"%hhd", isOK];
                
            }
            
            
        }
        
        if ([subTestDevice isEqualToString:@"Start logging"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Start_logging andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Start_logging];
            
            num = [array count]>0?[NSString stringWithFormat:@"%@", @"1"]: @"1";
            
        }
        //Unlock /sysconfig partition
        if ([subTestDevice isEqualToString:@"Unlock /sysconfig partition"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Unlock_sysconfig_partition andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Unlock_sysconfig_partition];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
            
        }
        //Set clock rate for 480p60
        if ([subTestDevice isEqualToString:@"Set clock rate for 480p60"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Set_clock_rate_for_480p60 andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Set_clock_rate_for_480p60];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
            
        }
        
        //Dump results of SWDL station
        if ([subTestDevice isEqualToString:@"Dump results of SWDL station"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Dump_results_of_SWDL_station andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Dump_results_of_SWDL_station];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        
        
        //Create QT folder in sysconfig folder
        if ([subTestDevice isEqualToString:@"Create QT folder in sysconfig folder"])
        {
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Create_QT_folder_in_sysconfig_folder andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Create_QT_folder_in_sysconfig_folder];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        if ([subTestDevice isEqualToString:@"Create QT Results File"])
        {
            //@synchronized (self) {
                subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
                subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
                retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_create_QT_Results_file andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
                
                BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_create_QT_Results_file];
                
                num = [NSString stringWithFormat:@"%hhd", isOK];
            //}
            
            
        }
        if ([subTestDevice isEqualToString:@"Write timestamp to qtresults"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Write_timestamp_to_qtresults andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Write_timestamp_to_qtresults];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        if ([subTestDevice isEqualToString:@"Write test plan version to both files"])
        {
            
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_write_test_planversion_to_both_file andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_write_test_planversion_to_both_file];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        if ([subTestDevice isEqualToString:@"Print test plan version"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_print_test_planversion andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_print_test_planversion];
           
            
            num = [array count] > 0?[NSString stringWithFormat:@"%@", array[0]]: @"error";
            
        }
        //Dump results of SOC station

        if ([subTestDevice isEqualToString:@"Dump results of SOC station"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Dump_results_of_SOC_station andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Dump_results_of_SOC_station];
            
            
            //num = [array count] > 0?[NSString stringWithFormat:@"%@", array[0]]: @"error";
            
            num = [NSString stringWithFormat:@"%@", retString];
        }
        
        //Reset clock rate to original
        if ([subTestDevice isEqualToString:@"Reset clock rate to original"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Reset_clock_rate_to_original andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Reset_clock_rate_to_original];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        
        if ([subTestDevice isEqualToString:@"Dump FATP serial number"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Dump_SerialNumber andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Dump_SerialNumber];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
            
        }
        
        if ([subTestDevice isEqualToString:@"Write Station Check Message to file"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_write_station_check_message andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_write_station_check_message];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
            
        }
        if ([subTestDevice isEqualToString:@"Print Station Check Message"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_print_station_check_message andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_print_station_check_message];
            num = [NSString stringWithFormat:@"%hhd", isOK];
            
        }
        
        if ([subTestDevice isEqualToString:@"Dump results of ICT station"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Dump_Results_Of_ICT_Station andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Dump_Results_Of_ICT_Station];
            num = [NSString stringWithFormat:@"%hhd", isOK];
            
        }
        if ([subTestDevice isEqualToString:@"Dump results of DFU station"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Dump_Results_Of_DFU_Station andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Dump_Results_Of_DFU_Station];
            num = [NSString stringWithFormat:@"%hhd", isOK];
            
        }
        if ([subTestDevice isEqualToString:@"Dump results of FCT station"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Dump_Results_Of_FCT_Station andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Dump_Results_Of_FCT_Station];
            num = [NSString stringWithFormat:@"%hhd", isOK];
            
        }
       
        
        //Load BurninTester.sh onto DUT
        if ([subTestDevice isEqualToString:@"Load BurninTester.sh onto DUT"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Load_BurninTester_onto_DUT andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Load_BurninTester_onto_DUT];
            num = [NSString stringWithFormat:@"%d", isOK];
        }
        //Reboot device into factory mode always
        if ([subTestDevice isEqualToString:@"Reboot device into factory mode always"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Reboot_device_into_factory_mode_always andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Reboot_device_into_factory_mode_always];
            num = [NSString stringWithFormat:@"%d", isOK];
        }
        
        
        if ([subTestDevice isEqualToString:@"Check PMIC0 HW Part Rev"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_PMIC0_HW_Part_Rev andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_PMIC0_HW_Part_Rev];
            if (![retString isEqualToString:@""]) {
                num = [NSString stringWithFormat:@"%@", [retString stringByReplacingOccurrencesOfString:@"\n" withString:@""]];
            }
        }
        if ([subTestDevice isEqualToString:@"Check PMIC1 HW Part Rev"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_PMIC1_HW_Part_Rev andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_PMIC1_HW_Part_Rev];
            if (![retString isEqualToString:@""]) {
                num = [NSString stringWithFormat:@"%@", [retString stringByReplacingOccurrencesOfString:@"\n" withString:@""]];
            }
            
        }
        
        if ([subTestDevice isEqualToString:@"Check Bleach Manufacture ID"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Bleach_Manufacture_ID andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Bleach_Manufacture_ID];
            num = [NSString stringWithFormat:@"%@", [retString stringByReplacingOccurrencesOfString:@"\n" withString:@""]];
            
        }

        

        if ([subTestDevice isEqualToString:@"Check Bleach HW Part Number"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Bleach_HW_Part_Number andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Bleach_HW_Part_Number];
            num = [NSString stringWithFormat:@"%@", [retString stringByReplacingOccurrencesOfString:@"\n" withString:@""]];
            
        }

        if ([subTestDevice isEqualToString:@"Check Bleach FW Major Rev"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Bleach_FW_Major_Rev andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Bleach_FW_Major_Rev];
            
            if (array.count > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            
        }
        
        if ([subTestDevice isEqualToString:@"Check NAND Manufacturer ID"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_DRAM_Manufacturer_ID andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_DRAM_Manufacturer_ID];
            num = [NSString stringWithFormat:@"%hhd", isOK];
            
        }
        
        
        
        
        if ([subTestDevice isEqualToString:@"Check DRAM HW Minor Rev"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_DRAM_HW_Minor_Rev andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_DRAM_HW_Minor_Rev];
            num = [NSString stringWithFormat:@"%hhd", isOK];
            
        }
        
        if ([subTestDevice isEqualToString:@"Check DRAM Size"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_DRAM_Size andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_DRAM_Size];
            num = [NSString stringWithFormat:@"%hhd", isOK];
            
        }
        
        if ([subTestDevice isEqualToString:@"Create and/or clear qt.txt"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            //retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Create_andor_Clear_QT_File subBackValueRegex:subBackValueRegex deviceNumber:deviceNumber andDelayTime:1000];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Create_andor_Clear_QT_File andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Create_andor_Clear_QT_File];
            num = [NSString stringWithFormat:@"%hhd", isOK];
            
        }
        
        if ([subTestDevice isEqualToString:@"Write Component Check Message to file"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_write_component_check_message_to_file andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_write_component_check_message_to_file];
            num = [NSString stringWithFormat:@"%hhd", isOK];
            
        }
        
        if ([subTestDevice isEqualToString:@"Print Component Check Message"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_print_component_check_message andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_print_component_check_message];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        //Change permission for i2c
        if ([subTestDevice isEqualToString:@"Change permission for i2c"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Change_permission_for_i2c andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Change_permission_for_i2c];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        if ([subTestDevice isEqualToString:@"Check NAND Manufacturer ID"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_NAND_Manufacturer_ID andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_NAND_Manufacturer_ID];
            
            if (array.count > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
        }
        if ([subTestDevice isEqualToString:@"Check NAND Part Number"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_NAND_Part_Number andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_NAND_Part_Number];
            
            if (array.count > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }

        }
        
        //Check Keystone Info
        
        if ([subTestDevice isEqualToString:@"Check Keystone Info"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Keystone_Info andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            
            BOOL isok = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Keystone_Info];
            
            num = [NSString stringWithFormat:@"%hhd", isok];
            
//            if (array.count > 0)
//            {
//                num = [NSString stringWithFormat:@"%@", array[0]];
//            }
        }
        if ([subTestDevice isEqualToString:@"Check NAND HW Major Rev"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_DRAM_HW_Major_Rev andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_DRAM_HW_Major_Rev];
            num = [NSString stringWithFormat:@"%@", retString];
            
        }
        
        
        if ([subTestDevice isEqualToString:@"Check NAND Serial Number"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_NAND_SerialNumber andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_NAND_SerialNumber];
            
            if (array.count > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
        }
        
        if ([subTestDevice isEqualToString:@"Check NAND FW Checksum"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_NAND_fw_Checksum andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_NAND_fw_Checksum];
            
            if (array.count > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
        }
        //Retrive /data/qt
        if ([subTestDevice isEqualToString:@"Retrive /data/qt"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$folder" withString:eachCsvDir];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Retrive_data_qt andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Retrive_data_qt];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }

        
        if ([subTestDevice isEqualToString:@"Check NAND FW version"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_NAND_fw_version andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_NAND_fw_version];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        if ([subTestDevice isEqualToString:@"Check NAND Device Version"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_NAND_Device_Version andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_NAND_Device_Version];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        if ([subTestDevice isEqualToString:@"Record NAND MFG Date/Time"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_NAND_MFG_Date_Time andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_NAND_MFG_Date_Time];
            num = [NSString stringWithFormat:@"%@", retString];
        }
        
        if ([subTestDevice isEqualToString:@"Check Keystone Manufacture ID"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Keystone_Manufacture_ID andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Keystone_Manufacture_ID];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        if ([subTestDevice isEqualToString:@"Check Keystone Device ID"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Keystone_fw_Device_ID andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Keystone_fw_Device_ID];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        if ([subTestDevice isEqualToString:@"Check Keystone HW Part Number"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Keystone_HW_Part_Number andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Keystone_HW_Part_Number];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        //N9 FW version dev-0.0.0[DEC] (20180722133705)\n
        
        if ([subTestDevice isEqualToString:@"Check Keystone FW Major Rev"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Keystone_fw_major_rev andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Keystone_fw_major_rev];
            
            
            if ([array count]> 0) {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            else{
                num = @"error";
            }
            
        }
        
        if ([subTestDevice isEqualToString:@"Check Keystone Checksum"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Keystone_Checksum andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Keystone_Checksum];
            
            if ([array count]> 0) {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            else{
                num = @"error";
            }
            
        }
        
        if ([subTestDevice isEqualToString:@"Check Keystone FW Minor Rev"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Keystone_fw_minor_rev andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Keystone_fw_minor_rev];
            
            
            if ([array count]> 0) {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            else{
                num = @"error";
            }
        }
        
        if ([subTestDevice isEqualToString:@"Write Initial OS Setup Message to file"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Write_Initial_Os_Setup andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Write_Initial_Os_Setup];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        if ([subTestDevice isEqualToString:@"Print Initial OS Setup Message"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Print_Initial_Os_Setup_Message andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Print_Initial_Os_Setup_Message];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        if ([subTestDevice isEqualToString:@"Check Board ID, bit 0"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Board_ID_BIT0 andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Board_ID_BIT0];
            num = [NSString stringWithFormat:@"%@", retString];
        }
        
        if ([subTestDevice isEqualToString:@"Check Board ID, bit 1"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Board_ID_BIT1 andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Board_ID_BIT1];
            num = [NSString stringWithFormat:@"%@", retString];
        }
        if ([subTestDevice isEqualToString:@"Check Board ID, bit 2"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Board_ID_BIT2 andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Board_ID_BIT2];
            num = [NSString stringWithFormat:@"%@", retString];
        }
        
        if ([subTestDevice isEqualToString:@"Check Board ID, bit 3"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Board_ID_BIT3 andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
           // BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Board_ID_BIT3];
            num = [NSString stringWithFormat:@"%@", retString];
        }
        
        if ([subTestDevice isEqualToString:@"Check Board Rev, bit 3"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Board_Rev_bit3 andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Board_Rev_bit3];
            num = [NSString stringWithFormat:@"%@", retString];
        }
        if ([subTestDevice isEqualToString:@"Check Board Rev, bit 2"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Board_Rev_bit2 andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Board_Rev_bit2];
            num = [NSString stringWithFormat:@"%@", retString];
        }
        if ([subTestDevice isEqualToString:@"Check Board Rev, bit 1"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Board_Rev_bit1 andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Board_Rev_bit1];
            num = [NSString stringWithFormat:@"%@", retString];
        }
        if ([subTestDevice isEqualToString:@"Check Board Rev, bit 0"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_Board_Rev_bit0 andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_Board_Rev_bit0];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        if ([subTestDevice isEqualToString:@"Read NAND Top Temp Sensor"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Read_Nand_Top_Temp_Sensor andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Read_Nand_Top_Temp_Sensor];

            
            if ([array count]> 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            else
            {
                num = @"error";
            }
        }
        if ([subTestDevice isEqualToString:@"Read NAND Bottom Temp Sensor"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Read_Nand_Bottom_Temp_Sensor andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Read_Nand_Bottom_Temp_Sensor];
            
            if ([array count] > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            else
            {
                num = @"error";
            }
        }
        
        //Read SOC Temp Sensor
        if ([subTestDevice isEqualToString:@"Read SOC Temp Sensor"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Read_SOC_Temp_Sensor andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            num = [NSString stringWithFormat:@"%@", retString];
            
            //NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Read_SOC_Temp_Sensor];
            
//            if ([array count] > 0)
//            {
//                num = [NSString stringWithFormat:@"%@", @"1"];
//            }
//            else
//            {
//                num = @"123";
//            }
        }
        
        //Read Keystone Temp Sensor
        if ([subTestDevice isEqualToString:@"Read Keystone Temp Sensor"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Read_Keystone_Temp_Sensor andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Read_Keystone_Temp_Sensor];
            
            if ([array count] > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            else
            {
                num = @"error";
            }
        }
        
        
        if ([subTestDevice isEqualToString:@"Dump Voltage vs Frequency Table CPU"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Dump_Voltage_Vs_Frequency_Table_CPU andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Dump_Voltage_Vs_Frequency_Table_CPU];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        if ([subTestDevice isEqualToString:@"Dump Voltage vs Frequency Table GPU"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Dump_Voltage_Vs_Frequency_Table_GPU andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Dump_Voltage_Vs_Frequency_Table_GPU];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
#pragma mark i2cget
        if ([subTestDevice isEqualToString:@"chmod 777 i2cdetect i2cdump i2cget i2cset"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_chmod_777_i2cdetect andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_chmod_777_i2cdetect];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        
        if ([subTestDevice isEqualToString:@"Read PMIC0 Voltage BUCK0 - PP1V8 - 1.8V"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Read_PMIC0_Voltage_BUCK0_PP1V8 andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Read_PMIC0_Voltage_BUCK0_PP1V8];
            
            if ([array count] > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            else
            {
                num = @"error";
            }

        }
        
        
        if ([subTestDevice isEqualToString:@"Read PMIC0 Voltage BUCK1 -  PP_GPU - DVFS 0.8V/0.9V"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Read_PMIC0_Voltage_BUCK1_PP_GPU_DVFS andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Read_PMIC0_Voltage_BUCK1_PP_GPU_DVFS];
            
            if ([array count] > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            else
            {
                num = @"error";
            }
        }
        
        
        
        if ([subTestDevice isEqualToString:@"Read PMIC0 BUCK2 - PP_ CPU - DVFS varies for different SoC silicon"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Read_PMIC0_BUCK2_PP_CPU_DVFS andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Read_PMIC0_BUCK2_PP_CPU_DVFS];
            
            if ([array count] > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            else
            {
                num = @"error";
            }

        }
        if ([subTestDevice isEqualToString:@"Read PMIC0 Voltage BUCK3 - PP0V8_CORE - 0.8V"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Read_PMIC0_Voltage_BUCK3_PP0V8_CORE andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Read_PMIC0_Voltage_BUCK3_PP0V8_CORE];
            
            if ([array count] > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            else
            {
                num = @"error";
            }

        }
        if ([subTestDevice isEqualToString:@"Read PMIC1 Voltage BUCK0 - PP3V3_WLBT - 3.3V"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Read_PMIC1_Voltage_BUCK0_PP3V3_WLBT andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Read_PMIC1_Voltage_BUCK0_PP3V3_WLBT];
            
            if ([array count] > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            else
            {
                num = @"error";
            }
        }
        if ([subTestDevice isEqualToString:@"Read PMIC1 Voltage BUCK1 - PP1V15_WLBT - 1.15V"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Read_PMIC1_Voltage_BUCK1_PP1V15_WLBT andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Read_PMIC1_Voltage_BUCK1_PP1V15_WLBT];
            
            if ([array count] > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            else
            {
                num = @"error";
            }

        }
        if ([subTestDevice isEqualToString:@"Read PMIC1 Voltage BUCK2 - PP3V3_WLBT - 3.3V"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Read_PMIC1_Voltage_BUCK2_PP3V3_WLBT andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Read_PMIC1_Voltage_BUCK2_PP3V3_WLBT];
            
            if ([array count] > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            else
            {
                num = @"error";
            }
        }
        if ([subTestDevice isEqualToString:@"Read PMIC1 Voltage BUCK3 - PP1V1_SOC_DDR"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Read_PMIC1_Voltage_BUCK3_PP1V1_SOC_DDR andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Read_PMIC1_Voltage_BUCK3_PP1V1_SOC_DDR];
            
            if ([array count] > 0)
            {
                num = [NSString stringWithFormat:@"%@", array[0]];
            }
            else
            {
                num = @"error";
            }

        }
        
        if ([subTestDevice isEqualToString:@"Write HDMI Functional Tests Message to file"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Write_HDMI_Functional_Tests_Message_to_file andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Write_HDMI_Functional_Tests_Message_to_file];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        if ([subTestDevice isEqualToString:@"Print HDMI Functional Tests Message"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Print_HDMI_Functional_Tests_Message andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Print_HDMI_Functional_Tests_Message];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        //Write Quick Tests Message to file
        if ([subTestDevice isEqualToString:@"Write Quick Tests Message to file"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Write_Quick_Tests_Message_to_file andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Write_Quick_Tests_Message_to_file];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        //Write serial number to both files
        if ([subTestDevice isEqualToString:@"Write serial number to both files"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Write_serial_number_to_both_files andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Write_serial_number_to_both_files];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        
        //Print Quick Tests Message
        if ([subTestDevice isEqualToString:@"Print Quick Tests Message"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Print_Quick_Tests_Message andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Print_Quick_Tests_Message];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        //Check if DUT has entered QT station previously
        if ([subTestDevice isEqualToString:@"Check if DUT has entered QT station previously"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Check_if_DUT_has_entered_QT_station_previously andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_if_DUT_has_entered_QT_station_previously];
            
//            NSArray* array = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Check_if_DUT_has_entered_QT_station_previously];

           // if (array.count > 0) {
                num = [NSString stringWithFormat:@"%hhd", isOK];
//            }else{
//                num = @"error";
//            }            
        }
        
        //Read and write over SDIO
        if ([subTestDevice isEqualToString:@"Read and write over SDIO"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Read_and_write_over_SDIO andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Read_and_write_over_SDIO];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        //Stop logging
        if ([subTestDevice isEqualToString:@"Stop logging"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Stop_logging andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Stop_logging];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        //Retrive $timestamp.log
        if ([subTestDevice isEqualToString:@"Retrive $timestamp.log"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Retrive_timestamp_log andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Retrive_timestamp_log];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        //Retrive /sysconfig/qt/qtresults.txt
        if ([subTestDevice isEqualToString:@"Retrive /sysconfig/qt/qtresults.txt"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$folder" withString:eachCsvDir];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Retrive_qtresults_log andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Retrive_qtresults_log];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        
        //Delete $timestamp.log file
        if ([subTestDevice isEqualToString:@"Delete $timestamp.log file"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Delete_timestamp_log andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Delete_timestamp_log];
            
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        //Write QT Station Finish Message to file
        if ([subTestDevice isEqualToString:@"Write QT Station Finish Message to file"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Write_QT_Station_Finish_Message_to_file andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Write_QT_Station_Finish_Message_to_file];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        //Print Quick Tests Message
        if ([subTestDevice isEqualToString:@"Print QT Station Finish Message"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Print_Quick_Tests_Message andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Print_Quick_Tests_Message];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        
        //Write to soc.txt - PASS
        if ([subTestDevice isEqualToString:@"Write to soc.txt - PASS"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Write_to_soc_PASS andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Write_to_soc_PASS];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        if ([subTestDevice isEqualToString:@"Enable Colorbar output"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Enable_Colorbar_Output andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Enable_Colorbar_Output];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        //Lock /sysconfig partition
        if ([subTestDevice isEqualToString:@"Lock /sysconfig partition"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Enable_Colorbar_Output andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Enable_Colorbar_Output];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        //Run DRAM Stress Test: memtester
        if ([subTestDevice isEqualToString:@"Run DRAM Stress Test: memtester"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Run_DRAM_Stress_Test_memtester andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Run_DRAM_Stress_Test_memtester];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        //Run eMMC Stress Test: dd command: Write
        if ([subTestDevice isEqualToString:@"Run eMMC Stress Test: dd command: Write"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Run_DRAM_Stress_Test_memtester andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Run_DRAM_Stress_Test_memtester];
            num = [NSString stringWithFormat:@"%hhd", isOK];
        }
        //Run eMMC Stress Test: dd command: Write
        if ([subTestDevice isEqualToString:@"Run eMMC Stress Test: dd command: Write"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Run_eMMC_Stress_Test andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Run_eMMC_Stress_Test];
            num = [NSString stringWithFormat:@"%@", retString];
        }
        //Check DRAM info
        if ([subTestDevice isEqualToString:@"Check DRAM info"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Run_eMMC_Stress_Test andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            //BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Run_eMMC_Stress_Test];
            num = [NSString stringWithFormat:@"%@", retString];
        }

        
#pragma mark RGB TEST
        if ([subTestDevice isEqualToString:@"Characterize Colorbars RGB"])
        {
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
            subTestCommand = [subTestCommand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
            
            subFailTestCommmand = [subFailTestCommmand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
            
            retString = [terminalTool ReadTerminal:subTestCommand andTerminalType:Terminal_adb_Characterize_Colorbars_For_RGB andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
            
            NSString* logString = [NSString stringWithFormat:@"%@:index=7,测试项 %@：testCommand: %@\nretString: %@\n\n",[timeDay getFileTime],testitem.testName, subTestCommand,retString];
            
            [txtContentString appendFormat:@"%@", logString];
            [self UpdateTextView:logString andClear:NO andTextView:self.Log_View];
            
            NSArray* retArray = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Characterize_Colorbars_For_RGB];
            
            
            if ([retString containsString:@"Failed"]||retArray.count == 0) {
                
                int count = 0;
                
                subFailTestCommmand = [subFailTestCommmand stringByReplacingOccurrencesOfString:@"$timestamp" withString:timeStamp];
                subFailTestCommmand = [subFailTestCommmand stringByReplacingOccurrencesOfString:@"$uart" withString:self.product_uart_port_name];
                subFailTestCommmand = [subFailTestCommmand stringByReplacingOccurrencesOfString:@"<device number>" withString:self.device_number];
                
                while (true)
                {
                    
                    retString = [terminalTool ReadTerminal:subFailTestCommmand andTerminalType:Terminal_adb_Characterize_Colorbars_For_RGB andRegexStr:subBackValueRegex deviceNumber:self.device_number andDelayTime:1000];
                    retArray = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Characterize_Colorbars_For_RGB];
                    
                    NSString* logString = [NSString stringWithFormat:@"%@:index=7,测试项 %@：testCommand: %@\nretString: %@\n\n",[timeDay getFileTime],testitem.testName, subFailTestCommmand,retString];
                    
                    [txtContentString appendFormat:@"%@", logString];
                    [self UpdateTextView:logString andClear:NO andTextView:self.Log_View];
                    
                    
                    if ((![retString containsString:@"Failed"]&&retArray.count!=0)|| count == 2) {
                        break;
                    }
                    count++;
                }
                
            }
            BOOL isOK = [measureTool RegexDeviceNoDigitalValue:retString andRegex:@"" andTerminalType:Terminal_adb_Characterize_Colorbars_For_RGB];
            
            retArray = [measureTool RegexDeviceDigitalValue:retString andRegex:subBackValueRegex andTerminalType:Terminal_adb_Characterize_Colorbars_For_RGB];
            
            
            NSString* string = [[NSString alloc] init];
            
            if ([retArray count] > 0)
            {
                for(id obj in retArray)
                {
                    string = [string stringByAppendingFormat:@"%@;", [obj stringByReplacingOccurrencesOfString:@"\n" withString:@""]];
                }
            }
            else
            {
                isOK = NO;
            }
            
            num = isOK?[string stringByAppendingString:@"pass"]:[string stringByAppendingString:@"failed"];
            
            [NSThread sleepForTimeInterval:0.2];
            
        }
        
        
        
        //延迟时间
        if ([subTestDevice isEqualToString:@"SW"])
        {
            
            if (!isDebug)
            {
                 NSLog(@"软件休眠时间");
                [NSThread sleepForTimeInterval:DelayTime];
                [txtContentString appendFormat:@"%@:index=4,%@软件延时处理\n",[timeDay getFileTime],subTestDevice];
            }
            
            [NSThread sleepForTimeInterval:DelayTime];
        }
        else
        {
            NSLog(@"其它的情形");
        }
        
        if (![subTestDevice isEqualToString:@"SW"]&&![subTestDevice isEqualToString:@"Characterize Colorbars RGB"]) {
            
            NSString* logString = [NSString stringWithFormat:@"%@:index=7,测试项 %@：testCommand: %@\nretString: %@\n\n",[timeDay getFileTime],testitem.testName, subTestCommand,retString];
            [txtContentString appendFormat:@"%@", logString];
            
            [self UpdateTextView:logString andClear:NO andTextView:self.Log_View];
        }
    }
    
#pragma mark--------对数据进行处理
    //[txtContentString appendFormat:@"%@:index=7,测试项： %@\n",[timeDay getFileTime],testitem.testName];
    
    testvalue = [NSString stringWithFormat:@"%@",num];
    

#pragma mark--------对测试项进行赋值
    if ([testitem.testName containsString:@"_Vmeas"] || [testitem.testName containsString:@"_Rref"] || [testitem.testName containsString:@"_Cfix"] || [testitem.testName containsString:@"_Vs"] || [testitem.testName containsString:@"_Cref"] || [testitem.testName containsString:@"_Rdut"] || [testitem.testName containsString:@"_Cdut"] || [testitem.testName containsString:@"_Rfix"]||[testitem.testName containsString:@"ISOLATION"])
    {
        testvalue=[NSString stringWithFormat:@"%@",store_Dic[[NSString stringWithFormat:@"%@",testitem.testName]]];
        
        NSLog(@"打印多长的时间==========%@",testvalue);

    }
    
    
//判断值得大小
#pragma mark--------对测试出来的结果进行判断和赋值
    //上下限值对比
    if (([testvalue floatValue]>=[testitem.min floatValue]&&[testvalue floatValue]<=[testitem.max floatValue]&&![testvalue containsString:@"failed"])||([testitem.max isEqualToString:@"--"] && [testitem.min isEqualToString:@"--"]&&![testvalue containsString:@"failed"]&&![testvalue isEqualToString:@"failed"]&&![testvalue containsString:@"error"])||([[testvalue uppercaseString] containsString:@"PASS"]))
    {
        
        if (fix_type == 1) {
            
            testitem.value1 = [testvalue isEqualToString:@""]?@"123":testvalue;
            testitem.result1 = @"PASS";
            
        }
        else if (fix_type == 2)
        {
            testitem.value2 = [testvalue isEqualToString:@""]?@"123":testvalue;
            testitem.result2 = @"PASS";
        }
        else if (fix_type == 3)
        {
            testitem.value3 = [testvalue isEqualToString:@""]?@"123":testvalue;
            testitem.result3 = @"PASS";
        }
        else if (fix_type == 4)
        {
            testitem.value4 = [testvalue isEqualToString:@""]?@"123":testvalue;
            testitem.result4 = @"PASS";
        }
        
        
        
        testitem.messageError=nil;
        ispass = YES;
    }
    else
    {

        
        if (fix_type == 1) {
            testitem.value1 = [testvalue isEqualToString:@""]?@"123":testvalue;
            testitem.result1 = @"Fail";
        }
        else if (fix_type == 2)
        {
            testitem.value2 = [testvalue isEqualToString:@""]?@"123":testvalue;
            testitem.result2 = @"Fail";
        }
        else if (fix_type == 3)
        {
            testitem.value3 = [testvalue isEqualToString:@""]?@"123":testvalue;
            testitem.result3 = @"FAIL";
        }
        else if (fix_type == 4)
        {
            testitem.value4 = [testvalue isEqualToString:@""]?@"123":testvalue;
            testitem.result4 = @"FAIL";
        }
        
        
        testitem.messageError=[NSString stringWithFormat:@"%@ Fail",testitem.testName];
        ispass = NO;
        PF = NO;
            
    }
    
    
    //对时间进行赋值
    endTime = [timeDay getCurrentSecond];
    testitem.startTime = startTime;
    testitem.endTime   = endTime;

    
    
    //处理相关的测试项
    if (!(testvalue==NULL)) {
        [ItemArr addObject:testitem];      //将测试项加入数组中
        [testAppendString appendFormat:@"%@,",testvalue];
        
        if (fix_type==1) [testResultAppendStr appendFormat:@"%@,",testitem.result1];
        if (fix_type==2) [testResultAppendStr appendFormat:@"%@,",testitem.result2];
        if (fix_type==3) [testResultAppendStr appendFormat:@"%@,",testitem.result3];
        if (fix_type==4) [testResultAppendStr appendFormat:@"%@,",testitem.result4];
    }
    
    if (!ispass) {
        [testFailArr addObject:[NSString stringWithFormat:@"%@", testitem.testName]];
    }
    
    NSString* endTestTime = [[GetTimeDay shareInstance] getLogTime];
    NSDate* date_before = [df dateFromString:beforeTestTime];
    NSDate* date_end = [df dateFromString:endTestTime];
    NSTimeInterval intervalTime = [date_end timeIntervalSinceDate:date_before];
    totalTime+=intervalTime;
    [itemTimeArr addObject:[NSString stringWithFormat:@"%d,%@,%f\n",item_index,testitem.testName,intervalTime]];
    
    
    return ispass;
}


//================================================
//保存csv
//================================================
-(void)SaveCSV:(FileCSV *)csvFile withBool:(BOOL)need_title
{
    NSString * line    =  @"";
    NSString * result =  @"";
    NSString * value  =  @"";
    
    for(int i=0;i<[ItemArr count];i++)
    {
        Item *testitem=ItemArr[i];
        
        if (fix_type == 1) {value  = testitem.value1;}
        if (fix_type == 2) {value  = testitem.value2;}
        if (fix_type == 3) {value  = testitem.value3;}
        if (fix_type == 4) {value  = testitem.value4;}
        
        if(testitem.isTest)  //需要测试的才需要上传
        {
            if((testitem.isShow == YES)&&(testitem.isTest))    //需要显示并且需要测试的才保存
            {
                line=[line stringByAppendingString:[NSString stringWithFormat:@"%@,",value]];
            }
        }
    }
    line = [line stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    
    NSString *test_result;
    if (PF)
    {
        test_result = @"PASS";
    }
    else
    {
        test_result = @"FAIL";
    }
    //line字符串前面增加SN和测试结果
//   NSString *  contentStr = [NSMutableString stringWithFormat:@"\n%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@",start_time,end_time,[self.Config_Dic objectForKey:kSoftwareVersion],self.NestID,@"Cr",self.Config_pro,self.dut_sn,test_result,FixtureID,[self.Config_Dic objectForKey:kOperator_ID],line];
    
    
    NSString *  contentStr = [NSMutableString stringWithFormat:@"\n%@,%@,%@%@,%@",self.dut_sn,test_result,line,start_time,end_time];
    
     NSMutableString  * contentString = [NSMutableString stringWithString:contentStr];
    
    
    //如果addDcr=YES,加数据加到contentString中
    if (addDcr)
    {
        [contentString appendString:[NSString stringWithFormat:@"%@",dcrAppendString]];
    }
    
    
    
    if(need_title == YES)
    {
        NSString   * titleString = [NSString stringWithFormat:@"Version:,%@\n%@",[self.Config_Dic objectForKey:kSoftwareVersion],self.csvTitle];
        
        [csvFile CSV_Write:titleString];
    }
    
    [csvFile CSV_Write:contentString];
    
}


-(void)setCsvTitle:(NSString *)csvTitle
{
    _csvTitle = csvTitle;
}

-(void)setDut_sn:(NSString *)dut_sn
{
    _dut_sn = dut_sn;
}

-(void)setFoldDir:(NSString *)foldDir
{
    _foldDir = foldDir;
}

-(void)setToFold:(NSString *)toFold
{
    _toFold = toFold;
}




#pragma mark=========================通知类消息
//监测开始测试的消息

-(void)NSThreadStart_Notification:(NSNotification *)noti
{
    
    if ((Instrument&&self.isTest)||isDebug) {
        
        index = 2;
    }
    else //发送通知，测试已经结束，传数值过去
    {
        [[NSNotificationCenter defaultCenter] postNotificationName:SNChangeNotice object:[NSString stringWithFormat:@"%dFX",fix_type] userInfo:nil];
    }
    
}

-(void)NSThreadEnd_Notification:(NSNotification *)noti
{
    index = 1000;
}


#pragma mark================空测试时，公司默认为NULL
-(void)selectNullTestNoti:(NSNotification *)noti
{
    if ([noti.object isEqualToString:@"NullTest"])
    {
         nulltest = YES;
         companyName = @"NULL";
    }
    else
    {
         nulltest = NO;
    }
}

#pragma mark---------------test number
-(void)select_testnum:(NSNotification*)noti
{
    
    if ([noti.name isEqualToString:kTestNum]) {
        
        testNum = [[noti.userInfo objectForKey:@"testCount"] integerValue];
        
        
    }
    
}

#pragma mark--------------选择测试40个测试数据
-(void)selectTestDataNoti:(NSNotification *)noti
{
    if ([noti.name isEqualToString:kTest40DataNotice]) {
        
        if ([noti.object isEqualToString:@"YES"]) {
            
            addDcr = YES;
        }
        else
        {
            addDcr = NO;
        }
    }
}




#pragma mark-----------------多次测试和的值
-(void)add_RFixture_Value_To_Sum_Testname:(NSString *)testname RFixture:(double)RFixture
{
    NSString *largeRes= @">1TOhm";
    if ([testname isEqualToString:@"B_E_DCR"])         B_E_Sum   = B_E_Sum + RFixture;
    if ([testname isEqualToString:@"B2_E2_DCR"])       B2_E2_Sum = B2_E2_Sum + RFixture;
    if ([testname isEqualToString:@"H203_BC_B4_E4_DCR_X"])       B4_E4_Sum = B4_E4_Sum + RFixture;
    if ([testname isEqualToString:@"ABC_DEF_DCR"])     ABC_DEF_Sum =ABC_DEF_Sum + RFixture;
    
    
    if ([testname isEqualToString:@"H203_BC_B4_E4_DCR_X"]) {
        
        [store_Dic setValue:[NSString stringWithFormat:@"%@",largeRes] forKey:@"H109_BC_ISOLATION_R_DC"];
        [store_Dic setValue:[NSString stringWithFormat:@"%.3f",RFixture] forKey:@"H204_BC_B4_E4_DCR_Rfix_X"];
    }
    else
    {
        [store_Dic setValue:[NSString stringWithFormat:@"%@",largeRes] forKey:[NSString stringWithFormat:@"%@_Rdut",testname]];
        [store_Dic setValue:[NSString stringWithFormat:@"%.3f",RFixture] forKey:[NSString stringWithFormat:@"%@_Rfix",testname]];
    }
}


#pragma mark-------------返回总文件
-(NSString *)backTotalFilePathwithFloder:(NSString *)FoldStr
{
    if (fix_type==1) {
        
       return [NSString stringWithFormat:@"%@/%@_A.csv",FoldStr,[timeDay getCurrentDay]];
    }
    else if (fix_type==2)
    {
       return [NSString stringWithFormat:@"%@/%@_B.csv",FoldStr,[timeDay getCurrentDay]];
    }
    else if (fix_type==3)
    {
       return [NSString stringWithFormat:@"%@/%@_C.csv",FoldStr,[timeDay getCurrentDay]];
    }
    else
    {
       return [NSString stringWithFormat:@"%@/%@_D.csv",FoldStr,[timeDay getCurrentDay]];
    }
}


//更新upodateView
-(void)UpdateTextView:(NSString*)strMsg andClear:(BOOL)flagClearContent andTextView:(NSTextView *)textView
{
    if (flagClearContent)
    {
        dispatch_async(dispatch_get_main_queue(),
                       ^{
                           [textView setString:@""];
                       });
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(),
                       ^{
                           if ([[textView string]length]>0)
                           {
                               NSString * messageString = [NSString stringWithFormat:@"%@: %@\n",[[GetTimeDay shareInstance] getFileTime],strMsg];
                               NSRange range = NSMakeRange([textView.textStorage.string length] , messageString.length);
                               [textView insertText:messageString replacementRange:range];
                              
                           }
                           else
                           {
                               [textView setString:[NSString stringWithFormat:@"%@",strMsg]];
                           }
                           
                           [textView setTextColor:[NSColor redColor]];
                       });
    }
}



//线程开始
-(void)threadStart
{
    
    [thread start];
    
}




//线程结束
-(void)threadEnd
{
    [thread cancel];
//    [agilentB2987A CloseDevice];
//    [agilentE4980A CloseDevice];
//    [serialport Close];
//    
//    agilentB2987A = nil;
//    agilentE4980A = nil;
//    serialport = nil;
}


#pragma mark ===============唤醒2987A
-(void)timewake
{
 //    [agilentB2987A WriteLine:@"*RST" andCommunicateType:AgilentB2987A_USB_Type];
}

-(NSMutableArray*)parseTxt:(NSString*)content withPattern:(NSString*)pattern{
    
    NSMutableArray* stringArray = [[NSMutableArray alloc] init];
    
    @synchronized (self)
    {
        NSRegularExpression *regex = [[NSRegularExpression alloc] initWithPattern:pattern options:NSRegularExpressionCaseInsensitive error:nil];
        
        NSArray *results = [regex matchesInString:content options:0 range:NSMakeRange(0, content.length)];
        
        if (results.count != 0) {
            for (NSTextCheckingResult* result in results) {
                for (int i=1; i<[result numberOfRanges]; i++)
                {
                    [stringArray addObject:[content substringWithRange:[result rangeAtIndex:i]]];
                }
            }
        }
    }
    
    return stringArray;
}


@end
