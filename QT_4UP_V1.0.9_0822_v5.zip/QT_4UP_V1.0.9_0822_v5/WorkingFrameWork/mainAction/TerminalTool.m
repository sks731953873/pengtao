//
//  MeasurementValueHandle.m
//  QT
//
//  Created by test on 18/07/2018.
//  Copyright © 2018 macjinlongpiaoxu. All rights reserved.
//

#import "TerminalTool.h"
#import "Lock.h"
#import "HiperTimer.h"


static TerminalTool *terminalTool = nil;

@implementation TerminalTool
{
    Lock* teminalLock;
}

-(id)init{
    
    if (self = [super init])
    {
    }
    return self;
}



+(instancetype)shareInstance
{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        terminalTool = [[self alloc] init];
    });
    return terminalTool;
    
}


-(void)addGlobalLock
{
    teminalLock = [Lock shareInstance];
    
}


-(void)dealloc
{
   
   // [terminalTool release];
    terminalTool=nil;
    
    //[super dealloc];
}


-(NSString*)ReadTerminal:(NSString*)strCmd andTerminalType:(enum TerminalType)terminalType andRegexStr:(NSString*)strRegex deviceNumber:(NSString*)deviceNumber andDelayTime:(int)testDelayTime
{
    NSString* strReuslt = [[NSString alloc] init];
    
    switch (terminalType)
    {
            
        case Terminal_adb_Start_logging:
        {
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"<device number>" withString:deviceNumber];
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            HiperTimer* timer = [[HiperTimer alloc] init];
            [timer Start];
            
            while ([timer durationMillisecond] < 10000)
            {
                strReuslt =  [self sendCommand_4:strCmd  andDelayTime:testDelayTime];
                if ([strReuslt length] > 0)
                {
                    break;
                }
            }
        }
            break;
            
#pragma mark 返回值长度大于0，adb command的使用方式
        case Terminal_adb_Check_NAND_fw_version:
        case Terminal_adb_Check_NAND_Device_Version://乱码
        case Terminal_adb_Check_NAND_MFG_Date_Time:
        
        case Terminal_adb_Characterize_Colorbars_For_720p60_8bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_1080p60_8bpc_RGB:
        case Terminal_adb_Characterize_Colorbars_For_1080p60_8bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k24_8bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k30_8bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k60_8bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k60_8bpc_YCbCr_1:
        case Terminal_adb_Characterize_Colorbars_For_4k60_12bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k60_8bpc_RGB:
        case Terminal_adb_Characterize_Colorbars_For_480p60_12bpc_YCbCr :
        case Terminal_adb_Characterize_Colorbars_For_720p60_12bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_1080p60_12bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k24_12bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k30_12bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_4k60_12bpc_YCbCr_1:
        case Terminal_adb_Characterize_Colorbars_For_720p60_8bpc_RGB:
        case Terminal_adb_Characterize_Colorbars_For_480p60_8bpc_YCbCr:
        case Terminal_adb_Characterize_Colorbars_For_480p60_8bpc_RGB:
        case Terminal_adb_Characterize_Colorbars_For_RGB:
        case Terminal_adb_Enable_Colorbar_Output:
        
        {
            
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"<device number>" withString:deviceNumber];
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            HiperTimer* timer = [[HiperTimer alloc] init];
            [timer Start];
            
            while ([timer durationMillisecond] < 10000)
            {
                strReuslt =  [self sendCommand_2:strCmd  andDelayTime:testDelayTime];
                
                if ([strReuslt length] > 0) {
                    
                    break;
                }
                
            }
        }
            break;
            
#pragma mark unlock/lock
            
            
        case Terminal_adb_create_QT_Results_file:
        case Terminal_adb_write_serialnumber:
        {
            [teminalLock lock];
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"<device number>" withString:deviceNumber];
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            HiperTimer* timer = [[HiperTimer alloc] init];
            [timer Start];
            
            while ([timer durationMillisecond] < 10000) {
                
                strReuslt =  [self sendCommand:strCmd  andDelayTime:testDelayTime];
                
                if ([strReuslt length] > 0&& [strReuslt containsString:strRegex]) {
                    break;
                }
            }
            [teminalLock unlock];
            
        }
            break;

            
#pragma mark 返回值等于0\n
        case Terminal_adb_Reboot_device_into_factory_mode_always:
        
        case Terminal_adb_Write_to_soc_PASS:
        case Terminal_adb_Write_QT_Station_Finish_Message_to_file:
        
        case Terminal_adb_Write_Quick_Tests_Message_to_file:
        case Terminal_adb_Write_HDMI_Functional_Tests_Message_to_file:
        case Terminal_adb_Check_Board_ID_BIT3:
        case Terminal_adb_Check_Board_ID_BIT2:
        case Terminal_adb_Check_Board_ID_BIT1:
        case Terminal_adb_Check_Board_ID_BIT0:
        case Terminal_adb_Dump_SerialNumber:
        case Terminal_adb_Delete_timestamp_log:
        case Terminal_adb_Check_Board_Rev_bit0:
        case Terminal_adb_Check_Board_Rev_bit1:
        case Terminal_adb_Check_Board_Rev_bit2:
        case Terminal_adb_Check_Board_Rev_bit3://有待进一步解决
        case Terminal_adb_Write_Initial_Os_Setup:
        case Terminal_adb_write_component_check_message_to_file:
        case Terminal_adb_Create_andor_Clear_QT_File:
        case Terminal_adb_write_station_check_message:
        case Terminal_adb_write_test_planversion_to_both_file:
        case Terminal_adb_write_timestamp_to_both_file:
        case Terminal_adb_wait_device:
        case Terminal_adb_chmod_777_i2cdetect:
        case Terminal_adb_Change_permission_for_i2c:
        {
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"<device number>" withString:deviceNumber];
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            HiperTimer* timer = [[HiperTimer alloc] init];
            [timer Start];
            
            while ([timer durationMillisecond] < 5000)
            {
                strReuslt =  [self sendCommand:strCmd  andDelayTime:testDelayTime];
                
                if ([strReuslt length] > 0&&[strReuslt isEqualToString:@"0\n"]) {
                    
                    break;
                }
            }
        }
            break;
#pragma mark 返回值等于1
        case Terminal_adb_Dump_results_of_SWDL_station:
        case Terminal_adb_Dump_results_of_SOC_station:
        
        case Terminal_adb_Read_SOC_Temp_Sensor:
        case Terminal_adb_Check_Keystone_Manufacture_ID:
        case Terminal_adb_Check_Keystone_fw_Device_ID:
        case Terminal_adb_Check_Keystone_HW_Part_Number://等待新需求
            
            
        case  Terminal_adb_Check_Bleach_Manufacture_ID:
        
        case  Terminal_adb_Check_Bleach_HW_Part_Number:
        
        case  Terminal_adb_Check_DRAM_Manufacturer_ID:
        case  Terminal_adb_Check_DRAM_HW_Major_Rev:
        case  Terminal_adb_Check_DRAM_HW_Minor_Rev:
        case  Terminal_adb_Check_DRAM_Size://等待客户新需求
            
        
        case Terminal_adb_Check_DUT_entered_SOC_station_previously:
        case Terminal_adb_Dump_Results_Of_FCT_Station:
        case Terminal_adb_Dump_Results_Of_DFU_Station:
        case Terminal_adb_Dump_Results_Of_ICT_Station:
        
        case Terminal_adb_Write_SerialNumber_To_Both_Files:
        
        case Terminal_adb_Check_Board_ID://1\n
        {
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"<device number>" withString:deviceNumber];
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
//            HiperTimer* timer = [[HiperTimer alloc] init];
//            [timer Start];
//            
//            while ([timer durationMillisecond] < 10000)
//            {
                strReuslt =  [self sendCommand:strCmd  andDelayTime:testDelayTime];
                
                if ([strReuslt containsString:@"1"]&& ![strReuslt containsString:@"unknown"]) {
                    //strReuslt = @"1";
                    break;
                //}
            }
        }
            break;
            
        
        case Terminal_adb_Unlock_sysconfig_partition:
        {
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"<device number>" withString:deviceNumber];
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            HiperTimer* timer = [[HiperTimer alloc] init];
            [timer Start];
            
            while ([timer durationMillisecond] < 10000) {
                
                strReuslt =  [self sendCommand:strCmd  andDelayTime:testDelayTime];
                
                if ([strReuslt containsString:@"Unlock success!"]||[strReuslt containsString:@"Already unlocked!"]) {
                    break;
                }
            }
        }
            break;
        case Terminal_adb_root:
        {
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"<device number>" withString:deviceNumber];
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            HiperTimer* timer = [[HiperTimer alloc] init];
            [timer Start];
            
            while ([timer durationMillisecond] < 10000) {
                
                strReuslt =  [self sendCommand:strCmd  andDelayTime:testDelayTime];
                
                if ([strReuslt containsString:@"restarting adbd as root"]||[strReuslt containsString:@"adbd is already running as root"]) {
                    break;
                }
            }
        }
            break;
            
#pragma mark hex转化为int
        case Terminal_adb_Read_PMIC0_Voltage_BUCK0_PP1V8:
        case Terminal_adb_Read_PMIC0_Voltage_BUCK1_PP_GPU_DVFS:
        case Terminal_adb_Read_PMIC0_BUCK2_PP_CPU_DVFS:
        case Terminal_adb_Read_PMIC0_Voltage_BUCK3_PP0V8_CORE:
        case Terminal_adb_Read_PMIC1_Voltage_BUCK0_PP3V3_WLBT:
        case Terminal_adb_Read_PMIC1_Voltage_BUCK1_PP1V15_WLBT:
        case Terminal_adb_Read_PMIC1_Voltage_BUCK2_PP3V3_WLBT:
        case Terminal_adb_Read_PMIC1_Voltage_BUCK3_PP1V1_SOC_DDR:
        {
            {
                strCmd = [strCmd stringByReplacingOccurrencesOfString:@"<device number>" withString:deviceNumber];
                strCmd = [strCmd stringByReplacingOccurrencesOfString:@"\n" withString:@""];
                
                HiperTimer* timer = [[HiperTimer alloc] init];
                [timer Start];
                
                while ([timer durationMillisecond] < 10000) {
                    
                    strReuslt =  [self sendCommand:strCmd  andDelayTime:testDelayTime];
                    
                    if ([strReuslt length] > 0&& [strReuslt containsString:@"x"]) {
                        break;
                    }
                }
                
            }
            
            
        }
            break;
#pragma mark 返回值：result = regex
        case Terminal_adb_Retrive_qtresults_log:
        case Terminal_adb_Set_clock_rate_for_480p60:
        case Terminal_adb_Retrive_data_qt:
        case Terminal_adb_Check_Keystone_Info:
        case Terminal_adb_Lock_sysconfig_partition:
        case Terminal_adb_Print_QT_Station_Finish_Message:
        case Terminal_adb_Retrive_timestamp_log:
        case Terminal_adb_Read_and_write_over_SDIO:
        case Terminal_adb_Print_Quick_Tests_Message:
        case Terminal_adb_Create_QT_folder_in_data_folder:
        case Terminal_adb_Load_BurninTester_onto_DUT:
            
        case Terminal_adb_Print_HDMI_Functional_Tests_Message:
        case Terminal_adb_Dump_Voltage_Vs_Frequency_Table_CPU:
        case Terminal_adb_Dump_Voltage_Vs_Frequency_Table_GPU:
        case Terminal_adb_Print_Initial_Os_Setup_Message:
        
        case Terminal_adb_Check_Keystone_fw_checksum:
        
        
        case Terminal_adb_print_component_check_message:
        case Terminal_adb_print_station_check_message:
        
        case Terminal_adb_Create_QT_folder_in_sysconfig_folder:
        case Terminal_adb_create_timestamped_log_file:
        case Terminal_adb_create_SOC_folder:
        case Terminal_adb_verify_timestamp:
        case Terminal_adb_shell_partition_lock:
        case Terminal_adb_remount:
        {
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"<device number>" withString:deviceNumber];
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            HiperTimer* timer = [[HiperTimer alloc] init];
            [timer Start];
            
            while ([timer durationMillisecond] < 10000) {
                
                strReuslt =  [self sendCommand:strCmd  andDelayTime:testDelayTime];
                
                if ([strReuslt length] > 0&& [strReuslt containsString:strRegex]) {
                    break;
                }
            }
            
        }
            break;
        case Terminal_adb_Check_DRAM_info:
        case Terminal_adb_Run_eMMC_Stress_Test:
        case Terminal_adb_Run_DRAM_Stress_Test_memtester:
        
        case Terminal_adb_Stop_logging:
        case Terminal_adb_Read_Keystone_Temp_Sensor:
        case Terminal_adb_Write_timestamp_to_qtresults:
        case Terminal_adb_print_s_biuld_file:
        case Terminal_adb_print_sysconfig_swdl_txt:
        case Terminal_adb_Check_Keystone_Checksum:
        case Terminal_adb_Verify_data_qt_folder_is_created:
        case Terminal_adb_Check_NAND_SerialNumber:
        case Terminal_adb_Check_NAND_HW_MAJOR_REV:
        case Terminal_adb_Check_NAND_Part_Number:
        case Terminal_adb_Check_NAND_Manufacturer_ID:
        case Terminal_adb_print_test_planversion:
        case Terminal_adb_Check_PMIC0_HW_Part_Rev:
        case Terminal_adb_Check_PMIC1_HW_Part_Rev:
        case Terminal_adb_Check_Bleach_FW_Major_Rev:
        case Terminal_adb_Check_Bleach_Device_ID:
        case Terminal_adb_Check_Keystone_fw_major_rev://正则表达式
        case Terminal_adb_Check_Keystone_fw_minor_rev:
        case Terminal_adb_Read_Nand_Bottom_Temp_Sensor:
        case Terminal_adb_Read_Nand_Top_Temp_Sensor:
        case Terminal_adb_Check_NAND_fw_Checksum:
        case Terminal_adb_Check_if_DUT_has_entered_QT_station_previously:
        case Terminal_adb_Write_serial_number_to_both_files:
        case Terminal_adb_Reset_clock_rate_to_original:
        {
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"<device number>" withString:deviceNumber];
            strCmd = [strCmd stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            HiperTimer* timer = [[HiperTimer alloc] init];
            [timer Start];
            
            while ([timer durationMillisecond] < 10000) {
                
                strReuslt =  [self sendCommand:strCmd  andDelayTime:testDelayTime];
                
                if ([strReuslt length] > 0) {
                    break;
                }
            }

            
        }
            
            break;
        default:
            break;
    }
    
    return strReuslt;
}

- (BOOL)isAllNum:(NSString *)string{
    unichar c;
    for (int i=0; i<string.length; i++) {
        c=[string characterAtIndex:i];
        if (!isdigit(c)) {
            return NO;
        }
    }
    return YES;
}

-(NSString*)sendCommand_4:(NSString*)command andDelayTime:(int)time
{
    
    // [teminalLock lock];
    
    NSString* strResult = [[NSString alloc] init];
    
    // @synchronized (self) {
    NSPipe* pipe = [NSPipe pipe];
    
    NSTask* task = [[NSTask alloc] init];
    [task setLaunchPath:@"/bin/bash"];
    NSArray* array = [NSArray arrayWithObjects:@"-c",command, nil];
    [task setArguments:array];
    
    NSDictionary *env = @{@"PWD":[[NSBundle mainBundle] resourcePath],
                          @"PATH":@"/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/usr/local/bin/platform-tools",
                          @"SHELL":@"/bin/bash"};
    
    [task setEnvironment:env];
    
    NSPipe *readPipe = [NSPipe pipe];
    NSFileHandle *readHandle = [readPipe fileHandleForReading];
    NSPipe *writePipe = [NSPipe pipe];
    NSFileHandle *writeHandle = [writePipe fileHandleForWriting];
    [task setStandardInput: writePipe];
    [task setStandardOutput: readPipe];
    
    [writeHandle closeFile];
    [task setStandardError:readPipe];
    
    [task launch];
    
    
    
    return @"1";
}



-(NSString*)sendCommand_3:(NSString*)command andDelayTime:(int)time
{
    
    // [teminalLock lock];
    
    NSString* strResult = [[NSString alloc] init];
    
    // @synchronized (self) {
    NSPipe* pipe = [NSPipe pipe];
    
    NSTask* task = [[NSTask alloc] init];
    [task setLaunchPath:@"/bin/bash"];
    NSArray* array = [NSArray arrayWithObjects:@"-c",command, nil];
    [task setArguments:array];
    
    NSDictionary *env = @{@"PWD":[[NSBundle mainBundle] resourcePath],
                          @"PATH":@"/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/usr/local/bin/platform-tools",
                          @"SHELL":@"/bin/bash"};
    
    [task setEnvironment:env];
    
    NSPipe *readPipe = [NSPipe pipe];
    NSFileHandle *readHandle = [readPipe fileHandleForReading];
    NSPipe *writePipe = [NSPipe pipe];
    NSFileHandle *writeHandle = [writePipe fileHandleForWriting];
    [task setStandardInput: writePipe];
    [task setStandardOutput: readPipe];
    
    [writeHandle closeFile];
    [task setStandardError:readPipe];
    
    [task launch];
    
    [NSThread sleepForTimeInterval:(time*0.001)];
    
    NSData* data = [[readPipe fileHandleForReading] readDataToEndOfFile];
    
    strResult = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    [task waitUntilExit];
    
    return strResult;
}


-(NSString*)sendCommand_2:(NSString*)command andDelayTime:(int)time
{
    // [teminalLock lock];
    
    NSString* strResult = [[NSString alloc] init];
    
    // @synchronized (self) {
    NSPipe* pipe = [NSPipe pipe];
    
    NSTask* task = [[NSTask alloc] init];
    [task setLaunchPath:@"/bin/bash"];
    NSArray* array = [NSArray arrayWithObjects:@"-c",command, nil];
    [task setArguments:array];
    
    NSDictionary *env = @{@"PWD":[[NSBundle mainBundle] resourcePath],
                          @"PATH":@"/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/usr/local/bin/platform-tools",
                          @"SHELL":@"/bin/bash"};
    
    [task setEnvironment:env];
    
    NSPipe *readPipe = [NSPipe pipe];
    NSFileHandle *readHandle = [readPipe fileHandleForReading];
    NSPipe *writePipe = [NSPipe pipe];
    NSFileHandle *writeHandle = [writePipe fileHandleForWriting];
    [task setStandardInput: writePipe];
    [task setStandardOutput: readPipe];
    
    [writeHandle closeFile];
    [task setStandardError:readPipe];
    
    [task launch];
    
    [NSThread sleepForTimeInterval:(time*0.001)];
    
    NSData* data = [[readPipe fileHandleForReading] readDataToEndOfFile];
    
    strResult = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    [task waitUntilExit];
    
    
    return strResult;
}




-(NSString*)sendCommand:(NSString*)command andDelayTime:(int)time
{
    
   // [teminalLock lock];
    
    NSString* strResult = [[NSString alloc] init];
    
   // @synchronized (self) {
        NSPipe* pipe = [NSPipe pipe];
    
        NSTask* task = [[NSTask alloc] init];
        [task setLaunchPath:@"/bin/sh"];
        NSArray* array = [NSArray arrayWithObjects:@"-c",command, nil];
        [task setArguments:array];
        
        [task setStandardOutput:pipe];
        
        [task setStandardError:pipe];
        
        [task launch];
        
        [NSThread sleepForTimeInterval:(time*0.001)];
    
        NSData* data = [[pipe fileHandleForReading] readDataToEndOfFile];
        
        strResult = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
        //[task waitUntilExit];
    
    
    //strResult  = @"1";
    
   // }

   // [teminalLock unlock];
    
    
    return strResult;
}


@end
