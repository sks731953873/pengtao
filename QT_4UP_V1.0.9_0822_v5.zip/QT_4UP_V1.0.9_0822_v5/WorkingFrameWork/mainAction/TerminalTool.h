//
//  MeasurementValueHandle.h
//  QT
//
//  Created by test on 18/07/2018.
//  Copyright © 2018 macjinlongpiaoxu. All rights reserved.
//

#import <Foundation/Foundation.h>


enum TerminalType
{
    Terminal_adb_write_serialnumber,//write serialnumber
    Terminal_adb_wait_device,
    Terminal_adb_root,
    Terminal_adb_remount,
    Terminal_adb_shell_partition_lock,
    Terminal_adb_verify_timestamp,
    Terminal_adb_Create_QT_folder_in_data_folder,//Create QT folder in data folder
    Terminal_adb_Verify_data_qt_folder_is_created,//Verify /data/qt folder is created
    Terminal_adb_print_s_biuld_file,//print s-biuld file
    Terminal_adb_print_sysconfig_swdl_txt,//sysconfig/swdl.txt
    
    Terminal_adb_create_SOC_folder,
    Terminal_adb_create_timestamped_log_file,
    Terminal_adb_Start_logging,//Start logging
    Terminal_adb_Unlock_sysconfig_partition,//Unlock /sysconfig partition
    Terminal_adb_Dump_results_of_SWDL_station,//Dump results of SWDL station
    Terminal_adb_Set_clock_rate_for_480p60,//Set clock rate for 480p60
    
    Terminal_adb_Create_QT_folder_in_sysconfig_folder,
    Terminal_adb_create_QT_Results_file,
    //Write timestamp to qtresults
    Terminal_adb_Write_timestamp_to_qtresults,
    Terminal_adb_write_timestamp_to_both_file,
    Terminal_adb_write_test_planversion_to_both_file,
    Terminal_adb_Dump_results_of_SOC_station,//Dump results of SOC station
    Terminal_adb_print_test_planversion,
    Terminal_adb_Dump_SerialNumber,        //Write serial number to both files
    Terminal_adb_Write_SerialNumber_To_Both_Files,
    Terminal_adb_Reset_clock_rate_to_original,//Reset clock rate to original
    
    
    Terminal_adb_write_station_check_message,
    Terminal_adb_print_station_check_message,
    Terminal_adb_Dump_Results_Of_ICT_Station,
    Terminal_adb_Dump_Results_Of_DFU_Station,
    Terminal_adb_Dump_Results_Of_FCT_Station,
    Terminal_adb_Check_DUT_entered_SOC_station_previously,  //Check if DUT has entered SOC station previously
    Terminal_adb_Check_PMIC0_HW_Part_Rev,//Check PMIC1 HW Part Rev
    Terminal_adb_Check_PMIC1_HW_Part_Rev,
    
    Terminal_adb_Load_BurninTester_onto_DUT,//Load BurninTester.sh onto DUT
    Terminal_adb_Reboot_device_into_factory_mode_always,//Reboot device into factory mode always
    
    Terminal_adb_Check_Bleach_Manufacture_ID,
    Terminal_adb_Check_Bleach_Device_ID,
    Terminal_adb_Check_Bleach_HW_Part_Number,
    Terminal_adb_Check_Bleach_FW_Major_Rev,
    Terminal_adb_Check_DRAM_Manufacturer_ID,
    Terminal_adb_Check_DRAM_HW_Major_Rev,
    Terminal_adb_Check_DRAM_HW_Minor_Rev,
    Terminal_adb_Check_DRAM_Size,
    
    Terminal_adb_Create_andor_Clear_QT_File,
    Terminal_adb_write_component_check_message_to_file,
    Terminal_adb_print_component_check_message,
    Terminal_adb_Change_permission_for_i2c,//Change permission for i2c
    Terminal_adb_Check_NAND_Manufacturer_ID,
    Terminal_adb_Check_NAND_Part_Number,
    Terminal_adb_Check_NAND_HW_MAJOR_REV,
    Terminal_adb_Check_NAND_SerialNumber,
    Terminal_adb_Check_Keystone_Info,//Check Keystone Info
    
    Terminal_adb_Check_NAND_fw_Checksum,
    Terminal_adb_Retrive_data_qt,//Retrive /data/qt
    Terminal_adb_Check_NAND_fw_version,
    Terminal_adb_Check_NAND_Device_Version,
    Terminal_adb_Check_NAND_MFG_Date_Time,
    
    Terminal_adb_Check_Keystone_Manufacture_ID,
    Terminal_adb_Check_Keystone_fw_Device_ID,
    Terminal_adb_Check_Keystone_HW_Part_Number,
    
    Terminal_adb_Check_Keystone_Checksum,
    Terminal_adb_Check_Keystone_fw_major_rev,//Check Keystone Checksum
    Terminal_adb_Check_Keystone_fw_minor_rev,
    Terminal_adb_Check_Keystone_fw_checksum,
    Terminal_adb_Write_Initial_Os_Setup,
    Terminal_adb_Print_Initial_Os_Setup_Message,
    Terminal_adb_Check_Board_ID,
    Terminal_adb_Check_Board_ID_BIT3,
    Terminal_adb_Check_Board_ID_BIT2,
    Terminal_adb_Check_Board_ID_BIT1,
    Terminal_adb_Check_Board_ID_BIT0,
    
    Terminal_adb_Check_Board_Rev_bit0,
    Terminal_adb_Check_Board_Rev_bit1,
    Terminal_adb_Check_Board_Rev_bit2,
    Terminal_adb_Check_Board_Rev_bit3,
    Terminal_adb_Check_Board_Rev_bit,//Check Board Rev, bit 3
    Terminal_adb_Read_Nand_Top_Temp_Sensor,
    Terminal_adb_Read_Nand_Bottom_Temp_Sensor,
    Terminal_adb_Read_SOC_Temp_Sensor,//Read SOC Temp Sensor
    Terminal_adb_Read_Keystone_Temp_Sensor,//Read Keystone Temp Sensor
    
    Terminal_adb_Dump_Voltage_Vs_Frequency_Table_CPU,
    Terminal_adb_Dump_Voltage_Vs_Frequency_Table_GPU,
    
    Terminal_adb_chmod_777_i2cdetect,
    Terminal_adb_Read_PMIC0_Voltage_BUCK0_PP1V8,
    Terminal_adb_Read_PMIC0_Voltage_BUCK1_PP_GPU_DVFS,
    Terminal_adb_Read_PMIC0_BUCK2_PP_CPU_DVFS,
    Terminal_adb_Read_PMIC0_Voltage_BUCK3_PP0V8_CORE,
    Terminal_adb_Read_PMIC1_Voltage_BUCK0_PP3V3_WLBT,
    Terminal_adb_Read_PMIC1_Voltage_BUCK1_PP1V15_WLBT,
    Terminal_adb_Read_PMIC1_Voltage_BUCK2_PP3V3_WLBT,
    Terminal_adb_Read_PMIC1_Voltage_BUCK3_PP1V1_SOC_DDR,

    
    Terminal_adb_Lock_sysconfig_partition,//Lock /sysconfig partition
    Terminal_adb_Write_to_soc_PASS,//Write to soc.txt - PASS
    Terminal_adb_Print_QT_Station_Finish_Message,//Print Quick Tests Message
    Terminal_adb_Write_QT_Station_Finish_Message_to_file,//Write QT Station Finish Message to file
    Terminal_adb_Delete_timestamp_log,//Delete $timestamp.log file
    Terminal_adb_Retrive_timestamp_log,//Retrive $timestamp.log
    Terminal_adb_Stop_logging,//Stop logging
    Terminal_adb_Read_and_write_over_SDIO,//Read and write over SDIO
    Terminal_adb_Retrive_qtresults_log, //Retrive /sysconfig/qt/qtresults.txt
    
    Terminal_adb_Check_if_DUT_has_entered_QT_station_previously,//Check if DUT has entered QT station previously
    Terminal_adb_Print_Quick_Tests_Message,//Print Quick Tests Message
    Terminal_adb_Write_Quick_Tests_Message_to_file,//Write Quick Tests Message to file
    Terminal_adb_Write_HDMI_Functional_Tests_Message_to_file,
    Terminal_adb_Print_HDMI_Functional_Tests_Message,
    Terminal_adb_Enable_Colorbar_Output,
    Terminal_adb_Check_DRAM_info,//Check DRAM info
    Terminal_adb_Run_DRAM_Stress_Test_memtester,//Run DRAM Stress Test: memtester
    Terminal_adb_Run_eMMC_Stress_Test,//Run eMMC Stress Test
    Terminal_adb_Write_serial_number_to_both_files,//Write serial number to both files
    
    Terminal_adb_Characterize_Colorbars_For_480p60_8bpc_RGB ,
    Terminal_adb_Characterize_Colorbars_For_480p60_8bpc_YCbCr,
    Terminal_adb_Characterize_Colorbars_For_720p60_8bpc_RGB,
    
    Terminal_adb_Characterize_Colorbars_For_720p60_8bpc_YCbCr,
    Terminal_adb_Characterize_Colorbars_For_1080p60_8bpc_RGB,
    Terminal_adb_Characterize_Colorbars_For_1080p60_8bpc_YCbCr,
    Terminal_adb_Characterize_Colorbars_For_4k24_8bpc_YCbCr,
    Terminal_adb_Characterize_Colorbars_For_4k30_8bpc_YCbCr,
    Terminal_adb_Characterize_Colorbars_For_4k60_8bpc_YCbCr,
    
    Terminal_adb_Characterize_Colorbars_For_4k60_12bpc_YCbCr,
    Terminal_adb_Characterize_Colorbars_For_4k60_8bpc_RGB,
    Terminal_adb_Characterize_Colorbars_For_4k60_8bpc_YCbCr_1,
    Terminal_adb_Characterize_Colorbars_For_480p60_12bpc_YCbCr ,
    Terminal_adb_Characterize_Colorbars_For_720p60_12bpc_YCbCr,
    Terminal_adb_Characterize_Colorbars_For_1080p60_12bpc_YCbCr,
    Terminal_adb_Characterize_Colorbars_For_4k24_12bpc_YCbCr,
    
    Terminal_adb_Characterize_Colorbars_For_4k30_12bpc_YCbCr,
    Terminal_adb_Characterize_Colorbars_For_4k60_12bpc_YCbCr_1 ,
    
    Terminal_adb_Characterize_Colorbars_For_RGB,
    
    
    Terminal_Default,
};


@interface TerminalTool : NSObject
{
    
}

+(instancetype)shareInstance;

-(NSString*)ReadTerminal:(NSString*)strCmd andTerminalType:(enum TerminalType)terminalType andRegexStr:(NSString*)strRegex deviceNumber:(NSString*)deviceNumber andDelayTime:(int)testDelayTime;
-(void)addGlobalLock;
-(NSString*)sendCommand:(NSString*)command andDelayTime:(int)time;

@end
