//
//  MeasurementValueHandle.h
//  QT
//
//  Created by test on 18/07/2018.
//  Copyright © 2018 macjinlongpiaoxu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TerminalTool.h"

enum Device
{
    Device_Fixture,
    Device_Agilent,
    Device_Default=Device_Fixture,
};


@interface MeasurementValueHandle : NSObject

+(instancetype)shareInstance;

-(BOOL)RegexDeviceNoDigitalValue:(NSString*)strResult andRegex:(NSString*)strRegex andTerminalType:(enum TerminalType)terminalType;

-(NSMutableArray*)RegexDeviceDigitalValue:(NSString*)strResult andRegex:(NSString*)strRegex andTerminalType:(enum TerminalType)terminalType;

-(NSMutableArray*)parseTxt:(NSString*)content withPattern:(NSString*)pattern;
@end
