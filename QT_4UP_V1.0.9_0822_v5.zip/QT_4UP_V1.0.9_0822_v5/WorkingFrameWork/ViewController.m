//
//  ViewController.m
//  WorkingFrameWork
//
//  Created by mac on 2017/10/27.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
// F0T82330000JKLW0V／F0T82330000JKLW1S／F0T82330000JKLW2P／F0T82330000JKLW3L

#import "ViewController.h"
#import "Table.h"
#import "Plist.h"
#import "Param.h"
#import "TestAction.h"
#import "MKTimer.h"
#import "AppDelegate.h"
#import "Folder.h"
#import "GetTimeDay.h"
#import "FileCSV.h"
//#import "visa.h"
#import "SerialPort.h"
#import "Common.h"
#import "TestStep.h"
#import "BYDSFCManager.h"
#import "ManagerPdca.h"
#import "Alert.h"
#import "TerminalTool.h"
#import "MeasurementValueHandle.h"

//文件名称
NSString * param_Name = @"Param";

@interface ViewController()<NSTextFieldDelegate>
{
    Table * tab1;
    Table * tab2;
    
    Alert      *   alert;
    
    Folder   * fold;
    FileCSV  * csvFile;
    
    NSThread * thread;
    
    Plist * plist;
    Param * param;
//    SerialPort *   scanSerialPort1;        //控制板类
//    SerialPort *   scanSerialPort2;
//    SerialPort *   scanSerialPort3;
//    SerialPort *   scanSerialPort4;
    
    
//    SerialPort *   humiturePort;      //温湿度控制类
    NSArray    *   itemArr1;
    NSArray    *   itemArr2;
    
    TestAction * action1;
    TestAction * action2;
    TestAction * action3;
    TestAction * action4;
    
    ManagerPdca * pdca;               //上传PDCA
    
    //定时器相关
     MKTimer * mkTimer;
     int      ct_cnt;                  //记录cycle time定时器中断的次数
    
    IBOutlet NSPopUpButton *testCount;
    
    __weak IBOutlet NSPopUpButton *popupUsb;
    
    IBOutlet NSTextField *NS_TF1;                     //产品1输入框
    IBOutlet NSTextField *NS_TF2;                     //产品2输入框
    IBOutlet NSTextField *NS_TF3;                     //产品3输入框
    IBOutlet NSTextField *NS_TF4;                     //产品4输入框
    
    
    IBOutlet NSTextView *Log_View;                    //Log日志
    
    IBOutlet NSTextField *  Status_TF;                //显示状态栏
    IBOutlet NSTextField *  testFieldTimes;           //时间显示输入框

    IBOutlet NSTextField *  TestCount_TF;             //测试的次数
    IBOutlet NSButton    *  IsUploadPDCA_Button;      //上传PDCA的按钮
    IBOutlet NSButton    *  IsUploadSFC_Button;       //上传SFC的按钮
    IBOutlet NSTextField *  Version_TF;               //软件版本
    
    
    IBOutlet NSTextView *A_LOG_TF;
    IBOutlet NSTextView *B_LOG_TF;
    IBOutlet NSTextView *C_LOG_TF;
    IBOutlet NSTextView *D_LOG_TF;
    
    IBOutlet NSTextView *A_FailItem;
    IBOutlet NSTextView *B_FailItem;
    IBOutlet NSTextView *C_FailItem;
    IBOutlet NSTextView *D_FailItem;
    
    
    IBOutlet NSButton *choose_dut1;
    IBOutlet NSButton *choose_dut2;
    IBOutlet NSButton *choose_dut3;
    IBOutlet NSButton *choose_dut4;
    
    
    
    IBOutlet NSButton      *startbutton;
    IBOutlet NSButton      *ComfirmButton;
    IBOutlet NSButton      *singlebutton;
    
    int index;
    //创建相关的属性
    NSString * foldDir;               //config属性总文件
    NSString * totalFold;             //所有文件总文件
    NSString * totalPath;             //包含到cr的文件路径
    
    //温湿度相关属性
    NSString             * humitureString;
    NSString             * temptureString;
    
    //测试结束通知中返回的对象===数据中含有P代表成功，含有F代表失败
    NSString             * notiString_A;
    NSString             * notiString_B;
    NSString             * notiString_C;
    NSString             * notiString_D;
    NSString             * testingFixStr;         //正在测试的治具
    
    //产品通过的的次数和测试的总数
    int                   passNum;             //通过的测试次数
    int                   totalNum;            //通过的测试总数
    int                   nullNum;             //空测试完成的次数
    int                   fix_A_num;
    int                   fix_B_num;
    int                   fix_C_num;
    int                   fix_D_num;
  
//
    
    int                   testnum;            //传送过来产品的总个数

    int                   testNum;
    
    NSMutableDictionary        * config_Dic;  //相关的配置参数属
    
    BOOL                        singleTest;         //产品单个测试
    NSString                  * fixtureID;         //fixture的值
    
    //===================新增的项
    TestStep                  * testStep;
    BYDSFCManager             * sfcManager;
    NSDictionary              * A_resultDic;  //接收A通道的测试数据
    NSDictionary              * B_resultDic;  //接收B通道的测试数据
    NSDictionary              * C_resultDic;  //接收C通道的测试数据
    NSDictionary              * D_resultDic;  //接收D通道的测试数据
    
    //===================NG的产品
     NSMutableArray           * snArr;         //SN的字符串数组
     NSMutableArray           * SnArr_TF;      //SN TextField数组
    
    //===================通过可变数组的大小，判断当前有几个在测试
    NSMutableArray            *ChooseNumArray; //测试个数
    //===================工位数据生成地址单独设置
    BOOL                      isUpLoadSFC;
    BOOL                      isUpLoadPDCA;
    
    BOOL                      isLoopTest;      //循环测试
    BOOL                      isComfirmOK;     //单个模式选项是否确认
}

@end

@implementation ViewController


//软件测试整个流程  //door close--->SN---->config-->监测start--->下压气缸---->抛出SN-->直接运行


- (void)viewDidLoad
{
    [super viewDidLoad];
    //测试区
    
    NSLog(@"testCount: %@", testCount.titleOfSelectedItem);
    //整型变量定义区
    index    = 0;
    passNum  = 0;
    totalNum = 0;
    nullNum  = 0;
    
    fix_A_num = 0;
    fix_B_num = 0;
    fix_C_num = 0;
    fix_D_num = 0;
    testnum   = 0;
    testNum = 0;
    testingFixStr = @"";
    
    
    
    //BOOL变量
    singleTest   = NO;
    isUpLoadSFC  = YES;
    isUpLoadPDCA = YES;
    isLoopTest   = NO;
    isComfirmOK  = NO;
    //新增内容
    testStep = [TestStep Instance];
    
    config_Dic = [[NSMutableDictionary alloc]initWithCapacity:10];
    plist = [Plist shareInstance];
    param = [[Param alloc]init];
    [param ParamRead:param_Name];
    snArr = [[NSMutableArray alloc] initWithCapacity:10];
    SnArr_TF = [[NSMutableArray alloc] initWithCapacity:10];
    ChooseNumArray =[[NSMutableArray alloc] initWithCapacity:10];
    
    [config_Dic setValue:param.sw_ver forKey:kSoftwareVersion];
    [Version_TF setStringValue:param.sw_ver];
    
    
     alert = [Alert shareInstance];
    //第一响应
    [NS_TF1 acceptsFirstResponder];
    //加载界面
    itemArr1 = [plist PlistRead:@"QT_Station" Key:@"AllItems"];
    tab1 = [[Table  alloc] init:Tab1_View DisplayData:itemArr1];
    
    //初始化温湿度和主控板
//     humiturePort = [[SerialPort alloc]init];
//    [humiturePort setTimeout:1 WriteTimeout:1];
//     scanSerialPort1   = [[SerialPort alloc]init];
//    [serialport setTimeout:1 WriteTimeout:1];
 
//    scanSerialPort2   = [[SerialPort alloc]init];
//    scanSerialPort3   = [[SerialPort alloc]init];
//    scanSerialPort4   = [[SerialPort alloc]init];
    
    
    //软件初始化
    A_resultDic = [[NSDictionary alloc] init];
    B_resultDic = [[NSDictionary alloc] init];
    C_resultDic = [[NSDictionary alloc] init];
    D_resultDic = [[NSDictionary alloc] init];
    
    //开启定时器
    mkTimer = [[MKTimer alloc] init];
    //创建总文件
    fold    = [[Folder alloc] init];
    csvFile = [[FileCSV alloc] init];
    
    //保存路径
    totalPath = [NSString stringWithFormat:@"%@/%@/%@_%@",param.foldDir,[[GetTimeDay shareInstance] getCurrentDay],param.sw_name,param.sw_ver];
    [[NSUserDefaults standardUserDefaults] setValue:totalPath forKey:kTotalFoldPath];

    
    //上传相关文件
    testStep   = [TestStep Instance];
    sfcManager = [BYDSFCManager Instance];
    pdca       = [[ManagerPdca alloc]init];
    
    //监听测试结束，重新等待SN
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(selectSnChangeNoti:) name:@"SNChangeNotice" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(selectTestModeNotice:) name:kTestModeNotice object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(selectSfc_PDCAUpload:) name:kSfcUploadNotice object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(selectSfc_PDCAUpload:) name:kPdcaUploadNotice object:nil];
    
    
    
    
//    //监听仪器是否有断开连接
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(selectInstrument:) name:kInStrumentNotice object:nil];
    
    //开启4条线程
    [self createThreadWithNum:1];
    [self createThreadWithNum:2];
    [self createThreadWithNum:3];
    [self createThreadWithNum:4];

    
    thread = [[NSThread alloc] initWithTarget:self selector:@selector(Working) object:nil];
    [thread start];
}

- (IBAction)ChooseTestNum:(id)sender {
    
    NSMutableDictionary* dic = [[NSMutableDictionary alloc] init];
    [dic setValue:[NSString stringWithFormat:@"%@", testCount.titleOfSelectedItem] forKey:@"testCount"];
    
    //[[NSNotificationCenter defaultCenter] postNotificationName:kTestNum userInfo:dic];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:kTestNum object:nil  userInfo:dic];
    
}


#pragma mark=======================开始测试
- (IBAction)start_Action:(id)sender
{
    
    if (singleTest)
    {
        
        if (isComfirmOK)
        {
            index = 8;
            startbutton.enabled = NO;
        }
        else
        {
            [Status_TF setStringValue:@"请点击Comfirm确认选项"];
        }
    }
    else
    {
        index = 8;
        startbutton.enabled = NO;
    }
}

-(int)HexStrToInt:(NSString*)hexStr
{
    int result = 0;
    NSString* str = [[hexStr uppercaseString] stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    for (int i = 0; i < [str length]; i++)
    {
        int charValue = [str characterAtIndex:i];
        
        if ((charValue >= '0') && (charValue <= '9'))
        {
            result += (charValue - '0') * pow(16, ([str length] - 1 -i));
        }
        else if ((charValue >= 'A') && (charValue <= 'F'))
        {
            result += (charValue - 'A' + 10) * pow(16, ([str length] - 1 -i));
        }
    }
    
    return result;
}


- (IBAction)refreshUsbAction:(id)sender {
    
    TerminalTool* terminalTool = [TerminalTool shareInstance];
    MeasurementValueHandle* measureTool = [MeasurementValueHandle shareInstance];
    
    NSString* terminalStr = [terminalTool sendCommand:@"/usr/local/bin/platform-tools/adb devices -l" andDelayTime:1000];
    NSArray* array = [measureTool RegexDeviceDigitalValue:terminalStr andRegex:@".*?usb:(.*?)\\s.*?" andTerminalType:Terminal_adb_Start_logging];
    
    
    NSMutableArray  * arr = [NSMutableArray arrayWithArray:array];
    [arr addObject:@"NULL"];
    
    
    
    //显示在界面PopButton按钮上
    [popupUsb addItemsWithTitles:arr];
    [popupUsb addItemsWithTitles:arr];
    [popupUsb addItemsWithTitles:arr];
    [popupUsb addItemsWithTitles:arr];
    
}


#pragma mark----------scanAction


#pragma mark=======================通道测试完成通知
//=============================================
-(void)selectSnChangeNoti:(NSNotification *)noti
{
    
     totalNum++;

    if ([noti.object containsString:@"1"]) {
        

        fix_A_num = 101;
        notiString_A = noti.object;
        A_resultDic =  [noti.userInfo mutableCopy];
        
        NSLog(@"A_resultDic：%@",noti.userInfo);
        
        if ([noti.object containsString:@"X"]) {
            
            totalNum--;
        }
        
        NSLog(@"fixture_A 测试已经完成了");
    }
    if ([noti.object containsString:@"2"]) {
        
        fix_B_num = 102;
        notiString_B = noti.object;
        B_resultDic  = noti.userInfo;
         NSLog(@"B_resultDic：%@",B_resultDic);

        NSLog(@"fixture_B 测试已经完成了");
        if ([noti.object containsString:@"X"]) {
            
            totalNum--;
        }
    }
    if ([noti.object containsString:@"3"]) {
        
         fix_C_num = 103;
         notiString_C = noti.object;
         C_resultDic = noti.userInfo;
        
        NSLog(@"fixture_C 测试已经完成了");
        
        if ([noti.object containsString:@"X"]) {
            
            totalNum--;
        }
    }
    if ([noti.object containsString:@"4"]) {
        
        fix_D_num = 104;
        notiString_D = noti.object;
        D_resultDic = noti.userInfo;
        NSLog(@"fixture_D 测试已经完成了");
        
        if ([noti.object containsString:@"X"]) {
            
            totalNum--;
        }
    }
}



-(void)Working
{
    
    while ([[NSThread currentThread] isCancelled]==NO) //线程未结束一直处于循环状态
    {
        
#pragma mark-------------//index = 0,初始化控制板串口
        if (index == 0)
        {
            
            [NSThread sleepForTimeInterval:0.5];
            
//            BOOL  isOpen1 = [scanSerialPort1 Open:param.scanner_uart_port_name1];
//            [NSThread sleepForTimeInterval:0.5];
//            BOOL  isOpen2 = [scanSerialPort2 Open:param.scanner_uart_port_name2];
//            [NSThread sleepForTimeInterval:0.5];
//            BOOL  isOpen3 = [scanSerialPort2 Open:param.scanner_uart_port_name3];
//            [NSThread sleepForTimeInterval:0.5];
//            BOOL  isOpen4 = [scanSerialPort2 Open:param.scanner_uart_port_name4];
//            [NSThread sleepForTimeInterval:0.5];
//            
            if (param.isDebug)
            {
                
                  NSLog(@"index = 0,debug中，模拟控制板初始化");
                 [self UpdateTextView:@"index = 0,模拟控制板初始化" andClear:NO andTextView:Log_View];
                
//                if(isOpen1&&isOpen2&&isOpen3&&isOpen4)
//                {
//                    dispatch_async(dispatch_get_main_queue(), ^{
//                        [Status_TF setStringValue:@"index=0,4 scanner  connect success"];
//                    });
//    
//                    [self UpdateTextView:@"index = 0,4 scanner success" andClear:NO andTextView:Log_View];
//    
//                    [NSThread sleepForTimeInterval:0.2];
//    
//                    [scanSerialPort1 WriteLine:@"+"];
//    
//                    [NSThread sleepForTimeInterval:0.5];
//    
//                    fixtureID = [scanSerialPort1 ReadExisting];
//    
//    
//                    if ([fixtureID length]>0)
//                    {
//                         index = 1;
//                    }
//                    else
//                    {
//                        dispatch_async(dispatch_get_main_queue(), ^{
//                            [Status_TF setStringValue:@"请检查治具电源"];
//                        });
//                    }
//    
//                    //开始测试时，气缸弹出来
////                    while (YES)
////                    {
////                        [NSThread sleepForTimeInterval:0.2];
////                        [serialport WriteLine:@"reset"];
////                        [NSThread sleepForTimeInterval:0.5];
////                        NSString * backstring = [serialport ReadExisting];
////                        
////                        if ([backstring containsString:@"OK"])
////                        {
////                            break;
////                        }
////                    }
//                }
                
                
                 dispatch_async(dispatch_get_main_queue(), ^{
                     [Status_TF setStringValue:@"index = 0,Debug:控制板初始化"];
                 });
                
                 sfcManager.station_id = @"YF-L01-FATP-AOI-01";
                 index = 1;
            }
//            else if(isOpen)
//            {
//                dispatch_async(dispatch_get_main_queue(), ^{
//                    [Status_TF setStringValue:@"index=0,Controller Board connect success"];
//                });
//                
//                [self UpdateTextView:@"index = 0,FIX-O connect success" andClear:NO andTextView:Log_View];
//                
//                [NSThread sleepForTimeInterval:0.2];
//                
//                [serialport WriteLine:@"Fixture ID?"];
//                
//                [NSThread sleepForTimeInterval:0.5];
//                
//                fixtureID = [serialport ReadExisting];
//                
//                
//                if ([fixtureID containsString:@"\r\n"])
//                {
//                    fixtureID = [[fixtureID componentsSeparatedByString:@"\r\n"] objectAtIndex:1];
//                    fixtureID = [fixtureID stringByReplacingOccurrencesOfString:@"*_*" withString:@""];
//                }
//
//                sfcManager.station_id = fixtureID;
//                
//                if ([fixtureID length]>0)
//                {
//                     index = 1;
//                }
//                else
//                {
//                    dispatch_async(dispatch_get_main_queue(), ^{
//                        [Status_TF setStringValue:@"请检查治具电源"];
//                    });
//                }
//                
//                //开始测试时，气缸弹出来
//                while (YES)
//                {
//                    [NSThread sleepForTimeInterval:0.2];
//                    [serialport WriteLine:@"reset"];
//                    [NSThread sleepForTimeInterval:0.5];
//                    NSString * backstring = [serialport ReadExisting];
//                    
//                    if ([backstring containsString:@"OK"])
//                    {
//                        break;
//                    }
//                }
//            }
            else
            {
                NSLog(@"控制板打开失败");
                dispatch_async(dispatch_get_main_queue(), ^{
                    [Status_TF setStringValue:@"Controller Board connect fail"];
                });
                [self UpdateTextView:@"index = 0,控制板打开失败" andClear:NO andTextView:Log_View];
            }
        }
        
        
#pragma mark-------------//index=1,初始化温湿度板子
        if (index == 1) {
            
            if (param.isDebug)
            {
                NSLog(@"index = 1,debug 模式中");
                [self UpdateTextView:@"index = 1,debug 模式中,模拟温湿度板子初始化" andClear:NO andTextView:Log_View];
                index = 2;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [Status_TF setStringValue:@"index = 0,Debug:温湿度初始化"];
                });
            }
//            else if (!humiturePort.IsOpen)
//            {
//                 BOOL  isOpen = [humiturePort Open:param.humiture_uart_port_name];
//                 if (isOpen) {
//                     
//                    dispatch_async(dispatch_get_main_queue(), ^{
//                        [Status_TF setStringValue:@"index=1,Humiture connect success"];
//                    });
//                     
//                     
//                    //获取温湿度的值
//                    [humiturePort WriteLine:@"Read"];
//                    [NSThread sleepForTimeInterval:0.5];
//                    NSString  * back_humitureStr = [[humiturePort ReadExisting] stringByReplacingOccurrencesOfString:@"\n" withString:@""];
//                    back_humitureStr= [back_humitureStr stringByReplacingOccurrencesOfString:@"\r" withString:@""];
//                    
//
//                     
//                     if ([back_humitureStr containsString:@","])
//                     {
//                         
//                         NSArray  * arr = [back_humitureStr componentsSeparatedByString:@","];
//                
//                         //存储温湿度
//                         [config_Dic setValue:[arr[1] stringByReplacingOccurrencesOfString:@"%" withString:@""] forKey:kHumit];
//                         [config_Dic setValue:arr[0] forKey:kTemp];
//                        
//                     }
//                     
//                    [self UpdateTextView:@"index = 1,温湿度连接成功" andClear:NO andTextView:Log_View];
//                    index = 2;
//                }
//                else
//                {
//                    dispatch_async(dispatch_get_main_queue(), ^{
//                        [Status_TF setStringValue:@"index=1,Humiture connect Fail"];
//                    });
//                }
//            }
            else
            {
                NSLog(@"温湿度打开成功");
                dispatch_async(dispatch_get_main_queue(), ^{
                    [Status_TF setStringValue:@"index=1,Humiture connect success"];
                });
                
                //获取温湿度的值
//                [humiturePort WriteLine:@"Read"];
//                [NSThread sleepForTimeInterval:0.5];
//                NSString  * back_humitureStr = [humiturePort ReadExisting];
                

                
//                if ([back_humitureStr containsString:@","])
//                {
//                    
//                    NSArray  * arr = [back_humitureStr componentsSeparatedByString:@","];
//                    
//                
//                    //存储温湿度
//                    [config_Dic setValue:arr[0] forKey:kTemp];
//                
//                    [config_Dic setValue:[arr[1] stringByReplacingOccurrencesOfString:@"%" withString:@""] forKey:kHumit];
//                
//                }
                
                index = 2;
            }
        }
        

#pragma mark-------------//index = 2,请选择测试项
        if (index == 2)
        {
            index = 3;
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [Status_TF setStringValue:@"index = 3,开始检测SN"];
            });
        }
        
        
#pragma mark-------------//index = 3,检测SN1的输入值
        if (index == 3) {
            
            [NSThread sleepForTimeInterval:0.5];
            sfcManager.station_id = fixtureID;
            testnum = 0;
            
            if (param.isDebug&&singleTest) {
                
                if (choose_dut1.state) {
                    
                    [self ShowcompareNumwithTextField:NS_TF1 Index:3 SnIndex:1];
                    
                    //action1.dut_sn = NS_TF1.stringValue;
                    action1.isTest = YES;
                }
                else
                {
                    index = 4;
                    action1.isTest = NO;
                }
                
            }
            else if (param.isDebug){
                
                if ([NS_TF1.stringValue length] == 17) {
                    //action1.dut_sn = [NS_TF1 stringValue];
                    index = 4;
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        [Status_TF setStringValue:@"index = 3,SN1 is OK"];
                    });
                    
                    
                    if (isUpLoadSFC)
                    {
                        [self compareSNToServerwithTextField:NS_TF1 Index:3 SnIndex:1];
                    }
                    
                    
                }
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [Status_TF setStringValue:@"index = 3,SN1 is Wrong"];
                    
                });
            }
            else if (singleTest){
                if (choose_dut1.state) {
                    
                    if (isUpLoadSFC)
                    {
                        [self compareSNToServerwithTextField:NS_TF1 Index:3 SnIndex:1];
                    }
                    else
                    {
                        [self ShowcompareNumwithTextField:NS_TF1 Index:3 SnIndex:1];
                    }
                   // action1.dut_sn = NS_TF1.stringValue;
                    action1.isTest = YES;
                }
                else
                {
                    index = 4;
                    action1.isTest = NO;
                }
            }
            else{
                
                if (isUpLoadSFC) {
                    [self compareSNToServerwithTextField:NS_TF1 Index:3 SnIndex:1];
                }
                else
                {
                    [self ShowcompareNumwithTextField:NS_TF1 Index:3 SnIndex:1];
                }
                
                //action1.dut_sn = NS_TF1.stringValue;
                action1.isTest = YES;
            }
            
        }
        
#pragma mark-------------//index = 4,检测SN2的输入值
        if (index == 4) {
            
            [NSThread sleepForTimeInterval:0.5];
            
            if (param.isDebug&&singleTest) {
                
                if (choose_dut2.state)
                {
                    [self ShowcompareNumwithTextField:NS_TF2 Index:4 SnIndex:2];
                   // action2.dut_sn = NS_TF2.stringValue;
                    action2.isTest = YES;
                }
                else
                {
                    index = 5;
                    action2.isTest = NO;
                }
            }
            else if (param.isDebug) {
                
                if ([NS_TF2.stringValue length] == 17) {
                    //action2.dut_sn = [NS_TF2 stringValue];
                    index = 5;
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        [Status_TF setStringValue:@"index = 4,SN2 is OK"];
                    });
                }
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [Status_TF setStringValue:@"index = 4,SN2 is Wrong"];
                });
                
                if (isUpLoadSFC) {
                    
                    [self compareSNToServerwithTextField:NS_TF2 Index:4 SnIndex:2];
                    
                }
            }
            else if (singleTest) {
                
                if (choose_dut2.state)
                {
                    
                    if (isUpLoadSFC) {
                         [self compareSNToServerwithTextField:NS_TF2 Index:4 SnIndex:2];
                    }
                    else
                    {
                         [self ShowcompareNumwithTextField:NS_TF2 Index:4 SnIndex:2];
                    }
                   
                   // action2.dut_sn = NS_TF2.stringValue;
                    action2.isTest = YES;
                }
                else
                {
                    index = 5;
                    action2.isTest = NO;
                }
            }
            else
            {
                if (isUpLoadSFC)
                {
                     [self compareSNToServerwithTextField:NS_TF2 Index:4 SnIndex:2];
                }
                else
                {
                     [self ShowcompareNumwithTextField:NS_TF2 Index:4 SnIndex:2];
                    
                    if ([NS_TF2.stringValue length] == 17) {
                        
                        index = index  + 2;
                    }
                }
                
                //action2.dut_sn = NS_TF2.stringValue;
                action2.isTest = YES;
            }
        }
        
#pragma mark-------------//index = 5,检测SN3的输入值
        if (index == 5) {
            
            [NSThread sleepForTimeInterval:0.5];
            
            if (param.isDebug&&singleTest) {
                
                if (choose_dut3.state) {
                    [self ShowcompareNumwithTextField:NS_TF3 Index:5 SnIndex:3];
                    //action3.dut_sn = NS_TF3.stringValue;
                    action3.isTest = YES;
                }
                else
                {
                    index = 6;
                    action3.isTest = NO;
                }
            }
           else if (param.isDebug)
           {
                
                if ([NS_TF3.stringValue length] == 17)
                {
                    //action3.dut_sn = [NS_TF3 stringValue];
                    index = 6;
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        [Status_TF setStringValue:@"index = 5,SN3 is OK"];
                    });
                }
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [Status_TF setStringValue:@"index = 5,SN3 is wrong"];
                });
               
               if (isUpLoadSFC)
               {
                   
                   [self compareSNToServerwithTextField:NS_TF3 Index:5 SnIndex:3];
               }
               
               
            }
            else if (singleTest)
            {
                if (choose_dut3.state) {
                    
                    if (isUpLoadSFC) {
                        
                      [self compareSNToServerwithTextField:NS_TF3 Index:5 SnIndex:3];
                    }
                    else
                    {
                      [self ShowcompareNumwithTextField:NS_TF3 Index:5 SnIndex:3];
                    }
                    
                    //action3.dut_sn = NS_TF3.stringValue;
                    action3.isTest = YES;
                }
                else
                {
                    index = 6;
                    action3.isTest = NO;
                }
            }
            else
            {
                
                if (isUpLoadSFC)
                {
                    [self compareSNToServerwithTextField:NS_TF3 Index:5 SnIndex:3];
                }
                else
                {
                    [self ShowcompareNumwithTextField:NS_TF3 Index:5 SnIndex:3];
                }
                
                //action3.dut_sn = NS_TF3.stringValue;
                action3.isTest = YES;
            }
        }
        
#pragma mark-------------//index = 6,检测SN4的输入值
        
        if (index == 6) {
            
            [NSThread sleepForTimeInterval:0.5];
           
            if (param.isDebug&&singleTest) {
                
                if (choose_dut4.state) {
                    [self ShowcompareNumwithTextField:NS_TF4 Index:6 SnIndex:4];
                    //action4.dut_sn = NS_TF4.stringValue;
                    action4.isTest = YES;
                }
                else
                {
                    index = 7;
                    action4.isTest = NO;
                }
                
            }
           else if (param.isDebug)
           {
                
                if ([NS_TF4.stringValue length] == 17) {
                    //action4.dut_sn = [NS_TF4 stringValue];
                    index = 7;
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        [Status_TF setStringValue:@"index = 6,SN4 is OK"];
                    });
                }
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [Status_TF setStringValue:@"index = 6,SN4 is Wrong"];
                });
                
                if (isUpLoadSFC)
                {
                    [self compareSNToServerwithTextField:NS_TF4 Index:6 SnIndex:4];
                }
            }
            else if (singleTest) {
                
                if (choose_dut4.state) {
                    
                    if (isUpLoadSFC) {
                        
                        [self compareSNToServerwithTextField:NS_TF4 Index:6 SnIndex:4];
                    }
                    else
                    {
                         [self ShowcompareNumwithTextField:NS_TF4 Index:6 SnIndex:4];
                    }
                    //action4.dut_sn = NS_TF4.stringValue;
                    action4.isTest = YES;
                }
                else
                {
                    index = 7;
                    action4.isTest = NO;
                }
            }
            else
            {
                if (isUpLoadSFC) {
                     [self compareSNToServerwithTextField:NS_TF4 Index:6 SnIndex:4];
                }
                else
                {
                    [self ShowcompareNumwithTextField:NS_TF4 Index:6 SnIndex:4];
                }
                
                 //action4.dut_sn = NS_TF4.stringValue;
                 action4.isTest = YES;
            }
            
        }
        
#pragma mark------------//index=7,判断当前配置文件和changeID等配置
        if (index == 7) { //判断当前配置文件和changeID等配置
            
            [NSThread sleepForTimeInterval:0.3];
           
           
                
                if (NS_TF1.stringValue.length == 17)
                {
                    testNum = 1;
                }
                if (NS_TF1.stringValue.length == 17&&NS_TF2.stringValue.length == 17)
                {
                    testNum = 2;
                }
                if (NS_TF1.stringValue.length == 17&&NS_TF2.stringValue.length == 17&&NS_TF3.stringValue.length == 17)
                {
                    testNum = 3;
                }
            
                if (NS_TF1.stringValue.length == 17&&NS_TF2.stringValue.length == 17&&NS_TF3.stringValue.length == 17&&NS_TF4.stringValue.length == 17)
                {
                    testNum = 4;
                }
            
            
                [NSThread sleepForTimeInterval:1];
                
                NSMutableDictionary* dic = [[NSMutableDictionary alloc] init];
                [dic setValue:[NSString stringWithFormat:@"%d", testNum] forKey:@"testCount"];
                
                
                [[NSNotificationCenter defaultCenter] postNotificationName:kTestNum object:nil  userInfo:dic];
                
            
            //配置好了，将相关参数传送
            if (action1!=nil) {
                
                
                action1.Config_Dic = [NSDictionary dictionaryWithDictionary:config_Dic];
                
            }
            if (action2!=nil) {
                action2.Config_Dic = [NSDictionary dictionaryWithDictionary:config_Dic];
                
            }
            if (action3!=nil) {
                action3.Config_Dic = [NSDictionary dictionaryWithDictionary:config_Dic];
                
            }
            if (action4!=nil)
            {
                action4.Config_Dic = [NSDictionary dictionaryWithDictionary:config_Dic];
            }
            
            if (!isLoopTest) {
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [tab1 ClearTable];
                    
                    [DUT_Result1_TF setStringValue:@""];
                    [DUT_Result2_TF setStringValue:@""];
                    [DUT_Result3_TF setStringValue:@""];
                    [DUT_Result4_TF setStringValue:@""];
                    startbutton.enabled = YES;
                    [Status_TF setStringValue:@"Index = 8,Click Start Button"];
                    
                });
                
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [tab1 ClearTable];
                    
                });
                
            }
        
            [self UpdateTextView:@"index=7,参数已经配置好" andClear:NO andTextView:Log_View];
            
            
            
            
            if(isLoopTest){
                
                index = 8;
                testnum = 0;
            }
            else{
                
                index = 1000;
                
            }
        }
        
        
#pragma mark-------------//index=8,双击start按钮/或者点击界面上的start按钮
        if (index == 8) {
            
            
//            if (!startbutton.enabled)
//            {
//                [serialport WriteLine:@"start"];
//            }
            
             [NSThread sleepForTimeInterval:0.5];
             // NSString  * backstring = [serialport ReadExisting];
            
            if (param.isDebug) {
                NSLog(@"index = 8,debug 模式中");
                [self UpdateTextView:@"index = 8,debug 模式中,监测双击启动" andClear:NO andTextView:Log_View];
                index = 9;
            }
//            else if ([backstring containsString:@"START"]&&[backstring containsString:@"*_*\r\n"])
//            {
//                NSLog(@"检测START，软件开始测试");
//                
//                dispatch_async(dispatch_get_main_queue(), ^{
//                    
//                    [Status_TF setStringValue:@"index=9,Start OK"];
//                    
//                });
//                
//                [self UpdateTextView:@"index=9,Start OK" andClear:NO andTextView:Log_View];
//                
//                index = 9;
//                
//            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [Status_TF setStringValue:@"index=8,Start NG,请启动"];
                });
                
                [self UpdateTextView:@"Start NG,请启动" andClear:NO andTextView:Log_View];
            }
        }

 #pragma mark-------------//index=9,发送开始测试的通知
        if (index == 9)
        {
            //给SN赋值
            action1.dut_sn = NS_TF1.stringValue;
            action2.dut_sn = NS_TF2.stringValue;
            action3.dut_sn = NS_TF3.stringValue;
            action4.dut_sn = NS_TF4.stringValue;
            
            
            [[NSNotificationCenter defaultCenter] postNotificationName:@"NSThreadStart_Notification" object:nil];
            
            dispatch_async(dispatch_get_main_queue(), ^{

                startbutton.enabled = NO;
               // ReloadButton.hidden = YES;
            });
            
            
            [testFieldTimes setStringValue:@"0"];
            [mkTimer setTimer:0.1];
            [mkTimer startTimerWithTextField:testFieldTimes];
            ct_cnt = 1;
            [self UpdateTextView:@"index = 10,程序开始测试" andClear:NO andTextView:Log_View];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [Status_TF setStringValue:@"index=10, Testing......"];
            });
            
            if(isLoopTest){
                
                index = 1000;
                
            }
            else{
                
                index = 1000;
            }
            
        }
        
        
#pragma mark-------------//index=101,A治具测试结束，发送指令信号灯
        if (fix_A_num == 101) {
            
            [NSThread sleepForTimeInterval:0.3];
            
            testingFixStr = @"ASN1";
            
            if (param.isDebug&&!isLoopTest)
            {
                
                NSLog(@"治具A测试完毕，灯光操作完成");

                //testnum++;
                //fix_A_num =0;
                
                if (![notiString_A containsString:@"X"]&&isUpLoadPDCA==YES&&!isLoopTest) {
                    [self UpdateTextView:@"fix_A_num = 101,治具A灯光操作已经完成" andClear:NO andTextView:Log_View];
                    
                    [pdca UploadPDCA_Dafen:1 Dic:A_resultDic Arr:itemArr1 BOOL:[notiString_A containsString:@"P"]?YES:NO];
                    
                    NSLog(@"fix_C_num = 101");
                }
                
                
                [self LightAndShowResultWithFix:notiString_A TestingFixStr:testingFixStr Dictionary:A_resultDic];
                
                
//                if ([notiString_A containsString:@"P"]) {
//                    
//                    passNum++;
//                }
                
//                if (testnum==[ChooseNumArray count]||testnum== 4) {
//                    
//                    index = 105;
//                    
//                    NSLog(@"A====%d",testnum);
//                }
            }
            else
            {
                
                //上传PDCA
                if (![notiString_A containsString:@"X"]&&isUpLoadPDCA==YES) {
                    
                    [pdca UploadPDCA_Dafen:1 Dic:A_resultDic Arr:itemArr1 BOOL:[notiString_A containsString:@"P"]?YES:NO];
                }

                
                [self LightAndShowResultWithFix:notiString_A TestingFixStr:testingFixStr Dictionary:A_resultDic];
            }
            
        }
        
        
#pragma mark-------------//index=102,B治具测试结束，发送指令信号灯
        if (fix_B_num == 102) {
            
            [NSThread sleepForTimeInterval:0.3];
            testingFixStr = @"BSN2";
            
            if (param.isDebug&&!isLoopTest) {
                
                 NSLog(@"治具B测试完毕，灯光操作完成");

                //testnum++;
                //fix_B_num =0;
                
                if (![notiString_B containsString:@"X"]&&isUpLoadPDCA==YES&&!isLoopTest) {
                    //[NSThread sleepForTimeInterval:0.3];
                    NSLog(@"B_resultDic：上传PDCA的时间");
                    
                    [self UpdateTextView:@"fix_B_num = 102,治具B灯光操作已经完成" andClear:NO andTextView:Log_View];
                    [pdca UploadPDCA_Dafen:2 Dic:B_resultDic Arr:itemArr1 BOOL:[notiString_B containsString:@"P"]?YES:NO];
                    
                    NSLog(@"fix_C_num = 102");
                }

                [self LightAndShowResultWithFix:notiString_B TestingFixStr:testingFixStr Dictionary:B_resultDic];

//                if ([notiString_B containsString:@"P"]) {
//                    
//                    passNum++;
//                }
                
//                if (testnum==[ChooseNumArray count]||testnum== 4) {
//                    index = 105;
//                    NSLog(@"B====%d",testnum);
//                }
            }
            else
            {

                //上传PDCA
                if (![notiString_B containsString:@"X"]&&isUpLoadPDCA==YES&&!isLoopTest) {
                   
                    NSLog(@"B_resultDic：上传PDCA的时间");
                   [pdca UploadPDCA_Dafen:2 Dic:B_resultDic Arr:itemArr1 BOOL:[notiString_B containsString:@"P"]?YES:NO];
                }
                
                [self LightAndShowResultWithFix:notiString_B TestingFixStr:testingFixStr Dictionary:B_resultDic];
            }
        }
        
#pragma mark-------------//index=103,C治具测试结束，发送指令信号灯
        if (fix_C_num == 103) {
            
            [NSThread sleepForTimeInterval:0.3];
            testingFixStr = @"CSN3";
            
            if (param.isDebug&&!isLoopTest) {
                
                NSLog(@"治具C测试完毕，灯光操作完成");

                //testnum++;
                //fix_C_num=0;
                
                if (![notiString_C containsString:@"X"]&&isUpLoadPDCA==YES) {
                    //[NSThread sleepForTimeInterval:0.6];
                    [self UpdateTextView:@"fix_C_num = 103,治具C灯光操作已经完成" andClear:NO andTextView:Log_View];
                    
                    [pdca UploadPDCA_Dafen:3 Dic:C_resultDic Arr:itemArr1 BOOL:[notiString_C containsString:@"P"]?YES:NO];
                    NSLog(@"fix_C_num = 103");
                }
                
                [self LightAndShowResultWithFix:notiString_C TestingFixStr:testingFixStr Dictionary:C_resultDic];
                
                
//                if ([notiString_C containsString:@"P"]) {
//                    
//                    passNum++;
//                }
                
//                if (testnum==[ChooseNumArray count]||testnum== 4) {
//                    index = 105;
//                    NSLog(@"C====%d",testnum);
//                }
                
                
            }
            else
            {
                //上传PDCA
                if (![notiString_C containsString:@"X"]&&isUpLoadPDCA==YES&&!isLoopTest)
                {
                    [pdca UploadPDCA_Dafen:3 Dic:C_resultDic Arr:itemArr1 BOOL:[notiString_C containsString:@"P"]?YES:NO];
                }
                
                [self LightAndShowResultWithFix:notiString_C TestingFixStr:testingFixStr Dictionary:C_resultDic];
            }
        }
        
#pragma mark-------------//index=104,C治具测试结束，发送指令信号灯
        if (fix_D_num == 104) { //扫描SN
            
            [NSThread sleepForTimeInterval:0.3];
            testingFixStr = @"DSN4";
            
            if (param.isDebug && !isLoopTest) {
                NSLog(@"治具D测试完毕，灯光操作完成");
                
                //testnum++;
                //fix_D_num=0;
                
                
                //上传PDCA
                if (![notiString_D containsString:@"X"]&&isUpLoadPDCA==YES) {
                    
                    [self UpdateTextView:@"fix_D_num = 104,治具D灯光操作已经完成" andClear:NO andTextView:Log_View];
                    //[NSThread sleepForTimeInterval:0.9];
                    [pdca UploadPDCA_Dafen:4 Dic:D_resultDic Arr:itemArr1 BOOL:[notiString_D containsString:@"P"]?YES:NO];
                    NSLog(@"fix_C_num = 104");
                    
                    
                }
                
                [self LightAndShowResultWithFix:notiString_D TestingFixStr:testingFixStr Dictionary:D_resultDic];
                
//                if (testnum==[ChooseNumArray count]||testnum== 4) {
//                    index = 105;
//                    NSLog(@"C====%d",testnum);
//                }
            }
            else
            {
                
                //上传PDCA
                if (![notiString_D containsString:@"X"]&&isUpLoadPDCA==YES&&!isLoopTest) {
                    
                        [pdca UploadPDCA_Dafen:4 Dic:D_resultDic Arr:itemArr1 BOOL:[notiString_D containsString:@"P"]?YES:NO];
                }
                
                [self LightAndShowResultWithFix:notiString_D TestingFixStr:testingFixStr Dictionary:D_resultDic];
                
            }
        }
  
#pragma mark111
        if (index == 105) {
            
            [NSThread sleepForTimeInterval:0.5];
            if (param.isDebug) {
                
                NSLog(@"整个测试已经结束，回到初始状态");
            }
            else
            {
                //发送reset的命令
               // [serialport WriteLine:@"reset"];
                
                [NSThread sleepForTimeInterval:0.5];
                
//                if ([[serialport ReadExisting] containsString:@"OK"]) {
//                    
//                     dispatch_async(dispatch_get_main_queue(), ^{
//                         
//                         [Status_TF setStringValue:@"治具复位OK"];
//                     });
//                }
            }

            
            dispatch_sync(dispatch_get_main_queue(), ^{
                
                [TestCount_TF setStringValue:[NSString stringWithFormat:@"%d/%d",passNum,totalNum]];
                startbutton.enabled = NO;
                ComfirmButton.enabled = YES;
                
                //清空所有NStextView的值
                //[self UpdateTextView:@"" andClear:YES andTextView:Log_View];
                [self UpdateTextView:@"" andClear:YES andTextView:A_LOG_TF];
                [self UpdateTextView:@"" andClear:YES andTextView:B_LOG_TF];
                [self UpdateTextView:@"" andClear:YES andTextView:C_LOG_TF];
                [self UpdateTextView:@"" andClear:YES andTextView:D_LOG_TF];
                
                if (!isLoopTest)
                {
                    //清空SN
                    NS_TF1.stringValue = @"";
                    NS_TF2.stringValue = @"";
                    NS_TF3.stringValue = @"";
                    NS_TF4.stringValue = @"";
                }
                
               
                //========定时器结束========
                [mkTimer endTimer];
                 ct_cnt = 0;
                
            });
            
            NSTextField *TF = [self.view viewWithTag:1];
            [TF becomeFirstResponder];
            
            
           //测试结束时，发送结束通知
            [[NSNotificationCenter defaultCenter] postNotificationName:@"NSThreadEnd_Notification" object:nil];
            
            if (singleTest) {
                
                 index = 3;
            }
            else if (isLoopTest)
            {
                
                index = 7;
            }
            else
            {
                index = 2;
            }

        }
        
#pragma mark-------------//index=1000,测试结束
        if (index == 1000) { //等待测试结束，并返回测试的结果
            [NSThread sleepForTimeInterval:0.001];
        }
    }
}


#pragma mark====================测试模式:空测，单测，循环
-(void)selectTestModeNotice:(NSNotification *)noti
{
        //循环
        if ([noti.object isEqualToString:@"LoopTest"])
        {
            
             isLoopTest = YES;
            
            
        }
        //正常
        else if ([noti.object isEqualToString:@"NormalTest"])
        {
            isLoopTest = NO;
        }
        //其它
        else
        {
         
            NSLog(@"其它测试模式");
        }
        
        itemArr1 = [plist PlistRead:@"QT_Station" Key:@"AllItems"];
        tab1 = [tab1 init:Tab1_View DisplayData:itemArr1];
        
        //创建个线程
        if (action1==nil) {
            [self createThreadWithNum:1];
        }
        if (action2==nil) {
            [self createThreadWithNum:2];
        }
        if (action3==nil) {
            [self createThreadWithNum:3];
        }
        if (action4==nil) {
            [self createThreadWithNum:4];
        }
}



#pragma mark----------监听SFC和PDCA的上传状态
-(void)selectSfc_PDCAUpload:(NSNotification *) noti
{
    if ([noti.name isEqualToString:kPdcaUploadNotice]) {
        
        if ([noti.object isEqualToString:@"YES"]) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                IsUploadPDCA_Button.state = YES;
                
                isUpLoadPDCA = YES;
            });
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                IsUploadPDCA_Button.state = NO;
                
                isUpLoadPDCA = NO;
               
            });
        }
    }
    
    if ([noti.name isEqualToString:kSfcUploadNotice]) {
        
        if ([noti.object isEqualToString:@"YES"]) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                IsUploadSFC_Button.state = YES;
                
                isUpLoadSFC = YES;
            });
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                IsUploadSFC_Button.state = NO;
                
                isUpLoadSFC = NO;
            });
        }
    }
}




#pragma mark====================确认选项
- (IBAction)makesureDut:(id)sender {

    singlebutton.state = NO;
    singleTest = YES;
    isComfirmOK  = YES;
    
    //makesure之后不可点击
    choose_dut1.enabled = NO;
    choose_dut2.enabled = NO;
    choose_dut3.enabled = NO;
    choose_dut4.enabled = NO;
    ComfirmButton.hidden = YES;
    
    [ChooseNumArray removeAllObjects];

    if (singleTest) {

       index = 3;
        
    }
    
   

    if (choose_dut1.state) {
        
        [self createThreadWithNum:1];
        
        [ChooseNumArray addObject:@"Test"];

    }
//    else //销毁线程
//    {
//        if (action1 !=nil) {
//            [action1 threadEnd];
//            action1 = nil;
//        }
//        
//    }
    
    if (choose_dut2.state) {
        
        [self createThreadWithNum:2];
        
        [ChooseNumArray addObject:@"Test"];
    }
//    else
//    {
//        if (action2 !=nil) {
//            
//            [action2 threadEnd];
//            action2 = nil;
//            
//        }
//    }
    if (choose_dut3.state) {
        
        [self createThreadWithNum:3];
        
        [ChooseNumArray addObject:@"Test"];
    }
//    else
//    {
//        if (action3 !=nil) {
//            
//            [action3 threadEnd];
//            action3 = nil;
//        }
//    }

    if (choose_dut4.state) {
        
        [self createThreadWithNum:4];
        
        [ChooseNumArray addObject:@"Test"];
    }
//    else
//    {
//        if (action4 !=nil) {
//            
//            [action4 threadEnd];
//            action4 = nil;
//        }
//
//    
//    }
}


#pragma mark====================选择测试项
- (IBAction)single_test:(id)sender {
    
    if (singlebutton.state) {
        
        ComfirmButton.hidden = NO;
        choose_dut1.enabled = YES;
        choose_dut2.enabled = YES;
        choose_dut3.enabled = YES;
        choose_dut4.enabled = YES;
    
    }
    else
    {
        choose_dut1.enabled  = NO;
        choose_dut2.enabled  = NO;
        choose_dut3.enabled  = NO;
        choose_dut4.enabled  = NO;
        ComfirmButton.hidden = YES;
    
    
    }
    
}



#pragma mark 控制光标 成为第一响应者

//-(void)controlTextDidChange:(NSNotification *)obj{
//    
//    NSTextField *tf = (NSTextField *)obj.object;
//    
//    if (tf.tag == 4) {
//        
//        [tf setEditable:YES];
//    }
//    
//    if (tf.stringValue.length == 17) {
//        
//        NSTextField *nextTF;
//        if (tf.tag == 4) {
//            
//           nextTF = [self.view viewWithTag:tf.tag-3];
//        }
//        else
//        {
//            nextTF = [self.view viewWithTag:tf.tag+1];
//        }
//       
//    
//        if (nextTF) {
//            
//            
//            if (nextTF.tag == 4) {
//                
//                [nextTF setEditable:YES];
//                
//            }
//            [tf resignFirstResponder];
//            [nextTF becomeFirstResponder];
//            
//        }
//    }
//}




//更新upodateView
-(void)UpdateTextView:(NSString*)strMsg andClear:(BOOL)flagClearContent andTextView:(NSTextView *)textView
{
    if (flagClearContent)
    {
        dispatch_async(dispatch_get_main_queue(),
                       ^{
                           [textView setString:@""];
                       });
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(),
                       ^{
                           if ([[textView string]length]>0)
                           {
                               NSString * messageString = [NSString stringWithFormat:@"%@: %@\n",[[GetTimeDay shareInstance] getFileTime],strMsg];
                               NSRange range = NSMakeRange([textView.textStorage.string length] , messageString.length);
                               [textView insertText:messageString replacementRange:range];
                               
                           }
                           else
                           {
                                NSString * messageString = [NSString stringWithFormat:@"%@: %@\n",[[GetTimeDay shareInstance] getFileTime],strMsg];
                               [textView setString:[NSString stringWithFormat:@"%@\n",messageString]];
                           }
                           
                               [textView setTextColor:[NSColor redColor]];
                           
                       });
    }
}


#pragma mark----------------生成线程
-(void)createThreadWithNum:(int)num
{
    
    if (num == 1 && action1 == nil) {
        action1  = [[TestAction alloc] initWithTable:tab1 withFixParam:param withType:num];
        action1.resultTF  = DUT_Result1_TF;//显示结果的lable
        action1.Log_View  = A_LOG_TF;
        action1.Fail_View = A_FailItem;
        action1.dutTF     = NS_TF1;
       [action1 setCsvTitle:plist.titile];
        
    }
    if (num == 2 && action2 == nil) {
        action2  = [[TestAction alloc] initWithTable:tab1 withFixParam:param withType:num];
        action2.resultTF  = DUT_Result2_TF;//显示结果的lable
        action2.Log_View  = B_LOG_TF;
        action2.Fail_View =B_FailItem;
        action2.dutTF     = NS_TF2;
        [action2 setCsvTitle:plist.titile];
    }
    
    if (num == 3 && action3 == nil) {
        action3 = [[TestAction alloc]initWithTable:tab1 withFixParam:param withType:num];
        action3.resultTF   = DUT_Result3_TF;//显示结果的lable
        action3.Log_View   = C_LOG_TF;
        action3.Fail_View  = C_FailItem;
        action3.dutTF      = NS_TF3;
        [action3 setCsvTitle:plist.titile];
        
    }
    
    if (num ==4 && action4 == nil){
        action4 = [[TestAction alloc] initWithTable:tab1 withFixParam:param withType:num];
        action4.resultTF  = DUT_Result4_TF;//显示结果的lable
        action4.Log_View  = D_LOG_TF;
        action4.Fail_View = D_FailItem;
        action4.dutTF     = NS_TF4;
        [action4 setCsvTitle:plist.titile];
    }
    
}


#pragma mark---------------释放仪器仪表
-(void)viewWillDisappear
{

    if (action1 != nil) {
        
        [action1 threadEnd];
         action1 = nil;
    }
    if (action2 != nil) {
        
        [action2 threadEnd];
         action2 = nil;
    }
    if (action3 != nil) {
        
        [action3 threadEnd];
        action3 = nil;
    }
    if (action4 != nil) {
        
        [action4 threadEnd];
         action4 = nil;
    }
    
//    [serialport Close];
//    [humiturePort Close];


}

- (void)viewDidDisappear
{
    if (action1 != nil) {
        
        [action1 threadEnd];
        action1 = nil;
    }
    if (action2 != nil) {
        
        [action2 threadEnd];
        action2 = nil;
    }
    if (action3 != nil) {
        
        [action3 threadEnd];
        action3 = nil;
    }
    if (action4 != nil) {
        
        [action4 threadEnd];
        action4 = nil;
    }

    
    
}


#pragma mark---------------正常测试时，数据校验
-(void)compareSNToServerwithTextField:(NSTextField *)tf Index:(int)testIndex SnIndex:(int)snIndex
{
    
    if ([tf.stringValue length] == 17) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [Status_TF setStringValue:[NSString stringWithFormat:@"index = %d:SN%d Enter OK",testIndex,snIndex]];
        });
        
        NSString  * startTime = [[GetTimeDay shareInstance] getCurrentDayTime];
        testStep.strSN  = tf.stringValue;
        
        
        //-(BOOL)StepSFC_CheckUploadSN:(BOOL)isUploadSFC Option:(NSString*)option testResult:(NSString*)testResult startTime:(NSString*)startTime endTime:(NSString*)endTime product:(NSString *)product macAddress:(NSString *)macAddress cType:(NSString *)ctype faiureMessage:(NSString *)failMsg testArgument:(NSArray*)array；
        
        if ([testStep StepSFC_CheckUploadSN:YES Option:@"isSNValid" checkSN:nil testResult:nil startTime:startTime endTime:startTime product:@"A111" macAddress:nil cType:@"validate" faiureMessage:nil testArgument:nil])
        {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [Status_TF setStringValue:[NSString stringWithFormat:@"SN%d 检验OK",snIndex]];
                
            });
            
            index = testIndex+1;
        }
        else
        {
            
            
            dispatch_async(dispatch_get_main_queue(), ^{
                //[tf  setStringValue:@"SN is not valid"];
                
            });
            index = testIndex+1;
        }
        
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^{
     
            [Status_TF setStringValue:[NSString stringWithFormat:@"index = %d:SN%d NG,Enter right SN",testIndex,snIndex]];
        });
    }
}


#pragma mark---------------正常测试时，无SFC请求时
-(void)ShowcompareNumwithTextField:(NSTextField *)tf Index:(int)testIndex SnIndex:(int)snIndex
{
    
    if ([tf.stringValue length] == 17) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [Status_TF setStringValue:[NSString stringWithFormat:@"index = %d:SN%d Enter OK",testIndex,snIndex]];
        });
        
        index = testIndex+1;;
    }
    else
    {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [Status_TF setStringValue:[NSString stringWithFormat:@"index = %d:SN%d NG,Enter right SN",testIndex,snIndex]];
        });
    }
}


#pragma mark--------------点亮指示灯，并显示测试的结果，上传SFC
-(void)LightAndShowResultWithFix:(NSString *)notiString TestingFixStr:(NSString *)testingFix Dictionary:(NSDictionary *)resultDic
{
    
    NSString  * SnString = [testingFix substringFromIndex:1];
    
    NSString * passSN = [resultDic objectForKey:@"dut_sn"];
    
    if (isUpLoadSFC) {
        
        NSString* startTime = [[GetTimeDay shareInstance] getCurrentDayTime];
        
        NSData  * data=[NSData dataWithContentsOfFile:@"/vault/data_collection/test_station_config/gh_station_info.json"];
        NSError  * error;
        
        NSDictionary * jsonDic=[[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error] objectForKey:@"ghinfo"];
        NSString * macAddress =[jsonDic objectForKey:@"MAC"];
        
        if ([notiString containsString:@"P"]) {
            
            
            bool isPass = [testStep StepSFC_CheckUploadSN:YES Option:@"isPass" checkSN:passSN testResult:@"PASS" startTime:[resultDic objectForKey:@"start_time"] endTime:[resultDic objectForKey:@"end_time"] product:@"A111" macAddress:macAddress cType:@"ADD_RECORD" faiureMessage:nil testArgument:nil];
            if (isPass) {
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [Status_TF setStringValue:[NSString stringWithFormat:@"Test result is pass, %@ SFC upload success",SnString]];
                });
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [Status_TF setStringValue:[NSString stringWithFormat:@"Test result is pass,%@ SFC upload fail",SnString]];
                });
                
            }
            
        }
        else{
            id arr = [resultDic objectForKey:@"testFailArr"];
            
            bool isPass = [testStep StepSFC_CheckUploadSN:YES Option:@"isFail" checkSN:passSN testResult:@"FAIL" startTime:[resultDic objectForKey:@"start_time"] endTime:[resultDic objectForKey:@"end_time"] product:@"A111" macAddress:macAddress cType:@"ADD_RECORD" faiureMessage:@"8888888" testArgument:[resultDic objectForKey:@"testFailArr"]];
            if (isPass) {
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [Status_TF setStringValue:[NSString stringWithFormat:@"Test result is fial, %@ SFC upload success",SnString]];
                });
                
            }
            else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [Status_TF setStringValue:[NSString stringWithFormat:@"Test result is fal,%@ SFC upload fail",SnString]];
                });
                
            }
        }
        
//        if ([testStep StepSFC_CheckUploadSN:YES Option:@"uploadLog" testResult:[notiString containsString:@"P"]?@"Pass":@"Fail" startTime:startTime testArgument:[resultDic objectForKey:@"dic"]])
//        {
//        
//            dispatch_async(dispatch_get_main_queue(), ^{
//                
//                [Status_TF setStringValue:[NSString stringWithFormat:@"%@ SFC upload success",SnString]];
//            });
//            
//            
//        }
//        else
//        {
//            dispatch_async(dispatch_get_main_queue(), ^{
//                
//                 [Status_TF setStringValue:[NSString stringWithFormat:@"%@ SFC upload fail",SnString]];
//            });
//        }
    }
    
    
    NSString  * string = [testingFix substringToIndex:1];
    
    
    //发送指示灯
    if ([notiString containsString:@"P"]) {
        
        passNum++;
        
       // [serialport WriteLine:[NSString stringWithFormat:@"FIX_%@ pass",string]];
        
        [NSThread sleepForTimeInterval:0.5];
        
//        if ([[serialport ReadExisting] containsString:@"OK"]) {
//            
//             NSLog(@"FIX_%@，亮绿灯",string);
//            [self UpdateTextView:[NSString stringWithFormat:@"%@治具测试OK，绿灯亮",string] andClear:NO andTextView:Log_View];
//        }

    }
    else
    {
        
        // [serialport WriteLine:[NSString stringWithFormat:@"FIX_%@ fail",string]];
        
         [NSThread sleepForTimeInterval:0.5];
        
//        if ([[serialport ReadExisting] containsString:@"OK"]) {
//            
//            NSLog(@"FIX_%@,亮红灯",string);
//           [self UpdateTextView:[NSString stringWithFormat:@"%@治具测试NG，红灯亮",string] andClear:NO andTextView:Log_View];
//        }
    }
    
    
    if ([string containsString:@"A"])fix_A_num=0;
    if ([string containsString:@"B"])fix_B_num=0;
    if ([string containsString:@"C"])fix_C_num=0;
    if ([string containsString:@"D"])fix_D_num=0;
    testnum++;
    
    
//    if (testnum==[ChooseNumArray count]||testnum== 4) {
//        
//        index = 105;
//        
//        NSLog(@"%@====%d",string,testnum);
//    }
    if (singleTest&&testNum == testnum)
    {
        [mkTimer endTimer];
    }
    
    if (testnum== 4)
    {
        index = 105;
        NSLog(@"%@====%d",string,testnum);
    }

    
}



-(void)dealloc
{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];

}




- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

@end
