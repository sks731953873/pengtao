//
//  BYDSFCManager.m
//  PDCA_Demo
//
//  Created by CW-IT-MB-046 on 14-12-25.
//  Copyright (c) 2014年 CW-IT-MB-046. All rights reserved.
//

#import "BYDSFCManager.h"
#import <Cocoa/Cocoa.h>

static BYDSFCManager* bydSFC=nil;

@implementation BYDSFCManager
@synthesize SFCErrorType=_SFCErrorType;
@synthesize errorMessage = _errorMessage;
@synthesize SFCCheckType=_SFCCheckType;
@synthesize ServerFCKey=_ServerFCKey;    //
//@synthesize station_id = _station_id;

- (id) init
{
    if (self = [super init])
    {
        _unit = [[BYDSFCUnit alloc] init];
        //读取param服务器的相关消息
        plist =[[Plist alloc]init];
        
        if (plist != nil)
        {
            _ServerFCKey=@"ServerFC";
            [self getUnitValue];
        }
    
        _errorMessage = @"";
        _strSN=[[NSString alloc] init];
        _strUpdateBDA=[[NSString alloc] init];
        _station_id = [[NSString alloc] init];
    }
    
    return self;
}


//Create static instance
+(BYDSFCManager*)Instance
{
    if(bydSFC==nil)
    {
        bydSFC=[[BYDSFCManager alloc] init];
    }
    
    return bydSFC;
}

//create an url
- (NSString *) createURL:(enum eSFC_Check_Type)sfcCheckType
                      sn:(NSString *)sn
              testResult:(NSString *)result
               startTime:(NSString *)tmStartStr
            testArgument:(NSArray  *)array
                 endTime:(NSString *)tmEndStr
                 product:(NSString *)product
              macAddress:(NSString *)macAddress
                   cType:(NSString *)ctype
               bdaSerial:(NSString *)strbdaSerial
           faiureMessage:(NSString *)failMsg
{

    
    /*******
     NSMutableString* urlString = [NSMutableString stringWithFormat:@"http://%@:%@/handle.act?c=",_unit.MESServerIP, _unit.netPort];           ip and port
    
    
    http://10.12.5.180:50000/manufacturing/BobcatIntegerationServlet?test_station_name=YF-FATP-AOI&station_id=YF-L01-FATP-AOI-01&sn=F0T5297006QG9KP1X&c=validate
     
     http://10.12.5.180:50000/manufacturing/BobcatIntegerationServlet?test_station_name=ZR-MLB-FCT1&station_id=ZR-MLB-FCT1-L01&sn=F0T5297006QG9KP1X&c=ADD_RECORD&mac_address=12:4D:93:dk:09:8W&product=A111&start_time=2014-12-0615:57:00&stop_time=2014-12-0616:01:00&result=PASS
     
     http://10.12.5.180:50000/manufacturing/BobcatIntegerationServlet?test_station_name=YF-FATP-AOI&station_id=YF-L01-FATP-AOI-01&sn=F0T5297006QG9KP1X&c=ADD_RECORD&mac_address=12:4D:93:dk:09:8W&product=A111&result=FAIL&start_time=2014-12-0615:57:00&stop_time=2014-12-0616:01:00&list_of_failing_tests=NCGAP&failure_message=8888888
     
     *******/
    
    NSMutableString* urlString = [NSMutableString stringWithFormat:@"http://%@:%@/manufacturing/BobcatIntegerationServlet?",_unit.MESServerIP, _unit.netPort];          // ip and port
    
    switch (sfcCheckType)
    {
//        case e_SEVER_CHECK:
//        {            
//            [urlString appendFormat:@"%@", @"CHECK"];
//        }
//            break;
            
        case e_SN_VALID_CHECK:
        {
            id tep = _station_id;
            [urlString appendFormat:@"%@=%@&",SFC_TEST_STATION_NAME,_unit.stationName];
            [urlString appendFormat:@"%@=%@&", SFC_TEST_STATION_ID, _unit.stationID];
            [urlString stringByReplacingOccurrencesOfString:@"\r" withString:@""];
            [urlString appendFormat:@"%@=%@&", SFC_TEST_SN, sn];
            [urlString appendFormat:@"%@=%@",SFC_TEST_C_TYPE,@"validate"];

        }
            break;
            
        case e_RESULT_PASS:
        {
            [urlString appendFormat:@"%@=%@&",SFC_TEST_STATION_NAME,_unit.stationName];
            [urlString appendFormat:@"%@=%@&", SFC_TEST_STATION_ID, _unit.stationID];
            [urlString stringByReplacingOccurrencesOfString:@"\r" withString:@""];
            [urlString appendFormat:@"%@=%@&", SFC_TEST_SN, sn];
            [urlString appendFormat:@"%@=%@&",SFC_TEST_C_TYPE,ctype];
            [urlString appendFormat:@"%@=%@&",SFC_TEST_MAC_ADDRESS,macAddress];
            [urlString appendFormat:@"%@=%@&",SFC_TEST_PRODUCT,product];
            [urlString appendFormat:@"%@=%@&",SFC_TEST_START_TIME,tmStartStr];
            [urlString appendFormat:@"%@=%@&",SFC_TEST_STOP_TIME,tmEndStr];
            [urlString appendFormat:@"%@=%@",SFC_TEST_RESULT,result];
            
        }
            break;
            
        case e_RESULT_FAIL:
        {
            [urlString appendFormat:@"%@=%@&",SFC_TEST_STATION_NAME,_unit.stationName];
            [urlString appendFormat:@"%@=%@&", SFC_TEST_STATION_ID, _unit.stationID];
            [urlString stringByReplacingOccurrencesOfString:@"\r" withString:@""];
            [urlString appendFormat:@"%@=%@&", SFC_TEST_SN, sn];
            [urlString appendFormat:@"%@=%@&",SFC_TEST_C_TYPE,ctype];
            [urlString appendFormat:@"%@=%@&",SFC_TEST_MAC_ADDRESS,macAddress];
            [urlString appendFormat:@"%@=%@&",SFC_TEST_PRODUCT,product];
            [urlString appendFormat:@"%@=%@&",SFC_TEST_RESULT,result];
            [urlString appendFormat:@"%@=%@&",SFC_TEST_START_TIME,tmStartStr];
            [urlString appendFormat:@"%@=%@&",SFC_TEST_STOP_TIME,tmEndStr];
            [urlString appendFormat:@"%@=",SFC_TEST_FAIL_LIST];
            [urlString appendFormat:@"%s","("];
            
            
            for (NSInteger i = 0; i< [array count]; i++)
            {
                if (i == [array count]-1) {
                    
                    [urlString appendFormat:@"%@", array[i]];
                    
                }
                else{
                    
                    [urlString appendFormat:@"%@&", array[i]];
                    
                }
            }
            
            [urlString appendFormat:@"%s",")&"];
            [urlString appendFormat:@"%@=%@",SFC_TEST_FAIL_MESSAGE,failMsg];
            [urlString stringByReplacingOccurrencesOfString:@"\r" withString:@""];
            [urlString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
        }
            break;
        case e_LOG_CHECK:
        {
            [urlString appendFormat:@"LOG&%@=%@&",SFC_TEST_STATION_NAME,_unit.stationName];
            [urlString appendFormat:@"%@=%@&", SFC_TEST_STATION_ID, self.station_id];
            
            [urlString appendFormat:@"%@=%@&", SFC_TEST_SN, sn];
            [urlString appendFormat:@"%@=%@&", SFC_TEST_RESULT, result];
            [urlString appendFormat:@"%@=%@",SFC_TEST_START_TIME,tmStartStr];
     
            
            if ([self.config_pro length]>0) {
                
                [urlString appendFormat:@"&p1=%@",self.config_pro];
            }
            else
            {
                [urlString appendFormat:@"&p1=null"];
            }
            
            for(int i = 0; i < [array count]; i++)
            {
                [urlString appendFormat:@"&p%d=%@",i+2,array[i]];
            }
            
            [urlString stringByReplacingOccurrencesOfString:@"\r" withString:@""];
            [urlString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        }
            
            break;
        default:
            break;
    }

    return urlString;
}


- (BOOL) submit:(NSString *)urlString
{
    BOOL flag = NO;
    _isCheckPass = NO;
// [[TestLog Instance] WriteLogResult:[GetTimeDay GetCurrentTime] andText:urlString];
    NSString* url = [urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSMutableURLRequest* urlRequest = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:url]];
    if (!urlRequest)
    {
        _errorMessage = [_errorMessage stringByAppendingString:@"error: Cann't connect the server.\r\n"];
        flag = NO;
        return flag;
    }
    
    
    [urlRequest setTimeoutInterval:10];
    [urlRequest setCachePolicy:NSURLRequestReloadIgnoringCacheData];
    [urlRequest setNetworkServiceType:NSURLNetworkServiceTypeBackground];
    [urlRequest setHTTPMethod:@"GET"];
    
    
    // 单独处理请求任务
    NSThread* thrdSumbit = [[NSThread alloc] initWithTarget:self
            selector:@selector(handleHttpRequest:)object:urlRequest];
   
    if ([NSURLConnection canHandleRequest:urlRequest])
    {
        [thrdSumbit start];
    }
    
    // set timeout, timeout = 5s
    float time = 0;
    while (time < 5)
    {
        if (_isCheckPass)
        {
            if (_SFCErrorType==SFC_Success)
            {
                flag=YES;
            }

            break;
        }
        [NSThread sleepForTimeInterval:0.01];
        time += 0.1;
    }
    
    if (time>=5 &&_SFCErrorType!=SFC_Success)
    {
        _SFCErrorType=SFC_TimeOut_Error;
    }
    return flag;
}




- (void) handleHttpRequest:(NSURLRequest *)urlRequest
{
    _isCheckPass = NO;
    [NSThread sleepForTimeInterval:0.3];
    NSData * byteRequest = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:nil error:nil];
    NSString* backFromHttpStr = [[NSString alloc] initWithData:byteRequest encoding:NSUTF8StringEncoding];
    NSLog(@"HttpBackValue:%@",backFromHttpStr);
    
    NSMutableString* strLogFile=[[NSMutableString alloc] initWithFormat:@"HttpBackValue:%@\r\n",backFromHttpStr];
    NSLog(@"%@",strLogFile);

    if ([backFromHttpStr length]<1)
    {
        _SFCErrorType=SFC_ErrorNet;
        //[self showAlertMessage:@"NetWork timeout"];
    }
    else if([backFromHttpStr containsString:@"OK"])
    {
        _SFCErrorType= SFC_Success;
    
    }
    else
    {
        _SFCErrorType = SFC_Error;
        
        //[self showAlertMessage:backFromHttpStr];
        
    }
    
    
    _isCheckPass = YES;
    [NSThread exit];
}


#pragma mark-------提示框的内容
-(void)showAlertMessage:(NSString*)showMessage{
    
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        NSAlert * alert1 = [NSAlert new];
        alert1.messageText = @"Comfirm";
        alert1.informativeText = showMessage;
        [alert1 addButtonWithTitle:@"YES"];
        //第一种方式，以modal的方式出现
        [alert1 runModal];
        
    });
}



- (NSString *) timeToStr:(time_t)time
{
    struct tm* tm = localtime(&time);
    return [NSString stringWithFormat:@"%d-%d-%d %d:%d:%d", (tm->tm_year + 1900), (tm->tm_mon + 1),
            tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec];
}


- (BOOL)   Option:(NSString*)option
checkSerialNumber:(NSString *)sn
       testResult:(NSString*)testResult
        startTime:(NSString*)startTime
          endTime:(NSString*)endTime
          product:(NSString*)product
       macAddress:(NSString*)macAddress
            cType:(NSString*)cType
    faiureMessage:(NSString*)faiureMessage
     testArgument:(NSArray *)array
{
    
    NSString* url;
    
    
    if ([option isEqualToString:@"isSNValid"]) {
        url = [self createURL:e_SN_VALID_CHECK sn:sn testResult:nil
                    startTime:nil testArgument:nil endTime:nil product:nil macAddress:nil cType:@"validate" bdaSerial:nil faiureMessage:nil];
    }
    else if ([option isEqualToString:@"isPass"]){
        
        url = [self createURL:e_RESULT_PASS sn:sn testResult:testResult
                    startTime:startTime testArgument:nil endTime:endTime product:product macAddress:macAddress cType:cType bdaSerial:nil faiureMessage:nil];
    }
    else
    {
        url = [self createURL:e_RESULT_FAIL sn:sn testResult:testResult
                    startTime:startTime testArgument:array endTime:endTime product:product macAddress:macAddress cType:cType bdaSerial:nil faiureMessage:@"8888888"];
    }
    
    NSLog(@"Check SerialNumber url:%@",url);
    return [self submit:url];
}

- (BOOL) checkComplete:(NSString *)sn
                result:(NSString *)result
             startTime:(time_t)tmStart
               endTime:(time_t)tmEnd
           failMessage:(NSString *)failMsg
{
    

    
    NSString* url = [self createURL:e_COMPLETE_RESULT_CHECK
                                 sn:sn testResult:result
                          startTime:[self timeToStr:tmStart]
                       testArgument:nil
                            endTime:[self timeToStr:tmEnd]
                            product:nil
                         macAddress:nil
                              cType:@"validate"
                            bdaSerial:nil
                      faiureMessage:failMsg];
    NSLog(@"CheckComplete url:%@",url);
    return [self submit:url];
}


-(void)getUnitValue{

    NSDictionary  * dic= [plist PlistRead:@"Param"];
    NSDictionary  * subDic = [dic objectForKey:_ServerFCKey];
    _unit.MESServerIP  = [subDic objectForKey:@"Server_IP"];
    _unit.netPort      = [subDic objectForKey:@"Net_Port"];
    _unit.stationName  = [subDic objectForKey:@"Station_Name"];
    _unit.stationID = [subDic objectForKey:@"Station_ID"];
}


@end
