//
//  ConfigInstr.h
//  BCM
//
//  Created by mac on 26/02/2018.
//  Copyright © 2018 macjinlongpiaoxu. All rights reserved.
//

#import <Cocoa/Cocoa.h>
//#include "AgilentTools.h"

@interface ConfigInstr : NSWindowController

@end
