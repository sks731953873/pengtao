//
//  ViewController.h
//  WorkingFrameWork
//
//  Created by mac on 2017/10/27.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController
{
   IBOutlet NSView *Tab1_View;
   IBOutlet NSView *Tab2_View;
    
   IBOutlet NSTextField *DUT_Result1_TF;
   IBOutlet NSTextField *DUT_Result2_TF;
   IBOutlet NSTextField *DUT_Result3_TF;
   IBOutlet NSTextField *DUT_Result4_TF;
    
}


@end

