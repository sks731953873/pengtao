//
//  HXWindowControllerCollection.m
//  Mac_1.0
//
//  Created by xin on 2019/2/14.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "HXWindowControllerCollection.h"

@interface HXWindowControllerCollection ()
@property (nonatomic, copy) NSMutableArray *windowControllers;

@end
@implementation HXWindowControllerCollection


- (instancetype)init {
    if (self = [super init]) {
        _windowControllers = [[NSMutableArray alloc] init];
    }
    return self;
}

- (void)presentWindowController:(NSWindowController *)controller {
    [self presentWindowController:controller withAnimationBlock:nil];
}

- (void)presentWindowController:(NSWindowController *)controller animatedFromBottom:(BOOL)animated {
    HXAnimationBlock block = !animated? nil: ^(NSWindow *window, NSRect proposedEndFrame) {
        NSRect startFrame = startFrameForBottomAnimationUsingEndFrame(proposedEndFrame);
        [window setFrame:startFrame display:YES];
        [window makeKeyAndOrderFront:nil];
        [window.animator setFrame:proposedEndFrame display:YES];
    };
    [self presentWindowController:controller withAnimationBlock:block];
}

- (void)presentWindowController:(NSWindowController *)controller animatedFromBottomRight:(BOOL)animated {
    HXAnimationBlock block = !animated? nil: ^(NSWindow *window, NSRect proposedEndFrame) {
        window.alphaValue = 0.0f;
        NSRect main_rect = [NSScreen mainScreen].visibleFrame;
        proposedEndFrame.origin.y = 0;
        proposedEndFrame.origin.x = main_rect.size.width - proposedEndFrame.size.width;
        [window setFrame:NSOffsetRect(proposedEndFrame, 0, -100) display:YES];
        [window makeKeyAndOrderFront:nil];
        [NSAnimationContext runAnimationGroup:^(NSAnimationContext * _Nonnull context) {
            context.duration = 2.0f;
            window.animator.alphaValue = 1.0f;
            [window.animator setFrame:proposedEndFrame display:YES];
        } completionHandler:nil];
    };
    [self presentWindowController:controller withAnimationBlock:block];
}
// Designated presenter
- (void)presentWindowController:(NSWindowController *)controller withAnimationBlock:(HXAnimationBlock)block {
    if ([self containsController:controller]) {
        return;
    }
    [self addWindowController:controller];
    if (block) {
        block(controller.window, controller.window.frame);
    } else {
        [controller showWindow:nil];
    }
}


- (BOOL)containsWindow:(NSWindow *)window {
    return window.windowController? [_windowControllers containsObject:window.windowController]: NO;
}

- (BOOL)containsController:(NSWindowController *)controller {
    return [_windowControllers containsObject:controller];
}


#pragma mark -Private
- (void)addWindowController:(NSWindowController *)controller {
    controller.window.releasedWhenClosed = NO;
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(removeWindowController:)
                                                 name:NSWindowWillCloseNotification
                                               object:controller.window];
    [_windowControllers addObject:controller];
}

NSRect startFrameForBottomAnimationUsingEndFrame(NSRect frame) {
    frame.origin.y -= frame.size.height;
    return frame;
}


#pragma mark -Notification

- (void)removeWindowController:(NSNotification *)notification {
    NSWindow *window = (NSWindow *)notification.object;
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NSWindowWillCloseNotification object:window];
    [_windowControllers removeObject:window.windowController];
}

- (void)dealloc {
    [NSNotificationCenter.defaultCenter removeObserver:self];
}
@end
