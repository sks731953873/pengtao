//
//  UncaughtExceptionHandler.h
//  Mac_1.0
//
//  Created by apple on 2016/12/7.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UncaughtExceptionHandler : NSObject
{
    BOOL dismissed;
}
+(void) InstallUncaughtExceptionHandler;
void UncaughtExceptionHandlers (NSException *exception);
+ (NSArray *)backtrace;
@end
