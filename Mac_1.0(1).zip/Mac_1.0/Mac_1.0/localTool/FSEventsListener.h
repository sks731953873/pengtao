//
//  FSEventsListener.h
//  macOSTest
//
//  Created by apple on 2016/12/21.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YGFileRecordModel.h"

@interface FSEventsListener : NSObject
{
@private
    FSEventStreamRef mFileStream;
}


/** 根据监控路径来初始化*/
-(id)initWithFilePath:(NSArray *)pathsToWatch withFileRecordModel:(YGFileRecordModel *)fileRecordModel;

/*
    引用计数为0就会调用，   = nil;触发
 */
-( void )dealloc;



@end
