//
//  FSEventsListener.m
//  macOSTest
//
//  Created by apple on 2016/12/21.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "FSEventsListener.h"
#import "Singleton.h"
#import "YGTool.h"
void fsevents_callback( ConstFSEventStreamRef streamRef,
                       void * userData,
                       size_t numEvents,
                       void * eventPaths,
                       const FSEventStreamEventFlags eventFlags[],
                       const FSEventStreamEventId eventIds[]);

@implementation FSEventsListener

/*
    需要监控的类型
 */
static int IsAdd;
static int IsDelete;
static int IsUpdate;


-(id)initWithFilePath:(NSArray *)pathsToWatch withFileRecordModel:(YGFileRecordModel *)fileRecordModel;
{
    self = [super init];
    if (self == nil)
        return nil;
    NSMutableArray *defautlPath = [NSMutableArray array];
    for (NSString * path in pathsToWatch) {
        if ([path isEqualToString:@"下载目录"]) {
            NSString * path1 = [NSSearchPathForDirectoriesInDomains(NSDownloadsDirectory, NSUserDomainMask, YES) lastObject];
            [defautlPath addObject:path1];
            NSLog(@"1");
        }
        if ([path isEqualToString:@"文稿目录"]) {
            NSString * path1 = [NSSearchPathForDirectoriesInDomains(NSDownloadsDirectory, NSUserDomainMask, YES) lastObject];
            [defautlPath addObject:path1];
        }
    }
    if (defautlPath.count == 0 && pathsToWatch.count != 0) {
        defautlPath = [NSMutableArray arrayWithArray:pathsToWatch];
    }
    
    IsAdd = fileRecordModel.IsAdd;
    IsDelete = fileRecordModel.IsDelete;
    IsUpdate = fileRecordModel.IsUpdate;
    // create the context that will be associated to the stream. We pass a
    // pointer to the FSEventsListener instance as user data.
    
    FSEventStreamContext context = { 0 , (__bridge  void *) self , NULL , NULL , NULL };
    
    // create the event stream, with a flag telling that we want to watch file
    // level events. This will allow to directly retrieve the file names in the
    // callback, instead of just the name of the directory
    
    mFileStream = FSEventStreamCreate (kCFAllocatorDefault,
                                       fsevents_callback ,
                                       &context,
                                       (__bridge  CFArrayRef)[NSArray arrayWithArray:defautlPath],//监控文档路径
                                       kFSEventStreamEventIdSinceNow,
                                       (CFAbsoluteTime) 0.01,// 间隔时间
                                       kFSEventStreamCreateFlagFileEvents);
    
    // start the stream on the main event loop
    FSEventStreamScheduleWithRunLoop(mFileStream,
                                     CFRunLoopGetCurrent(),
                                     kCFRunLoopDefaultMode );
    FSEventStreamStart(mFileStream);
    // init the globally accessible instance
    return self ;
}

-( void )dealloc
{

    // stop and clean event stream
    FSEventStreamStop(mFileStream);
    FSEventStreamUnscheduleFromRunLoop(mFileStream,
                                       CFRunLoopGetCurrent(),
                                       kCFRunLoopDefaultMode);
        
    FSEventStreamInvalidate(mFileStream);
    FSEventStreamRelease(mFileStream);
}



#define CHECK_STREAM(x, y) if (((x) & (y)) == (y)) NSLog(@"    %s", #y);
/**
 
 文件删除可以监听到文件变动之后用文件管理器去查看路径是否还存在  如果不存在则被删除了 或者 可能是重命名了
 
 
 监听回调函数
 接收文件文档变动
 //0表示删除 1表示新增 2表示更新
 */
void fsevents_callback(ConstFSEventStreamRef streamRef,
                       void * userData,
                       size_t numEvents,
                       void * eventPaths,
                       const FSEventStreamEventFlags eventFlags[],
                       const FSEventStreamEventId eventIds[])
{
    NSFileManager * fileManager = [NSFileManager defaultManager];
    size_t i;
    char ** paths= eventPaths;// 文件文档路径
    
    for (i = 0; i < numEvents; ++i)
    {
        
        NSString * newName = [NSString stringWithCString:paths[i] encoding:NSUTF8StringEncoding];//  获取到文件名
        if ([newName hasSuffix:@".DS_Store"]) {// 不理会.DS_Store文件排列操作
            NSLog(@"是.DS_Store文件变动");
            continue;
        }

        if (eventFlags[i] &kFSEventStreamEventFlagItemRemoved)// 是删除操作
        {
            // 违规时间
            NSLog(@"删除=[%@]", newName);
            if (IsDelete)
            CreateRecvListener(newName, @"0");
            
        } else if (eventFlags[i] & kFSEventStreamEventFlagItemCreated){// 创建文件必定伴随重命名(目前不影响)
            // 违规时间
            NSLog(@"新建=[%@]", newName);
            if (IsAdd)
            CreateRecvListener(newName, @"1");
        } else if ((eventFlags[i] & kFSEventStreamEventFlagItemRenamed)) {
            if (![fileManager fileExistsAtPath:newName]) {
                // 操作文件路径不存在    有文件移动出去
                NSString *trashPath = [NSSearchPathForDirectoriesInDomains(NSTrashDirectory, NSUserDomainMask, YES) lastObject];
                NSString *filePath = [newName lastPathComponent];// 原名字
                NSString *fileTotrashPath = [trashPath stringByAppendingPathComponent:filePath];
                if ([fileManager fileExistsAtPath:fileTotrashPath]) {
                    NSLog(@"移动到垃圾篓=[%@]", newName);
                    if (IsDelete)
                    CreateRecvListener(newName, @"0");
                    
                }else{
//                    if (IsDelete) {
//                        CreateRecvListener(newName, @"0");
//                    }
                }
            }else{
                NSLog(@"文件有更新=[%@]", newName);
                if (IsUpdate)
                CreateRecvListener(newName, @"2");
                if((eventFlags[i] & kFSEventStreamEventFlagItemFinderInfoMod) && numEvents == 2) {
                    return;
                }
                
            }
        }
#if defined(DEBUG)
//        NSLog(@"event [%d] [%d] [%s]", (int)eventIds[i], eventFlags[i], paths[i]);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagNone);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagMustScanSubDirs);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagUserDropped);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagKernelDropped);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagEventIdsWrapped);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagHistoryDone);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagRootChanged);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagMount);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagUnmount);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagItemCreated);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagItemRemoved);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagItemInodeMetaMod);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagItemRenamed);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagItemModified);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagItemFinderInfoMod);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagItemChangeOwner);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagItemXattrMod);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagItemIsFile);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagItemIsDir);
        CHECK_STREAM(eventFlags[i], kFSEventStreamEventFlagItemIsSymlink);
#endif // _DEBUG
    }
//    if (!(state == -1)){
//        FSEventsListener *listener = (__bridge FSEventsListener *)userData;
//        if (listener.returnFileFixBlock != nil) {
//            listener.returnFileFixBlock(nil);
//        }
//    }
}

void CreateRecvListener(NSString *path, NSString *type){
    // 文件变动上报字典
    NSMutableDictionary * stateDictionary = [NSMutableDictionary dictionary];
    [stateDictionary setObject:CurrentTime(YGCURRENTTIMETYPEONE) forKey:@"OperationTime"];
    [stateDictionary setObject:path forKey:@"DocumentPath"];
    [stateDictionary setObject:type forKey:@"OperationType"];
    RecvMobilePolicy_File(stateDictionary);
}

@end
