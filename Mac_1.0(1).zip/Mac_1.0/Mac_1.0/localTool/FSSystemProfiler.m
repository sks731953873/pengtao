//
//  FSSystemProfiler.m
//  Mac_1.0
//
//  Created by xin on 2019/1/15.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "FSSystemProfiler.h"

@implementation FSSystemProfiler
/** 调用system_profiler:穿入字符串数组 返回信息字符串*/
+ (NSString *)system_profiler:(NSArray *)array {
    return [FSSystemProfiler YGTaskForlaunchPath:@"/usr/sbin/system_profiler" withArray:array];
}

+ (NSString *)YGTaskForlaunchPath:(NSString *)launchPath withArray:(NSArray *)array {
    NSFileManager * fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:launchPath]){
        HXINFOLOG(@"没有%@", launchPath);
        return nil;
    }
    NSTask *task = [[NSTask alloc] init];
    [task setLaunchPath:launchPath];
    task.arguments = array;
    NSPipe *outputPipe = [NSPipe pipe];
    [task setStandardOutput:outputPipe];
    [task launch];
    [task waitUntilExit];//NSTask默认是异步执行,如果有同步需求,可调用waitUntilExit()方法
    NSFileHandle * read = [outputPipe fileHandleForReading];
    NSData * dataRead = [read readDataToEndOfFile];
    NSString * stringRead = [[NSString alloc] initWithData:dataRead encoding:NSUTF8StringEncoding];
    return stringRead;
}

@end
