//
//  UncaughtExceptionHandler.m
//  Mac_1.0
//
//  Created by apple on 2016/12/7.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import "UncaughtExceptionHandler.h"
#include <Cocoa/Cocoa.h>
#include <libkern/OSAtomic.h>
#include <execinfo.h>
#include "YGTool.h"
#include "HardwareAssets.h"
NSString * const UncaughtExceptionHandlerSignalExceptionName = @"UncaughtExceptionHandlerSignalExceptionName";
NSString * const UncaughtExceptionHandlerSignalKey = @"UncaughtExceptionHandlerSignalKey";
NSString * const UncaughtExceptionHandlerAddressesKey = @"UncaughtExceptionHandlerAddressesKey";
volatile int32_t UncaughtExceptionCount = 0;
const int32_t UncaughtExceptionMaximum = 10;
const NSInteger UncaughtExceptionHandlerSkipAddressCount = 4;
const NSInteger UncaughtExceptionHandlerReportAddressCount = 5;

@implementation UncaughtExceptionHandler
NSString* getAppInfo()
{
    
    NSString * cpu = GetCPU();
    NSString *appInfo = [NSString stringWithFormat:@"App : %@ %@(%@)\nDevice : %@\nOS Version : %@ %@\n",
                         [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleDisplayName"],
                         [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"],
                         [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleVersion"],
                         readFile(@"computerName"),
                         readFile(@"SystemVersion"),
                         cpu];
    NSLog(@"Crash!!!! %@", appInfo);
    return appInfo;
}


void MySignalHandler(int signal)
{
    int32_t exceptionCount = OSAtomicIncrement32(&UncaughtExceptionCount);
    if (exceptionCount > UncaughtExceptionMaximum)
    {
        return;
    }
    
    if(signal==11)
    {//比较坑爹的是 我遇到的一个问题只有iPhone5出现问题 但是我这边测试的没有iPhone5 无法直接log  可能是内存不足 果然 删除几个应用就可以了 所以加了这句
//        NSAlert *alert = [NSAlert alertWithMessageText:@"可能原因:key"
//                                         defaultButton:@"ok"
//                                       alternateButton:nil
//                                           otherButton:nil
//                             informativeTextWithFormat:@"内存不足"];
//        [alert setAlertStyle:NSWarningAlertStyle];
//        [alert runModal];
    }
//    NSAlert *alert = [NSAlert alertWithMessageText:@"可能原因:key"
//                                     defaultButton:@"ok"
//                                   alternateButton:nil
//                                       otherButton:nil
//                         informativeTextWithFormat:@"内存不足"];
//    [alert setAlertStyle:NSWarningAlertStyle];
//    [alert runModal];

    NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObject:[NSNumber numberWithInt:signal] forKey:UncaughtExceptionHandlerSignalKey];
    NSArray *callStack = [UncaughtExceptionHandler backtrace];
    [userInfo setObject:callStack forKey:UncaughtExceptionHandlerAddressesKey];
    [[[UncaughtExceptionHandler alloc] init] performSelectorOnMainThread:@selector(handleException:) withObject:[NSException exceptionWithName:UncaughtExceptionHandlerSignalExceptionName reason:[NSString stringWithFormat:NSLocalizedString(@"Signal %d was raised.\n"@"%@", nil), signal, getAppInfo()] userInfo:[NSDictionary dictionaryWithObject:[NSNumber numberWithInt:signal] forKey:UncaughtExceptionHandlerSignalKey]]waitUntilDone:YES];
    
}


+(void) InstallUncaughtExceptionHandler
{
    signal(SIGABRT, MySignalHandler);
    signal(SIGILL, MySignalHandler);
    signal(SIGSEGV, MySignalHandler);
    signal(SIGFPE, MySignalHandler);
    signal(SIGBUS, MySignalHandler);
    signal(SIGPIPE, MySignalHandler);
}

+ (NSArray *)backtrace
{
    void* callstack[128];
    int frames = backtrace(callstack, 128);
    char **strs = backtrace_symbols(callstack, frames);
    int i;
    NSMutableArray *backtrace = [NSMutableArray arrayWithCapacity:frames];
    for (
         i = UncaughtExceptionHandlerSkipAddressCount;
         i < UncaughtExceptionHandlerSkipAddressCount +
         UncaughtExceptionHandlerReportAddressCount;
         i++)
    {
        [backtrace addObject:[NSString stringWithUTF8String:strs[i]]];
    }
    free(strs);
    return backtrace;
}
//响应Sheet的按钮事件
- (void)alertSheetDidEnd:(NSAlert *)alert returnCode:(NSInteger)returnCode
{
    NSLog(@"%@", alert.messageText);
    if (returnCode == 1)
    {
        NSLog(@"alternateButton clicked!");
        NSApplication *app = [NSApplication sharedApplication];
        [app terminate:self];
    }
    else if(returnCode == 0)
    {
        dismissed = YES;
    }
}

- (void)handleException:(NSException *)exception
{
    NSAlert *alert = [NSAlert alertWithMessageText:NSLocalizedString(@"Unhandled exception", nil)
                                     defaultButton:NSLocalizedString(@"Quit", nil)
                                   alternateButton:NSLocalizedString(@"Continue", nil)
                                       otherButton:nil
                         informativeTextWithFormat:@"%@", [NSString stringWithFormat:NSLocalizedString(@"You can try to continue but the application may be unstable.\n"@"%@\n%@", nil), [exception reason], [[exception userInfo] objectForKey:UncaughtExceptionHandlerAddressesKey]]];
    [alert setAlertStyle:NSWarningAlertStyle];
    [alert runModal];

    CFRunLoopRef runLoop = CFRunLoopGetCurrent();
    CFArrayRef allModes = CFRunLoopCopyAllModes(runLoop);
    while (!dismissed)
    {
        for (NSString *mode in (__bridge NSArray *)allModes)
        {
            CFRunLoopRunInMode((CFStringRef)mode, 0.001, false);
        }
    }
    CFRelease(allModes);
    NSSetUncaughtExceptionHandler(NULL);
    signal(SIGABRT, SIG_DFL);
    signal(SIGILL, SIG_DFL);
    signal(SIGSEGV, SIG_DFL);
    signal(SIGFPE, SIG_DFL);
    signal(SIGBUS, SIG_DFL);
    signal(SIGPIPE, SIG_DFL);
    if ([[exception name] isEqual:UncaughtExceptionHandlerSignalExceptionName])
    {
        kill(getpid(), [[[exception userInfo] objectForKey:UncaughtExceptionHandlerSignalKey] intValue]);
    }
    else
    {
        [exception raise];
    }
}
void UncaughtExceptionHandlers (NSException *exception) {
    NSArray *arr = [exception callStackSymbols];
    NSString *reason = [exception reason];
    NSString *name = [exception name];
    NSString *urlStr = [NSString stringWithFormat:@"mailto://304946561@qq.com?subject=bug报告&body=感谢您的配合!<br><br><br>错误详情:<br>%@<br>--------------------------<br>%@<br>---------------------<br>%@",
                        name,
                        reason,
                        [arr componentsJoinedByString:@"<br>"]];
    NSURL *url = [NSURL URLWithString:[urlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    [[NSWorkspace sharedWorkspace] openURL:url];
    
    //或者直接用代码，输入这个崩溃信息，以便在console中进一步分析错误原因
    NSLog(@"huxin, CRASH: %@", exception);
    NSLog(@"huxin, Stack Trace: %@", [exception callStackSymbols]);
}

@end
