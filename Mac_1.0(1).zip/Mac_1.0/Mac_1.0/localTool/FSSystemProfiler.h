//
//  FSSystemProfiler.h
//  Mac_1.0
//
//  Created by xin on 2019/1/15.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface FSSystemProfiler : NSObject

/** 调用system_profiler:穿入字符串数组 返回信息字符串*/
+ (NSString *)system_profiler:(NSArray *)array;

+ (NSString *)YGTaskForlaunchPath:(NSString *)launchPath withArray:(NSArray *)array;

@end


