//
//  YGNetAuthModel.h
//  Mac_1.0
//
//  Created by xin on 2018/4/10.
//  Copyright © 2018年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YGDataBase.h"
@interface YGNetAuthModel : NSObject
/** 数据库唯一标识*/
@property (nonatomic, assign) NSInteger identify;
/** 是否进行自动认证*/
@property (nonatomic, assign) NSInteger IsNetAuth;
/** 用户名*/
@property (nonatomic, copy) NSString *username;
/** 密码*/
@property (nonatomic, copy) NSString *password;
/** 最近一次认证时间*/
@property (nonatomic, assign) double InsertTime;
/** 认证周期*/
@property (nonatomic, assign) double autoAuthTime;
/** 角色ID*/
@property (nonatomic, assign) NSInteger RoleID;
/** 是否进行安检*/
@property (nonatomic, assign) NSInteger IsSafeCheck;
/** 策略ID*/
@property (nonatomic, assign) NSInteger PolicyID;
/** 设备认证类型-->NoAuth:自动认证，User：账号密码认证，Stop：禁止认证，Isolation：设备被隔离，NotLive：设备被删除*/
@property (nonatomic, copy) NSString *getAuthType;


+ (YGNetAuthModel *)model;
/** 自动认证接口*/
+ (void)NetAuthCheck:(BOOL *)isMust;
- (void)qunueCreateNetAuthTable;
/** NetAuth表插入完整数据*/
- (void)qunueInsertNetAuthTable;

- (YGNetAuthModel *)qunueSelectFromNetAuthModel;
/**
 通过唯一标志修改当前的数据库数据
 NetAuth表中只会存一条数据
 */
- (void)qunueUpdateNetAuthTable;


- (void)qunueUpdateNetAuthTableWithSomeThings:(NSString *)sql;

// 修改自动认证参数
- (void)qunueUpdateNetAuthTableWithAutomatically:(NSInteger)automatically;
// 修改参数
- (void)qunueUpdateNetAuthTableWithrecvRoleChangedTime:(double)recvRoleChangedTime;

// 清除策略时间
- (void)qunueUpdateNetAuthTableWithInsertTime:(double)insertTime;
@end
