/**
 * Created by Shinelon on 2017/5/19.
 */
$(".project-card").children(".img-responsive:eq(0)").attr("src","../img/jn.png");
$(".project-tit:eq(0)").css("color","green");

$(".project-card").on("click",function(){
    $(this).children(".project-tit").css("color","green");
    $(this).children(".img-responsive").attr("src","../img/jn.png");
    $(this).siblings().children(".project-tit").css("color","black");
    $(this).siblings().children(".img-responsive").attr("src","../img/jm.png")
})

$(".header-box").load("main.html");
$(".project-card:eq(0)").on("click",function(){
    $(this).parent().parent().siblings().load("main.html")
});
$(".project-card:eq(1)").on("click",function(){
    $(this).parent().parent().siblings().load("tool.html")
});
$(".project-card:eq(2)").on("click",function(){
    $(this).parent().parent().siblings().load("select.html")
})
$(".project-card:eq(3)").on("click",function(){
    $(this).parent().parent().siblings().load("myself.html")
})