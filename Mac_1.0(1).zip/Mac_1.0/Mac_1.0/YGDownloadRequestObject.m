//
//  YGDownloadRequestObject.m
//  Mac_1.0
//
//  Created by xin on 2018/4/19.
//  Copyright © 2018年 infogo. All rights reserved.
//

#import "YGDownloadRequestObject.h"
#import <Cocoa/Cocoa.h>
#import "YGAlert.h"
#import "YGNetHttpRequestObject.h"
@interface YGDownloadRequestObject()<XBDownloadManagerDelegate>
@property (nonatomic, strong) YGAlert *alert;
@property (nonatomic, strong) NSMutableArray<XBDownloadTaskInfo *> *cells;
@end

@implementation YGDownloadRequestObject
- (NSMutableArray<XBDownloadTaskInfo *> *)cells {
    if (_cells == nil) {
        _cells = [NSMutableArray array];
    }
    return _cells;
}

+ (instancetype)shareInstance {
    static YGDownloadRequestObject * instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[YGDownloadRequestObject alloc] init];
    });
    return instance;
}


#pragma mark
- (void)downloadForTaskSoftName:(NSString *)SoftName SoftURL:(NSString *)SoftUrl {
    //获取下载器的单例对象
    self.downloadManager = [XBDownloadManager manager];
    [self.downloadManager setDelegate:self andDelegateQueue:[NSOperationQueue mainQueue]];

    //设定同时下载数量最多为
    self.downloadManager.maxDownloadTask = 5;// 生成单例里面默认是5
    //获取当前任务数量
    HXINFOLOG(@"当前任务数量 = %ld", self.downloadManager.taskNumber);
    //注册通知，这个通知仅仅是通知任务数量
    [[NSNotificationCenter defaultCenter] addObserverForName:kXBDownloadManagerNotification object:self.downloadManager queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification * _Nonnull note) {
        NSNumber *num1 = note.userInfo[kManagerNotificationKeyTaskNumber];
        HXINFOLOG(@"当前任务数量1 = %@", num1.stringValue);
    }];

    YGPolicyTaskModel *model = [YGPolicyTaskModel model];
    model.SoftUrl = SoftUrl;
    model.SoftName = SoftName.length > 0? SoftName: SoftUrl.lastPathComponent;
    self.alert = [YGAlert alertWithStyle:NSInformationalAlertStyle message:@"正在下载" informative:@"" handler:^(NSModalResponse returnCode, NSString *message) {
        if ([message isEqualToString:@"已下载"]) {
            // 文件打开操作
            NSString *path = [kCachesDirictory stringByAppendingPathComponent:[SoftUrl lastPathComponent]];
            BOOL success = [[NSWorkspace sharedWorkspace] openFile:path];
            if (!success) {
                // 打开失败
                [YGNetHttpRequestObject postNotificationToControllerForMessage:@"文件打开失败"];
            }else {
                
            }
        }
    }];
    __weak typeof(self)weakS = self;
    [self.downloadManager addDownloadTaskWithUrl:model.SoftUrl andRelativePath:nil taskKey:nil policyTask:model taskExist:^(XBDownloadTaskInfo *key)  {
        __strong typeof(weakS)strongS = weakS;
        HXINFOLOG(@"重复下载,取消");
        if (key.status == XBDownloadTaskStatusSuccess) {
            //  重复下载的直接打开文件
            dispatch_async(dispatch_get_main_queue(), ^{
                strongS.alert.progressIndicator.doubleValue = 100;
                strongS.alert.textField.stringValue = @"100%";
                [strongS.alert addButtonWithTitle:@"打开"];
                [strongS.alert setMessageText:@"已下载"];
                // 文件打开操作
                NSString *path = [kCachesDirictory stringByAppendingPathComponent:[SoftUrl lastPathComponent]];
                BOOL success = [[NSWorkspace sharedWorkspace] openFile:path];
                if (success) {
                    [strongS.alert endAlertSheet];
                    strongS.alert = nil;
                }
            });
        }
    }];

}
#pragma mark - DownloadManager 代理
//添加任务，或设置代理时调用
- (void)managerAddTaskName:(NSString *)name andStatus:(XBDownloadTaskStatus)status fileLength:(NSInteger)length forKey:(NSString *)key atIndex:(NSInteger)idx withYGModel:(YGPolicyTaskModel *)model{
    XBDownloadTaskInfo *info = [[XBDownloadTaskInfo alloc] init];
    info.name = name;
    info.status = status;
    info.taskKey = key;
    info.filesize = length;
    info.ygTaskModel = model;
    [self.cells addObject:info];
}

//删除任务时调用,内部保证同一任务的其他代理方法会在该方法之前调用
- (void)managerDeleteTaskForKey:(NSString *)key atIndex:(NSInteger)idx{
    [self.cells removeObjectAtIndex:idx];
}

//任务状态改变时调用
- (void)managerTaskStatusChanged:(XBDownloadTaskStatus)status forKey:(NSString *)key atIndex:(NSInteger)idx{
    self.cells[idx].status = status;
    XBDownloadTaskInfo *info = self.cells[idx];
    if (status == XBDownloadTaskStatusSuccess) {
        // 下载成功 出现打开按钮
        NSNotification* notification = [NSNotification notificationWithName:@"RecvReportSendMsg" object:[NSString stringWithFormat:@"%@下载成功", info.ygTaskModel.SoftName]];
        [[NSNotificationCenter defaultCenter] postNotification:notification];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.alert.progressIndicator.doubleValue = 100;
            self.alert.textField.stringValue = @"100%";
            [self.alert setMessageText:@"已下载"];
            [self.alert addButtonWithTitle:@"打开"];
            NSString *path = [kCachesDirictory stringByAppendingPathComponent:[info.ygTaskModel.SoftUrl lastPathComponent]];
            if ([[NSFileManager defaultManager] fileExistsAtPath:path]) {
                BOOL success = [[NSWorkspace sharedWorkspace] openFile:path];
                if (success) {
                    [self.alert endAlertSheet];
                    self.alert = nil;
                }
            }

        });
    }
}
//进度和速度更新是调用，由kManagerProgressUpdateInterval控制
- (void)managerRefreshTaskProgress:(CGFloat)progress speed:(CGFloat)speed forKey:(NSString *)key atIndex:(NSInteger)idx{
    HXINFOLOG(@"progress = %f\n speed = %f", progress, speed)  ;
    self.cells[idx].progress = progress;
    self.cells[idx].speed = speed;
    dispatch_async(dispatch_get_main_queue(), ^{
        self.alert.progressIndicator.doubleValue = (double)(progress * 100);
        self.alert.textField.stringValue = [NSString stringWithFormat:@"%d%%", (int)(progress * 100)];
    });
}

//获得响应文件长度是调用
- (void)managerTaskFileLength:(NSInteger)fileLength forKey:(NSString *)key atIndex:(NSInteger)idx{
    self.cells[idx].filesize = fileLength;
}

//任务完成时调用
- (void)managerTaskCompleteWithError:(NSError *)error forKey:(NSString *)key atIndex:(NSInteger)idx{
    HXERRORLOG(@"error = %@ key = %@ idx = %ld", error, key, (long)idx);
}

- (void)dealloc
{
    HXINFOLOG(@"dealloc");
}
@end
