//
//  YGDownloadRequestObject.h
//  Mac_1.0
//
//  Created by xin on 2018/4/19.
//  Copyright © 2018年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XBDownloader.h"
@interface YGDownloadRequestObject : NSObject
@property (nonatomic, strong) XBDownloadManager *downloadManager;
+ (instancetype)shareInstance;

- (void)downloadForTaskSoftName:(NSString *)SoftName SoftURL:(NSString *)SoftUrl;

@end
