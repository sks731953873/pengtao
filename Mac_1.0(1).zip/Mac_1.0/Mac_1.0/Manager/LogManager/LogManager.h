//
//  LogManager.h
//  MAC_NAC
//
//  Created by apple on 2017/10/25.
//  Copyright © 2017年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>



// 至少有2个参数
#define save_local_Log(module,...) [[LogManager sharedInstance] logInfo:module logStr:__VA_ARGS__,nil]
@interface LogManager : NSObject

@property (nonatomic, copy) NSString *StartTime;
@property (nonatomic, copy) NSString *EndTime;

/**
 * 获取单例实例
 *
 * @return 单例实例
 */
+ (instancetype) sharedInstance;

#pragma mark - Method

/**
 * 写入日志
 *
 * @param module 模块名称
 * @param logStr 日志信息,动态参数
 */
- (void)logInfo:(NSString*)module logStr:(NSString*)logStr, ...;

/**
 * 清空过期的日志
 */
- (void)clearExpiredLog;

/**
 * 检测日志是否需要上传
 */
//- (void)checkLogNeedUpload;


/** 服务器通知要上传日志*/
- (void)serverUploadFiles;

/** 客户端在设置页面勾选后主动上报服务器*/
- (void)clientUploadFiles:(NSArray *)filePaths;
@end
