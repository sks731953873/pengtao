//
//  LogManager.m
//  MAC_NAC
//
//  Created by apple on 2017/10/25.
//  Copyright © 2017年 apple. All rights reserved.
//

#import "LogManager.h"
#import "YGTool.h"
#import "ZipArchive.h"
#import "YGAlert.h"
#import "YGNetHttpRequestObject.h"




// 日志保留最大天数
static const int LogMaxSaveDay = 7;
// 日志文件保存目录
static const NSString* LogFilePath = @"/Logs/";

@interface LogManager() <NSURLSessionTaskDelegate>
// 日期格式化
@property (nonatomic,retain) NSDateFormatter* dateFormatter;
// 时间格式化
@property (nonatomic,retain) NSDateFormatter* timeFormatter;

@property (nonatomic, strong) NSURLSession *session;
@property (nonatomic, strong) YGAlert *alert;
// 日志的目录路径
@property (nonatomic,copy) NSString* basePath;

@end

@implementation LogManager

- (NSURLSession *)session {
    if (!_session) {
        NSURLSessionConfiguration *cfg = [NSURLSessionConfiguration defaultSessionConfiguration];
        _session = [NSURLSession sessionWithConfiguration:cfg delegate:self delegateQueue:nil];
    }
    return _session;
}

/**
 * 获取单例实例
 *
 * @return 单例实例
 */
+ (instancetype) sharedInstance{
    
    static LogManager* instance = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!instance) {
            instance = [[LogManager alloc]init];
            NSNotificationCenter * notifi = [NSNotificationCenter defaultCenter];
            [notifi addObserver:instance selector:@selector(notificationCancelAlertTo) name:@"notificationCancelAlert" object:nil];
        }
    });
    return instance;
}

// 获取当前时间
+ (NSDate*)getCurrDate {
    NSDate *date = [NSDate date];
    NSTimeZone *zone = [NSTimeZone systemTimeZone];
    NSInteger interval = [zone secondsFromGMTForDate: date];
    NSDate *localeDate = [date dateByAddingTimeInterval: interval];
    return localeDate;
}
#pragma mark - Init

- (instancetype)init{
    self = [super init];
    if (self) {
        // 创建日期格式化
        NSDateFormatter* dateFormatter = [[NSDateFormatter alloc]init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd"];
        // 设置时区，解决8小时
        [dateFormatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
        self.dateFormatter = dateFormatter;
        // 创建时间格式化
        NSDateFormatter* timeFormatter = [[NSDateFormatter alloc]init];
        [timeFormatter setDateFormat:@"HH:mm:ss"];
        [timeFormatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
        self.timeFormatter = timeFormatter;
        
//        NSArray *paths1 =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
//        NSString *documentDirectory = [paths1 objectAtIndex:0];
        NSString *documentDirectory = kCachesDirictory;
        //定义记录文件全名以及路径的字符串filePath
        NSString *filePath = [documentDirectory stringByAppendingPathComponent:@"/IMC"];
        // 日志的目录路径
        self.basePath = [NSString stringWithFormat:@"%@%@",filePath,LogFilePath];
    }
    return self;
}

#pragma mark - Method
- (BOOL)shouldLog:(NSString*)module level:(NSString**)level
{
    // 信息级别
    NSArray *infoArr = @[@"[clearExpiredLog]",
                         @"SoftwareList",
                         @"SSZipArchive_log",
                         @"iosnative",
                         @"http/https",
                         @"UnInstallKey",
                         ];
    // 调试级别
    NSArray *debugArr = @[@"socket_log",
                          @"socket_error_log",
                          @"socket_task_log",
                          @"netauth_http_request",
                          @"Apple Script",
                          @"sleepMethod"];
    // 错误级别
    NSArray *errArr = @[@"hardwareAssets",];
    
    NSArray *finalArr = @[];
    
    if ([infoArr containsObject:module])
        *level = @"INFO";
    else if ([debugArr containsObject:module])
        *level = @"DEBUG";
    else
        *level = @"ERROR";
    
    // 读出配置信息
    NSString *logLvl = readFile(@"LogLvl");
    
    if ([logLvl isEqualToString:@"infoLog"])
        finalArr = infoArr;// 信息级别
    else if ([logLvl isEqualToString:@"debugLog"])
    {
        // 调试级别
        finalArr = [finalArr arrayByAddingObjectsFromArray:infoArr];
        finalArr = [finalArr arrayByAddingObjectsFromArray:debugArr];
    }
    else
    {
        // 错误级别
        finalArr = [finalArr arrayByAddingObjectsFromArray:infoArr];
        finalArr = [finalArr arrayByAddingObjectsFromArray:debugArr];
        finalArr = [finalArr arrayByAddingObjectsFromArray:errArr];
    }
    
    if ([finalArr containsObject:module])
        return YES;
    else
        return NO;
}

/**
 * 写入日志
 *
 * @param module 模块名称
 * @param logStr 日志信息,动态参数
 */
- (void)logInfo:(NSString*)module logStr:(NSString*)logStr, ...{
    
#pragma mark - 获取参数

    NSString *level = @"INFO";
    if (![self shouldLog:module level:&level])
        return;

    NSMutableString* parmaStr = [NSMutableString string];
    // 声明一个参数指针
    va_list paramList;
    // 获取参数地址，将paramList指向logStr
    va_start(paramList, logStr);
    id arg = logStr;
    @try {
        // 遍历参数列表
        while (arg) {
            [parmaStr appendString:arg];
            // 指向下一个参数，后面是参数类似
            arg = va_arg(paramList, NSString*);
        }
    } @catch (NSException *exception) {
        [parmaStr appendString:@"【记录日志异常】"];
    } @finally {
        // 将参数列表指针置空
        va_end(paramList);
    }
    
#pragma mark - 写入日志
    // 异步执行
    dispatch_async(dispatch_queue_create("writeLog", nil), ^{
        
        // 获取当前日期做为文件名
        NSString* fileName = [self.dateFormatter stringFromDate:[NSDate date]];
        NSString* filePath = [NSString stringWithFormat:@"%@%@.log",self.basePath,fileName];
        
        // [级别]-[时间]-[模块]-日志内容
        NSString* timeStr = [self.timeFormatter stringFromDate:[LogManager getCurrDate]];
        NSString* writeStr = [NSString stringWithFormat:@"[%@]-[%@]-[%@]-%@\n",level, timeStr,module,parmaStr];
        
        // 写入数据
        [self writeFile:filePath stringData:writeStr];
        
        HXINFOLOG(@"写入日志:%@\n%@",filePath, logStr);

    });
}

/**
 * 清空过期的日志
 */
- (void)clearExpiredLog{
    // 获取日志目录下的所有文件
    NSArray* files = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:self.basePath error:nil];
    if (files.count == 0) {
        return;
    }
    for (NSString* file in files) {
        NSString *dateFile = [file stringByReplacingOccurrencesOfString:@".log" withString:@""];
        NSDate* date = [self.dateFormatter dateFromString:dateFile];
        if (date) {
            NSTimeInterval oldTime = [date timeIntervalSince1970];
            NSTimeInterval currTime = [[LogManager getCurrDate] timeIntervalSince1970];
            NSTimeInterval second = currTime - oldTime;
            int day = (int)second / (24 * 3600);
            if (day >= LogMaxSaveDay) {
                // 删除该文件
                [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@/%@",self.basePath,file] error:nil];
                save_local_Log(@"[clearExpiredLog]", [NSString stringWithFormat:@"[%@]日志文件已被删除！", file]);
            }
        }
    }
}


#pragma mark - Private

/**
 * 写入字符串到指定文件，默认追加内容
 *
 * @param filePath 文件路径
 * @param stringData 待写入的字符串
 */
- (void)writeFile:(NSString*)filePath stringData:(NSString*)stringData{
    // 待写入的数据
    NSData* writeData = [stringData dataUsingEncoding:NSUTF8StringEncoding];
    
    // NSFileManager 用于处理文件
    BOOL createPathOk = YES;
    if (![[NSFileManager defaultManager] fileExistsAtPath:[filePath stringByDeletingLastPathComponent] isDirectory:&createPathOk]) {
        // 目录不存先创建
        [[NSFileManager defaultManager] createDirectoryAtPath:[filePath stringByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:nil];
    }
    if(![[NSFileManager defaultManager] fileExistsAtPath:filePath]){
        // 文件不存在，直接创建文件并写入
        [writeData writeToFile:filePath atomically:NO];
    }else{
        // NSFileHandle 用于处理文件内容
        // 读取文件到上下文，并且是更新模式
        NSFileHandle* fileHandler = [NSFileHandle fileHandleForUpdatingAtPath:filePath];
        // 跳到文件末尾
        [fileHandler seekToEndOfFile];
        // 追加数据
        [fileHandler writeData:writeData];
        // 关闭文件
        [fileHandler closeFile];
    }
}


#pragma mark 文件上传
/// 文件上传
- (void)NSURLSessionUploadTaskTest:(NSString *)zipFilePath {
    // 1.创建url  采用Apache本地服务器
    NSString *urlString = [NSString stringWithFormat:@"http://%@/update/upload_file.php", readFile(kServerAddress)];
    urlString = [urlString stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];
    NSURL *url = [NSURL URLWithString:urlString];
    // 2.创建请求
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    // 文件上传使用post
    request.HTTPMethod = @"POST";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=--MULTI-PARTS-FORM-DATA-BOUNDARY"];

    [request setValue:contentType forHTTPHeaderField:@"Content-Type"];
    // IMG_0359.jpg
    // 3.拼接表单，大小受MAX_FILE_SIZE限制(2MB)  FilePath:要上传的本地文件路径  formName:表单控件名称，应于服务器一致
//    NSData* data = [self getHttpBodyWithFilePath:@"/Users/xin/Documents/work/project/IMC/iOS客户端/2017年12月14日/2017-12-12.zip" formName:@"file" reName:@"/tmp/logs/client/2017-12-12.zip"];
    NSString *localFilePath = [NSString stringWithFormat:@"%@%@", self.basePath, zipFilePath];
    NSData *data = [self getHttpBodyWithFilePath:localFilePath
                                        formName:@"file"
                                          reName:[NSString stringWithFormat:@"/tmp/logs/client/%@/%@", readFile(kAgentID), zipFilePath]];
    request.HTTPBody = data;
    // 根据需要是否提供，非必须,如果不提供，session会自动计算
    [request setValue:[NSString stringWithFormat:@"%ld", data.length] forHTTPHeaderField:@"Content-Length"];

    // 4.1 使用dataTask
    // 弹窗提示开始上传
    self.alert = nil;
    __weak typeof(self)weakrSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        __strong typeof(weakrSelf)strongSelf = weakrSelf;
        strongSelf.alert = [YGAlert alertWithStyle:NSInformationalAlertStyle message:@"正在上传" informative:nil handler:^(NSModalResponse returnCode, NSString *message) {
            // 点击事件返回
        }];
        [[strongSelf.session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
            NSString *infoString =[[NSString alloc] initWithData:data encoding:CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000)];
            if (error == nil) {
                HXINFOLOG(@"upload success：%@", infoString);
            } else {
                [strongSelf.alert setMessageText:@"上传失败"];
                HXINFOLOG(@"upload error:%@\n[%@]",error, infoString);
                [YGNetHttpRequestObject postNotificationToControllerForMessage:@"文件上传:上传失败."];
            }
            //notificationCancelAlert  关闭上传进度弹窗
            dispatch_async(dispatch_get_main_queue(), ^{
                NSNotification *notification = [NSNotification notificationWithName:@"notificationCancelAlert" object:nil];
                [[NSNotificationCenter defaultCenter] postNotification:notification];
            });
            // 不管上报成功还是失败都删除zip文件
            NSError *rError = nil;
            [[NSFileManager defaultManager] removeItemAtPath:localFilePath error:&rError];
            if (error) {
                HXINFOLOG(@"removeItemAtPath error:[%@]", error);
            }
        }] resume];

    });


#if 0
    // 4.2 开始上传 使用uploadTask   fromData:可有可无，会被忽略
    [[self.session uploadTaskWithRequest:request fromData:data
                       completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
    }] resume];
#endif
}


#pragma mark URL-delegate
/** 上传进度监听*/
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didSendBodyData:(int64_t)bytesSent totalBytesSent:(int64_t)totalBytesSent totalBytesExpectedToSend:(int64_t)totalBytesExpectedToSend {
    float progress = (float)totalBytesSent / totalBytesExpectedToSend;
    HXINFOLOG(@"%f %@", progress, [NSThread currentThread]);
    __strong typeof(self)strongSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        strongSelf.alert.progressIndicator.doubleValue = progress*100;
        strongSelf.alert.textField.stringValue = [NSString stringWithFormat:@"%d%%", (int)(progress * 100)];
        if (progress >= 1) {
            [strongSelf.alert setMessageText:@"已上传"];
        }
    });

}

/// filePath:要上传的文件路径   formName：表单控件名称  reName：上传后文件名
- (NSData *)getHttpBodyWithFilePath:(NSString *)filePath formName:(NSString *)formName reName:(NSString *)reName
{
    NSMutableData *data = [NSMutableData data];
    NSURLResponse *response = [self getLocalFileResponse:filePath];
    // 文件类型：MIMEType  文件的大小：expectedContentLength  文件名字：suggestedFilename
//    NSString *fileType = response.MIMEType;

    // 如果没有传入上传后文件名称,采用本地文件名!
    if (reName == nil) {
        reName = response.suggestedFilename;
    }

    // 表单拼接
    NSMutableString *headerStrM1 =[NSMutableString string];
    NSMutableString *headerStrM2 =[NSMutableString string];
    NSMutableString *headerStrM3 =[NSMutableString string];
    NSMutableString *headerStrM4 =[NSMutableString string];
    [headerStrM1 appendFormat:@"--%@\r\n",@"--MULTI-PARTS-FORM-DATA-BOUNDARY"];
    [headerStrM1 appendFormat:@"Content-Disposition: form-data; name=\"file\"; filename=\"%@\"\r\n",filePath];
    [headerStrM1 appendFormat:@"Content-Type: application/octet-stream\r\n"];
    [headerStrM1 appendFormat:@"\r\n"];
    [data appendData:[headerStrM1 dataUsingEncoding:NSUTF8StringEncoding]];

    NSData *fileData = [NSData dataWithContentsOfFile:filePath];
    [data appendData:fileData];

    [headerStrM2 appendFormat:@"--%@\r\n",@"--MULTI-PARTS-FORM-DATA-BOUNDARY"];
    [headerStrM2 appendFormat:@"Content-Disposition: form-data; name=\"filepath\"\r\n"];
    [headerStrM2 appendFormat:@"\r\n"];
    [headerStrM2 appendFormat:@"%@\r\n", filePath];
    [data appendData:[headerStrM2 dataUsingEncoding:NSUTF8StringEncoding]];

    [headerStrM3 appendFormat:@"--%@\r\n",@"--MULTI-PARTS-FORM-DATA-BOUNDARY"];
    [headerStrM3 appendFormat:@"Content-Disposition: form-data; name=\"fileserverpath\"\r\n"];
    [headerStrM3 appendFormat:@"\r\n"];
    [headerStrM3 appendFormat:@"%@\r\n", reName];
    [data appendData:[headerStrM3 dataUsingEncoding:NSUTF8StringEncoding]];

    [headerStrM4 appendFormat:@"--%@\r\n",@"--MULTI-PARTS-FORM-DATA-BOUNDARY"];
    [headerStrM4 appendFormat:@"Content-Disposition: form-data; name=\"submit\"\r\n"];
    [headerStrM4 appendFormat:@"\r\n"];
    [headerStrM4 appendFormat:@"submit\r\n"];
    [data appendData:[headerStrM4 dataUsingEncoding:NSUTF8StringEncoding]];

    NSMutableString *footerStrM = [NSMutableString stringWithFormat:@"--%@--\r\n",@"boundary"];
    [data appendData:[footerStrM  dataUsingEncoding:NSUTF8StringEncoding]];
    //    NSLog(@"dataStr=%@",[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
    return data;
}
/// 获取响应，主要是文件类型和文件名
- (NSURLResponse *)getLocalFileResponse:(NSString *)urlString
{
    urlString = [urlString stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];
    // 本地文件请求
    NSURL *url = [NSURL fileURLWithPath:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];

    __block NSURLResponse *localResponse = nil;
    // 使用信号量实现NSURLSession同步请求
    dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
    [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        localResponse = response;
        dispatch_semaphore_signal(semaphore);
    }] resume];
    dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
    return  localResponse;
}

/** 生成zip并发起上传操作*/
- (void)createZipFileAtPaths:(NSArray *)paths whenFile:(NSString *)tPath{
    NSString* fileName = [self.dateFormatter stringFromDate:[NSDate date]];
    fileName = [fileName stringByReplacingOccurrencesOfString:@"-" withString:@""];
    NSString *zipFilePath = [NSString stringWithFormat:@"%@%@.zip", tPath, fileName];
    NSString *filePath = [NSString stringWithFormat:@"%@%@", self.basePath, zipFilePath];
//        NSArray* files = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:self.basePath error:nil];
    if ([SSZipArchive createZipFileAtPath:filePath withFilesAtPaths:paths]) {
        // 生成zip成功准备上传
        [self NSURLSessionUploadTaskTest:zipFilePath];
    }else{
//        save_local_Log(<#module, ...#>)
        HXINFOLOG(@"zip生成失败");
    }
}

/** 服务器通知要上传日志*/
- (void)serverUploadFiles {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSDirectoryEnumerator *dict = [fileManager enumeratorAtPath:self.basePath];
    NSMutableArray *fileArray = [NSMutableArray array];
    for (NSString *path in dict) {
        if (XInclusionRelationshipNotExists(path, @".log")) {
            continue;
        }
        NSInteger timePath = [[path stringByReplacingOccurrencesOfString:@"-" withString:@""] integerValue];
        if (timePath <= [self.EndTime integerValue] && timePath >= [self.StartTime integerValue]) {
            NSString *aPath = [NSString stringWithFormat:@"%@%@", self.basePath, path];
            if ([fileManager fileExistsAtPath:aPath]) {
                [fileArray addObject:aPath];
            }
        }
    }
    [self createZipFileAtPaths:fileArray whenFile:@"IMC_Server_"];
}

/** 客户端在设置页面勾选后主动上报服务器*/
- (void)clientUploadFiles:(NSArray *)filePaths {
    NSMutableArray *fArr = [NSMutableArray array];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    for (NSString *path in filePaths) {
        NSString *aPath = [NSString stringWithFormat:@"%@%@", self.basePath, path];
        if ([fileManager fileExistsAtPath:aPath]) {
            [fArr addObject:aPath];
        }
    }
    [self createZipFileAtPaths:fArr whenFile:@"IMC_Client_"];
}
- (void)notificationCancelAlertTo {
//    [self.alert endAlertSheet];
    self.alert = nil;
}
@end
