//
//  NotificationManager.h
//  Mac_1.0
//
//  Created by xin on 2018/4/27.
//  Copyright © 2018年 infogo. All rights reserved.
// 遗留：一轮转二轮再改

#import <Foundation/Foundation.h>

@interface NotificationManager : NSObject

@property (nonatomic, strong) NSUserNotificationCenter *userNotificationCenter;

/**
 * 获取单例实例
 *
 * @return 单例实例
 */
+ (instancetype) sharedInstance;
@end
