//
//  NotificationManager.m
//  Mac_1.0
//
//  Created by xin on 2018/4/27.
//  Copyright © 2018年 infogo. All rights reserved.
// 遗留：一轮转二轮再改

#import "NotificationManager.h"
#import "YGTool.h"
#import <Cocoa/Cocoa.h>
@interface NotificationManager() <NSUserNotificationCenterDelegate>



@end
@implementation NotificationManager


+ (instancetype)sharedInstance {
    static NotificationManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[NotificationManager alloc] init];
        manager.userNotificationCenter = [NSUserNotificationCenter defaultUserNotificationCenter];
        manager.userNotificationCenter.delegate = manager;
    });
    return manager;
}

#pragma mark NSUserNotificationCenterDelegate
- (void)userNotificationCenter:(NSUserNotificationCenter *)center didDeliverNotification:(NSUserNotification *)notification
{
    if ([notification.informativeText rangeOfString:@"警告"].location == NSNotFound)
    {
        writeFile(@"1", @"SendMsg");
    }
    HXINFOLOG(@"通知已经递交！");
}

- (void)userNotificationCenter:(NSUserNotificationCenter *)center didActivateNotification:(NSUserNotification *)notification
{
    HXINFOLOG(@"用户点击了OK！");
    NSApplication * application = [NSApplication sharedApplication];
    if ([application.dockTile.badgeLabel intValue] != 0) {
        [[application dockTile] setBadgeLabel:@""];
        writeFile(@"0", @"BedgeLabel");
    }
}

- (BOOL)userNotificationCenter:(NSUserNotificationCenter *)center shouldPresentNotification:(NSUserNotification *)notification
{
    //用户中心决定不显示该条通知(如果显示条数超过限制或重复通知等)，returen YES;强制显示
    return YES;
}



@end
