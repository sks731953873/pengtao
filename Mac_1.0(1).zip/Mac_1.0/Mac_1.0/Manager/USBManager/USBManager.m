//
//  USBManager.m
//  Mac_1.0
//
//  Created by xin on 2019/1/11.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "USBManager.h"
#import "FSSystemProfiler.h"
#import "XMLDictionary.h"
#import <Cocoa/Cocoa.h>
#import "YGTool.h"
#import "Singleton.h"
#import "YGSPolicyUsbClassCtrlModel.h"
#import "ViewController.h"
@interface USBManager ()

@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSAlert *alert;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) NSArray *lastArray;
@property (nonatomic, copy) NSString *policyTime;
@property (nonatomic, copy) NSString *sysPolicyTime;

@end

@implementation USBManager

+ (instancetype)shareInstance {
    static USBManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[USBManager alloc] init];
        manager.timer = [NSTimer timerWithTimeInterval:5.5f target:manager selector:@selector(timerFireFinUSBContrl:) userInfo:nil repeats:YES];
        [manager.timer fire];
        [[NSRunLoop mainRunLoop] addTimer:manager.timer forMode:NSDefaultRunLoopMode];
        [[[NSWorkspace sharedWorkspace] notificationCenter]addObserver:self selector:@selector(deviceMounted:)  name:NSWorkspaceDidMountNotification object: nil];
        [[[NSWorkspace sharedWorkspace] notificationCenter]addObserver:self selector:@selector(deviceWillUnmounted:)  name:NSWorkspaceWillUnmountNotification object: nil];

        [[[NSWorkspace sharedWorkspace] notificationCenter]addObserver:self selector:@selector(deviceUnmounted:)  name:NSWorkspaceDidUnmountNotification object: nil];
    });
    return manager;
}

#pragma mark
- (void)timerFireFinUSBContrl:(NSTimer *)timer {
//    NSArray *infoArray = [USBManager getUSBDeviceInfoByIOKit];
    @synchronized (self) {
        __weak typeof (self) wSelf = self;
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            __strong typeof(wSelf) sSelf = wSelf;
            NSArray *infoArray = [sSelf getUSBDeviceInfoBySystemProfiler];
            __block NSArray *array = [NSArray arrayWithArray:infoArray];
            static dispatch_once_t timeOnceToken;
            dispatch_once(&timeOnceToken, ^{ // 刚开程序做个容错
                if (array.count > 0) {
                    for (USBModel *model in array) { // 获取当前的信息
                        USBModel *t_model = [model qunueSelectFromUsbTableWithUsbID:model.locationID];
                        NSInteger num = [readFile(@"USBNeedReg") integerValue];
                        if (num != 0) {
                            if (t_model.registered != 1 && t_model.volumes.count > 0) {
                                USBVolumeModel *volume_model = t_model.volumes[0];
                                if (volume_model.mount_point.length > 0) {
                                    NSURL *fileUrl = [NSURL fileURLWithPath:volume_model.mount_point];
                                    [YGTool AppleScriptAtMTLaunchedThroughTheUrlPath:fileUrl withPath:volume_model.mount_point];
                                }
                            }
                        }
                    }
                }
            });
            if (sSelf.lastArray.count < 1) {
                sSelf.lastArray = [NSArray arrayWithArray:infoArray];
                return;
            }
            [sSelf reportUSBUnknownClass:infoArray array:sSelf.lastArray andType:@"Insert"];
            [sSelf reportUSBUnknownClass:sSelf.lastArray array:infoArray andType:@"Remove"];
            sSelf.lastArray = [NSArray arrayWithArray:infoArray];
        });
    }
                       
}

- (void)reportUSBUnknownClass:(NSArray *)array1 array:(NSArray *)array2 andType:(NSString *)type {
    __block NSArray *a1 = [NSArray arrayWithArray:array1];
    __block NSArray *a2 = [NSArray arrayWithArray:array2];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        YGPolicyItem *policyItem = self.PolicyItem;
        for (USBModel *model1 in a1) {
            if (model1.volumes.count > 0 || model1.bsd_name.length > 1) // U盘设备不在这里触发
                continue;
            int i = 0;
            for (USBModel *model2 in a2) {
                if ([model1.locationID isEqualToString:model2.locationID]) {
                    i++;
                    break;
                }
            }
            if (i==0) {
//                USBModel *tb_model = [model1 qunueSelectFromUsbTableWithModel:model1];
                // 非存储类设备才在这里进行上报
                if (model1.volumes.count < 1
                     && model1.size.length < 1
                    && model1.bsd_name.length < 1) {
                    if ([policyItem.usbPlugAuditModel isCoincidenceBodyWithUSBModel:model1]){
                        RecvUSBPlugReport(model1, type);
                        RecvUSBUnknownClass(model1); // unknow
                    }
                }
            }
        }
    });
}

#pragma mark notification 只能监听到存储设备的插拔
+ (void)deviceMounted:(NSNotification *)notification{
    //    NSArray * devices = [[NSWorkspace sharedWorkspace] mountedRemovableMedia];
    //Use -[NSFileManager mountedVolumeURLsIncludingResourceValuesForKeys:options:] instead."
    USBManager *manager = [USBManager shareInstance];
    manager.usbNotification = notification;
    // 发送通知告诉需要创建UI
    @synchronized (manager) {
        USBModel *model = [USBManager getModelAtPath:notification.userInfo[@"NSWorkspaceVolumeURLKey"]];
        if (model && model.isPlug == 0) {
            [model qunueUpdateUsbTableWithIsPlug:1];
            [model deviceIsRegistered];
        }else{
            //  新的存储设备 1、获取设备信息 2、存储到本地
            [[USBManager shareInstance] getUSBDeviceInfoBySystemProfiler];
            model = [USBManager getModelAtPath:notification.userInfo[@"NSWorkspaceVolumeURLKey"]];
            if (model && model.isPlug == 0) {
                [model qunueUpdateUsbTableWithIsPlug:1];
                [model deviceIsRegistered];
            }
        }
    }
}

/** USB设备将要拔出*/
+ (void)deviceWillUnmounted:(NSNotification *)notification {
    USBManager *manager = [USBManager shareInstance];
    manager.usbNotification = notification;
    @synchronized (manager) {
        NSURL *url = notification.userInfo[@"NSWorkspaceVolumeURLKey"];
        USBModel *model = [USBManager getModelAtPath:url];
        if (!model)
            return;
        USBModel *db_model = [model qunueSelectFromUsbTableWithUsbID:model.locationID];
        [db_model qunueUpdateUsbTableWithIsPlug:0];
        //  1、获取是否有策略
        YGPolicyItem *localPlC = manager.PolicyItem;
        if ([readFile(Offline) intValue] != 0 && !localPlC.OffLineEffect)           // 离线且离线不生效则返回
            return;
        //  2、上报
        if (localPlC.usbPlugAuditModel.ItemName.length > 0) {
            if (model){
                if ([localPlC.usbPlugAuditModel isCoincidenceBodyWithUSBModel:model]) {
                    RecvUSBPlugReport(model, @"Remove");
                }
            }
        }
        [model ExitAllStorageDevicesByPath:url.path]; // 多个分区的同出同进
        [model qunueUpdateUsbTableVolumesToClear];
    }
}

/** USB设备拔出通知*/
+ (void)deviceUnmounted:(NSNotification *)notification{
    USBManager *manager = [USBManager shareInstance];
    manager.usbNotification = notification;
    @synchronized (manager) {
        NSURL *url = notification.userInfo[@"NSWorkspaceVolumeURLKey"];
        USBModel *model = [USBModel FindModelWithFilePath:url.path];
        if (model) {
            if (model.isPlug == 1) {
                [model qunueUpdateUsbTableWithIsPlug:0];
                YGPolicyItem *localPlC = manager.PolicyItem;
                if ([readFile(Offline) intValue] != 0 && !localPlC.OffLineEffect)           // 离线且离线不生效则返回
                    return;
                //  2、上报
                if (localPlC.usbPlugAuditModel.ItemName.length > 0) {
                    if (model){
                        if ([localPlC.usbPlugAuditModel isCoincidenceBodyWithUSBModel:model]) {
                            RecvUSBPlugReport(model, @"Remove");
                        }
                    }
                }
                [model ExitAllStorageDevicesByPath:url.path]; // 多个分区的同出同进
                [model qunueUpdateUsbTableVolumesToClear];
            }
        }
    }
}


// Global HID manager reference.
IOHIDManagerRef gIOHIDManager;
// HID callback
//void Handle_DeviceMatchingCallback(void *context,
//                                   IOReturn result,
//                                   void *sender,
//                                   IOHIDDeviceRef device);
- (void)registerMatching {
    // Assume gIOHIDManager has already been created.
    // Set up a device matching callback, providing a pointer to |self| as the context.
//    gIOHIDManager = IOHIDManagerCreate(kCFAllocatorDefault, kIOHIDOptionsTypeNone);
//    IOHIDManagerRegisterDeviceMatchingCallback(gIOHIDManager,
//                                               Handle_DeviceMatchingCallback,
//                                               (void *)self);
    NSLog(@"registerMatching");
//    [USBManager getUSBDeviceInfoByIOKit];
//    [self getUSBDeviceInfoBySystemProfiler];
//    [[[USBModel alloc] init] qunueSelectFromUsbModel];

}

- (void)handleMatchingDevice:(IOHIDDeviceRef)device
                      sender:(void *)sender
                      result:(IOReturn)result {
    // Do something...
}

void Handle_DeviceMatchingCallback(void *context,
                              IOReturn result,
                              void *sender,
                              IOHIDDeviceRef device) {
    USBManager *const myObject = (__bridge USBManager *const)context;
    [myObject handleMatchingDevice:device sender:sender result:result];
}

+ (NSArray *)getUSBDeviceInfoByIOKit {
    //    kern_return_t kr;
    NSMutableArray *matchArray = @[].mutableCopy;
    CFMutableDictionaryRef matchDict;
    io_iterator_t iterator;
    io_registry_entry_t entry;
//    NSOperatingSystemVersion needHostDeviceVersion = {10,11,0};
//    if ([[NSProcessInfo processInfo] isOperatingSystemAtLeastVersion:needHostDeviceVersion])
//        matchDict = IOServiceMatching("IOUSBHostDevice");
//    else
//        matchDict = IOServiceMatching("AppleUSBDevice");
//            matchDict = IOServiceMatching(kIOUSBDeviceClassName);
    matchDict = IOServiceMatching("IOUSBDevice");
    //    kr =
    IOServiceGetMatchingServices(kIOMasterPortDefault, matchDict, &iterator);
    NSDictionary *resultInfo = nil;
    while ((entry = IOIteratorNext(iterator)) != 0) {
        CFMutableDictionaryRef properties=NULL;
        //        kr =
        IORegistryEntryCreateCFProperties(entry,
                                          &properties,
                                          kCFAllocatorDefault,
                                          kNilOptions);
        if (properties){
            resultInfo = (__bridge_transfer NSDictionary *)properties;
            USBModel *model = [USBModel IOKitDictToModel:resultInfo];
            if (model) {
                [matchArray addObject:model];
                [model qunueUpdateUsbTable];
            }
            NSData *macData = [resultInfo objectForKey:@"IOMACAddress"];
            if (!macData){
                continue;
            }
        }
    }
    IOObjectRelease(iterator);
    return matchArray;
}

/** system_profiler SPUSBDataType
*/
- (NSArray *)getUSBDeviceInfoBySystemProfiler {
    NSString *string = [FSSystemProfiler system_profiler:@[@"SPUSBDataType", @"-xml"]];
    return [self creatPlistFileWithArr:string];
}

- (NSArray *)creatPlistFileWithArr:(NSString *)pString{
    //将字典保存到document文件->获取appdocument路径   要创建的plist文件名 -> 路径
    NSString *filePath = [kCachesDirictory stringByAppendingPathComponent:@"/IMC/cfg/USB.plist"];
    //将数组写入文件
    NSError *error = nil;
    [pString writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:&error];
    if (error)
        HXINFOLOG(@"获取plist，写入本地失败[%@]", error);

//    [array writeToFile:filePath atomically:YES];
    //读取文件
    NSArray *plistArr = [NSArray arrayWithContentsOfFile:filePath];
//    NSLog(@"读取 写入的plist 文件:%@",plistArr);
    NSDictionary *item0 = plistArr[0];
    if (self.dataArray.count > 0)
    [self.dataArray removeAllObjects];
    return [self find_ItemsDictionary:item0];
}

- (NSArray *)find_ItemsDictionary:(NSDictionary *)_items {
    NSObject *obj = _items[@"_items"];
    if (obj) {
        if ([obj isKindOfClass:[NSArray class]]) {
            NSArray *array = (NSArray *)obj;
            if (array.count > 0) {
                for (int i = 0; i < array.count; i++) {
                    NSDictionary *items = array[i];
                    [self find_ItemsDictionary:items];
                }
            }else{
                NSLog(@"cnm1");
            }
        }else{
            NSLog(@"cnm2");
        }
    }else{
        // items 不存在
        USBModel *model = [USBModel SystemProfilerXMLToModel:_items];
        if (model) {
            [model qunueUpdateUsbTableEntryInfo];
            [self.dataArray addObject:model];
        }
    }
    return self.dataArray;
}

#pragma mark 弹窗提示
- (void)ShowAlertNotificationWithModel:(USBModel *)model {
//    if (self.alert) return;
    self.alert = [[NSAlert alloc] init];
    self.alert.messageText = @"提示信息：";
    self.alert.informativeText = @"发现新USB设备，本地设置需要进行注册操作，是否立即注册?";
    [self.alert addButtonWithTitle:@"是"];
    [self.alert addButtonWithTitle:@"否"];
    self.alert.alertStyle = NSWarningAlertStyle;
    NSArray *array = [NSApp windows];
    NSWindow *window = nil;
    if (array.count > 0) {
        for (id object in array) {
            if ([object isKindOfClass:[NSWindow class]]) {
                NSWindow *win = (NSWindow *)object;
                if (win.title.length>0 && [win.title isEqualToString:@"IMC"]) {
                    window = win;
                    break;
                }
            }
        }
    }
    if (!window) {
        window = [NSApp keyWindow];
        if (!window) {
            window = [NSApp mainWindow];
            if (!window) {
                [NSApp activateIgnoringOtherApps:YES];
                NSArray *windows = [NSApp windows];
                window = windows[0];
                if ([window isVisible]) {
                    [window orderOut:self];
                } else {
                    [NSApp activateIgnoringOtherApps:YES];
                    [window makeKeyAndOrderFront:self];
                }
            }
        }
    }else{
        [NSApp activateIgnoringOtherApps:YES];
        [window makeKeyAndOrderFront:self];
    }

    [self performSelector:@selector(postCreateUSBInfoWindowControllerNotificationWithModel:) withObject:model afterDelay:20.0f];
    __block USBModel *block_model = model;
    __weak typeof(self)wSelf = self;
    [self.alert beginSheetModalForWindow:window completionHandler:^(NSModalResponse returnCode) {
        if (returnCode == 1000) {
            NSNotification* noti = [NSNotification notificationWithName:@"UsbDeviceRegistration" object:block_model];
            [[NSNotificationCenter defaultCenter] postNotification:noti];
        } else if (returnCode == 1001) {
            // 点击的否
            [wSelf postCreateUSBInfoWindowControllerNotificationWithModel:block_model];
        }
        //  有点击事件
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(postCreateUSBInfoWindowControllerNotificationWithModel:) object:nil];
        [NSObject cancelPreviousPerformRequestsWithTarget:self];
    }]; 
}

- (void)postCreateUSBInfoWindowControllerNotificationWithModel:(USBModel *)model {
    if (self.alert) {
        [NSApp endSheet:self.alert.window];
        [self.alert.window orderOut:nil];
//        NSApplication
//        -[NSApplication stopModalWithCode:]，如果窗口不消失，[alert orderOut:nil]
        self.alert = nil;
    }
    __block USBModel *bModel = model;
    dispatch_async(dispatch_get_main_queue(), ^{
        NSNotification *notification = [NSNotification notificationWithName:@"createUSBInfoWindowController" object:bModel];
        [[NSNotificationCenter defaultCenter] postNotification:notification];
    });
}

/** 通过路径从数据库中寻找该设备 */
+ (USBModel *)getModelAtPath:(NSURL *)pathUrl {
    USBVolumeModel *volume_model = [USBVolumeModel DAClassGetVolumeModelWithPathUrl:pathUrl];
    if (!volume_model){
        HXINFOLOG(@"通过DA和[%@]获取到的为空", pathUrl);
        return nil;
    }
    NSArray *array = [[USBModel model] qunueSelectFromUsbModel];
    for (USBModel *model in array) {
        if (model.volumes.count > 0) {
            for (USBVolumeModel *volumeModel in model.volumes) {
                if (volume_model) {
                    if ([volume_model.volume_uuid isEqualToString:volumeModel.volume_uuid]) {
                        return model;
                    }
                }
            }
        }
    }
    return nil;
}


/** 获取系统配置信息
 */
+ (NSInteger)GetSPolicy_UsbClassCtrlInfoWithType:(NSString *)Code {
    // Code 类似于CR08065000
    YGPolicyItem *localPolicyItem = [YGPolicyItem GetYGPolicyItem];
    if (localPolicyItem) {
        YGSPolicyUsbClassCtrlModel *model = localPolicyItem.SPolicyUsbClassCtrlModel;
        if (model) {
            for (YGUsbManagerModel *usbManagerModel in model.Body) {
                if (usbManagerModel) {
                    if ([Code isEqualToString:usbManagerModel.Code]) {
                        return usbManagerModel.NeedReg;
                    }
                }
            }
        }
    }
    return 0;
}
#pragma mark get / set
- (NSMutableArray *)dataArray {
    if (!_dataArray) {
        _dataArray = @[].mutableCopy;
    }
    return _dataArray;
}

- (BOOL)PolicyIsChanged {
    NSString *sysPolicyTime = readFile(@"sysPolicyTime");
    NSString *PolicyTime = readFile(@"PolicyTime");
    if (![sysPolicyTime isEqualToString:self.sysPolicyTime]||
        ![PolicyTime isEqualToString:self.policyTime]) {
        self.policyTime = PolicyTime;
        self.sysPolicyTime = sysPolicyTime;
        return YES;
    }
    return NO;
}

- (YGPolicyItem *)PolicyItem {
    if ([self PolicyIsChanged]) {
        _PolicyItem = [YGPolicyItem GetYGPolicyItem];
        return _PolicyItem;
    }
    return _PolicyItem;
}
#pragma mark policy
// 管控策略
+ (BOOL)isExecutionWithUSBModel:(USBModel *)model atPolicyUsbDeviceCtrl:(YGPolicyUsbDeviceCtrlModel *)policyUsbDeviceCtrlModel {
    BOOL result = NO;
    for (int i = 0; i < policyUsbDeviceCtrlModel.Body.count; i++) {
        YGUsbDeviceItem *item = policyUsbDeviceCtrlModel.Body[i]; // 按顺序取，按顺序判断
        NSInteger num = [item isCoincidenceWithUSBModel:model];
        switch (num) {
            case 0: {
                result = NO;
                break;
            }
            case 1: {
                if (item.Rule==2) {
                    // rule == 2  需要禁止
                    return YES;
                }else{
                    return NO;
                }
            }
            case 2: {
                result = NO;
                break;
            }
        }
     }
    return result;
}

// 插拔策略
+ (BOOL)isExecutionWithUSBModel:(USBModel *)model atPolicyUsbPlugAudit:(YGPolicyUsbPlugAuditModel *)policyUsbPlugAudit {
    BOOL result = NO;
    for (int i = 0; i < policyUsbPlugAudit.Body.count; i++) {
        YGUsbPlugItem *item = policyUsbPlugAudit.Body[i]; // 按顺序取，按顺序判断
        NSInteger num = [item isCoincidenceWithUSBModel:model];
        switch (num) {
            case 0: {
                result = NO;
                break;
            }
            case 1: {
                return YES;
            }
            case 2: {
                result = NO;
                break;
            }
        }
    }
    return result;
}
@end

