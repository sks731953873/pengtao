//
//  USBManager.h
//  Mac_1.0
//
//  Created by xin on 2019/1/11.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <IOKit/hid/IOHIDManager.h>
#import "USBModel.h"
#import "YGPolicyItem.h"

@interface USBManager : NSObject

@property (nonatomic, strong) YGPolicyItem *PolicyItem;
@property (nonatomic, strong) NSNotification *usbNotification;

+ (instancetype)shareInstance;
- (void)registerMatching;
- (void)handleMatchingDevice:(IOHIDDeviceRef)device
                      sender:(void *)sender
                      result:(IOReturn)result;

/** 弹窗提示*/ 
- (void)ShowAlertNotificationWithModel:(USBModel *)model;
/** 展示注册信息*/
- (void)postCreateUSBInfoWindowControllerNotificationWithModel:(USBModel *)model;


// 管控策略
+ (BOOL)isExecutionWithUSBModel:(USBModel *)model atPolicyUsbDeviceCtrl:(YGPolicyUsbDeviceCtrlModel *)policyUsbDeviceCtrlModel;

// 插拔策略
+ (BOOL)isExecutionWithUSBModel:(USBModel *)model atPolicyUsbPlugAudit:(YGPolicyUsbPlugAuditModel *)policyUsbPlugAudit;
@end


