//
//  USBVolumeModel.m
//  Mac_1.0
//
//  Created by xin on 2019/2/22.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "USBVolumeModel.h"
#import <DiskArbitration/DiskArbitration.h>

@interface USBVolumeModel ()<NSCoding>

@end
@implementation USBVolumeModel


- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.name forKey:@"VolumeModel_name"];
    [encoder encodeObject:self.bsd_name forKey:@"VolumeModel_bsd_name"];
    [encoder encodeObject:self.size_in_bytes forKey:@"VolumeModel_size_in_bytes"];
    [encoder encodeObject:self.size forKey:@"VolumeModel_size"];
    [encoder encodeObject:self.volume_uuid forKey:@"VolumeModel_volume_uuid"];
    [encoder encodeObject:self.mount_point forKey:@"VolumeModel_mount_point"];
}

- (id)initWithCoder:(NSCoder *)decoder{
    if (self = [super init]) {
        self.name =          [decoder decodeObjectForKey:@"VolumeModel_name"];
        self.bsd_name =      [decoder decodeObjectForKey:@"VolumeModel_bsd_name"];
        self.size_in_bytes = [decoder decodeObjectForKey:@"VolumeModel_size_in_bytes"];
        self.size =          [decoder decodeObjectForKey:@"VolumeModel_size"];
        self.volume_uuid =   [decoder decodeObjectForKey:@"VolumeModel_volume_uuid"];
        self.mount_point =   [decoder decodeObjectForKey:@"VolumeModel_mount_point"];
    }
    return self;
}

+ (USBVolumeModel *)model {
    return [[USBVolumeModel alloc] init];
}
// 利用DA框架通过BSDName获取当前的u盘信息
+ (USBVolumeModel *)DAClassGetVolumeModelWithBSDName:(NSString *)bsd_name{
    DASessionRef session = DASessionCreate(kCFAllocatorDefault);
    DADiskRef disk = DADiskCreateFromBSDName(kCFAllocatorDefault, session, [bsd_name UTF8String]);
    CFDictionaryRef dict = DADiskCopyDescription(disk);
    USBVolumeModel *model = nil;
    if (!dict) {
        if(dict)
            CFRelease(dict);
        if(disk)
            CFRelease(disk);
        if(session)
            CFRelease(session);
        return model;
    }
    NSURL *path_url = (__bridge NSURL*)CFDictionaryGetValue(dict, kDADiskDescriptionVolumePathKey);
    NSString *path = path_url.path;
    if (path.length > 0) {
        model = [USBVolumeModel model];
        model.mount_point = path;
        model.name = (__bridge NSString *)CFDictionaryGetValue(dict, kDADiskDescriptionVolumeNameKey);
        model.bsd_name = (__bridge NSString *)CFDictionaryGetValue(dict, kDADiskDescriptionMediaBSDNameKey);
        NSNumber *numberSize = (__bridge NSNumber *)CFDictionaryGetValue(dict, kDADiskDescriptionMediaSizeKey);
        model.size_in_bytes = numberSize.stringValue;
        if (CFDictionaryGetValue(dict, kDADiskDescriptionVolumeUUIDKey)) {
            NSString *uuid = (NSString *)CFBridgingRelease(CFUUIDCreateString(NULL,CFDictionaryGetValue(dict, kDADiskDescriptionVolumeUUIDKey)));
            if (uuid) {
                model.volume_uuid = uuid;
            }
        }else{
            model.volume_uuid = model.size_in_bytes;
        }
    }
    //                CFRelease(urlRef);
    if(dict)
        CFRelease(dict);
    if(disk)
        CFRelease(disk);
    if(session)
        CFRelease(session);
    return model;
}

// 利用DA框架通过Path获取当前的挂载u盘信息
+ (USBVolumeModel *)DAClassGetVolumeModelWithPathUrl:(NSURL *)url {
    USBVolumeModel *model = nil;
    if (url.isFileURL) {
        model = [USBVolumeModel model];
        DASessionRef session = DASessionCreate(kCFAllocatorDefault);
        DADiskRef disk = DADiskCreateFromVolumePath(kCFAllocatorDefault, session, (__bridge CFURLRef)url);
        if (!disk)
            return nil;
        CFDictionaryRef dict = DADiskCopyDescription(disk);
        if (!dict)
            return nil;
        NSURL *path_url = (__bridge NSURL*)CFDictionaryGetValue(dict, kDADiskDescriptionVolumePathKey);
        NSString *path = path_url.path;
        if (path.length > 0) {
            model.mount_point = path;
            model.name = (__bridge NSString *)CFDictionaryGetValue(dict, kDADiskDescriptionVolumeNameKey);
            model.bsd_name = (__bridge NSString *)CFDictionaryGetValue(dict, kDADiskDescriptionMediaBSDNameKey);
            NSNumber *numberSize = (__bridge NSNumber *)CFDictionaryGetValue(dict, kDADiskDescriptionMediaSizeKey);
            model.size_in_bytes = numberSize.stringValue;
            if (CFDictionaryGetValue(dict, kDADiskDescriptionVolumeUUIDKey)) {
                NSString *uuid = (NSString *)CFBridgingRelease(CFUUIDCreateString(NULL,CFDictionaryGetValue(dict, kDADiskDescriptionVolumeUUIDKey)));
                if (uuid) {
                    model.volume_uuid = uuid;
                }
            }else{
                model.volume_uuid = model.size_in_bytes;
            }
        }
        //                CFRelease(urlRef);
        CFRelease(dict);
        CFRelease(disk);
        CFRelease(session);
    }
    return model;
}


+ (void)umnountDrivePath:(NSString *)voulumePath {
    DASessionRef session = DASessionCreate(kCFAllocatorDefault);
    CFURLRef path = CFURLCreateWithString(NULL, (__bridge CFStringRef)voulumePath, NULL);
    DADiskRef disk = DADiskCreateFromVolumePath(kCFAllocatorDefault, session, path);
//    DADiskUnmount(disk, kDADiskUnmountOptionWhole, unmount_done, (__bridge void *)(self));
    DADiskUnmount(disk, kDADiskUnmountOptionWhole, nil, (__bridge void *)(self));
//    CFRelease(disk);
    CFRelease(session);
}

//void unmount_done(DADiskRef disk,
//                  DADissenterRef dissenter,
//                  void *context)
//{
//    if (dissenter)
//    {
//        NSLog(@"Unmount failed.");
//    } else {
//        NSLog(@"Unmounted Volume");
//    }
//    DriverUtilitiesController *driverUtilitiesController = (__bridge DriverUtilitiesController *)context;
//    [driverUtilitiesController clearUnmountCallback];
//}
//
//- (void)clearUnmountCallback
//{
//    DASessionUnscheduleFromRunLoop(_session, [[NSRunLoop mainRunLoop] getCFRunLoop], kCFRunLoopDefaultMode);
//    CFRelease(self.session);
//}


- (NSString *)description {
    return [NSString stringWithFormat:@"\n <%@>\n{\n  name = [%@]\n  bsd_name = [%@]\n  size = [%@]\n  size_in_bytes = [%@]\n  volume_uuid = [%@]\n  mount_point = [%@]\n}\n ",
            [self class],
            _name,
            _bsd_name,
            _size,
            _size_in_bytes,
            _volume_uuid,
            _mount_point];
}
@end
