//
//  USBModel.m
//  Mac_1.0
//
//  Created by xin on 2019/1/14.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "USBModel.h"
#import "YGDataBase.h"
#import "YGTool.h"
#import "Singleton.h"
#import "USBManager.h"
@interface USBModel ()

@property (nonatomic, strong) YGDataBase *db;

@end
@implementation USBModel


- (YGDataBase *)db {
    if (!_db) {
        _db = [YGDataBase shareFMDataBase];
    }
    return _db;
}

+ (USBModel *)model {
    return [[USBModel alloc] init];
}

- (NSString *)sessionID {
    if (!_sessionID) {
        _sessionID = @"";
    }
    return _sessionID;
}

- (NSInteger)DepartID {
    if (!_DepartID) {
        _DepartID = 0;
    }
    return _DepartID;
}

-(void)setSize:(NSString *)size {
    _size = size;
//    if ([@"CR08065000" isEqualToString:size]) {
//        
//    }
}
- (NSString *)type {
    if ([@"PR08075000" isEqualToString:_type]) {
        return _type;
    }
    if (_bsd_name.length > 0) {
        _type = @"CR08065000"; // 移动硬盘之类的存储设备
        return _type;
    }else if (XInclusionRelationshipExists(_USBProductName, @"Keyboard")) {
        _type = @"KB08070000";//  键盘
    }else if (XInclusionRelationshipExists(_USBProductName, @"print")) {
        _type = @"PR08075000";// 打印机
    }else if (XInclusionRelationshipExists(_USBProductName, @"mouse")) {
        _type = @"MO08080000";// 鼠标
    }else{
        _type = @"UN08100000";// 未知类型
    }
    return _type;
}

- (NSMutableArray *)volumes{
    if (!_volumes) {
        _volumes = [NSMutableArray array];
    }
    return _volumes;
}

+ (USBModel *)IOKitDictToModel:(NSDictionary *)resultInfo {
    NSString *USBProductName = resultInfo[@"USB Product Name"];
    if (!USBProductName ||
        (XInclusionRelationshipExists(USBProductName, @"USB") &&
         XInclusionRelationshipExists(USBProductName, @"Hub")) ||
        [USBProductName isEqualToString:@"iBridge"]) {
        return nil;
    }
    USBModel *model = [USBModel model];
    NSInteger pid = [resultInfo[@"idProduct"] integerValue];
    NSInteger vid = [resultInfo[@"idVendor"] integerValue];
    NSString * sessionID = resultInfo[@"sessionID"]? resultInfo[@"sessionID"]:@"";
//    NSInteger kUSBSerialNumberString = [YGTool numberHexString:resultInfo[@"kUSBSerialNumberString"]];
    model.USBProductName = USBProductName;
    model.USBVendorName = resultInfo[@"USB Vendor Name"];
    model.USBVendorString = resultInfo[@"kUSBVendorString"];
    model.pid = pid;
    model.vid = vid;
    model.sessionID = sessionID.length > 0? sessionID:@"";

    model.locationID = [USBModel UniqueIdentifierWithPid:pid vid:vid andSession:model.sessionID];
    return  model;
}

+ (NSString *)UniqueIdentifierWithPid:(NSInteger)pid vid:(NSInteger)vid andSession:(NSString *)session {
    if (session.length>6) {
        session = [session substringFromIndex:session.length - 6];
    }else if (session.length > 0) {
        session = session;
    } else {
        session = @"";
    }
    return [NSString stringWithFormat:@"%@%@%@", @(pid), @(vid), session];
}

+ (USBModel *)SystemProfilerXMLToModel:(NSDictionary *)infoDictionary {
    NSString *name = infoDictionary[@"_name"];
    if (!name ||
        ( XInclusionRelationshipExists(name, @"USB") && XInclusionRelationshipExists(name, @"Hub")) ||
        [name isEqualToString:@"iBridge"]) {
        return nil;
    }
    NSString *location_id = infoDictionary[@"location_id"];
    if (location_id.length < 1) {
        return nil;
    }
    USBModel *model = [USBModel model];
    NSString *product_id = infoDictionary[@"product_id"];
    NSString *vendor_id = infoDictionary[@"vendor_id"];

    NSString *bcd_device = infoDictionary[@"bcd_device"];
    model.pid = [YGTool numberHexString:product_id];
    model.vid = [YGTool numberHexString:vendor_id];
    if ([infoDictionary[@"1284DeviceID"] length] > 0) {
        model.type = @"PR08075000";
    }
    NSString *serial_num = infoDictionary[@"serial_num"];
    model.sessionID = serial_num.length>0?serial_num:@"";
    model.locationID = [USBModel UniqueIdentifierWithPid:model.pid vid:model.vid andSession:model.sessionID];
    model.USBVendorString = bcd_device;
    model.USBProductName = infoDictionary[@"_name"];
    model.USBVendorName = infoDictionary[@"manufacturer"];
    NSArray *media = infoDictionary[@"Media"];
    if (media.count > 0) {
        for (int i = 0 ; i < media.count; i++) {
            NSDictionary *mediaInfo = media[i];
            model.size = mediaInfo[@"size"];
            model.size_bytes = [NSString stringWithFormat:@"%@", mediaInfo[@"size_in_bytes"]];
            model.bsd_name = mediaInfo[@"bsd_name"]; // 总挂载目录
            NSArray *volumes = mediaInfo[@"volumes"];
            if (volumes.count > 0) {
                for (NSDictionary *iDict in volumes) {
                    USBVolumeModel *v_model = [USBVolumeModel model];
                    NSString *mount_point = iDict[@"mount_point"];
                    if (mount_point.length>0) {
                        v_model.mount_point = mount_point;
                        v_model.bsd_name = iDict[@"bsd_name"];
                        v_model.name = iDict[@"_name"];
                        v_model.size = iDict[@"size"];
                        v_model.size_in_bytes = [NSString stringWithFormat:@"%@", iDict[@"size_in_bytes"]];

                        if (iDict[@"volume_uuid"]){
                            v_model.volume_uuid = iDict[@"volume_uuid"];
                        }else{
                            v_model.volume_uuid = v_model.size_in_bytes;
                        }
                        [model.volumes addObject:v_model];
                    }
                }
            }else{
                USBVolumeModel *v_model = [USBVolumeModel DAClassGetVolumeModelWithBSDName:model.bsd_name];
                if (v_model)
                [model.volumes addObject:v_model];
            }
        }
    }
    return model;
}

- (void)ExitAllStorageDevicesByPath:(NSString *)path {
    if (self.volumes.count == 1) {
        return;
    }
    for (USBVolumeModel *model in self.volumes) {
        if (model.mount_point.length > 0 && ![path isEqualToString:model.mount_point]) {
            [YGTool AppleScriptAtMTLaunchedThroughTheUrlPath:[NSURL fileURLWithPath:model.mount_point] withPath:model.mount_point];
        }
    }
}

+ (USBModel *)FindModelWithFilePath:(NSString *)filePath {
    NSArray *array = [[USBModel model] qunueSelectFromUsbModel];
    USBModel *model = nil;
    if (array.count > 0) {
        for (USBModel *db_model in array) {
            if (db_model.volumes.count > 0) {
                for (USBVolumeModel *db_volumeModel in db_model.volumes) {
                    if ([db_volumeModel.mount_point isEqualToString:filePath]) {
                        model = db_model;
                        break;
                    }
                }
            }
        }
    }
    return model;
}



#pragma mark fmdb
/**
 在数据库中创建UsbTable表
 */
- (void)qunueCreateUsbTable {
    NSString *createString = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS UsbTable(identify INTEGER PRIMARY KEY AUTOINCREMENT, USBProductName TEXT,USBVendorName TEXT, vid INTEGER, pid INTEGER, USBVendorString TEXT, locationID TEXT, sessionID TEXT, volumes BLOB, isPlug INTEGER, size TEXT, registered INTEGER, RecordID INTEGER, User TEXT, EndDate TEXT, DepartID INTEGER, bsd_name TEXT,size_bytes TEXT)"];
    if (self.db.queue) {
        [self.db.queue inDatabase:^(FMDatabase *db) {
            BOOL b = [db executeUpdate:createString];
            if (!b)
            HXINFOLOG(@"create UsbTable is %@", b? @"success": @"faild");
        }];
    }
}

/** NetAuth表插入完整数据*/
- (void)qunueInsertUsbTable {
    [self qunueCreateUsbTable];
    [self.db.queue inDatabase:^(FMDatabase *db) {
        BOOL insert = [db executeUpdate:@"INSERT INTO UsbTable (USBProductName,USBVendorName,vid,pid,USBVendorString,locationID,sessionID, volumes, isPlug,size,registered, RecordID, User, EndDate, DepartID, bsd_name, size_bytes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                       self.USBProductName,
                       self.USBVendorName,
                       [NSNumber numberWithDouble:self.vid],
                       [NSNumber numberWithInteger:self.pid],
                       self.USBVendorString,
                       self.locationID,
                       self.sessionID,
                       [self arrayToData:self.volumes],
                       @(self.isPlug),
                       self.size,
                       self.registered,
                       self.RecordID,
                       self.registeredUser,
                       self.EndDate,
                       @(self.DepartID),
                       self.bsd_name,
                       self.size_bytes];
        if (insert) {
            HXINFOLOG(@"FMDB 添加成员成功!!![%@]", self);
        }else{
            HXINFOLOG(@"FMDB 添加成员失败~~~");
        }
    }];
}

- (NSArray *)qunueSelectFromUsbModel {
    if (![self.db isHasTable:@"UsbTable"]) {
        return nil;
    }
    __block NSMutableArray *array = [NSMutableArray array];
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM UsbTable"];
    [_db.queue inDatabase:^(FMDatabase *db) {
        FMResultSet *result = [db executeQuery:sql];
        while ([result next]) {
            USBModel *model = [USBModel model];
            model.identify = [result intForColumn:@"identify"];
            model.USBVendorName = [result stringForColumn:@"USBVendorName"];
            model.USBProductName = [result stringForColumn:@"USBProductName"];
            model.sessionID = [result stringForColumn:@"sessionID"];
            model.pid = [result intForColumn:@"pid"];
            model.vid = [result intForColumn:@"vid"];
            model.USBVendorString = [result stringForColumn:@"USBVendorString"];
            model.locationID = [result stringForColumn:@"locationID"];
            model.isPlug = [result intForColumn:@"isPlug"];
            model.size = [result stringForColumn:@"size"];
            NSData *volumes = [result dataForColumn:@"volumes"];
            model.volumes = (NSMutableArray *)[model dataToArray:volumes];
            model.registered = [result intForColumn:@"registered"];
            model.RecordID = [result intForColumn:@"RecordID"];
            model.registeredUser = [result stringForColumn:@"User"];
            model.EndDate = [result stringForColumn:@"EndDate"];
            model.DepartID = [result intForColumn:@"DepartID"];
            model.bsd_name = [result stringForColumn:@"bsd_name"];
            model.size_bytes = [result stringForColumn:@"size_bytes"];
            [array addObject:model];
        }
    }];
    return array;
}

// 通过model查找表中的是否存在
- (USBModel *)qunueSelectFromUsbTableWithModel:(USBModel *)model {
    if (![self.db isHasTable:@"UsbTable"]) {
        return nil;
    }
    __block USBModel *usbModel = nil;
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM UsbTable where (pid = '%@' and vid = '%@' and locationID = '%@')",
                     @(model.pid),
                     @(model.vid),
                     model.locationID];
    [_db.queue inDatabase:^(FMDatabase *db) {
        FMResultSet *result = [db executeQuery:sql];
        while ([result next]) {
            usbModel = [[USBModel alloc] init];
            usbModel.identify = [result intForColumn:@"identify"];
            usbModel.USBVendorName = [result stringForColumn:@"USBVendorName"];
            usbModel.USBProductName = [result stringForColumn:@"USBProductName"];
            usbModel.sessionID = [result stringForColumn:@"sessionID"];
            usbModel.pid = [result intForColumn:@"pid"];
            usbModel.vid = [result intForColumn:@"vid"];
            usbModel.USBVendorString = [result stringForColumn:@"USBVendorString"];
            usbModel.locationID = [result stringForColumn:@"locationID"];
            usbModel.isPlug = [result intForColumn:@"isPlug"];
            usbModel.size = [result stringForColumn:@"size"];
            usbModel.registered = [result intForColumn:@"registered"];
            usbModel.RecordID = [result intForColumn:@"RecordID"];
            usbModel.registeredUser = [result stringForColumn:@"User"];
            usbModel.EndDate = [result stringForColumn:@"EndDate"];
            usbModel.DepartID = [result intForColumn:@"DepartID"];
            usbModel.bsd_name = [result stringForColumn:@"bsd_name"];
            usbModel.size_bytes = [result stringForColumn:@"size_bytes"];
            NSData *volumes = [result dataForColumn:@"volumes"];
            usbModel.volumes = (NSMutableArray *)[usbModel dataToArray:volumes];
        }
    }];
    return usbModel;
}

// 通过唯一标识查找model
- (USBModel *)qunueSelectFromUsbTableWithUsbID:(NSString *)usbID {
    if (![self.db isHasTable:@"UsbTable"]) {
        return nil;
    }
    __block USBModel *usbModel = nil;
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM UsbTable where locationID = '%@'",
                     usbID];
    [_db.queue inDatabase:^(FMDatabase *db) {
        FMResultSet *result = [db executeQuery:sql];
        while ([result next]) {
            usbModel = [[USBModel alloc] init];
            usbModel.identify = [result intForColumn:@"identify"];
            usbModel.USBVendorName = [result stringForColumn:@"USBVendorName"];
            usbModel.USBProductName = [result stringForColumn:@"USBProductName"];
            usbModel.sessionID = [result stringForColumn:@"sessionID"];
            usbModel.pid = [result intForColumn:@"pid"];
            usbModel.vid = [result intForColumn:@"vid"];
            usbModel.USBVendorString = [result stringForColumn:@"USBVendorString"];
            usbModel.locationID = [result stringForColumn:@"locationID"];
            usbModel.isPlug = [result intForColumn:@"isPlug"];
            usbModel.size = [result stringForColumn:@"size"];
            usbModel.registered = [result intForColumn:@"registered"];
            usbModel.RecordID = [result intForColumn:@"RecordID"];
            usbModel.registeredUser = [result stringForColumn:@"User"];
            usbModel.EndDate = [result stringForColumn:@"EndDate"];
            usbModel.DepartID = [result intForColumn:@"DepartID"];
            usbModel.bsd_name = [result stringForColumn:@"bsd_name"];
            usbModel.size_bytes = [result stringForColumn:@"size_bytes"];
            NSData *volumes = [result dataForColumn:@"volumes"];
            usbModel.volumes = (NSMutableArray *)[usbModel dataToArray:volumes];
        }
    }];
    return usbModel;
}
//
/**
 通过唯一标志修改当前的数据库数据
 NetAuth表中只会存一条数据
 */
- (void)qunueUpdateUsbTable {
    __block USBModel *pModel = [self qunueSelectFromUsbTableWithModel:self];
    if (!pModel) { // 说明当前数据库中有表但无数据(因为无论如何都创建了表)
        [self qunueInsertUsbTable];
        return;
    }
    if (self.volumes.count < 1) {
//        HXWARNLOG(@"该对象不存入[%@]", @(self.locationID));
        return;
    }
    NSString *sql = @"UPDATE UsbTable SET volumes = ?, size = ? WHERE identify = ?";
    __weak typeof(self) weakSelf = self;
    [self.db.queue inDatabase:^(FMDatabase *db) {
        if ([db executeUpdate:sql, [weakSelf arrayToData:self.volumes], weakSelf.size, @(pModel.identify)]) {
            HXINFOLOG(@"UPDATE [%@] 成功", self);
        }else{
            HXINFOLOG(@"UPDATE [%@] 失败", self);
        }
    }];
}

/** 更新所有信息*/
- (void)qunueUpdateUsbTableEntryInfo {
    __block USBModel *pModel = [self qunueSelectFromUsbTableWithModel:self];
    if (!pModel) { // 说明当前数据库中有表但无数据(因为无论如何都创建了表)
        [self qunueInsertUsbTable];
        return;
    }
    if (self.volumes.count < 1) {
        //        HXWARNLOG(@"该对象不存入[%@]", @(self.locationID));
        return;
    }

    NSString *sql = @"UPDATE UsbTable SET volumes = ?, size = ?, bsd_name = ?, size_bytes = ? WHERE identify = ?";
    __block USBModel *model = self;
    [self.db.queue inDatabase:^(FMDatabase *db) {
        if ([db executeUpdate:sql, [model arrayToData:model.volumes], model.size, model.bsd_name, model.size_bytes, @(pModel.identify)]) {
//            HXINFOLOG(@"UPDATE [%@] 成功", self);
        }else{
            HXINFOLOG(@"UPDATE [%@] 失败", self);
        }
    }];
}

/**
 通过唯一标志修改当前的注册状态
 */
- (void)qunueUpdateUsbTableRegistered {
    USBModel *pModel = [self qunueSelectFromUsbTableWithModel:self];
    if (!pModel) { // 说明当前数据库中有表但无数据(因为无论如何都创建了表)
        [self qunueInsertUsbTable];
        return;
    }
    NSString *sql = [NSString stringWithFormat:@"UPDATE UsbTable SET registered = '%@', EndDate = '%@', User = '%@', DepartID = '%@' WHERE identify = '%@'",
                     @(self.registered),
                     self.EndDate,
                     self.registeredUser,
                     @(self.DepartID),
                     @(pModel.identify)];
    [self.db.queue inDatabase:^(FMDatabase *db) {
        if ([db executeUpdate:sql]) {
//            HXINFOLOG(@"UPDATE [%@] 成功", self);
        }else{
            HXINFOLOG(@"UPDATE [%@] 失败", self);
        }
    }];
}


/** 更新设备插入状态值*/
- (void)qunueUpdateUsbTableWithIsPlug:(NSInteger)isPlug {
    NSString *sql = @"UPDATE UsbTable SET isPlug = ? WHERE identify = ?";
    __block USBModel *model = self;
    [self.db.queue inDatabase:^(FMDatabase *db) {
        if (![db executeUpdate:sql, @(isPlug), @(model.identify)]) {
            HXINFOLOG(@"UPDATE [%@] 失败", self);
        }
    }];
}

/** 通过id清楚设备中的volumes条目*/
- (void)qunueUpdateUsbTableVolumesToClear {
    NSString *sql = @"UPDATE UsbTable SET volumes = ? WHERE identify = ?";
    __block USBModel *model = self;
    [self.db.queue inDatabase:^(FMDatabase *db) {
        if ([db executeUpdate:sql, [model arrayToData:[NSMutableArray array]], @(model.identify)]) {
            HXINFOLOG(@"UPDATE [%@] 成功", self);
        }else{
            HXINFOLOG(@"UPDATE [%@] 失败", self);
        }
    }];
}


- (NSData *)arrayToData:(NSMutableArray *)array {
    NSArray *a = [NSArray arrayWithArray:array];
    return [NSKeyedArchiver archivedDataWithRootObject:a];
}

- (NSArray *)dataToArray:(NSData *)datas {
    NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithData:datas];
    return [NSMutableArray arrayWithArray:array];
}
#pragma mark -判断是否注册
/** 获取当前设备是否注册*/
- (BOOL)deviceIsRegistered {
//    self.registered = 0;
//    self.EndDate = @"";
//    self.registeredUser = @"";
//    [self qunueUpdateUsbTableRegistered];
    RecvGetUsbInfo(self.locationID);

    __block BOOL result = NO;
    int64_t delayInSeconds = 1.5f; // 延迟的时间
    __block USBModel *b_model = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        YGPolicyItem *Item = [YGPolicyItem GetYGPolicyItem];
        if ([readFile(Offline) intValue] != 0 && !Item.OffLineEffect) {
            // 离线且离线不生效则返回
            return;
        }
        USBManager *manager = [USBManager shareInstance];
        USBModel *model = [b_model qunueSelectFromUsbTableWithModel:b_model];// 获取最新的
        // USB插拔审计
        if (manager.PolicyItem.usbPlugAuditModel.ItemName.length > 0 && model) {
            if ([manager.PolicyItem.usbPlugAuditModel isCoincidenceBodyWithUSBModel:model])
                RecvUSBPlugReport(model, @"Insert");
        }
        // USB设备管控
        BOOL shouldPlug = NO;
        if (manager.PolicyItem.usbDeviceCtrlModel.Body.count > 0 && model) {
            if ([USBManager isExecutionWithUSBModel:model
                              atPolicyUsbDeviceCtrl:manager.PolicyItem.usbDeviceCtrlModel]) {
                if (model.volumes.count > 0) {
                    for (USBVolumeModel *volumeModel in model.volumes) {
                        [YGTool AppleScriptAtMTLaunchedThroughTheUrlPath:[NSURL fileURLWithPath:volumeModel.mount_point] withPath:volumeModel.mount_point];
                    }
                }
            }else{
                shouldPlug = YES;
            }
        }else{
            shouldPlug = YES;
        }
        if (shouldPlug) {
            // 符合策略  但是非注册设备是不能用的
            if (model.registered != 1) {
                NSInteger suc = [readFile(@"USBNeedReg") integerValue];
                if (suc != 0) {
                    if (model.volumes.count>0) {
                        for (USBVolumeModel *volumeModel in model.volumes) {
                            if (volumeModel.mount_point.length>0) {
//                                [USBVolumeModel umnountDrivePath:volumeModel.mount_point];
                                [YGTool AppleScriptAtMTLaunchedThroughTheUrlPath:[NSURL fileURLWithPath:volumeModel.mount_point] withPath:volumeModel.mount_point];
                            }
                        }
                    }
                }
            }
        }
        
        // 是否需要注册
        for (YGUsbManagerModel *usb_manager_model in Item.SPolicyUsbClassCtrlModel.Body) {
            if ([model.type isEqualToString:usb_manager_model.Code]){
                switch (usb_manager_model.NeedReg) {
                    case 0: {
                        // 无需注册  什么都不做 也不弹窗 直接返回
//                        dispatch_async(dispatch_get_main_queue(), ^{
//                            [[USBManager shareInstance] postCreateUSBInfoWindowControllerNotificationWithModel:model];
//                        });
                        break;
                    }
                    case 1: {
                        // 手动注册
                        dispatch_async(dispatch_get_main_queue(), ^{
                            if (model.registered != 1) {              // 发起手动注册
                                if (model.EndDate.length<1) {
                                    // 未注册未审核
                                    [[USBManager shareInstance] ShowAlertNotificationWithModel:model];
                                }else{
                                    // 已注册未审核状态才信息弹窗
                                    [[USBManager shareInstance] postCreateUSBInfoWindowControllerNotificationWithModel:model];
                                }
                            }else{
                                result = YES; // 已注册设备，弹窗提示
                                [[USBManager shareInstance] postCreateUSBInfoWindowControllerNotificationWithModel:model];
                            }
                        });
                        break;
                    }
                    case 2: {
                        // 自动注册
                        if (model.registered != 1) {
                            // 自动注册  信息默认
                            RecvUSBRegister(model, readFile(@"serUserName"), @"自动注册", readFile(@"selfDepart"));
                            model.registered = 2;
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [[USBManager shareInstance] postCreateUSBInfoWindowControllerNotificationWithModel:model];
                            });
                        }else{
                            result = YES;
                            // 已注册设备  进行信息展示
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [[USBManager shareInstance] postCreateUSBInfoWindowControllerNotificationWithModel:model];
                            });
                        }
                        break;
                    }
                }
            }
        }

    });
    return result;
}

- (NSString *)description {
    return [NSString stringWithFormat:@"\n <%@>\n{\n  identity = [%@]\n  USBProductName = [%@]\n  USBVendorName = [%@]\n  USBVendorString = [%@]\n  pid = [%@]\n  vid = [%@]\n  sessionID = [%@]\n  locationID = [%@]\n  type = [%@]\n  volumes = [%@]\n  size = [%@]\n  registered = [%@]\n  RecordID = [%@]\n  registeredUser = [%@]\n  EndDate = [%@]\n  DepartID = [%@]\n  bsd_name = [%@]\n  isPlug = [%@]\n  size_bytes = [%@]\n}\n ",
            [self class],
            @(_identify),
            _USBProductName,
            _USBVendorName,
            _USBVendorString,
            @(_pid),
            @(_vid),
            _sessionID,
            _locationID,
            _type,
            _volumes,
            _size,
            @(_registered),
            @(_RecordID),
            _registeredUser,
            _EndDate,
            @(_DepartID),
            _bsd_name,
            @(_isPlug),
            _size_bytes];
}


@end
