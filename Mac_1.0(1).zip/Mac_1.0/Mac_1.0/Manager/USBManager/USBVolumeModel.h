//
//  USBVolumeModel.h
//  Mac_1.0
//
//  Created by xin on 2019/2/22.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface USBVolumeModel : NSObject

@property (nonatomic, copy) NSString *name;
/** 大小 8.0G*/
@property (nonatomic, copy) NSString *size;
/** 挂载点 路径*/
@property (nonatomic, copy) NSString *mount_point;
/** 挂在在哪个disk下*/
@property (nonatomic, copy) NSString *bsd_name;
/** byte字节*/
@property (nonatomic, copy) NSString *size_in_bytes;
/** 唯一标示*/
@property (nonatomic, copy) NSString *volume_uuid;


+ (USBVolumeModel *)model;

+ (USBVolumeModel *)DAClassGetVolumeModelWithBSDName:(NSString *)bsd_name;
+ (USBVolumeModel *)DAClassGetVolumeModelWithPathUrl:(NSURL *)url ;
+ (void)umnountDrivePath:(NSString *)voulumePath;
@end


