//
//  USBModel.h
//  Mac_1.0
//
//  Created by xin on 2019/1/14.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "USBVolumeModel.h"



@interface USBModel : NSObject

/** 数据库唯一标识*/
@property (nonatomic, assign) NSInteger identify;
@property (nonatomic, copy) NSString *USBProductName;
@property (nonatomic, copy)NSString *USBVendorName;
@property (nonatomic, copy)NSString *USBVendorString;
@property (nonatomic, assign)NSInteger pid;
@property (nonatomic, assign)NSInteger vid;
@property (nonatomic, copy)NSString * locationID;
@property (nonatomic, copy) NSString * sessionID;
/** 服务器插入时记录的ID*/
@property (nonatomic, assign) NSInteger RecordID;
@property (nonatomic, strong) NSMutableArray *volumes;
//@property (nonatomic, strong) NSMutableArray *paths;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, assign) NSInteger isPlug;
/** 是否在服务器注册*/
@property (nonatomic, assign) NSInteger registered;
// 8.05 GB
@property (nonatomic, copy) NSString *size;
//8053055488
@property (nonatomic, copy) NSString *size_bytes;
// disk3
@property (nonatomic, copy) NSString *bsd_name;
/** 是否正在注册*/
//?????

/** 注册人*/
@property (nonatomic, copy) NSString *registeredUser;
/** 注册时绑定的部门DepartID*/
@property (nonatomic, assign) NSInteger DepartID;
/** 注册到期时间*/
@property (nonatomic, copy) NSString *EndDate;
+ (USBModel *)IOKitDictToModel:(NSDictionary *)resultInfo;
+ (USBModel *)SystemProfilerXMLToModel:(NSDictionary *)infoDictionary;
+ (USBModel *)model;
+ (USBModel *)FindModelWithFilePath:(NSString *)filePath;
#pragma mark fmdb
/**
 在数据库中创建UsbTable表
 */
- (void)qunueCreateUsbTable;

/** NetAuth表插入完整数据*/
- (void)qunueInsertUsbTable ;

// 取出所有的数据
- (NSArray *)qunueSelectFromUsbModel ;

// 通过model查找表中的是否存在
- (USBModel *)qunueSelectFromUsbTableWithModel:(USBModel *)model;

// 通过唯一标识查找model
- (USBModel *)qunueSelectFromUsbTableWithUsbID:(NSString *)usbID;
//
/**
 通过唯一标志修改当前的数据库数据
 NetAuth表中只会存一条数据
 */
- (void)qunueUpdateUsbTable;
- (void)qunueUpdateUsbTableRegistered;

/** 更新所有信息*/
- (void)qunueUpdateUsbTableEntryInfo;
/** 更新设备插入状态值*/
- (void)qunueUpdateUsbTableWithIsPlug:(NSInteger)isPlug;
/** 通过id清楚设备中的volumes条目*/
- (void)qunueUpdateUsbTableVolumesToClear;

#pragma mark  通过socket获取当前设备的注册状态
/** 获取当前设备是否注册*/
- (BOOL)deviceIsRegistered;

- (void)ExitAllStorageDevicesByPath:(NSString *)path;
@end


