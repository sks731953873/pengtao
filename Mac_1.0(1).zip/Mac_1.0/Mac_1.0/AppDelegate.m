//
//  AppDelegate.m
//  Mac_1.0
//
//  Created by apple on 2016/11/7.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import "AppDelegate.h"
#import "YGTool.h"
#import "UncaughtExceptionHandler.h"
#import "YGFileDefault.h"
//# import <CommonCrypto/CommonDigest.h>
@interface AppDelegate ()
/** 退出弹窗*/
@property (nonatomic, strong) NSAlert *alert;
@property (nonatomic, strong) NSStatusItem *statusItem;//在.h文件中定义*

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
#pragma mark 崩溃日志
    // 将下面C函数的函数地址当做参数
//    [UncaughtExceptionHandler InstallUncaughtExceptionHandler];
//    NSSetUncaughtExceptionHandler (&UncaughtExceptionHandlers);
    // Insert code here to initialize your application
    // 注册点击dock中的退出方法，当点击dock中的退出时触发(handleQuitEvent:withReplyEvent:)
    NSAppleEventManager* appleEventManager = [NSAppleEventManager sharedAppleEventManager];
    [appleEventManager setEventHandler:self
                           andSelector:@selector(handleQuitEvent:withReplyEvent:)
                         forEventClass:kCoreEventClass
                            andEventID:kAEQuitApplication];
    [[NSApp mainWindow] center];
//    [[NSNotificationCenter defaultCenter] addObserver:self.application selector:@selector(windowDidExpose:) name:NSWindowWillBeginSheetNotification object:self];
    //   [NSApp hideOtherApplications:_application]; // 隐藏别的app
    [self isFirstOpenAPP];
    [YGTool appleScriptClearArpTable];

}
- (void)applicationDidBecomeActive:(NSNotification *)notification {
    NSApplication * application = [NSApplication sharedApplication];
    if ([application.dockTile.badgeLabel intValue] != 0) {
        [[application dockTile] setBadgeLabel:@""];
        writeFile(@"0", @"BedgeLabel");
    }
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

- (void)handleQuitEvent:(NSAppleEventDescriptor*)event withReplyEvent:(NSAppleEventDescriptor*)replyEvent {
//    NSArray *windows = [NSApp windows];
//    NSWindow *window = windows[0];
//    [NSApp activateIgnoringOtherApps:YES];
//    [window makeKeyAndOrderFront:self];
//    [self ShowNSAlertSheet];
    exit(0);
}

//采用Sheet的方式展示
- (void)ShowNSAlertSheet {
    //    [self applicationShouldHandleReopen:app hasVisibleWindows:YES];
    self.alert = [[NSAlert alloc] init];
    self.alert.messageText = @"关闭";
    self.alert.informativeText = @"确定要退出该程序吗?";
    [self.alert addButtonWithTitle:@"退出"];
    [self.alert addButtonWithTitle:@"返回"];

    [self.alert setAlertStyle:NSWarningAlertStyle];
    //__bridge_retained for arc
    NSWindow *window = [NSApp keyWindow];
    if (!window) {
        window = [NSApp mainWindow];
        if (!window) {
            [NSApp activateIgnoringOtherApps:YES];
            NSArray *windows = [NSApp windows];
            if (windows.count > 0) {
                window = windows[0];
                if ([window isVisible]) {
                    [window orderOut:self];
                } else {
                    [NSApp activateIgnoringOtherApps:YES];
                    [window makeKeyAndOrderFront:self];
                }
            }
        }
    }
    [self.alert beginSheetModalForWindow:window completionHandler:^(NSModalResponse returnCode) {
        if (returnCode == 1000) {
            exit(0);
        }else if (returnCode == 1001) {

        }
    }];
}

- (BOOL)applicationShouldHandleReopen:(NSApplication *)sender hasVisibleWindows:(BOOL)flag{
    NSApplication * application = [NSApplication sharedApplication];
    if ([application.dockTile.badgeLabel intValue] != 0) {
        [[application dockTile] setBadgeLabel:@""];
        writeFile(@"0", @"BedgeLabel");
    }
    
    if (!flag) {
        for (NSWindow * window in sender.windows) {
            [window makeKeyAndOrderFront:self];
        }
    }
    return YES;
}

// 现在是在安装软件的PKG内增加了一个文件，每次安装软件的时候就会先去判断该文件是否存在，如果存在就认为新装的客户端;如果不存在就认为已经安装
- (void)isFirstOpenAPP { 
//    NSString *f2 = [YGFileDefault readInfoFrom:@"firstLaunch"];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSUserDirectory, NSLocalDomainMask, YES);
    NSString *libraryPath = [paths lastObject];
    NSString *pPath = [libraryPath stringByAppendingPathComponent:@"Shared/firstLaunch.cfg"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:pPath]) {// 存在该文件
        [self writeCurrentTime];
        NSError *error = nil;
        [[NSFileManager defaultManager] removeItemAtPath:pPath error:&error];
    }else {
        NSString *firstLaunch = readFile(@"firstLaunch");
        if (firstLaunch.length < 1) {
            [self writeCurrentTime];
        }
    }
    [self clearExpiredLog];
}

- (void)writeCurrentTime {
    double time = current_Time_Stamp();
    long cTime = time;
    writeFile([NSString stringWithFormat:@"%ld", cTime], @"firstLaunch");
    //        [YGFileDefault writeInfo:[NSString stringWithFormat:@"%ld", cTime] toPath:@"firstLaunch"];
}

// 清除过期日志
- (void)clearExpiredLog{
    [[LogManager sharedInstance] clearExpiredLog];
}
#pragma mark -增加Item
- (void)createStateBarItem {
    self.statusItem = [[NSStatusBar systemStatusBar] statusItemWithLength:NSVariableStatusItemLength];
    NSMenu *statusMenu = [[NSMenu alloc] initWithTitle:@""];

    NSMenuItem *item1 = [[NSMenuItem alloc] initWithTitle:@"status_item_open"
                                                   action:@selector(startApp)
                                            keyEquivalent:@"o"];
    item1.enabled = YES;
    [statusMenu insertItem:item1 atIndex:0];
    NSMenuItem *item2 = [[NSMenuItem alloc] initWithTitle:@"status_item_checkForUpdate"
                                                   action:@selector(appCheckForUpdates:)
                                            keyEquivalent:@"u"];
    item2.enabled = YES;
    [statusMenu insertItem:item2 atIndex:1];
    NSMenuItem *item3 = [[NSMenuItem alloc] initWithTitle:@"alert_exit"
                                                   action:@selector(exit)
                                            keyEquivalent:@"q"];
    item3.enabled = YES;
    [statusMenu insertItem:item3 atIndex:2];
    NSImage *icon = [NSImage imageNamed:@"icon_32"];
    //    icon.template = YES;
    _statusItem.image = icon;
    [_statusItem setHighlightMode:YES];
    _statusItem.menu = statusMenu;
}
@end
