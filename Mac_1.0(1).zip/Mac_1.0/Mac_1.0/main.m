//
//  main.m
//  Mac_1.0
//
//  Created by apple on 2016/11/7.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
