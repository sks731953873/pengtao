 //
//  Singleton.m
//  Mac_1.0
//
//  Created by apple on 2016/11/10.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import "Singleton.h"
#import "YGTool.h"
#import "SoftwareList.h"
//#import "YGMessageSplicing.h"
#import "HardwareAssets.h"
#import "YGRemoteManagement.h"
#import "YGPolicyItem.h"
#import "YGInternetBehaviorItemList.h"
#import "zlib.h"
#include <stdio.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <netdb.h> //hostent
#include <sys/ioctl.h>
#include <sys/_select.h>
#import "YGNetHttpRequestObject.h"
#import "XMLDictionary.h"
#import "NSData+UTF8.h"
#import "HXZipAndUnzip.h"
#import "YGUSBDeviceModel.h"

#define ENCODE_KEY "infogo"
#define socket_log @"socket_log" //  用于记录日志
#define socket_error_log @"socket_error_log"
#define socket_task_log @"socket_task_log"
@interface Singleton ()
{
    /** 总策略类*/
    YGPolicyItem * policyItem;
}


@end

@implementation Singleton

@synthesize connectTimer;

static NSString *const kPolicyTime = @"PolicyTime";
// 目前主要是用来记录USB全局是否手动注册的策略的更新时间
static NSString *const kSysPolicyTime = @"sysPolicyTime";


typedef struct _SvrPacketHead
{
    // 注意不能使用long型，long型在X64上面是8个字节
    unsigned int	nLen;                           // 所有数据的长度，含本身
    unsigned int	cVersion;		//'ASM5'        // 报文格式版本，当前为5。为将来扩展报文格式
    unsigned int	cType;                          // 报文的类型 1-客户端请求AsmSvr报文 2-AsmSvr应答给客户端报文 3-AsmSvr请求报文 4-AsmSvr应答给报文 5-WEB端请求报文 6-应答给WEB端报文
    unsigned int	cZip;                           // 报文是否进行了压缩
    unsigned int	cCrypt;                         // 报文是否进行了加密    异或加密 infogo
    char			szTradeCode[32];                // 交易代码，异或加密    infogo
    unsigned int	nSerial;
    unsigned int	nOriSize;
}SvrPacketHead, *PSvrPacketHead;
/*
 通讯的报文格式为
 SvrPacketHead + Data
 其中Data的长度由HEAD中的nLen进行指定，DATA的格式采用XML报文进行操作，将以前的XML报文中的HEAD去掉。XML报文格式
 
 */

+ (instancetype)shareInstancetype {
    static dispatch_once_t onceToken;
    static Singleton *instance = nil;
    dispatch_once(&onceToken, ^{
        instance = [[Singleton alloc] init];
    });
    return instance;
}
/**
 * cutil_socket_connect:
 * @nSocket: socket
 * @pszHost: 地址
 * @nPort: 端口号
 * @nMicroTime: 超时时间（毫秒）
 *
 *  0 = success; -1 = fail
 */
int cutil_socket_connect(int nSocket, char *pszHost, int nPort, int nMicroTime)
{
    socklen_t nLen;

    long nBlock;
    struct sockaddr_in struYourAddr;
    
    if(!pszHost || (strcmp(pszHost, "NULL") == 0))
    {
        save_local_Log(socket_error_log, @"Connect must set host\n");
        return -1;
    }

    struYourAddr.sin_addr.s_addr = (in_addr_t)in_inet_addr(pszHost);
    struYourAddr.sin_family = AF_INET;
    struYourAddr.sin_port = htons(nPort);
    
    if(nMicroTime <= 0)
    {
        if(connect(nSocket, (struct sockaddr *)&struYourAddr,
                   sizeof(struYourAddr)) != 0)
        {
            save_local_Log(socket_error_log, [NSString stringWithFormat:@"connect to server %s:%d\n", pszHost, nPort]);
            return -1;
        }
        return 0;
    }
    
    // 设置socket为非阻塞模式
    nBlock = 1;
    ioctl(nSocket, FIONBIO, &nBlock);
    if(connect(nSocket,
               (struct sockaddr *)&struYourAddr,
               sizeof(struYourAddr)) < 0)
    {
        fd_set struSet;
        struct timeval struTimeOut;
        FD_ZERO(&struSet);
        FD_SET(nSocket, &struSet);
        struTimeOut.tv_sec  = nMicroTime / 1000;
        struTimeOut.tv_usec = nMicroTime % 1000;
        if(select(nSocket + 1, NULL, &struSet, NULL, &struTimeOut) > 0)
        {
            int nError;
            nLen = sizeof(nError);
            
            if((getsockopt(nSocket, SOL_SOCKET, SO_ERROR, (char *)&nError, &nLen) < 0) || (nError != 0))
            {
                save_local_Log(socket_error_log, [NSString stringWithFormat:@"connect to server %s:%d\n", pszHost, nPort]);

                // 修改为阻塞模式
                nBlock = 0;
                ioctl(nSocket, FIONBIO, &nBlock);
                return -1;
            }
        }
        else
        {
            save_local_Log(socket_error_log, [NSString stringWithFormat:@"connect to server %s:%d timeout %d!\n", pszHost, nPort, nMicroTime]);
            // 修改为阻塞模式
            nBlock = 0;
            ioctl(nSocket, FIONBIO, &nBlock);
            return -1;
        }
    }
    // 修改为阻塞模式
    nBlock = 0;
    ioctl(nSocket, FIONBIO, &nBlock);
    nLen = sizeof(struYourAddr);
    if(getsockname(nSocket, (struct sockaddr *)&struYourAddr, &nLen) < 0)
    {
        save_local_Log(socket_error_log, @"getsockname error");
        return -1;
    }
    return 0;
}

static unsigned long in_inet_addr(char *pszHost)
{
    unsigned long nRet;
    struct in_addr struAddr;
    
    nRet = inet_aton(pszHost, &struAddr);
    if(nRet != 0)
        nRet = struAddr.s_addr;
    if(nRet == 0)
    {
        char szIp[256];
        struct hostent * pstruHost;
        // 域名转换成地址
        pstruHost = gethostbyname(pszHost);
        if(pstruHost == NULL)
        {
            return 0;
        }
        strncpy(szIp, inet_ntoa(*(struct in_addr *)pstruHost -> h_addr_list[0]), sizeof(szIp));
        nRet = inet_aton(szIp, &struAddr);
        if(nRet != 0)
            nRet = struAddr.s_addr;
    }
    return nRet;
}


//static int client_sockfd;// socket
int heartBeat_nSerial;// 交易流水号
int ygPolicyNum;// GetAgentPolicyList 获取的策略个数
int ygRecvPolicyNum;//  GetPolicyItem 已经接收到了的policy个数
static NSString *pIpForLocal;
int lastSerial;
#pragma mark 初始化client_sockfd 并开启接收
/** 初始化client_sockfd 并开启接收*/
- (void)initNetwork:(NSString *)addressip andPort:(int) port {
    if (!addressip||addressip.length < 1) {
        save_local_Log(socket_error_log, @"create socket, but NO Ip");
        return;
    }

    NSArray *infoArray = [addressip componentsSeparatedByString:@":"];
    if (infoArray.count == 2) {
        addressip = infoArray[0];
    }
    if (pIpForLocal.length > 1 && self.client_sockfd > 0) {
        if (![addressip isEqualToString:pIpForLocal]) {
            HXINFOLOG(@"ip address is changed, so we need close socket now");
            CloseSocket();
        }else{
            return;
        }
    } else {
        pIpForLocal = addressip;
    }
    /*创建客户端套接字--IPv4协议，面向连接通信，TCP协议*/
    if((self.client_sockfd=socket(PF_INET,SOCK_STREAM,0))<0)
    {
        perror("socket");
        return ;
    }
    if (cutil_socket_connect(self.client_sockfd, (char *)addressip.UTF8String, port, 10 * 1000)< 0){
        HXINFOLOG(@"socket connect faild");
        CloseSocket();
        return;
    }
    writeFile(@"", kPolicyTime);

//    // 离线到在线或者第一次运行进入程序就向服务器获取策略
    [self GetAgentPolicyList];
    __weak typeof(self)wSelf = self;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        __strong typeof(wSelf)sSelf = wSelf;
        NSMutableArray *policy = [NSMutableArray array];
        while(true)
        {
            @synchronized (sSelf) {
                int recv_nSerial = 0;
                char pTradeCode[32];
                NSString *tstring = [[NSString alloc] init];
                char *receive = RecvFromServer(sSelf.client_sockfd, pTradeCode, 0, &recv_nSerial, &tstring);
                if (receive == NULL)
                {
                    free(receive);
                    int i = -10;// socket 关闭了这里只要区分开关
                    if (sSelf.client_sockfd && recv_nSerial != -1) {
                        HXINFOLOG(@"receive == nil");
                        i = CloseSocket();
                    }
                    save_local_Log(socket_log, [NSString stringWithFormat:@"receive回执为空（服务器主动关闭socket）关闭socket closeSocket返回值为:%d", i]);
                    dispatch_async(dispatch_get_main_queue(), ^{
                        NSNotification * notification = [NSNotification notificationWithName:@"createSocket" object:nil];
                        [[NSNotificationCenter defaultCenter] postNotification:notification];
                    });
                    break;
                }
                if (receive) {
    #pragma mark socket回执
                    NSStringEncoding gbkEncoding = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    //                NSString *receiveString = [NSString stringWithCString:receive encoding:gbkEncoding];
                    NSString *receiveString = [[NSString alloc] initWithBytes:receive length:strlen(receive) encoding:gbkEncoding];
    //                NSString * receiveString1 = [NSString stringWithFormat:@"%s", receive];
    //                NSString *re111 = [NSString stringWithCString:receive encoding:NSUTF8StringEncoding];

                    if (receiveString.length < 1) {
                        NSString * receive_string = [NSString stringWithFormat:@"%s", receive];
                        save_local_Log(socket_error_log,@"socket获取报文出错[%@]", receive_string);
    //                    continue;
                        if (receive_string) {
                            receiveString = receive_string;
                        }else {
                            continue;
                        }
                    }
                    NSString *xmlString = [receiveString stringByReplacingOccurrencesOfString:@"<?xml version=\"1.0\" encoding=\"gbk\"?>" withString:@""];
                    NSDictionary *xmlDictionary = [NSDictionary dictionaryWithXMLString:xmlString];
                    NSString *tradeCode = xmlDictionary[@"TradeCode"];
                    if (![receiveString isEqualToString:tstring]|| ![tstring isEqualToString:receiveString]) {

                    }
                    save_local_Log(socket_log, [NSString stringWithFormat:@"socket流水号:[%d]-[%s]-[%lu][%lu][%@]", recv_nSerial, pTradeCode, strlen(receive), (unsigned long)receiveString.length, receiveString]);
                    if (strcmp(pTradeCode, "HeartTest") == 0) {
                        lastSerial = recv_nSerial;
                    }
                    if ([@"RealTime" isEqualToString:tradeCode]) {
                        NSString *RealTimeCode = xmlDictionary[@"RealTimeCode"];
                        if ([@"SendMsg" isEqualToString:RealTimeCode]) {
                            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                                RecvReportSendMsg(receiveString, recv_nSerial);// 服务端向客户端发送消息，客户端弹窗
                            });
                        }else if ([@"LockScreen" isEqualToString:RealTimeCode]){
                            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                                RecvReportLockScreen(recv_nSerial);// 锁屏
                            });
                        }else if ([@"GetAgentTime" isEqualToString:RealTimeCode]){
                            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                                RecvReportGetAgentTime(recv_nSerial);// 上传本地时间
                            });
                        }else if ([@"ModifyAgentTime" isEqualToString:RealTimeCode]){
                            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                                NSString * agentTime = CutOffStringBetweenBoth(receiveString, @"<Time>", @"</Time>");
                                RecvReportModifyAgentTime(agentTime, recv_nSerial);// 远程修改客户端时间
                            });
                        }else if ([@"TerminateProcess" isEqualToString:RealTimeCode]){
                            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                                RecvReportTerminateProcess(receiveString, recv_nSerial);// 终止进程
                            });
                        }else if ([@"ReportProcessInfo" isEqualToString:RealTimeCode]){
                            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                                RecvReportProcessInfo(recv_nSerial);// 正在运行的应用
                            });
                        }else if ([RealTimeCode isEqualToString:@"GetClientLog"]) {
    #pragma mark 服务器告知客户端上报日志
                            LogManager *lManager = [LogManager sharedInstance];
                            lManager.StartTime = [xmlDictionary[@"StartTime"] stringByReplacingOccurrencesOfString:@"-" withString:@""];
                            lManager.EndTime = [xmlDictionary[@"EndTime"] stringByReplacingOccurrencesOfString:@"-" withString:@""];
                            [lManager serverUploadFiles];
                        }else if ([RealTimeCode isEqualToString:@"uninstallcode"]) {
    #pragma mark 万能安全规范确认码
                            NSString *unInstallKey = xmlDictionary[@"Uninstallcode"];
                            writeFile(unInstallKey, @"UnInstallKey");// 保存万能卸载码
                        }
                    } else if ([@"GetAgentPolicyList" isEqualToString:tradeCode]){
    #pragma mark 主动获取策略项
                        if (xmlDictionary[@"ASM"]) {
                            xmlDictionary = xmlDictionary[@"ASM"];
                        }
                        // 服务器策略最后更新时间
                        NSString *localPolicyItemTime = readFile(kPolicyTime);
                        NSString *_policyItemTime = xmlDictionary[kPolicyTime];
                        // 服务器系统策略最后更新时间
                        NSString *SPolicy_UsbClassCtrl_time = GetSPolicy_UsbClassCtrlTime(xmlDictionary[@"SystemPolicyItems"]);
                        NSString *local_sys_usb_time = readFile(kSysPolicyTime);
                        if ([_policyItemTime isEqualToString:localPolicyItemTime] &&
                            [SPolicy_UsbClassCtrl_time isEqualToString:local_sys_usb_time]) {
                            continue;
                        }else {
                            writeFile(_policyItemTime, kPolicyTime);
                            writeFile(SPolicy_UsbClassCtrl_time, kSysPolicyTime);
                        }
                        ygPolicyNum = 0;
                        ygRecvPolicyNum = 0;
                        [policy removeAllObjects];// 清空
                        self->policyItem = nil;
                        if (self->policyItem == nil) {
                            self->policyItem = [YGPolicyItem Item];
                        }
                        // 请求服务器之后收到的策略项检查
                        self->policyItem = DealwithPolicyItemStr(xmlDictionary, self->policyItem);
                        // 下发策略项个数
                        ygPolicyNum = self->policyItem.ygPolicyNum;
                        if (ygPolicyNum == 0){
                            dispatch_async(dispatch_get_main_queue(), ^{
                                NSNotification *notification = [NSNotification notificationWithName:@"releasePolicyTimer" object:self->policyItem];
                                [[NSNotificationCenter defaultCenter] postNotification:notification];
                            });
                        }
                    }else if ([@"GetPolicyItem" isEqualToString:tradeCode]){
                        if ([@"SPolicy_UsbClassCtrl" isEqualToString:xmlDictionary[@"ItemName"]]){
                            YGSPolicyUsbClassCtrlModel *SPolicyUsbClassCtrlModel = [YGSPolicyUsbClassCtrlModel modelWithDictionary:xmlDictionary];
                            self->policyItem.SPolicyUsbClassCtrlModel = SPolicyUsbClassCtrlModel;
                        } else {
                            [policy addObject:receiveString];// 一个一个存起来 集满了才去检测.....
                        }
                        ygRecvPolicyNum++;
                        if (ygRecvPolicyNum == ygPolicyNum){
                            self->policyItem = GetPolicyItem(policy, self->policyItem);// 每个策略项处理
                            // 将策略保存到本地
                            [YGPolicyItem SaveYGPolicyItem:self->policyItem];
                            dispatch_async(dispatch_get_main_queue(), ^{
                                NSNotification * notification = [NSNotification notificationWithName:@"ViolationHandling" object:self->policyItem];
                                [[NSNotificationCenter defaultCenter] postNotification:notification];
                            });
                        }
                    }else if ([@"RoleChanged" isEqualToString:tradeCode]){
    #pragma mark 策略项  服务端策略项变更了 RoleChanged
                        //  2018年04月26日 修改逻辑，不在这里释放->改为在GetAgentPolicyList内判断是否有策略变动，如果没有策略的变动就不释放策略计时器
                        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                            [sSelf GetAgentPolicyList];
                        });

                    }else if([@"SvrMsgToAss" isEqualToString:tradeCode]) {
    #pragma mark 强制下线
                        NSString *whatToDo = xmlDictionary[@"WhatToDo"];
                        if ([whatToDo isEqualToString:@"IpRenew"]) {
                            YGNetAuthModel *model = [[YGNetAuthModel model] qunueSelectFromNetAuthModel];
                            if (model.IsNetAuth == 1) {
                                model.IsNetAuth = 0;
                                [model qunueUpdateNetAuthTable];
                                [YGNetHttpRequestObject postNotificationToControllerForMessage:xmlDictionary[@"Msg"]];
                            }
                        }
                    }else if ([@"GetDepart" isEqualToString:tradeCode]) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            NSNotification * notification = [NSNotification notificationWithName:@"recvGetDepart" object:xmlDictionary];
                            [[NSNotificationCenter defaultCenter] postNotification:notification];
                            NSNotification *notification2 = [NSNotification notificationWithName:@"recvGetDepartUSBInfo" object:xmlDictionary];
                            [[NSNotificationCenter defaultCenter] postNotification:notification2];

                        });
                    }else if ([@"GetUsbInfo" isEqualToString:tradeCode]) {
                        xmlString = [xmlString stringByReplacingOccurrencesOfString:@"/Password" withString:@"/Passwd"];
                        NSDictionary *usbInfoXMLDict = [NSDictionary dictionaryWithXMLString:xmlString];
                        NSDictionary *usb = usbInfoXMLDict[@"Usb"];
                        if (usb.count > 0) {
                            USBModel *model = [[USBModel model] qunueSelectFromUsbTableWithUsbID:usb[@"UsbID"]];
                            model.registered = [usb[@"Registered"] integerValue];
                            model.registeredUser = usb[@"User"]?usb[@"User"]:@"";
                            model.EndDate = usb[@"EndDate"]?usb[@"EndDate"]:@"";
                            model.DepartID = [usb[@"DepartID"] integerValue];
                            [model qunueUpdateUsbTableRegistered];
                        }else{
                            YGUSBDeviceModel *device_model = [[YGUSBDeviceModel model] qunueSelectFromUSBDeviceTableWithSerial:recv_nSerial];
                            if (device_model) {
                                USBModel *usb_model = [[USBModel model] qunueSelectFromUsbTableWithUsbID:device_model.USBID];
                                if (usb_model) {
                                    usb_model.registered = 0;
                                    usb_model.registeredUser = @"";
                                    usb_model.EndDate = @"";
                                    usb_model.DepartID = 0;
                                    [usb_model qunueUpdateUsbTableRegistered];
                                }
                            }
                        }
                        [[YGUSBDeviceModel model] qunueDeleteUSBDeviceTable:recv_nSerial];
                    }else if ([@"GetDeviceProperty" isEqualToString:tradeCode]) {
                        NSDictionary *DeviceDictionary = xmlDictionary[@"Device"];
                        writeFile(DeviceDictionary[@"DepartId"], @"selfDepart");
                        writeFile(DeviceDictionary[@"UserName"], @"serUserName");
                    }
                }
                if (receive) {
                    free(receive);
                    receive = NULL;
                }
            }
        }
    });
}

- (void)inspectPolicy{
    YGPolicyItem *pli = [YGPolicyItem GetYGPolicyItem];
    if (!pli){
        return;
    }
    if (pli.OffLineEffect) {
        dispatch_async(dispatch_get_main_queue(), ^{
            NSNotification * notification = [NSNotification notificationWithName:@"ViolationHandling" object:pli];
            [[NSNotificationCenter defaultCenter] postNotification:notification];
        });
    }
}


static int heartBeatFail = 0;
static BOOL isMust = YES;
#pragma mark 心跳
/** 心跳*/
-(void)longConnectToSocket{
    const char *pFormt = "<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>%s</TradeCode><AgentID>%s</AgentID><requestClientType>mobile</requestClientType></ASM>";
    char szBuf[1024] = {0};
    char *pTradeName = "HeartTest";
    const char *pID = [readFile(kAgentID) UTF8String];
    
    sprintf(szBuf, pFormt, pTradeName, pID);

    int numOfSerial = arc4random()%1000000;
    heartBeat_nSerial = numOfSerial;
    int sendResult = [self SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:numOfSerial];
    if (sendResult == 1){
        save_local_Log(socket_task_log, [NSString stringWithFormat:@"成功--心跳:流水号=[%d]---heartbeat = %d", numOfSerial, heartBeatFail]);
        // 心跳成功 客户端在线
        if (heartBeatFail > 0) {
            heartBeatFail = 0;
            writeFile([NSString stringWithFormat:@"%d", heartBeatFail], Offline);
            [self recvComputerWakeup];
            [self GetAgentPolicyList];
        }
        [YGNetAuthModel NetAuthCheck:&isMust];
        // 客户端在线就上报离线时的违规app
        NSData *data = readFile(MReportViolationLog);
        if (data){
            NSMutableDictionary *local = [NSMutableDictionary dictionaryWithDictionary:[NSKeyedUnarchiver unarchiveObjectWithData:data]];
            for (NSString *path in local) {
                [self RecvMobilePolicy_Application:local[path]];
            }
        }
    }else if (sendResult <= 0){
        BOOL result = NO;
        heartBeatFail++;
        if (sendResult == -1) {
            if (heartBeatFail >= 1)
                result = YES;
            save_local_Log(socket_task_log, [NSString stringWithFormat:@"发送心跳报文时发现socket关闭了"]);
        }
        if (sendResult == 0)  {
            if (heartBeatFail > 1)
                result = YES;
            save_local_Log(socket_task_log, [NSString stringWithFormat:@"失败--心跳报文:\n%s", szBuf]);
        }
        if (result) {
            // 记录离线状态
            writeFile([NSString stringWithFormat:@"%d", heartBeatFail], Offline);
            [self inspectPolicy];
            dispatch_async(dispatch_get_main_queue(), ^{
                NSNotification * notification = [NSNotification notificationWithName:@"createSocket" object:nil];
                [[NSNotificationCenter defaultCenter] postNotification:notification];
            });
        }
    }
}
/** wakeup服务器唤醒报文*/
- (void)recvComputerWakeup {
    const char *pFormt = "<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>%s</TradeCode><AgentID>%s</AgentID><RoleID>%d</RoleID></ASM>";
    char szBuf[1024] = {0};
    char *pTradeName = "ComputerWakeup";
    const char *pID = [readFile(kAgentID) UTF8String];
    YGNetAuthModel *model = [[YGNetAuthModel model] qunueSelectFromNetAuthModel];
    int roleId = (int)model.RoleID;
    sprintf(szBuf, pFormt, pTradeName, pID, roleId);

    int numOfSerial = arc4random()%1000000;
    int sendResult = [self SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:numOfSerial];
    if (sendResult) {

    }
}

- (void)recvGetDeviceProperty {
    const char *pFormt = "<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>%s</TradeCode><AgentID>%s</AgentID></ASM>";
    char szBuf[1024] = {0};
    char *pTradeName = "GetDeviceProperty";
    const char *pID = [readFile(kAgentID) UTF8String];
    sprintf(szBuf, pFormt, pTradeName, pID);
    int numOfSerial = arc4random()%1000000;
    int sendResult = [self SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:numOfSerial];
    if (sendResult) {

    }
}
/**第一次软件上报 */
- (void)firstUploadSoftInfo {
    const char *pFormt = "<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>%s</TradeCode><AgentID>%s</AgentID>%s</ASM>";
    NSDictionary * allAppList = [SoftwareList allAppList];// 获取软件信息（数组内包含的每个字典是每个软件的信息）
    if (!allAppList) {
        // 获取本地全部软件失败
        save_local_Log(@"error_log", [NSString stringWithFormat:@"获取本地全部软件失败"]);
        return;
    }
    NSString * strhx = [[[SoftwareList alloc] init] uploadString:allAppList];// 将软件信息拼装成字符串
    char *sendBuf = StringToGbk(strhx);
    char *szBuf = (char *)malloc(strlen(sendBuf) + 1024);// 动态分配的要free
    char *pTradeName = "ReportSoftInstalled";
    sprintf( szBuf, pFormt, pTradeName, [readFile(kAgentID) UTF8String], sendBuf);
    int result = [self SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:arc4random()%1000000];
    if (szBuf) {
        free(szBuf);
    }
    if (result == 1)
        save_local_Log(socket_task_log, @"第一次上报软件成功");
    else if (result != 1)
        save_local_Log(socket_task_log, @"第一次上报软件失败");
}

/*
 <ASM>
 <TradeCode> ReportHardware </TradeCode>
 <AgentID>1800003</AgentID>
 <HardInfo>
 <Type></Type>
 <Name></Name>
 <Vendor></Vendor>
 <Prop></Prop>
 <ChangeTime>2013-07-03</ChangeTime>
 </HardInfo>
 </ASM>
 */
/**第一次上报硬件信息*/
- (void)firstUploadHardware {
    HXINFOLOG(@"上报软件信息");
    const char *pFormt = "<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>%s</TradeCode><AgentID>%s</AgentID>%s</ASM>";
    NSString * hardware = [HardwareAssets HardwareData];
    hardware = [hardware stringByReplacingOccurrencesOfString:@"ComputerTime" withString:CurrentTime(YGCURRENTTIMETYPETWO)];
    char *sendBuf = StringToGbk(hardware);
    
    char *szBuf = (char *)malloc(strlen(sendBuf) + 1024);
    char *pTradeName = "ReportHardware";
    sprintf( szBuf, pFormt, pTradeName, [readFile(kAgentID) UTF8String], sendBuf);
    uint32_t serial = arc4random()%1000000;
    int result = [self SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:serial];
    if (result == 1)
        save_local_Log(socket_task_log, @"第一次上报硬件信息成功");
        
    else if (result == 0)
        save_local_Log(socket_task_log, @"第一次上报硬件信息失败");
    if (szBuf)
        free(szBuf);
}


#pragma makr 策略项
// 获取策略项报文
- (void)GetAgentPolicyList{
    NSString *deviceID = readFile(kAgentID);
    if (deviceID.length < 1) {
        return;
    }
    char *hBuff = "<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>GetAgentPolicyList</TradeCode><AgentID>%s</AgentID><requestClientType>mobile</requestClientType></ASM>";
    char szBuf[1024] = {};
    char *pTradeName = "GetAgentPolicyList";
    sprintf(szBuf, hBuff, (char *)[deviceID UTF8String]);
    int requestPolicySerial = arc4random()%1000000;
    int result = [self SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:requestPolicySerial];
    if (result==1)
        save_local_Log(socket_task_log, [NSString stringWithFormat:@"发送获取policyitem请求成功.流水号=[%d]", requestPolicySerial]);
    else
        save_local_Log(socket_task_log, [NSString stringWithFormat:@"发送获取policyitem请求失败.流水号=[%d]", requestPolicySerial]);
}

// 拿到策略项之后，去服务器取策略
- (void)GetPolicy:(NSString *)itemID {
    char * hBuff = "<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>GetPolicyItem</TradeCode><AgentID>%s</AgentID><ItemID>%s</ItemID></ASM>";
    
    char szBuf[1024] = {};
    char *pTradeName = "GetPolicyItem";
    sprintf(szBuf, hBuff, (char *)[readFile(kAgentID) UTF8String], (char *)[itemID UTF8String]);
    int result = [self SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:arc4random()%1000000];
    if (result == 1)
        save_local_Log(socket_task_log, [NSString stringWithFormat:@"发送GetPolicy成功[%s]", szBuf]);
    else{
        save_local_Log(socket_task_log, [NSString stringWithFormat:@"发送GetPolicy失败:\n[%s]", szBuf]);
//        if (!(result==-1))
//        GetPolicy(model);
    }
}

#pragma mark 策略违规上报
#pragma mark 软件黑白名单回应报文
- (void)RecvMobilePolicy_Application:(ApplicationInfo *)app {
    if (app.ApplicationName.length < 1){
        save_local_Log(socket_error_log, @"上报违规软件时，软件信息为空");
        return;
    }
    NSString * recvString = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>MReportViolationLog</TradeCode><AgentID>%@</AgentID><ItemList><Item><ViolationStartTime>%@</ViolationStartTime><ViolationEndTime>%@</ViolationEndTime><ViolationItem>MobilePolicy_Application</ViolationItem><Remark>%@</Remark></Item></ItemList></ASM>",
                             readFile(kAgentID),
                             app.createTime,// 创建时间creationDate
                             app.removeTime,// 最后修改时间fileModDate
                             app.ApplicationName];
    char *hBuff = StringToGbk(recvString);
    char *szBuf = (char *)malloc(strlen(hBuff) + 100);
    char *pTradeName = "MReportViolationLog";
    sprintf(szBuf, "%s", hBuff);
    int result = [self SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:arc4random()%1000000];
    if (result == 1) {
        save_local_Log(socket_task_log, @"发送RecvMobilePolicy_Application成功");
        NSData *data = readFile(MReportViolationLog);
        if (data){
            NSMutableDictionary *local = [NSMutableDictionary dictionaryWithDictionary:[NSKeyedUnarchiver unarchiveObjectWithData:data]];
            if ([[local allKeys] containsObject:app.ApplicationPath])
                [local removeObjectForKey:app.ApplicationPath];
            NSData *saveData = [NSKeyedArchiver archivedDataWithRootObject:local];
            if (saveData)
                writeFile(saveData, MReportViolationLog);
            else
                writeFile([NSKeyedArchiver archivedDataWithRootObject:[NSDictionary dictionary]], MReportViolationLog);
        }
    }else{
        save_local_Log(socket_task_log, [NSString stringWithFormat:@"发送RecvMobilePolicy_Application失败:\n%@", recvString]);
        NSData *data = readFile(MReportViolationLog);
        NSMutableDictionary *local = [NSMutableDictionary dictionaryWithDictionary:[NSKeyedUnarchiver unarchiveObjectWithData:data]];
        if (![[local allValues] containsObject:app]) {
            [local setObject:app forKey:app.ApplicationPath];
        }
        NSData *saveData = [NSKeyedArchiver archivedDataWithRootObject:local];
        writeFile(saveData, MReportViolationLog);
    }
    if (szBuf)
    free(szBuf);
    
}
#pragma mark 文件监控回应报文
void RecvMobilePolicy_File(NSDictionary * state){
    NSString * recvString = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>MOperateReportFileLog</TradeCode><AgentID>%@</AgentID><ItemList><Item><OperationTime>%@</OperationTime><DocumentPath>%@</DocumentPath><OperationType>%@</OperationType><Remark></Remark></Item></ItemList></ASM>",
                             readFile(kAgentID),
                             [state objectForKey:@"OperationTime"], // 违规时间
                             [state objectForKey:@"DocumentPath"],  // 违规路径
                             [state objectForKey:@"OperationType"]];// 违规类型
    char *hBuff = StringToGbk(recvString);
    char *szBuf = (char *)malloc(strlen(hBuff) + 100);
    char *pTradeName = "MOperateReportFileLog";
    sprintf(szBuf, "%s", hBuff);
    int result = [[Singleton shareInstancetype] SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:arc4random()%1000000];
    if (result == 1)
        save_local_Log(socket_task_log, @"发送RecvMobilePolicy_File成功");
    else
        save_local_Log(socket_task_log, [NSString stringWithFormat:@"发送RecvMobilePolicy_File失败:\n%@", recvString]);

    if (szBuf)
    free(szBuf);
}

#pragma mark USB管控
void RecvUSBRegister(USBModel *model, NSString *user, NSString *message, NSString *departID) {
    NSString * recvString = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"gbk\"?>"
                             "<ASM>"
                             "<TradeCode>UsbRegister</TradeCode>"
                             "<AgentID>%@</AgentID>"
                             "<Usb>"
                             "<UsbID>%@</UsbID>"             // USB设备ID
                             "<Name>%@</Name>"               // USB设备名称
                             "<Class>%@</Class>"             // 设备类型代码
                             "<Capacity>%@</Capacity>"       // 如果是U盘，则为容量信息
                             "<Vendor>%@</Vendor>"           // 厂家名称
                             "<Product>%@</Product>"         // 产品名称
                             "<Password></Password>"         // 访问密码，如果为空，不需要密码
                             "</Usb>"
                             "<User>%@</User>"
                             "<DepartID>%@</DepartID>"
                             "<Reason>%@</Reason>"
                             "</ASM>",
                             readFile(kAgentID),
                             model.locationID,
                             model.USBProductName,
                             model.type,
                             model.size,
                             model.USBVendorName,
                             model.USBProductName,
                             user,
                             departID,
                             message];// 违规类型
    char *hBuff = StringToGbk(recvString);
    char *szBuf = (char *)malloc(strlen(hBuff) + 100);
    char *pTradeName = "UsbRegister";
    sprintf(szBuf, "%s", hBuff);
    int result = [[Singleton shareInstancetype] SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:arc4random()%1000000];
    if (result == 1) {
        save_local_Log(socket_task_log, @"发送UsbRegister成功");
    }else{
        save_local_Log(socket_task_log, [NSString stringWithFormat:@"发送UsbRegister失败:\n%@", recvString]);
    }
    if (szBuf)
        free(szBuf);
}


void RecvUSBPlugReport(USBModel *model, NSString *action) {
    NSString * recvString = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"gbk\"?>"
                             "<ASM>"
                             "<TradeCode>UsbPlugReport</TradeCode>"
                             "<AgentID>%@</AgentID>"
                             "<RecordID>%@</RecordID>"       // 如果是拔出类型，此ID为插入时返回的ID
                             "<UsbID>%@</UsbID>"             // USB设备ID
                             "<Name>%@</Name>"               // USB设备名称
                             "<Class>%@</Class>"             // 设备类型代码
                             "<Capacity>%@</Capacity>"       // 如果是U盘，则为容量信息
                             "<Vendor>%@</Vendor>"           // 厂家名称
                             "<Product>%@</Product>"         // 产品名称
                             "<Action>%@</Action>"           // 动作：插入、拔出 Insert/Remove
                             "<OsUser>%@</OsUser>"           // 操作系统用户
                             "<Time>%@</Time>"               // 时间2012-10-10 10:35:00
                             "</ASM>",
                             readFile(kAgentID),
                             @(model.RecordID),
                             model.locationID,
                             model.USBProductName.length>0?model.USBProductName:@"",
                             model.type.length>0?model.type:@"",
                             model.size.length > 0? model.size:@"",
                             model.USBVendorName.length>0?model.USBVendorName:@"",
                             model.USBProductName.length>0?model.USBProductName:@"",
                             action,
                             [YGTool getCurrentUserName],
                             CurrentTime(YGCURRENTTIMETYPEONE)];
    char *hBuff = StringToGbk(recvString);
    char *szBuf = (char *)malloc(strlen(hBuff) + 100);
    char *pTradeName = "UsbPlugReport";
    sprintf(szBuf, "%s", hBuff);
    int nSno = arc4random()%1000000;
    int result = [[Singleton shareInstancetype] SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:nSno];
    if (result == 1) {
        save_local_Log(socket_task_log, [NSString stringWithFormat:@"发送UsbPlugReport成功-[%d]", nSno]);
    }else{
        save_local_Log(socket_task_log, [NSString stringWithFormat:@"发送UsbPlugReport失败:\n%@", recvString]);
    }
    if (szBuf)
        free(szBuf);
}

/** 提交位置类型，服务器需要经过匹配，如果数据库中存在此类型，则返回错误*/
void RecvUSBUnknownClass(USBModel *model) {
    NSString * recvString = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"gbk\"?>"
                             "<ASM>"
                             "<TradeCode>UsbUnknownClass</TradeCode>"
                             "<AgentID>%@</AgentID>"
                             "<ClassCode>%@</ClassCode>"
                             "<UsbID>%@</UsbID>"          // USB设备ID
                             "<Name>%@</Name>"      // USB设备名称
                             "<Capacity>%@</Capacity>"            // 如果是U盘，则为容量信息
                             "<Vendor>%@</Vendor>"           // 厂家名称
                             "<Product>%@</Product>"        // 产品名称
                             "<OsUser>%@</OsUser>"      // 操作系统用户
                             "</ASM>",
                             readFile(kAgentID),
                             model.type,
                             model.locationID,
                             model.USBProductName.length > 0?model.USBVendorName:@"",
                             model.size.length >0 ? model.size:@"",
                             model.USBVendorName.length>0?model.USBVendorName:@"",
                             model.USBProductName.length >0 ? model.USBProductName:@"",
                             [YGTool getCurrentUserName]];
    char *hBuff = StringToGbk(recvString);
    char *szBuf = (char *)malloc(strlen(hBuff) + 100);
    char *pTradeName = "UsbUnknownClass";
    sprintf(szBuf, "%s", hBuff);
    int result = [[Singleton shareInstancetype] SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:arc4random()%1000000];
    if (result == 1) {
        save_local_Log(socket_task_log, @"发送UsbUnknownClass成功");
    }else{
        save_local_Log(socket_task_log, [NSString stringWithFormat:@"发送UsbUnknownClass失败:\n%@", recvString]);
    }
    if (szBuf)
        free(szBuf);
}

/** 获取USB设备信息*/
int RecvGetUsbInfo(NSString * locationID) {
    NSString * recvString = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"gbk\"?>"
                             "<ASM>"
                             "<TradeCode>GetUsbInfo</TradeCode>"
                             "<AgentID>%@</AgentID>"
                             "<UsbID>%@</UsbID>"          // USB设备ID
                             "</ASM>",
                             readFile(kAgentID),
                             locationID];// 违规类型
    char *hBuff = StringToGbk(recvString);
    char *szBuf = (char *)malloc(strlen(hBuff) + 100);
    char *pTradeName = "GetUsbInfo";
    sprintf(szBuf, "%s", hBuff);
    __block NSInteger nSNO = arc4random()%1000000;
    __block YGUSBDeviceModel *model = [YGUSBDeviceModel model];
    model.USBID = locationID;
    model.serial = nSNO;
    [model qunueInsertUSBDeviceTable];
    int result = [[Singleton shareInstancetype] SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:(int)nSNO];
    if (result == 1) {
        save_local_Log(socket_task_log, @"发送GetUsbInfo成功");
    }else{
        save_local_Log(socket_task_log, [NSString stringWithFormat:@"发送GetUsbInfo失败:\n%@", recvString]);
    }
    if (szBuf){
        free(szBuf);
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.f * NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        YGUSBDeviceModel *now_model = [[YGUSBDeviceModel model] qunueSelectFromUSBDeviceTableWithSerial:nSNO];
        if (now_model) { // 如果还存在就说明有问题撒
            [now_model qunueDeleteUSBDeviceTable:nSNO];
            USBModel *usb_model = [[USBModel model] qunueSelectFromUsbTableWithUsbID:model.USBID];
            if(usb_model) {
            }
        }
    });
    return result;
}

#pragma mark 上网行为管控回应报文
void RecvMobilePolicy_InternetBehavior(NSArray *urlArr)
{
    NSMutableString *recvString1 = [NSMutableString string];
    for (YGInternetBehaviorItemList * list in urlArr) {
        [recvString1 appendString:[NSString stringWithFormat:@"<Item><AccessTime>%@</AccessTime><AccessUrl>%@</AccessUrl><ViolationItem>MobilePolicy_InternetBehavior</ViolationItem><Remark></Remark></Item>", list.time, list.DomainName]];
    }
    NSString * recvString = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>MReportInternetBehaviorLog</TradeCode><AgentID>%@</AgentID><ItemList>%@</ItemList></ASM>",
                             readFile(kAgentID),
                             recvString1];
    char *hBuff = StringToGbk(recvString);
    char *szBuf = (char *)malloc(strlen(hBuff) + 100);
    char *pTradeName = "MReportInternetBehaviorLog";
    sprintf(szBuf, "%s", hBuff);
    int result = [[Singleton shareInstancetype] SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:arc4random()%1000000];

    if (result == 1) {
        save_local_Log(socket_task_log, @"发送MReportInternetBehaviorLog成功");
    }else{
        save_local_Log(socket_task_log, [NSString stringWithFormat:@"发送MReportInternetBehaviorLog失败:\n%@", recvString]);
    }
    if (szBuf){
        free(szBuf);
    }
}
#pragma mark 获取部门列表
int RecvGetDepart()
{
    NSString * recvString = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>GetDepart</TradeCode><AgentID>%@</AgentID></ASM>",
                             readFile(kAgentID)];

    char *hBuff = StringToGbk(recvString);
    char *szBuf = (char *)malloc(strlen(hBuff) + 100);
    char *pTradeName = "GetDepart";
    sprintf(szBuf, "%s", hBuff);
    int result = [[Singleton shareInstancetype] SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:1 nSNO:arc4random()%1000000];

    if (result == 1) {
        save_local_Log(socket_task_log, @"发送GetDepart成功");
    }else{
        save_local_Log(socket_task_log, [NSString stringWithFormat:@"发送GetDepart失败:\n%@", recvString]);
    }
    if (szBuf){
        free(szBuf);
    }
    return result;
}


#pragma mark socket
#pragma mark 接收信息
char * RecvFromServer(int nSocket, char *pszTradecode, int *nTradeCodeLen, int *recv_serial, NSString **testString)
{
    char HeadPacket[sizeof(SvrPacketHead) + 1];
    int nHeadLen = sizeof(SvrPacketHead);
    int nBodyLen = 0;
    SvrPacketHead *pHeadPacket = (SvrPacketHead *)HeadPacket;
    char *pBodyPacket = NULL;
    char *pUncompress = NULL;// 解压解密之后的字符
    memset(HeadPacket, 0, nHeadLen);
    // 接收头
    if(RecvLengh(nSocket, HeadPacket, nHeadLen) < 0){
        save_local_Log(socket_error_log, @"recv headPacket error");
        return NULL;
    }
    nBodyLen = pHeadPacket->nLen - sizeof(SvrPacketHead);
    if(nBodyLen < 1 || nBodyLen > 1024 * 1024 || pHeadPacket->nOriSize < 1 || pHeadPacket->nOriSize > 1024 * 1024)
    {
        save_local_Log(socket_error_log, [NSString stringWithFormat:@"body len error %d!\n", nBodyLen]);
        return NULL;
    }
    pBodyPacket = (char *)malloc(nBodyLen);
    memset(pBodyPacket, 0, nBodyLen);
    // 继续接收
    if(RecvLengh(nSocket, pBodyPacket, nBodyLen) < 0)
    {
        save_local_Log(socket_error_log, [NSString stringWithFormat:@"body recv error %d!\n", nBodyLen]);
        free(pBodyPacket);
        pBodyPacket = NULL;
        return NULL;
    }
    // 对head解密 - 对pHeadPacket->szTradeCode解密
    cutil_xor_decrypt((unsigned char *)pHeadPacket->szTradeCode, (const unsigned char *)ENCODE_KEY, sizeof(pHeadPacket->szTradeCode), strlen(ENCODE_KEY));

    *recv_serial = pHeadPacket->nSerial;
    if(pszTradecode) 
        memcpy(pszTradecode, pHeadPacket->szTradeCode, sizeof(pHeadPacket->szTradeCode));

    // 对body解密
    if(pHeadPacket->cCrypt)
        cutil_xor_decrypt((unsigned char *)pBodyPacket, (const unsigned char *)ENCODE_KEY, nBodyLen, strlen(ENCODE_KEY));// 对pBodyPacket解密

    if (!pBodyPacket)
        save_local_Log(socket_error_log, [NSString stringWithFormat:@"解密pBodyPacket失败[%s][%d]", pBodyPacket, nBodyLen]);

    if(pHeadPacket->cZip && pBodyPacket)
    {// 解压缩
        pUncompress = (char *)malloc(pHeadPacket->nOriSize+16);
        memset(pUncompress, 0, pHeadPacket->nOriSize+16);
        HXZipAndUnzip *zip = [[HXZipAndUnzip alloc] init];


        NSData *content=[NSData dataWithBytes:pBodyPacket length:nBodyLen];
        NSData *data = [zip gzipInflate:content];
        NSStringEncoding gbkEncoding = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);

        *testString   =[[NSString alloc] initWithData:data encoding:gbkEncoding];

        cutil_zlib_uncompress(pBodyPacket, nBodyLen, pUncompress, &pHeadPacket->nOriSize);
        if (pBodyPacket) {
            free(pBodyPacket);
            pBodyPacket = NULL;
        }
//        save_local_Log(socket_log, [NSString stringWithFormat:@"\nsocket传过来的字符串解密后长度应该是[%d]\n实际长度[%lu]\n", pHeadPacket->nOriSize, strlen(pUncompress)]);
    }
    else
    {// 不需要解压
        sprintf(pUncompress, "%s", pBodyPacket);
        if (pBodyPacket) {
            free(pBodyPacket);
            pBodyPacket = NULL;
        }
    }
    return pUncompress;
}

/** 返回为-1 则返回失败*/
long RecvLengh(int socket, char *buff, int nLen) {
    char *p = buff;
    int nRecvLen; // 接收到的长度
    int nLeftLen = nLen;
    struct sockaddr_in struAddr;
    while(nLeftLen > 0) {
        nRecvLen = (int)recv(socket, p, nLeftLen, 0);
        if(nRecvLen < 0){
            if (errno == EINTR || errno == EWOULDBLOCK || errno == EAGAIN) {
                continue;
            }
            socklen_t len = sizeof(struAddr);
            getpeername(socket, (struct sockaddr *)&struAddr, &len);
            save_local_Log(socket_error_log, [NSString stringWithFormat:@"recv socket %s:%d buffer error:%s should %d ret %d! maybe we have timeout!\n",
                  inet_ntoa(struAddr.sin_addr),
                  ntohs(struAddr.sin_port),
                  strerror(errno),
                  nLeftLen,
                  nRecvLen]);
//            HXINFOLOG(@"%@", [NSString stringWithFormat:@"recv socket %s:%d buffer error:%s should %d ret %d! maybe we have timeout!\n",
//                              inet_ntoa(struAddr.sin_addr),
//                              ntohs(struAddr.sin_port),
//                              strerror(errno),
//                              nLeftLen,
//                              nRecvLen]);
            return -1;
        }else if(nRecvLen == 0){
            save_local_Log(socket_error_log, @"peer close the socket!\n");
            return -1;
        }
        p += nRecvLen;
        nLeftLen -= nRecvLen;
    }
    return nLen;
}

// 关闭socket
int CloseSocket()
{
    int i = 1;
    Singleton *slt = [Singleton shareInstancetype];
    if (slt.client_sockfd > 0) {
//        i = shutdown(client_sockfd, SHUT_RDWR);
        i = close(slt.client_sockfd);// 关闭成功返回0，关闭失败返回-1
        if (i == 0){
            save_local_Log(socket_log, @"成功关闭close");
        } else {
            save_local_Log(socket_log, @"关闭close失败");
        }
        
        slt.client_sockfd = 0;
//        nSerial = -1;
    }
    return i;// i = 1 socket没有存在
}

//
// 向服务器发送交易报文
// pTradeCode:"HeartTest"
// pTradeContent:"<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>HeartTest</TradeCode><AgentID>35</AgentID></ASM>"
// nContentLen:strlen(pTradeContent)
/*
 char *pTradeName         交易名称
 char *pTradeContent      客户端上传的xml
 int nContentLen          pTradeContent的长度
 char *pRecv              服务器回执的报文
 int nRevLen              pRecv的长度
 int cType                报文的类型 1客户端请求报文 2应答给客户端报文 3AsmSvr请报文 4应答给AsmSvr报文 5WEB端请求报文 6应答给WEB端报文
 int nSNO                 nSerial 对应的交易id
 发送报文
 true 发送成功(收到了正确的回执)
 */
- (BOOL)IsSendTo:(char *)pTradeName pTradeContent:(char *)pTradeContent nContentLen:(int)nContentLen pRecv:(char *)pRecv nRevLen:(int)nRevLen cType:(int)cType nSNO:(int)nSNO {
    // 传数据顺序先压缩再加密
    char *pCompressBuf = NULL;
    int nSrcLen = nContentLen;
    uLongf nLen1 = nContentLen;
//    uLongf nLen1;
    //    int *nLen1 = malloc(sizeof(int));
    // 不知道为什么执行完cutil_zlib_compress，nSrcLen变为0了
    pCompressBuf = (char *)malloc(nSrcLen+16);
    memset(pCompressBuf, 0, nSrcLen+16);
    const char * packet = cutil_zlib_compress(pTradeContent, nSrcLen, pCompressBuf, &nLen1);
    
    unsigned int psize = (unsigned int)nLen1;
//    unsigned int ksize = sizeof(ENCODE_KEY) - 1;
    unsigned int ksize = strlen(ENCODE_KEY);
    // 加密
    if (!packet) {
        save_local_Log(socket_error_log, [NSString stringWithFormat:@"zip is faild, packet == null pTradeContent = %s, nSrclen = %d", pTradeContent, nSrcLen]);
        return false;
    }
    unsigned char * suv = cutil_xor_encrypt((unsigned char *)packet, (const unsigned char *)ENCODE_KEY, psize, ksize);
    
    char *pBuff = NULL;
    SvrPacketHead *pHead = NULL;
    pBuff = (char *)malloc(sizeof(SvrPacketHead) + nContentLen + 16);
    if (!pBuff)
    {
        save_local_Log(socket_error_log, @"recv is faild, recv head is null");
        return FALSE;
    }

    memset(pBuff, 0, sizeof(SvrPacketHead) + nContentLen+16);
    memcpy(pBuff + sizeof(SvrPacketHead), suv, nLen1);
    // 加表头
    pHead = (PSvrPacketHead)pBuff;
    pHead->nLen = (unsigned int)(sizeof(SvrPacketHead) + nLen1);
    pHead->cVersion = '5MSA';
    pHead->cType = cType;
    pHead->cZip = TRUE;
    pHead->cCrypt = TRUE;
    strncpy(pHead->szTradeCode, pTradeName, sizeof(pHead->szTradeCode));
    cutil_xor_encrypt((unsigned char *)pHead->szTradeCode, (unsigned char *)ENCODE_KEY, sizeof(pHead->szTradeCode), strlen(ENCODE_KEY));
    pHead->nSerial = nSNO;
    pHead->nOriSize = nContentLen;

    ssize_t sLen = [self SendTo:pBuff withLen:pHead->nLen];

    if(pBuff){
        free(pBuff);
        pBuff = NULL;
    }
    if (pCompressBuf) {
        free(pCompressBuf);
        pCompressBuf = NULL;
    }
    //    NSLog(@"发送信息流水号:%d------回执字段长度sLen ====== %zd", nSNO, sLen);
    if (sLen < 1) {
        save_local_Log(socket_error_log, @"sendto back slen<1");
        return FALSE;
    }
    return TRUE;
}

/** 发送信息*/
- (long)SendTo:(char *)buff withLen:(int)len {
    ssize_t sLen = send(self.client_sockfd, buff, len, 0);
//    WSAGetLastError
//    if (errno) {
//        NSString * error = [NSString stringWithFormat:@"%@\nerrno =  \"%d\"", CurrentTime(YGCURRENTTIMETYPEONE), errno];
//    }
    return sLen;
}


/*
    由于目前的整体需求，对于IsSendTo函数中并不需要去接收send之后服务器的回执报文(服务器的回执报文都在)
 char *pTradeName         交易名称
 char *pTradeContent      客户端上传的xml
 int nContentLen          pTradeContent的长度
 int cType                报文的类型 1客户端请求报文 2应答给客户端报文 3AsmSvr请报文 4应答给AsmSvr报文 5WEB端请求报文 6应答给WEB端报文
 int nSNO                 nSerial 对应的交易id
 发送报文
 true 发送成功(收到了正确的回执)
 */
- (int)SocketSendUNRecv:(char *)pTradeName pTradeContent:(char *)pTradeContent nContentLen:(int)nContentLen cType:(int)cType nSNO:(int)nSNO {
    if (strcmp(pTradeName, "HeartTest") == 0 && self.client_sockfd != 0) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            if (heartBeat_nSerial != lastSerial && self.client_sockfd!=0) {
                HXINFOLOG(@"send fail");
                CloseSocket();
            }
        });
    }
    if (self.client_sockfd == 0) {
        HXINFOLOG(@"SocketSendUNRecv  -----  socket is close[%s]", pTradeName);
        return -1;// socket关闭了
    }
    
    BOOL send = [self IsSendTo:pTradeName pTradeContent:pTradeContent nContentLen:nContentLen pRecv:nil nRevLen:0 cType:cType nSNO:nSNO];
    return send;
}


#pragma mark  加密 解密  压缩 解压缩
//加密算法
unsigned char* cutil_xor_encrypt(unsigned char* packet ,
                                 const unsigned char* key ,
                                 unsigned int psize ,
                                 unsigned int ksize )
{
    unsigned i, j;
    unsigned char temp;
    for( i = 0 , j = 0 ; i < psize ; i++ , j = (j+1)%ksize )
    {
        temp = (packet[i]^key[j]);
        packet[i] = (temp<<4) + (temp>>4);
    }
    return packet;
}

// 解密
unsigned char* cutil_xor_decrypt( unsigned char* packet ,
                                 const unsigned char* key ,
                                 unsigned int psize ,
                                 unsigned int ksize )
{
    unsigned i , j;
    for( i = 0 , j = 0 ; i < psize ; i++ , j = (j+1)%ksize )
    {
        packet[i] = ( packet[i]<<4 ) + ( packet[i]>>4 );
        packet[i] = packet[i] ^ key[j];
    }
    return packet;
}

// 压缩
const char* cutil_zlib_compress( const char* src , int srclen , char* dst , uLongf* pdstlen )
{
    if( srclen < 0
       || *pdstlen < 0
       || src == 0
       || dst == 0 )
    {
        return 0;
    }
    if( compress2( (Bytef *)dst , pdstlen , (Bytef *)src , srclen , Z_BEST_COMPRESSION ) != Z_OK )
    {
        return 0;
    }
    return dst;
}

/**
 * cutil_zlib_uncompress
 *
 * 在内存中进行ZLIB解压
 * pdstlen返回解压后的大小
 *
 * Returns: NULL          失败
 *          const char*   解压缓冲区地址
 */
const char* cutil_zlib_uncompress( const char* src , int srclen , char* dst , int* pdstlen )
{
    if( src == 0
       || dst == 0
       || srclen < 0
       || *pdstlen < 0 )
       
    {
        return 0;
    }
    if( uncompress((Bytef *)dst , (uLongf *)pdstlen , (Bytef *)src , (uLong)srclen ) != Z_OK )
    {
        return 0;
    }
    return dst;
}

#pragma mark -dealloc

- (void)dealloc{
    HXINFOLOG(@"singleton dealloc");
}

@end
