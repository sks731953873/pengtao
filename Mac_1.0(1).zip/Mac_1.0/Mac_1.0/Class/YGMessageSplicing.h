//
//  YGMessageSplicing.h
//  Mac_1.0
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 infogo. All rights reserved.
// 安检项

#import <Foundation/Foundation.h>

@interface YGMessageSplicing : NSObject
/** 安装软件检测*/
+ (NSString *)CheckSoftInstallStat:(NSString *)message withWeb:(BOOL)isWeb;
/** 禁止安装软件检测*/
+ (NSString *)CheckSoftForbidInstallStat:(NSString *)message withWeb:(BOOL)isWeb;
/** 禁止运行进程检测*/
+ (NSString *)CheckSystemProcess:(NSString *)message withWeb:(BOOL)isWeb;
/** 必须运行的进程检测*/
+ (NSString *)CheckProcessMustRun:(NSString *)message withWeb:(BOOL)isWeb;
/** 上报软件进程信息*/
+ (NSString *)ReportProcessInfo:(NSString *)agentID;
/** 安全桌面安全检查*/
+ (NSString *)CheckSecureDesktop:(NSString *)message withWeb:(BOOL)isWeb;
/** 杀毒软件安全检查*/
+ (NSString *)CheckAntiVirusSoft:(NSString *)message withWeb:(BOOL)isWeb;
+ (NSArray *)getCurrentCheckItemID:(NSString *)string;
@end
