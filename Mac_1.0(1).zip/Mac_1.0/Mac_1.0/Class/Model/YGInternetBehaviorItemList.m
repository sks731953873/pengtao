//
//  YGInternetBehaviorItemList.m
//  Mac_1.0
//
//  Created by apple on 2017/2/7.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import "YGInternetBehaviorItemList.h"

@implementation YGInternetBehaviorItemList
@synthesize DomainName;
@synthesize Remark;
@synthesize time;

- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.DomainName forKey:@"DomainName"];
    [encoder encodeObject:self.Remark forKey:@"Remark"];
    [encoder encodeObject:self.time forKey:@"time"];
}

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.DomainName = [decoder decodeObjectForKey:@"DomainName"];
        self.Remark = [decoder decodeObjectForKey:@"Remark"];
        self.time = [decoder decodeObjectForKey:@"time"];
    }
    return self;
}

//  初始化
+ (YGInternetBehaviorItemList *)List
{
    return [[YGInternetBehaviorItemList alloc] init];
}

- (BOOL)isEqualToYGInternetBehaviorItemList:(YGInternetBehaviorItemList *)list
{
    if (!list && !list){
        return YES;
    }
    // 如果是完全相同的对象，就省去后面的判断
    if (self == list) return YES;
    // 如果object的类型不对，就不需要比较
    if (![list isKindOfClass:self.class]) return NO;

    
    // 对象类型,两个对象为nil时isEqual:的结果为0(NO),所以需要专门处理
    // 两个对象都为nil时  跳过
    if (self.Remark || list.Remark) {
        if (![self.Remark isEqualToString:list.Remark]) return NO;
    }
    if (self.DomainName || list.DomainName) {
        if (![self.DomainName isEqualToString:list.DomainName]) return NO;
    }
    if (self.time || list.time) {
        if (![self.time isEqualToString:list.time]) {
            return NO;
        }
    }
    return YES;
}

-(NSUInteger)hash
{
    return self.Remark.hash + self.DomainName.hash + self.time.hash;
}
//  重写
- (BOOL)isEqual:(id)object{
    return [self isEqualToYGInternetBehaviorItemList:object];
}

@end
