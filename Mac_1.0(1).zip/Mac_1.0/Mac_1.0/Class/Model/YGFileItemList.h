//
//  YGFileItemList.h
//  Mac_1.0
//
//  Created by apple on 2017/1/4.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef NS_ENUM(NSInteger) {
    Inside = 0, // 内置
    Outside// 外置
}SDCardType;
@interface YGFileItemList : NSObject<NSCoding>
/** 内置还是外置 内置为0*/
@property (nonatomic, assign) SDCardType SDCardType;
/** File策略下发的监控路径*/
@property (nonatomic, copy) NSString    *FilePath;
/** File策略下发的备注*/
@property (nonatomic, copy) NSString    *Remark;

/**初始化*/
+ (YGFileItemList *)List;

/** 比较两个YGAppItemList是否相同*/
- (BOOL)isEqualToYGFileItemList:(YGFileItemList *)list;

@end
