//
//  YGPolicyTaskModel.h
//  Mac_1.0
//
//  Created by Xin on 2017/6/14.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YGPolicyTaskModel : NSObject<NSCoding>

@property (nonatomic, copy) NSString *TaskID;

@property (nonatomic, copy) NSString *SoftUrl;

@property (nonatomic, copy) NSString *SoftName;

@property (nonatomic, copy) NSString *Package;

@property (nonatomic, copy) NSString *SavePath;

@property (nonatomic, copy) NSString *IsRun;

@property (nonatomic, copy) NSString *SourceFile;

@property (nonatomic, copy) NSString *SuccessOption;

@property (nonatomic, copy) NSString *PauseTime;

//@property (nonatomic, copy) NSString *
+ (YGPolicyTaskModel *)model;
@end
