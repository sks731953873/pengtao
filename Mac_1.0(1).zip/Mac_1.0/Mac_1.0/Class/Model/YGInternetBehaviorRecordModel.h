//
//  YGInternetBehaviorRecordModel.h
//  Mac_1.0
//
//  Created by apple on 2017/2/7.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YGInternetBehaviorRecordModel : NSObject<NSCoding>
/**?????*/
@property (nonatomic, assign) BOOL IsEnable;
/** 记录日志*/
@property (nonatomic, assign) BOOL IsRecordLog;
/** 关闭wifi开关*/
@property (nonatomic, assign) BOOL IsCloseData;
/** YGInternetBehaviorRecordModel模型数组*/
@property (nonatomic, strong) NSArray * ItemList;
/** 初始化*/
+ (YGInternetBehaviorRecordModel *)Model;
/** 比较两个YGInternetBehaviorRecordModel是否相等*/
- (BOOL)isEqualYGInternetBehaviorRecordModel:(YGInternetBehaviorRecordModel *)model;
@end
