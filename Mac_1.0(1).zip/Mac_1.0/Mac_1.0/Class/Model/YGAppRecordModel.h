//
//  YGAppRecordModel.h
//  Mac_1.0
//
//  Created by apple on 2016/12/26.
//  Copyright © 2016年 infogo. All rights reserved.
//黑白名单

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger){
    WhiteList = 0, // 白名单
    BlackList// 黑名单
}PolicyType;

@interface YGAppRecordModel : NSObject<NSCoding>

/**策略类型，黑白名单*/
@property (nonatomic, assign) PolicyType policyType;// 策略类型，黑白名单
/** 软件信息*/
@property (nonatomic, strong) NSArray *ItemList;
// 违规处理
/** 绕过锁屏后多少秒锁屏*/
@property (nonatomic, assign) int lockTime;// 锁屏周期
/** 是否锁屏*/
@property (nonatomic, assign) BOOL isLock;
/** 是否断网*/
@property (nonatomic, assign) BOOL isOutNet;// 是否断网
/** 是否记录日志*/
@property (nonatomic, assign) BOOL isRecord; // 是否记录日志

/** 策略更新时间ItemTime*/
@property (nonatomic, copy) NSString *ItemTime;
/** 初始化*/
+ (YGAppRecordModel *)Model;

/** 比较两个YGAppRecordModel类是否相等*/
- (BOOL)isEqualToYGAppRecordModel:(YGAppRecordModel *)recordModel;

@end
