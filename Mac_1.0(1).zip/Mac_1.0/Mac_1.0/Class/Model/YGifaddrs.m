//
//  YGifaddrs.m
//  Mac_1.0
//
//  Created by apple on 2016/12/7.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import "YGifaddrs.h"

@implementation YGifaddrs

@end
