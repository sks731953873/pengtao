//
//  YGWifiRecordModel.m
//  Mac_1.0
//
//  Created by apple on 2016/12/28.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import "YGWifiRecordModel.h"
#import "YGWifiItemList.h"
@implementation YGWifiRecordModel
@synthesize agentID;
@synthesize ItemList;
@synthesize ItemID;
@synthesize ItemTime;
@synthesize isEnable;

- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.agentID forKey:@"agentID"];
    [encoder encodeObject:self.ItemList forKey:@"ItemList"];
    [encoder encodeObject:self.ItemID forKey:@"ItemID"];
    [encoder encodeObject:self.ItemTime forKey:@"ItemTime"];
    [encoder encodeObject:[NSNumber numberWithBool:self.isEnable] forKey:@"isEnable"];
}

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.agentID = [decoder decodeObjectForKey:@"agentID"];
        self.ItemList = [decoder decodeObjectForKey:@"ItemList"];
        self.ItemID = [decoder decodeObjectForKey:@"ItemID"];
        self.ItemTime = [decoder decodeObjectForKey:@"ItemTime"];
        self.isEnable = [[decoder decodeObjectForKey:@"isEnable"] boolValue];
    }
    return self;
}


+ (YGWifiRecordModel *)Model{
    return [[YGWifiRecordModel alloc] init];
}
- (BOOL)isEqualToYGWifiRecordModel:(YGWifiRecordModel *)recordModel
{
    if (!self && !recordModel) {
        return YES;
    }
    // 如果是完全相同的对象，就省去后面的判断
    if (self == recordModel) return YES;
    
    // 如果object的类型不对，就不需要比较
    if (![recordModel isKindOfClass:self.class]) return NO;
    
    // 基本数据类型
    BOOL result = (self.isEnable == recordModel.isEnable && self.ItemList.count == recordModel.ItemList.count);
    if (!result) return result;
    
    // 两个数组内字段不同则不等（包括顺序）
    for (int i = 0; i < self.ItemList.count; i++) {
        YGWifiItemList *ygWifiItemList1 = self.ItemList[i];
        YGWifiItemList *ygWifiItemList2 = recordModel.ItemList[i];
        BOOL itemListResult = [ygWifiItemList1 isEqualToYGWifiItemList:ygWifiItemList2];
        if (!itemListResult && (ygWifiItemList1 || ygWifiItemList2)) {
            return itemListResult;
        }
    }
    
    // 对象类型,两个对象为nil时isEqual:的结果为0(NO),所以需要专门处理
    if (self.ItemID || recordModel.ItemID) {
        if (![self.ItemID isEqualToString:recordModel.ItemID]) return NO;
    }
    if (self.agentID || recordModel.agentID) {
        if (![self.agentID isEqualToString:recordModel.agentID]) return NO;
    }
    if (self.ItemTime || recordModel.ItemTime) {
        if (![self.ItemTime isEqualToString:recordModel.ItemTime]) return NO;
    }
    return YES;
}
/** 重写hash*/
- (NSUInteger)hash
{
    return self.agentID.hash + self.ItemID.hash + self.ItemTime.hash + self.isEnable + self.ItemList.hash;
}

- (BOOL)isEqual:(YGWifiRecordModel *)object
{
    return [self isEqualToYGWifiRecordModel:object];
}
@end
