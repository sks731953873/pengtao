//
//  YGifaddrs.h
//  Mac_1.0
//
//  Created by apple on 2016/12/7.
//  Copyright © 2016年 infogo. All rights reserved.
//  地址信息

#import <Foundation/Foundation.h>

@interface YGifaddrs : NSObject
@property(nonatomic) struct ifaddrs *ygifaddrs;
@property(nonatomic)        struct ifaddrs  *ifa_next;
@property(nonatomic, assign)char            *ifa_name;
@property(nonatomic, assign)unsigned int	 ifa_flags;
@property(nonatomic)        struct sockaddr	*ifa_addr;
@property(nonatomic)        struct sockaddr	*ifa_netmask;
@property(nonatomic)        struct sockaddr	*ifa_dstaddr;
@property(nonatomic)        void		*ifa_data;

@end
