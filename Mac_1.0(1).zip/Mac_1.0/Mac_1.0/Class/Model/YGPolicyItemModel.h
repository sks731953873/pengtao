//
//  YGPolicyItemModel.h
//  Mac_1.0
//
//  Created by apple on 2016/12/23.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

#define YGMP_Application     @"MACMobilePolicy_Application"            // 应用黑白名单策略
#define YGMP_File            @"MobilePolicy_File"                   // 文档策略
#define YGMP_WiFi            @"MACMobilePolicy_WiFi"                   // WiFi策略
#define YGMP_InternetBehavio @"MobilePolicy_InternetBehavior"   // 上网行为管控
#define YGMP_UsbPlugAudit    @"MACMobilePolicy_UsbPlugAudit"  //
#define YGMP_UsbDeviceCtrl   @"MACMobilePolicy_UsbDeviceCtrl"

@interface YGPolicyItemModel : NSObject<NSCoding>

/** 策略id*/
@property (nonatomic, copy) NSString * itemId;
/** 策略名称*/
@property (nonatomic, copy) NSString * name;
/** 策略下发时间*/
@property (nonatomic, copy) NSString * time;
/** itemIndexOf*/
@property (nonatomic, copy) NSString * itemIndexOf;


+ (YGPolicyItemModel *)modelWithDictionary:(NSDictionary *)item;

@end
