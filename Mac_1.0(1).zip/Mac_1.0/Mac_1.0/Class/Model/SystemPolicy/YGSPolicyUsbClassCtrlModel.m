//
//  YGSPolicyUsbClassCtrlModel.m
//  Mac_1.0
//
//  Created by xin on 2019/2/15.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "YGSPolicyUsbClassCtrlModel.h"
#import "YGTool.h"
@implementation YGSPolicyUsbClassCtrlModel


- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.Body forKey:@"Body"];
    [encoder encodeObject:self.ItemID forKey:@"ItemID"];
    [encoder encodeObject:self.ItemName forKey:@"ItemName"];
}

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.Body = [decoder decodeObjectForKey:@"Body"];
        self.ItemID = [decoder decodeObjectForKey:@"ItemID"];
        self.ItemName = [decoder decodeObjectForKey:@"ItemName"];
    }
    return self;
}
/** 单独存储到本地，暂时未用
 */
+ (void)SaveSPolicyUsbClassCtrlModel:(YGSPolicyUsbClassCtrlModel *)SPolicyUsbClassCtrlModel {
//    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:SPolicyUsbClassCtrlModel];
//    writeFile(data, kInfogoPOLICY);
}


+ (YGSPolicyUsbClassCtrlModel *)modelWithDictionary:(NSDictionary *)dictionary {
    YGSPolicyUsbClassCtrlModel *model = [[YGSPolicyUsbClassCtrlModel alloc] init];
    model.ItemID = dictionary[@"ItemID"];
    model.ItemName = dictionary[@"ItemName"];
    NSMutableArray *_body = [NSMutableArray array];
    id Body = dictionary[@"Body"];
    if ([Body isKindOfClass:[NSDictionary class]]) {
        NSDictionary *Ctrl = Body[@"Ctrl"];
        id Items = Ctrl[@"Item"];
        if ([Items isKindOfClass:[NSDictionary class]]) {
            YGUsbManagerModel *model = [YGUsbManagerModel modelWithDictionary:Items];
            if (model)
                [_body addObject:model];
        }else if ([Items isKindOfClass:[NSArray class]]) {
            for (NSDictionary *item in Items) {
                YGUsbManagerModel *model = [YGUsbManagerModel modelWithDictionary:item];
                if (model) {
                    [_body addObject:model];
                }
            }
        }
    }
    model.Body = [_body copy];
    return model;
}


@end
