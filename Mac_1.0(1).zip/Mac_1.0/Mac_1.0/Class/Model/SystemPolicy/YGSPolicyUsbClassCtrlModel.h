//
//  YGSPolicyUsbClassCtrlModel.h
//  Mac_1.0
//
//  Created by xin on 2019/2/15.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YGUsbManagerModel.h"


@interface YGSPolicyUsbClassCtrlModel : NSObject

@property (nonatomic, copy) NSString *ItemName;
@property (nonatomic, copy) NSString *ItemID;
@property (nonatomic, strong) NSMutableArray<YGUsbManagerModel *> *Body;

+ (YGSPolicyUsbClassCtrlModel *)modelWithDictionary:(NSDictionary *)dictionary;
@end


