//
//  YGUsbManagerModel.m
//  Mac_1.0
//
//  Created by xin on 2019/2/15.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "YGUsbManagerModel.h"
#import "YGTool.h"
@implementation YGUsbManagerModel

- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:[NSNumber numberWithInteger:self.NeedReg] forKey:@"NeedReg"];
    [encoder encodeObject:self.Code forKey:@"Code"];
    [encoder encodeObject:self.Desc forKey:@"Desc"];
    [encoder encodeObject:self.Name forKey:@"Name"] ;
}

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.NeedReg = [[decoder decodeObjectForKey:@"NeedReg"] integerValue];
        self.Code = [decoder decodeObjectForKey:@"Code"];
        self.Desc = [decoder decodeObjectForKey:@"Desc"];
        self.Name = [decoder decodeObjectForKey:@"Name"];
    }
    return self;
}

+ (YGUsbManagerModel *)modelWithDictionary:(NSDictionary *)dictionary {
    if (dictionary.count < 1) {
        return nil;
    }
    YGUsbManagerModel *model = [[YGUsbManagerModel alloc] init];
    model.Code = dictionary[@"Code"];
    model.Desc = dictionary[@"Desc"];
    model.Name = dictionary[@"Name"];
    model.NeedReg = [dictionary[@"NeedReg"] integerValue];
    writeFile(dictionary[@"NeedReg"], @"USBNeedReg");
    return model;
}
@end
