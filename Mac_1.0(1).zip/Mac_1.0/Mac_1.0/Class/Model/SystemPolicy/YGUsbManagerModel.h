//
//  YGUsbManagerModel.h
//  Mac_1.0
//
//  Created by xin on 2019/2/15.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface YGUsbManagerModel : NSObject
/**CR08065000*/
@property (nonatomic, copy) NSString *Code;
/**UFlash*/
@property (nonatomic, copy) NSString *Name;
/**存储设备*/
@property (nonatomic, copy) NSString *Desc;
/** 0 无需注册 1 手动注册 2 自动注册*/
@property (nonatomic, assign) NSInteger NeedReg;


+ (YGUsbManagerModel *)modelWithDictionary:(NSDictionary *)dictionary;
@end


