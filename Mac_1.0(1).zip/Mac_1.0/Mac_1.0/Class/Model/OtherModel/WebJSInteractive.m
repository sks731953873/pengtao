//
//  WebJSInteractive.m
//  Mac_1.0
//
//  Created by xin on 2018/4/10.
//  Copyright © 2018年 infogo. All rights reserved.
//

#import "WebJSInteractive.h"
#import "YGTool.h"
#import "YGNetAuthModel.h"
@interface WebJSInteractive ()

@property (nonatomic, strong) WebJSInteractive *wJSInteractive;

@end
@implementation WebJSInteractive

-(WebJSInteractive *)wJSInteractive {
    if (!_wJSInteractive) {
        _wJSInteractive = [[WebJSInteractive alloc] init];
    }
    return _wJSInteractive;
}
#pragma mark 用户信息
+ (void)webJSgetUesrInfo:(WKWebView *)webView {
    __weak typeof(webView)weakWebView = webView;
    NSString *RoleID = readFile(@"RoleID");
    NSString *UserName = readFile(@"UserName");
    if (RoleID.length < 1)
        RoleID = @"";
    if (UserName.length < 1)
        UserName = @"";
    NSString *rString = [NSString stringWithFormat:@"getUserInfo('%@#infogo#%@')", UserName, RoleID];
    [weakWebView evaluateJavaScript:rString completionHandler:^(id id , NSError * _Nullable error) {

    }];
}

+ (void)webJSgetAboutInfo:(WKWebView *)webView {
    __weak typeof (webView)weakWebView = webView;
    NSString *version = [[[NSBundle mainBundle]infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    [weakWebView evaluateJavaScript:[NSString stringWithFormat:@"getAboutInfo('%@')", version] completionHandler:^(id id, NSError * _Nullable error) {

    }];
}

+ (void)webJSgetOffLineAboutInfo:(WKWebView *)webView {
    NSString *version = [[[NSBundle mainBundle]infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    NSString *string = readFile(@"aboutInfo");
    string = string.length > 0?[NSString stringWithFormat:@"%@</br>版本:%@",  string, version]:[NSString stringWithFormat:@"版本:%@", version];
    [webView evaluateJavaScript:[NSString stringWithFormat:@"getOffLineAboutInfo('%@')", string] completionHandler:^(id id, NSError * _Nullable error) {

    }];
}

+ (void)webJSgetSupporInfo:(WKWebView *)webView {
    __weak typeof (webView)weakWebView = webView;
    NSString *string = readFile(@"supportInfo");

    NSString *rString = [NSString stringWithFormat:@"getSupportInfo('%@')", string.length > 0 ? string : @" "];
    [weakWebView evaluateJavaScript:rString completionHandler:^(id id, NSError * _Nullable error) {

    }];
}

+ (void)webJSgetPolicyInfo:(WKWebView *)webView {
    NSString *msg = [self CurrentPolicy];

    [webView evaluateJavaScript:[NSString stringWithFormat:@"getPolicyInfo('%@')", msg] completionHandler:^(id id, NSError * _Nullable error) {

    }];
}

+ (void)webJSgetofflineInfo:(WKWebView *)webView {
    __weak typeof (webView)weakWeb = webView;
    NSString *string = readFile(@"offlineInfo");
    if (string.length < 1) {
        string = @"";
    }
    [weakWeb evaluateJavaScript:[NSString stringWithFormat:@"getofflineInfo('%@')", string] completionHandler:^(id id, NSError * _Nullable error) {

    }];
}


/**
 -1:未管控
 0:
 2:管控
 */
+ (void)webJSgetMdmControlWithString:(NSString *)string {
    //    string = [self cut_request_string:string start:@"[<REQUEST>]" endString:@"[</REQUEST>]"];
    //    if (InclusionRelation(string, @"#infogo#")) {
    //        // uuid policyid deviceid
    //        NSArray *array = [string componentsSeparatedByString:@"#infogo#"];
    //        if ([array[0] integerValue] != -1) {
    //            return;
    //        }
    //        if ([array[1] length] < 1 || [array[2] length] < 1 || [array[3] length] < 1 || [array[4] length] < 1) return;
    //        NSString *urlString = [NSString stringWithFormat:@"%@user/downloadd.do?uid=%@_%@_%@", array[4], array[1], array[2], array[3]];
    //        NSURL *url = [NSURL URLWithString:urlString];
    //        if ([[UIApplication sharedApplication] canOpenURL:url]) {
    //            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //                [[UIApplication sharedApplication] openURL:url];
    //            });
    //        }
    ////        HXINFOLOG(@"去外网下载配置文件:%@", result?@"success":@"faild");
    //    }
}

+ (void)webJSgetConfig:(WKWebView *)webView withString:(NSString *)string {
//    __weak typeof (webView)weakWeb = webView;
//    NSRange rang = [string rangeOfString:@"</CallOneFuncMode>"];
//    NSInteger num = rang.length + rang.location;
//    NSMutableString * changeString = [NSMutableString stringWithString:string];
//
//    [changeString insertString:@"\n    <Result>Yes</Result>" atIndex:num];
    //    NSString * automatica = readFile(@"automatically");// 获取设置页面的是否自动认证
//    YGDeviceInfo *c_deviceInfo = [[YGDeviceInfo info] qunueSelectFromDeviceInfo];
//    NSString * automatica = [NSString stringWithFormat:@"%ld", (long)c_deviceInfo.automatically];
//    NSString *newString = [NSString stringWithFormat:@"%@[<REPLY>]{\"autoauth\":%@}[</REPLY>]", changeString, automatica];
//    NSString * SERIAL = [self cutOffString:string];//截取SERIAL
//    NSString * base64 = [CommonFunc base64StringFromText:newString];
//    NSString * xmlString = [NSString stringWithFormat:@"var script = document.createElement('script');"
//                            "script.type = 'text/javascript';"
//                            "script.text = \"function myFunction(result,serial,type,encode) { "
//                            "onRecvMsg(result,serial,type,encode);"
//                            "}\";"
//                            "document.getElementsByTagName('head')[0].appendChild(script);"];
//    [weakWeb evaluateJavaScript:xmlString completionHandler:^(id id, NSError * _Nullable error) {
//
//    }];
//    [weakWeb evaluateJavaScript:[NSString stringWithFormat:@"myFunction('%@','%@','%@','%@')", base64, SERIAL, @"end", @"base64"] completionHandler:^(id id, NSError * _Nullable error) {
//
//    }];

}

+ (void)webJSnativeCheckApp:(WKWebView *)webView withString:(NSString *)string {
//    NSStringEncoding gbkEncoding = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
//    string = [string stringByReplacingPercentEscapesUsingEncoding:gbkEncoding];
//    string = [self cut_request_string:string start:@"[<REQUEST>]" endString:@"[</REQUEST>]"];
//    NSArray *array = [string componentsSeparatedByString:@"#infogo#"];
//    NSMutableString *mString = [NSMutableString string];
//    YGDataBase * db = [YGDataBase shareFMDataBase];

//    if (array.count>0) {
//        for (int i = 0; i < array.count; i++) {
//            YGApp *app = [db qunueSelectAppForAppName:array[i]];
//            if (app.applicationIdentifier.length > 0) {
//                [mString insertString:@"true#infogo#" atIndex:mString.length];
//            }else{
//                [mString insertString:@"false#infogo#" atIndex:mString.length];
//            }
//        }
//    }
//    if (mString.length < 1) return;
//    [webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"nativeCheckApp('%@')", mString]];
}
+ (void)webJSgetInfoForWorktab:(WKWebView *)webView {
//    __weak typeof (webView)weakWebView = webView;
//    Information *im = [[Information alloc] init];
//    NSString *dModel = [im getCurrentDeviceModel];
//    NSArray *dArray = [dModel componentsSeparatedByString:@"@"];
//    NSString * DeviceNameStr =  dArray[0];// 设备的类别
//
//    UIDevice *device            = [UIDevice currentDevice];
//    int battrey                 = [self getCurrentBatteryLevel];
//    if (battrey <= 0) {
//        device.batteryMonitoringEnabled = YES;
//        battrey = (int)(device.batteryLevel * 100);
//    }
//    if (battrey <= 0) {
//        battrey = 50;
//    }
//    NSString * systemNameStr    = device.systemName;// 当前运行的系统名称
//    NSString * systemVersionStr = device.systemVersion;// 9.2
//    NSString *fileSystemFreeSizeStr = [Information getDivceFreeSize];
//    NSArray * infoArray = [im logMemoryInfo];
//
//    double freeMenmory  = [infoArray[4] doubleValue];
//    double allMenmory   = [NSProcessInfo processInfo].physicalMemory /1000.0/1000.0;
//    NSString * systemInfo = [NSString stringWithFormat:@"%@%@", systemNameStr, systemVersionStr];// iphone os 9.2
//    NSString *msg = [NSString stringWithFormat:@"%@#infogo#%@#infogo#%@#infogo#%d%%#infogo#%dMB", DeviceNameStr, systemInfo, fileSystemFreeSizeStr, battrey, (int)(allMenmory - freeMenmory)];
//    //  abs 取绝对值allMenmory可能为空
//    [weakWebView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"getInfoForWorktab('%@')", msg]];
}

+ (void)webJSgetSystemInfo:(WKWebView *)webView withString:(NSString *)string {
//
//    __weak typeof (webView)weakWeb = webView;
//    Information *_information = [[Information alloc] init];
//    NSString *dModel = [_information getCurrentDeviceModel];
//    NSArray *dArray = [dModel componentsSeparatedByString:@"@"];
//
//    NSString *DeviceNameStr     = dArray[0];
//    NSString *cpuStr            = dArray[1];
//    NSString *physicalMemoryStr = dArray[2];
//
//    UIDevice *device = [UIDevice currentDevice];
//    NSString *systemNameStr    = device.systemName;// 当前运行的系统名称
//    NSString *systemVersionStr = device.systemVersion;
//
//    NSString *kernerlNumberStr = [NSString stringWithFormat:@"%d", countOfCores()];// 内核数
//
//    NSString *fileSystemSizeStr = [Information getDivceSize];
//    NSString *fileSystemFreeSizeStr = [Information getDivceFreeSize];
//    NSString * operatorStr = [_information currentOperator]; // 运营商
//    NSString * ipAddressStr = [_information getWIFIIPAddress];// ip地址
//
//    NSArray * infoArray      = [_information logMemoryInfo];
//    NSString * activeMenmory = infoArray[2];
//    NSString *uuidStr     = [Information findForgedDiskID];// 使用uuid充当DiskId
//    NSString *addressStr1 = [Information findForgedMAC];// 使用uuid伪造的mac
//    NSString * isRoot = [_information isJailBreak];
//    NSString * batteryStateStr = [_information powerState];
//
//    NSString * systemInfo = [NSString stringWithFormat:@"%@%@", systemNameStr, systemVersionStr];// iphone os 9.2
//    NSString *mark = readFile(@"ifa_netmask");
//    if (mark.length < 1) {
//        mark = @"255.255.255.0";
//    }
//    NSString * str1 = [NSString stringWithFormat:@"[<REPLY>]<?xml version=\"1.0\" encoding=\"gbk\"?><MSAC><ComputerName>%@</ComputerName><Mac>%@</Mac><Ip>%@</Ip><OS>%@</OS><DeviceName>%@</DeviceName><DiskId>%@</DiskId><IeVersion>Safari</IeVersion><CPU>%@</CPU><Phonestoragespace>%@</Phonestoragespace><Phoneavailablestorage>%@</Phoneavailablestorage><DiskSize></DiskSize><Sdcardavailablestorage></Sdcardavailablestorage><Memory>%@</Memory><Runmemory>%@</Runmemory><Imei></Imei><Networksystem>%@</Networksystem><Kernelnumber>%@</Kernelnumber><Roam></Roam><Phonetype></Phonetype><Whetheroot>%@</Whetheroot><Charging>%@</Charging><Mark>%@</Mark><GateWay></GateWay></MSAC>[</REPLY>]",
//                       DeviceNameStr,
//                       addressStr1,
//                       ipAddressStr,
//                       systemInfo,
//                       DeviceNameStr,
//                       uuidStr,
//                       cpuStr,
//                       fileSystemSizeStr,
//                       fileSystemFreeSizeStr,
//                       physicalMemoryStr,
//                       activeMenmory,
//                       operatorStr,
//                       kernerlNumberStr,
//                       isRoot,
//                       batteryStateStr,
//                       mark];
//    NSRange rang = [string rangeOfString:@"</CallOneFuncMode>"];
//    if (rang.location == NSNotFound){
//        return;
//    }
//    NSInteger num = rang.length + rang.location;
//    NSMutableString * changeString = [NSMutableString stringWithString:string];
//    [changeString insertString:@"\n    <Result>Yes</Result>" atIndex:num];// 插入
//    NSString *newString = [NSString stringWithFormat:@"%@%@", changeString, str1];
//    NSString * base64 = [CommonFunc base64StringFromText:newString];
//    NSString * SERIAL = [self cutOffString:string];//截取SERIAL
//    [weakWeb stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"myFunction('%@','%@','%@','%@')", base64, SERIAL, @"end", @"base64"]];
    return ;
}

+ (void)webJSnativeGetDeviceId:(WKWebView *)webView {
    NSString *string = readFile(@"DeviceID");
    if (string.length < 1) {
        string = @"";
    }
    [webView evaluateJavaScript:[NSString stringWithFormat:@"nativeGetDeviceId('%@')", string] completionHandler:^(id id, NSError * _Nullable error) {

    }];
}


+ (void)webJSsetNetCfg {
//    // 要做兼容  ios10以前和ios10
//    //注意首字母改成了大写，prefs->Prefs
//    if (DEVICEVERSION < 10.0) {
//        NSURL * url = [NSURL URLWithString:@"prefs:root=WIFI"];
//        if([[UIApplication sharedApplication] canOpenURL:url]) {
//            [[UIApplication sharedApplication] openURL:url];
//        }
//    } else if (DEVICEVERSION >= 11.0) {
//        //        NSURL *url = [NSURL URLWithString:@"App-Prefs:root=General&path=WIFI"];
//        NSURL *url = [NSURL URLWithString:@"App-Prefs:root=WIFI"];
//        if ([[UIApplication sharedApplication] canOpenURL:url]) {
//            [[UIApplication sharedApplication] openURL:url];
//        }
//    }else {
//        NSURL*url=[NSURL URLWithString:@"Prefs:root=WIFI"];
//        Class LSApplicationWorkspace = NSClassFromString(@"LSApplicationWorkspace");
//        [[LSApplicationWorkspace performSelector:@selector(defaultWorkspace)] performSelector:@selector(openSensitiveURL:withOptions:) withObject:url withObject:nil];
//    }
}
#pragma mark webConfig存储离线等信息
+ (void)webJSgetWEBConfig:(NSString *)urlStr
{
//    NSString *str = [self cut_request_string:urlStr start:@"[<REQUEST>]" endString:@"[</REQUEST>]"];
//    NSData *jsonData = [str dataUsingEncoding:NSUTF8StringEncoding];
//    NSError *error;
//    NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:jsonData
//                                                             options:NSJSONReadingMutableContainers
//                                                               error:&error];
//    if (jsonDict.count < 1) {
//        return;
//    }
//    for (NSString *str in [jsonDict allKeys]) {
//        writeFile([jsonDict objectForKey:str], str);
//    }
    NSRange range1 = [urlStr rangeOfString:@"[<REQUEST>]"];
    NSRange range2 = [urlStr rangeOfString:@"[</REQUEST>]"];
    NSRange range;
    range.length = range2.location - range1.location - range1.length;
    range.location = range1.length + range1.location;
    NSString * str = [urlStr substringWithRange:range];
    NSData *jsonData = [str dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
    NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:jsonData
                                                             options:NSJSONReadingMutableContainers
                                                               error:&error];
    if (jsonDict.count > 0) {
        NSString *deviecID = jsonDict[@"DeviceID"];
        if (deviecID.length > 0) {
            writeFile(jsonDict[@"DeviceID"], kAgentID);
        }
        NSString *autoAuth = jsonDict[@"AndroidAutoAuth"];
        NSString *RoleID = jsonDict[@"RoleID"];
        YGNetAuthModel *model = [[YGNetAuthModel model] qunueSelectFromNetAuthModel];
        if (autoAuth.length > 0) {
            model.IsNetAuth = 1;
            model.autoAuthTime = [autoAuth doubleValue];
            model.InsertTime = current_Time_Stamp();
            model.RoleID = RoleID.integerValue;
        }else {
            model.IsNetAuth = 0;
            model.autoAuthTime = 0;
            model.InsertTime = 0;
            model.RoleID = RoleID.integerValue;
        }
        [model qunueUpdateNetAuthTable];
        NSString *unInstallKey = jsonDict[@"UnInstallKey"];
        //        if (unInstallKey.length > 0) {
        writeFile(unInstallKey, @"UnInstallKey");// 保存万能卸载码
        //        }
    }
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSDirectoryEnumerator<NSString *> * myDirectoryEnumerator;
    NSString *strPath = kCachesDirictory;
    myDirectoryEnumerator=  [fileManager enumeratorAtPath:strPath];
    NSString *path;
    while (path = [myDirectoryEnumerator nextObject]) {
        for (NSString * namePath in path.pathComponents) {
            if ([[namePath pathExtension] isEqualToString:@"dmg"] || [[namePath pathExtension] isEqualToString:@"pkg"]) {
                NSString *sFile = [strPath stringByAppendingPathComponent: namePath];
                if ([fileManager fileExistsAtPath:sFile]) {
                    if ([fileManager removeItemAtPath:[strPath stringByAppendingPathComponent: namePath] error:nil]) {

                    }
                }
            }
        }
    }
}


#pragma mark -------------------------------tool------------------------------
/** 截取SERIAL*/
+ (NSString *)cutOffString:(NSString *)requestString
{
    NSRange range = [requestString rangeOfString:@"SERIAL"];
    range.location += 7;
    range.length = 10;
    NSString *serialString = [requestString substringWithRange:range];
    return serialString;
}

// 替换操作  返回YES：存储成功  返回NO：存储失败
+ (BOOL)stringByExistAndSaveOfString:(NSString *)target withString:(NSString *)repString {
    if ([target rangeOfString:repString].location != NSNotFound) {
        NSArray *array = [target componentsSeparatedByString:@":"];
        if (array.count > 1) {
            NSString *string = [array[1] stringByReplacingOccurrencesOfString:@"\"" withString:@""];
            if (string.length) {
                writeFile(string, repString);
                return YES;
            }
        }
    }
    return NO;
}

+ (NSString *)cut_request_string:(NSString *)string start:(NSString *)startString endString:(NSString *)endString{
    NSRange range1 = [string rangeOfString:startString];
    NSRange range2 = [string rangeOfString:endString options:NSBackwardsSearch];
    NSRange range;
    if (range1.location == NSNotFound || range2.location == NSNotFound) {
        return nil;
    }
    range.length = range2.location - range1.location - range1.length;
    range.location = range1.length + range1.location;
    NSString * str = [string substringWithRange:range];
    return str;
}

+ (int)getCurrentBatteryLevel{
//    UIApplication *app = [UIApplication sharedApplication];
//    if (app.applicationState == UIApplicationStateActive||app.applicationState==UIApplicationStateInactive) {
//        Ivar ivar = class_getInstanceVariable([app class],"_statusBar");
//        id status = object_getIvar(app, ivar);
//        for (id aview in [status subviews]) {
//            int batteryLevel = 0;
//            for (id bview in [aview subviews]) {
//                if ([NSStringFromClass([bview class]) caseInsensitiveCompare:@"UIStatusBarBatteryItemView"] == NSOrderedSame&&[[[UIDevice currentDevice] systemVersion] floatValue] >=6.0)
//                {
//                    Ivar ivar=  class_getInstanceVariable([bview class],"_capacity");
//                    if(ivar)
//                    {
//                        batteryLevel = ((int (*)(id, Ivar))object_getIvar)(bview, ivar);
//                        //这种方式也可以
//                        /*ptrdiff_t offset = ivar_getOffset(ivar);
//                         unsigned char *stuffBytes = (unsigned char *)(__bridge void *)bview;
//                         batteryLevel = * ((int *)(stuffBytes + offset));*/
//                        //                        NSLog(@"电池电量:%d",batteryLevel);
//                        if (batteryLevel > 0 && batteryLevel <= 100) {
//                            return batteryLevel;
//                        } else {
//                            return 0;
//                        }
//                    }
//                }
//            }
//        }
//    }

    return 0;
}

+ (NSString *)CurrentPolicy {
//    YGDeviceInfo *c_deviceInfo = [[YGDeviceInfo info] qunueSelectFromDeviceInfo];
//    NSDate *date = [NSDate dateWithTimeIntervalSince1970:c_deviceInfo.recvRoleChangedTime];
//    NSDateFormatter *objDateformat = [[NSDateFormatter alloc] init];
//    [objDateformat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
//    NSString *timeString = [objDateformat stringFromDate:date];
//    YGDataBase *db = [YGDataBase shareFMDataBase];
//    YGGeofenceModel *geoModel = [db qunueGetGeofence];
//    NSMutableArray  *wList = [db qunueGetAllWiFi];
//    if (geoModel && wList.count > 0)
//        return [NSString stringWithFormat:@"策略获取时间:%@#infogo#地理围栏策略#infogo#WIFI连接控制策略", timeString];
//    if (geoModel)
//        return [NSString stringWithFormat:@"策略获取时间:%@#infogo#地理围栏策略", timeString];
//    if (wList.count > 0)
//        return [NSString stringWithFormat:@"策略获取时间:%@#infogo#WIFI连接控制策略", timeString];
    return @"";
}



@end
