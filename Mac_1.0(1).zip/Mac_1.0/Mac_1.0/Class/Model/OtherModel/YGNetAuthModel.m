    //
//  YGNetAuthModel.m
//  Mac_1.0
//
//  Created by xin on 2018/4/10.
//  Copyright © 2018年 infogo. All rights reserved.
//

#import "YGNetAuthModel.h"
#import "YGNetHttpRequestObject.h"
#import "YGTool.h"
#import "YGMessageSplicing.h"
#import "CommonFunc.h"
@interface YGNetAuthModel()

@property (nonatomic, strong) YGDataBase *db;

@end

@implementation YGNetAuthModel

+ (YGNetAuthModel *)model {
    return [[YGNetAuthModel alloc] init];
}

- (YGDataBase *)db {
    if (!_db) {
        _db = [YGDataBase shareFMDataBase];
    }
    return _db;
}


/**
 在数据库中创建NetAuthTable表
 username:用户名
 password:密码
 InsertTime:上次认证时间
 getauthtype:认证类型 --> NoAuth:自动认证，User：账号密码认证，Stop：禁止认证，Isolation：设备被隔离，NotLive：设备被删除
 policyId:规范ID
 IsSafeCheck:是否开启安检项
 */
- (void)qunueCreateNetAuthTable {
    NSString *createString = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS NetAuthTable(identify INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT,password TEXT, InsertTime INTEGER, autoAuthTime INTEGER, getAuthType TEXT, RoleID INTEGER, IsSafeCheck INTEGER, IsNetAuth TEXT, PolicyID INTEGER)"];
    if (self.db.queue) {
        [self.db.queue inDatabase:^(FMDatabase *db) {
            BOOL b = [db executeUpdate:createString];
            HXINFOLOG(@"create NetAuthTable is %@", b? @"success": @"faild");
        }];
    }
}
/** NetAuth表插入完整数据*/
- (void)qunueInsertNetAuthTable {
    [self qunueCreateNetAuthTable];
    [self.db.queue inDatabase:^(FMDatabase *db) {
        BOOL insert = [db executeUpdate:@"INSERT INTO NetAuthTable (username,password,InsertTime,autoAuthTime,getAuthType,RoleID,IsSafeCheck, IsNetAuth, PolicyID) VALUES (?,?,?,?,?,?,?,?,?)",
                       self.username,
                       self.password,
                       [NSNumber numberWithDouble:self.InsertTime],
                       [NSNumber numberWithInteger:self.autoAuthTime],
                       self.getAuthType,
                       [NSNumber numberWithInteger:self.RoleID],
                       [NSNumber numberWithInteger:self.IsSafeCheck],
                       [NSNumber numberWithInteger:self.IsNetAuth],
                       [NSNumber numberWithInteger:self.PolicyID]];
        if (insert) {
//            HXINFOLOG(@"FMDB 添加成员成功!!![%@]", self);
        }else{
            HXINFOLOG(@"FMDB 添加成员失败~~~");
        }
    }];
}

// 因为该表中只会存一条数据 所以拿到了就是正确的数据
- (YGNetAuthModel *)qunueSelectFromNetAuthModel {
    if (![self.db isHasTable:@"NetAuthTable"]) {
        return nil;
    }
    __block YGNetAuthModel *model = nil;
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM NetAuthTable"];
    [_db.queue inDatabase:^(FMDatabase *db) {
        FMResultSet *result = [db executeQuery:sql];
        while ([result next]) {
            model = [YGNetAuthModel model];
            model.identify = [result intForColumn:@"identify"];
            model.username = [result stringForColumn:@"username"];
            model.password = [result stringForColumn:@"password"];
            model.RoleID = [result intForColumn:@"RoleID"];
            model.PolicyID = [result intForColumn:@"PolicyID"];
            model.IsNetAuth = [result intForColumn:@"IsNetAuth"];
            model.InsertTime = [result doubleForColumn:@"InsertTime"];
            model.IsSafeCheck = [result intForColumn:@"IsSafeCheck"];
            model.getAuthType = [result stringForColumn:@"getAuthType"];
            model.autoAuthTime = [result doubleForColumn:@"autoAuthTime"];
        }
    }];
    return model;
}

// 通过model查找表中的是否存在
- (BOOL)qunueSelectFromNetAuthModelWithModel:(YGNetAuthModel *)model {
    if (![self.db isHasTable:@"NetAuthTable"]) {
        return NO;
    }
    __block BOOL res = NO;
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM NetAuthTable where (username = '%@' and password = '%@' and RoleID = '%@' and PolicyID = '%@' and IsNetAuth = '%@' and InsertTime = '%@' and IsSafeCheck = '%@' and getAuthType = '%@' and autoAuthTime = '%@')",
                     model.username,
                     model.password,
                     @(model.RoleID),
                     @(model.PolicyID),
                     @(model.IsNetAuth),
                     @(model.InsertTime),
                     @(model.IsSafeCheck),
                     model.getAuthType,
                     @(model.autoAuthTime)];
    [_db.queue inDatabase:^(FMDatabase *db) {
        FMResultSet *result = [db executeQuery:sql];
        while ([result next]) {
            res = YES;
        }
    }];
    return res;
}

/**
 通过唯一标志修改当前的数据库数据
 NetAuth表中只会存一条数据
 */
- (void)qunueUpdateNetAuthTable {
    YGNetAuthModel *pModel = [self qunueSelectFromNetAuthModel];
    if (!pModel) { // 说明当前数据库中有表但无数据(因为无论如何都创建了表)
        [self qunueInsertNetAuthTable];
        return;
    }
    if ([self qunueSelectFromNetAuthModelWithModel:self]) {
        HXINFOLOG(@"与数据库一致，所以不更新数据库");
        return;
    }
    NSString *sql = [NSString stringWithFormat:@"UPDATE NetAuthTable SET username = '%@', password = '%@', getAuthType = '%@', InsertTime = '%@', RoleID = '%@', autoAuthTime = '%@', IsSafeCheck = '%@', IsNetAuth = '%@', PolicyID = '%@' WHERE identify = '%@'",
                     self.username,
                     self.password,
                     self.getAuthType,
                     [NSNumber numberWithDouble:self.InsertTime],
                     [NSNumber numberWithInteger:self.RoleID],
                     [NSNumber numberWithDouble:self.autoAuthTime],
                     [NSNumber numberWithInteger:self.IsSafeCheck],
                     [NSNumber numberWithInteger:self.IsNetAuth],
                     [NSNumber numberWithInteger:self.PolicyID],
                     [NSNumber numberWithInteger:self.identify]];
    [self.db.queue inDatabase:^(FMDatabase *db) {
        if ([db executeUpdate:sql]) {
//            HXINFOLOG(@"UPDATE [%@] 成功", self);
        }else{
            HXINFOLOG(@"UPDATE [%@] 失败", self);
        }
    }];
}


- (void)qunueUpdateNetAuthTableWithSomeThings:(NSString *)sql {
    [self.db.queue inDatabase:^(FMDatabase *db) {
        if ([db executeUpdate:sql]) {
//            HXINFOLOG(@"updata success [\n%@\n]", sql);
        }else{
            HXINFOLOG(@"updata fiald [\n%@\n]", sql);
        }
    }];
}

// 修改自动认证参数
- (void)qunueUpdateNetAuthTableWithAutomatically:(NSInteger)automatically{
    NSString *sql = [NSString stringWithFormat:@"UPDATE DeviceInfo SET automatically = '%@' WHERE identify = '%@'",
                     [NSNumber numberWithInteger:automatically],
                     @(1)];
    [self.db.queue inDatabase:^(FMDatabase *db) {
        BOOL b = [db executeUpdate:sql];
        if (b) {
//            HXINFOLOG(@"UPDATE [%@] 成功", @(automatically));
        }else{
            HXINFOLOG(@"UPDATE [%@] 失败", @(automatically));
        }
    }];
}
// 修改参数
- (void)qunueUpdateNetAuthTableWithrecvRoleChangedTime:(double)recvRoleChangedTime{
    NSString *sql = [NSString stringWithFormat:@"UPDATE DeviceInfo SET recvRoleChangedTime = '%@' WHERE identify = '%@'",
                     [NSNumber numberWithDouble:recvRoleChangedTime],
                     @(1)];
    [self.db.queue inDatabase:^(FMDatabase *db) {
        BOOL b = [db executeUpdate:sql];
        if (b) {
//            HXINFOLOG(@"UPDATE recvRoleChangedTime[%f] 成功", recvRoleChangedTime);
        }else{
            HXINFOLOG(@"UPDATE recvRoleChangedTime[%f] 失败", recvRoleChangedTime);
        }
    }];
}

// 清除策略时间
- (void)qunueUpdateNetAuthTableWithInsertTime:(double)insertTime {
    NSString *sql = [NSString stringWithFormat:@"UPDATE DeviceInfo SET InsertTime = '%@' WHERE identify = '%@'",
                     @(insertTime),
                     @(1)];
    [self.db.queue inDatabase:^(FMDatabase *db) {
        BOOL b = [db executeUpdate:sql];
        if (b) {
//            HXINFOLOG(@"UPDATE recvRoleChangedTime 成功");
        }else{
            HXINFOLOG(@"UPDATE recvRoleChangedTime 失败");
        }
    }];

}
- (NSString *)description {
    return [NSString stringWithFormat:@"\n <%@>\n{\n  identity = [%@]\n  username = [%@]\n  password = [%@]\n  getAuthType = [%@]\n  InsertTime = [%@]\n  RoleID = [%@]\n  IsSafeCheck = [%@]\n  autoAuthTime = [%@]\n  IsNetAuth = [%@]\n  PolicyID = [%@]\n}\n",
            [self class],
            @(_identify),
            _username,
            _password,
            _getAuthType,
            @(_InsertTime),
            @(_RoleID),
            @(_IsSafeCheck),
            @(_autoAuthTime),
            @(_IsNetAuth),
            @(_PolicyID)];
}


#pragma mark 获取自动认证
/**
 校验时间节点是否需要自动认证
 */
+ (void)NetAuthCheck:(BOOL *)isMust {
    YGNetAuthModel *pModel = [[YGNetAuthModel model] qunueSelectFromNetAuthModel];
    if (pModel.IsNetAuth) {//  是否开启自动认证
        NSString *addressServer = readFile(kServerAddress);
        NSString *deviceID = readFile(kAgentID);
        // 判断时间节点
        double currentTime = current_Time_Stamp();
        double timeDiff = currentTime - pModel.InsertTime;
        if (fabs(timeDiff) > pModel.autoAuthTime || *isMust) {// test    应该是要大于pModel.autoAuthTime 即大于周期时间
            if ((*isMust)) {
                *isMust = NO;
            }
            pModel.InsertTime = currentTime;
            [pModel qunueUpdateNetAuthTable];
            // 超过认证周期需要进行认证
            // 1.1获取认证类型 User
            if ([YGNetHttpRequestObject YGNetHttpPolicyCheckItemGetAuthType:addressServer
                                                                   deviceID:deviceID
                                                                   andModel:&pModel]) {
                // 1.2获取是否要进行安检
                // 获取__res = '1#infogo#3#infogo#20002' 1.是否要进行安检.2.policyid.3.roleid
                if ([YGNetHttpRequestObject YGNetHttpPolicyCheckItemGetAuthMes:addressServer
                                                                      deviceid:deviceID
                                                                         model:&pModel]) {
                    writeFile(@"1", @"isSleepNetAuth"); // 锁屏或睡眠后唤醒 触发的认证流程 将该值改了是为了保证一定时间内只做了1次认证

                    if (pModel.IsSafeCheck == 1) {
                        // 2.获取安检信息
                        // 2.1 获取总的安检信息
                        NSString *checkItem = [YGNetHttpRequestObject YGNetHttpPolicyCheckItemXml:addressServer andPolicyID:pModel.PolicyID];
                        NSArray *checkItemArray = [YGMessageSplicing getCurrentCheckItemID:checkItem];
                        // 3.获取单个安检信息->进行安检
                        NSString *pCheckItem = [NSString string];
                        NSString *policyResult = [YGNetAuthModel getPolicyResult:checkItemArray serverAddress:addressServer withTrueID:&pCheckItem];
                        // 3...安检不通过要做弹窗处理
                        // 4.上报安检结果
                        //将安检id集合中的#infogo#转成###||###,然后加密
                        NSString *reqString = nil;
                        // 替换掉安检结果中的yes和no
                        if (XInclusionRelationshipExists(pCheckItem, @"###||###")) {//
                            reqString = [CommonFunc base64StringFromText:pCheckItem];// 将安检id加密
                        }else {
                            reqString = pCheckItem;
                        }
                        [YGNetHttpRequestObject YGNetHttpPolicyCheckItemMobileResult:addressServer deviceID:deviceID model:pModel resultItems:reqString resultXML:policyResult];
                    } else {
                        // 不需要安检，直接上报结果信息->放开网络
                        [YGNetHttpRequestObject YGNetHttpPolicyCheckItemMobileResult:addressServer deviceID:deviceID model:pModel resultItems:@"" resultXML:@""];
                    }
                }
            }
            [pModel qunueUpdateNetAuthTable];
        }
    }
}

+ (NSString *)getPolicyResult:(NSArray *)items serverAddress:(NSString *)serverAddress withTrueID:(NSString **)tID {
    NSMutableString *allResultString = [NSMutableString string];
    NSMutableString *m_TID = [NSMutableString string];
    if (items.count > 0) {
        NSString *resultString = nil;
        for (int i = 0; i < items.count; i++) {
//            NSString *itemID = items[i];
            NSArray *checkItems = [items[i] componentsSeparatedByString:@":"];
            if (checkItems.count == 2) {
                NSString *itemID_id = checkItems[0]; // id
                NSString *itemID_key = checkItems[1];// 是否为关键安检项 yes和no
//                itemID = ReplaceString(itemID, @":Yes");
//                itemID = ReplaceString(itemID, @":No");
                // 对单个安检id请求->获取当前的安检项
                NSString *policyString = [YGNetHttpRequestObject YGNetHttpPolicyCheckItemGetPolicy:serverAddress andItemID:itemID_id];
                policyString = ReplaceString(policyString, @"'");
                policyString = ReplaceString(policyString, @"__res = ");
                NSString *DLLFunc = CutOffStringBetweenBoth(policyString, @"<InsideName>", @"</InsideName>");
                if (DLLFunc.length > 0) {
                    if ([DLLFunc isEqualToString:@"MACCheckSoftInstallStat"]) {
                        /** 安装软件检测*/
                        resultString = [YGMessageSplicing CheckSoftInstallStat:policyString withWeb:NO];
                    }else if ([DLLFunc isEqualToString:@"MACCheckSoftForbidInstallStat"]){
                        /** 禁止安装软件检测*/
                        resultString = [YGMessageSplicing CheckSoftForbidInstallStat:policyString withWeb:NO];
                    }else if ([DLLFunc isEqualToString:@"MACCheckSystemProcess"]) {
                        /** 禁止运行进程检测*/
                        resultString = [YGMessageSplicing CheckSystemProcess:policyString withWeb:NO];
                    }else if ([DLLFunc isEqualToString:@"MACCheckAntiVirusSoft"]) {
                        /** 杀毒软件安全检查*/
                        resultString = [YGMessageSplicing CheckAntiVirusSoft:policyString withWeb:NO];
                    }else if ([DLLFunc isEqualToString:@"MACCheckSecureDesktop"]) {
                        /** 安全桌面安全检查*/
                        resultString = [YGMessageSplicing CheckSecureDesktop:policyString withWeb:NO];
                    }else if ([DLLFunc isEqualToString:@"MACCheckProcessMustRun"]) {
                        /** 必须运行的进程检测*/
                        resultString = [YGMessageSplicing CheckProcessMustRun:policyString withWeb:NO];
                    }else if ([DLLFunc isEqualToString:@"MACReportProcessInfo"]) {
                        /** 上报软件进程信息*/
                        resultString = [YGMessageSplicing ReportProcessInfo:policyString];
                    }
                    // 关键安检项不通过时要弹窗提示
                    // 1.是否为关键安检项
                    if (resultString.length > 0 &&[itemID_key isEqualToString:@"Yes"]) {
                        // 2.是否不通过
                        if (XInclusionRelationshipExists(resultString, @"<Result>No</Result>")) {
                            // 3.发送提示弹窗
                            [YGNetHttpRequestObject postNotificationToControllerForMessage:@"自动认证失败:安检未通过，您不能正常使用网络，请打开IMC客户端重新进行认证安检！"];
                        }
                    }
                    if (resultString.length > 0) {
                        [allResultString appendString:resultString];
                        [m_TID appendString:itemID_id];
                        if (i != items.count - 1) {
                            [allResultString appendString:@"###||###"];
                            [m_TID appendString:@"###||###"];
                        }
                    }
                }
            }
        }
    }
    *tID = m_TID;
    return allResultString;
}
@end
