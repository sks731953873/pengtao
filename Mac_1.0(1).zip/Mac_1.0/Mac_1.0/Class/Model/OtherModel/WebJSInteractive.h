//
//  WebJSInteractive.h
//  Mac_1.0
//
//  Created by xin on 2018/4/10.
//  Copyright © 2018年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>


@interface WebJSInteractive : NSObject
+ (void)webJSgetAboutInfo:(WKWebView *)webView;
+ (void)webJSgetUesrInfo:(WKWebView *)webView;
+ (void)webJSgetPolicyInfo:(WKWebView *)webView;
+ (void)webJSgetSupporInfo:(WKWebView *)webView;
+ (void)webJSgetWEBConfig:(NSString *)urlStr;
+ (void)webJSgetSystemInfo:(WKWebView *)webView withString:(NSString *)string;
+ (void)webJSgetInfoForWorktab:(WKWebView *)webView;
+ (void)webJSgetConfig:(WKWebView *)webView withString:(NSString *)string;
+ (void)webJSnativeCheckApp:(WKWebView *)webView withString:(NSString *)string;
+ (void)webJSgetMdmControlWithString:(NSString *)string;
+ (void)webJSnativeGetDeviceId:(WKWebView *)webView;
+ (void)webJSgetofflineInfo:(WKWebView *)webView;
+ (void)webJSgetOffLineAboutInfo:(WKWebView *)webView;
/** 跳转到系统wifi设置页面*/
+ (void)webJSsetNetCfg;
@end
