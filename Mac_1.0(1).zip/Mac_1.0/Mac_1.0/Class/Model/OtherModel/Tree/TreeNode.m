//
//  TreeNode.m
//  Mac_1.0
//
//  Created by xin on 2019/1/23.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "TreeNode.h"

@implementation TreeNode

//- (NSInteger)level {
//    return [self.levelString componentsSeparatedByString:@"."].count;
//}

- (NSInteger)DepartID {
    if (!_DepartID) {
        _DepartID = 0;
    }
    return _DepartID;
}
- (NSString *)levelString {
    if (!_levelString) {
        NSMutableString *mString = [NSMutableString string];
        for (int i = 0; i < self.level; i++) {
            [mString appendString:@"     "];
        }
        _levelString = [mString copy];
    }
    return _levelString;
}

- (BOOL)isLeaf {
    return self.subNodes.count == 0;
}

- (void)setSubNodes:(NSMutableArray *)subNodes {
    if (subNodes) {
        _subNodes = subNodes;
        for (TreeNode *node in _subNodes) {
            node.level = _level + 1;
        }
    }
}

- (void)setValue:(id)value forUndefinedKey:(nonnull NSString *)key {
    if ([value isKindOfClass:[NSArray class]]) {
        NSArray *valuArray = (NSArray *)value;
        for (int i = 0; i < valuArray.count; i ++) {
//            TreeNode *tree = [TreeNode modelWithDictionary:<#(NSDictionary *)#> levelString:<#(NSInteger)#> parent:<#(NSString *)#>]
        }
    }
}

+ (TreeNode *)modelWithDictionary:(NSDictionary *)dict levelString:(NSInteger)index parent:(NSString *)levelString {
    TreeNode *model = [[TreeNode alloc] init];
//    model.levelString = levelString != nil ? (levelString)
    return model;
}

+ (TreeNode *)ModelWithDictionary:(NSDictionary *)dict {
    TreeNode *node = nil;
    if (dict) {
        node = [[TreeNode alloc] init];
        node.name = dict[@"DepartName"];
        if (node.name.length < 1) {
            return nil;
        }
        node.DepartID = [dict[@"DepartID"] integerValue];
        node.UpID = [dict[@"UpID"] integerValue];
        node.OrderIndex = [dict[@"OrderIndex"] integerValue];
    }
    return node;
}

/** 将socket得到的部门信息整合成oc*/
+ (NSArray *)DealwithXMLDictionaryToArray:(NSDictionary *)xmlDict {
    NSMutableArray *array = [NSMutableArray array];
    id object = xmlDict[@"Depart"];
    if ([object isKindOfClass:[NSDictionary class]]) {
        NSDictionary *dict = object;
        TreeNode *node = [TreeNode ModelWithDictionary:dict];
        if (node)
        [array addObject:node];
    }else if ([object isKindOfClass:[NSArray class]]) {
        NSArray *Depart = (NSArray *)object;
        if (Depart.count > 0) {
            for (int i = 0; i < Depart.count; i++) {
                NSDictionary *dict = Depart[i];
                TreeNode *node = [TreeNode ModelWithDictionary:dict];
                if (node)
                [array addObject:node];
            }
        }
    }
    return array;
}
/** 将数组整理成TreeNode类*/
+ (NSArray *)DealwithDictionaryToArray:(NSDictionary *)xmldict {
    NSArray *array = [NSArray arrayWithArray:[TreeNode DealwithXMLDictionaryToArray:xmldict]];
    NSMutableArray *nodes = [NSMutableArray arrayWithArray:array];
    for (int i = 0; i < array.count; i++) {
        TreeNode *node1 = array[i];
        node1.subNodes = [NSMutableArray array];
        for (int j = 1; j < array.count; j++) {
            TreeNode *node2 = array[j];
            if (node1.DepartID == node2.UpID) {
                node2.level = node1.level + 1;
                [node1.subNodes addObject:node2];
                if ([nodes containsObject:node2]) {
                    [nodes removeObject:node2];
                }
            }
        }
    }
    return nodes;
}


- (NSArray *)needsDisplayNodes {
    return [self needsDisplayNodesOf:self];
}

- (NSArray *)needsDisplayNodesOf:(TreeNode *)ancestor {
    NSMutableArray *nodes = [NSMutableArray array];
    for (TreeNode *node in ancestor.subNodes) {
        [nodes addObject:node];
        if (node.isOpen) {
            [nodes addObjectsFromArray:[self needsDisplayNodesOf:node]];
        }
    }
    return nodes;
}


- (NSString *)description {
    return [NSString stringWithFormat:@"levelString:[%@] name:[%@]", _levelString, _name];
}
@end
