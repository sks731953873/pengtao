//
//  TreeNode.h
//  Mac_1.0
//
//  Created by xin on 2019/1/23.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface TreeNode : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, assign) NSInteger DepartID;
@property (nonatomic, assign) NSInteger UpID;
@property (nonatomic, assign) NSInteger OrderIndex;

@property (nonatomic, assign) BOOL isOpen;
@property (nonatomic, strong) NSMutableArray *subNodes;
@property (nonatomic, copy) NSString *levelString;
@property (nonatomic, assign) NSInteger level;
@property (nonatomic, assign) BOOL isLeaf;

- (NSArray *)needsDisplayNodes;
+ (NSArray *)DealwithDictionaryToArray:(NSDictionary *)xmldict;

/** 部门信息整合成oc*/
+ (NSArray *)DealwithXMLDictionaryToArray:(NSDictionary *)xmlDict;

@end


