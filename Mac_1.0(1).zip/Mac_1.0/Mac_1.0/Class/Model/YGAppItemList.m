//
//  YGItemList.m
//  Mac_1.0
//
//  Created by apple on 2016/12/26.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import "YGAppItemList.h"

@implementation YGAppItemList
@synthesize softName;
@synthesize remark;

- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.softName forKey:@"softName"];
    [encoder encodeObject:self.remark forKey:@"remark"];
}


- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.softName = [decoder decodeObjectForKey:@"softName"];
        self.remark = [decoder decodeObjectForKey:@"remark"];
    }
    return self;
}



+ (YGAppItemList *)list {
    return [[YGAppItemList alloc] init];
}


- (BOOL)isEqualToYGAppItemList:(YGAppItemList *)list{
    if (!self && !list) {
        return YES;
    }
    // 如果是完全相同的对象，就省去后面的判断
    if (self == list) return YES;
    // 如果object的类型不对，就不需要比较
    if (![list isKindOfClass:self.class]) return NO;
    
    // 对象类型,两个对象为nil时isEqual:的结果为0(NO),所以需要专门处理
    if (self.softName || list.softName) {
        if (![self.softName isEqualToString:list.softName]) return NO;
    }
    if (self.remark || list.remark) {
        if (![self.remark isEqualToString:list.remark]) return NO;
    }
    return YES;
}

// 重写
- (NSUInteger)hash
{
    return self.softName.hash + self.remark.hash;
}

- (BOOL)isEqual:(YGAppItemList *)object
{
    return [self isEqualToYGAppItemList:object];
}

@end
