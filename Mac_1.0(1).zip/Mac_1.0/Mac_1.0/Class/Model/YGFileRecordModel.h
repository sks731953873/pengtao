//
//  YGFileRecordModel.h
//  Mac_1.0
//
//  Created by apple on 2017/1/4.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YGFileRecordModel : NSObject<NSCoding>
/** File策略的AgentID*/
@property (nonatomic, copy) NSString *AgentID;
//????????????
@property (nonatomic, copy) NSString *Result;
/** File策略的ItemID*/
@property (nonatomic, copy) NSString *ItemID;
/** File策略下发时间*/
@property (nonatomic, copy) NSString *ItemTime;
///?????????????????
@property (nonatomic, assign) BOOL   IsEnable;
/** File监听文档更新*/
@property (nonatomic, assign) BOOL   IsUpdate;
/** File监听文档删除*/
@property (nonatomic, assign) BOOL   IsDelete;
/** File监听文档增加*/
@property (nonatomic, assign) BOOL   IsAdd;
//???????????
@property (nonatomic, assign) BOOL   SubDirectory;
/** YGFileItemList模型数组*/
@property (nonatomic, strong) NSArray  *ItemList;

/** 初始化*/
+ (YGFileRecordModel *)Model;

/** 比较两个YGAppItemList是否相同*/
- (BOOL)isEqualToYGFileRecordModel:(YGFileRecordModel *)list;
@end
