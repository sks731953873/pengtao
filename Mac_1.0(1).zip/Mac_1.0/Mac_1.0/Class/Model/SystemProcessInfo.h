//
//  SystemInfo.h
//  Mac_1.0
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SystemProcessInfo : NSObject
/**进程本地名称*/
@property (nonatomic, strong) NSString * processName;
/**进程id*/
@property (nonatomic, assign) long       processID;
/**com.xxx.xxx 进程名称 */
@property (nonatomic, strong) NSString * bundleID;
//
@property (nonatomic, strong) NSDate   * date;
@end
