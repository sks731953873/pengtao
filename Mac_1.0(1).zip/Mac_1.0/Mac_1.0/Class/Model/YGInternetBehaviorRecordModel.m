//
//  YGInternetBehaviorRecordModel.m
//  Mac_1.0
//
//  Created by apple on 2017/2/7.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import "YGInternetBehaviorRecordModel.h"
#import "YGInternetBehaviorItemList.h"
@implementation YGInternetBehaviorRecordModel
@synthesize IsEnable;
@synthesize IsCloseData;
@synthesize IsRecordLog;
@synthesize ItemList;

- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.ItemList forKey:@"ItemList"];
    [encoder encodeObject:[NSNumber numberWithBool:self.IsEnable] forKey:@"IsEnable"];
    [encoder encodeObject:[NSNumber numberWithBool:self.IsCloseData] forKey:@"IsCloseData"];
    [encoder encodeObject:[NSNumber numberWithBool:self.IsRecordLog] forKey:@"IsRecordLog"];
}

- (nullable instancetype)initWithCoder:(NSCoder *)deCoder{
    self = [super init];
    if (self) {
        self.ItemList = [deCoder decodeObjectForKey:@"ItemList"];
        self.IsEnable = [[deCoder decodeObjectForKey:@"IsEnable"] boolValue];
        self.IsCloseData = [[deCoder decodeObjectForKey:@"IsCloseData"] boolValue];
        self.IsRecordLog = [[deCoder decodeObjectForKey:@"IsRecordLog"] boolValue];
        
    }
    return self;
}

// 初始化
+ (YGInternetBehaviorRecordModel *)Model
{
    return [[YGInternetBehaviorRecordModel alloc] init];
}

- (BOOL)isEqualYGInternetBehaviorRecordModel:(YGInternetBehaviorRecordModel *)model
{
    if (!self && !model) {
        return YES;
    }
    // 如果是完全相同的对象，就省去后面的判断
    if (self == model) return YES;
    // 如果object的类型不对，就不需要比较
    if (![model isKindOfClass:self.class]) return NO;
    // 基本数据类型
    BOOL result = (self.IsEnable == model.IsEnable && self.IsCloseData == model.IsCloseData && self.IsRecordLog == model.IsRecordLog);
    if (!result) return result;
    // 两个数组内字段不同则不等（包括顺序）
    for (int i = 0; i < self.ItemList.count; i++) {
        YGInternetBehaviorItemList *ygItemList1 = self.ItemList[i];
        YGInternetBehaviorItemList *ygItemList2 = model.ItemList[i];
        BOOL itemListResult = [ygItemList1 isEqualToYGInternetBehaviorItemList:ygItemList2];
        if (!itemListResult && (ygItemList1 || ygItemList2)) {
            return itemListResult;
        }
    }
    return YES;
}

#pragma mark 重写
- (NSUInteger)hash
{
    return self.IsRecordLog + self.IsCloseData + self.IsEnable + self.ItemList.hash;
}

- (BOOL)isEqual:(id)object
{
    return [self isEqualYGInternetBehaviorRecordModel:object];
}

@end
