//
//  YGWifiItemList.h
//  Mac_1.0
//
//  Created by apple on 2016/12/28.
//  Copyright © 2016年 infogo. All rights reserved.
//wifi白名单 单个wifi信息

#import <Foundation/Foundation.h>

@interface YGWifiItemList : NSObject<NSCoding>
/** wifi名称*/
@property (nonatomic, copy) NSString *SSID;
/** wifi的bssid*/
@property (nonatomic, copy) NSString *APMac;
/** wifi的信息*/
@property (nonatomic, copy) NSString *Remark;
/** 初始化*/
+ (YGWifiItemList *)List;// 初始化

/** 比较两个YGWifiItemList是否相同*/
- (BOOL)isEqualToYGWifiItemList:(YGWifiItemList *)list;
@end
