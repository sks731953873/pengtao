//
//  YGItemList.h
//  Mac_1.0
//
//  Created by apple on 2016/12/26.
//  Copyright © 2016年 infogo. All rights reserved.
//黑白名单 下发的应用信息

#import <Foundation/Foundation.h>

@interface YGAppItemList : NSObject<NSCoding>

/** 软件名称*/
@property (nonatomic, copy)NSString * softName;
/** 软件信息*/
@property (nonatomic, copy)NSString * remark;

/**初始化*/
+ (YGAppItemList *)list;

/** 比较两个YGAppItemList是否相同*/
- (BOOL)isEqualToYGAppItemList:(YGAppItemList *)list;

@end
