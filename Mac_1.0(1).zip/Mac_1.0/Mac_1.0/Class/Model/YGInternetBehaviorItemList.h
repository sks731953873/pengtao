//
//  YGInternetBehaviorItemList.h
//  Mac_1.0
//
//  Created by apple on 2017/2/7.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YGInternetBehaviorItemList : NSObject<NSCoding>
/** 例外域名*/
@property (nonatomic, copy) NSString *DomainName;
/** 备注*/
@property (nonatomic, copy) NSString *Remark;
/** 违规外联时间*/
@property (nonatomic, copy) NSString *time;
/** 初始化*/
+ (YGInternetBehaviorItemList *)List;
/** 比较两个YGAppItemList是否相同*/
- (BOOL)isEqualToYGInternetBehaviorItemList:(YGInternetBehaviorItemList *)list;

@end
