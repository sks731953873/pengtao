//
//  ApplicationInfo.m
//  Mac_1.0
//
//  Created by apple on 2016/11/25.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import "ApplicationInfo.h"

@implementation ApplicationInfo
@synthesize ApplicationName;
@synthesize ApplicationPath;
@synthesize runningApplication;
@synthesize ApplicationProcessID;
@synthesize userName;
@synthesize bundleID;
@synthesize iconImage;
@synthesize createDate;
@synthesize removeTime;
@synthesize createTime;
@synthesize bundleVersion;



- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.ApplicationName forKey:@"ApplicationName"];
    [encoder encodeObject:self.ApplicationPath forKey:@"ApplicationPath"];
    [encoder encodeObject:self.runningApplication forKey:@"runningApplication"];
    [encoder encodeObject:self.ApplicationProcessID forKey:@"ApplicationProcessID"];
    [encoder encodeObject:self.userName forKey:@"pcuserName"];
    [encoder encodeObject:self.bundleID forKey:@"bundleID"];
    [encoder encodeObject:self.iconImage forKey:@"iconImage"];
    [encoder encodeObject:self.createDate forKey:@"createDate"];
    [encoder encodeObject:self.createTime forKey:@"createTime"];
    [encoder encodeObject:self.removeTime forKey:@"removeTime"];
    [encoder encodeObject:self.bundleVersion forKey:@"bundleVersion"];
}

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.ApplicationName = [decoder decodeObjectForKey:@"ApplicationName"];
        self.ApplicationPath = [decoder decodeObjectForKey:@"ApplicationPath"];
        self.runningApplication = [decoder decodeObjectForKey:@"runningApplication"];
        self.ApplicationProcessID = [decoder decodeObjectForKey:@"ApplicationProcessID"];
        self.userName = [decoder decodeObjectForKey:@"pcuserName"];
        self.bundleID = [decoder decodeObjectForKey:@"bundleID"];
        self.iconImage = [decoder decodeObjectForKey:@"iconImage"];
        self.createDate = [decoder decodeObjectForKey:@"createDate"];
        self.createTime = [decoder decodeObjectForKey:@"createTime"];
        self.removeTime = [decoder decodeObjectForKey:@"removeTime"];
        self.bundleVersion = [decoder decodeObjectForKey:@"bundleVersion"];
    }
    return self;
}

@end
