//
//  YGPolicyTaskModel.m
//  Mac_1.0
//
//  Created by Xin on 2017/6/14.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import "YGPolicyTaskModel.h"

@implementation YGPolicyTaskModel

- (void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.SoftName forKey:@"ygSoftName"];
    [aCoder encodeObject:self.TaskID forKey:@"ygTaskID"];
    [aCoder encodeObject:self.SoftUrl forKey:@"ygSoftUrl"];
    [aCoder encodeObject:self.Package forKey:@"ygPackage"];
    [aCoder encodeObject:self.SavePath forKey:@"ygSavePath"];
    [aCoder encodeObject:self.IsRun forKey:@"ygIsRun"];
    [aCoder encodeObject:self.SourceFile forKey:@"ygSourceFile"];
    [aCoder encodeObject:self.SuccessOption forKey:@"ygSuccessOption"];
    [aCoder encodeObject:self.PauseTime forKey:@"ygPauseTime"];
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    if (self) {
        self.SoftName = [aDecoder decodeObjectForKey:@"ygSoftName"];
        self.TaskID = [aDecoder decodeObjectForKey:@"ygTaskID"];
        self.SoftUrl = [aDecoder decodeObjectForKey:@"ygSoftUrl"];
        self.Package = [aDecoder decodeObjectForKey:@"ygPackage"];
        self.SavePath = [aDecoder decodeObjectForKey:@"ygSavePath"];
        self.IsRun = [aDecoder decodeObjectForKey:@"ygIsRun"];
        self.SourceFile = [aDecoder decodeObjectForKey:@"ygSourceFile"];
        self.SuccessOption = [aDecoder decodeObjectForKey:@"ygSuccessOption"];
        self.PauseTime = [aDecoder decodeObjectForKey:@"ygPauseTime"];
    }
    return self;
}


+ (YGPolicyTaskModel *)model {
    return [[YGPolicyTaskModel alloc] init];
}
@end
