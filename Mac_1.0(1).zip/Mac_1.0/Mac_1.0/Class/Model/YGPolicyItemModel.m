//
//  YGPolicyItemModel.m
//  Mac_1.0
//
//  Created by apple on 2016/12/23.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import "YGPolicyItemModel.h"


@implementation YGPolicyItemModel

@synthesize itemId;
@synthesize itemIndexOf;
@synthesize name;
@synthesize time;

- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.itemId forKey:@"itemId"];
    [encoder encodeObject:self.itemIndexOf forKey:@"itemIndexOf"];
    [encoder encodeObject:self.name forKey:@"name"];
    [encoder encodeObject:self.time forKey:@"time"];
}

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.itemId = [decoder decodeObjectForKey:@"itemId"];
        self.itemIndexOf = [decoder decodeObjectForKey:@"itemIndexOf"];
        self.name = [decoder decodeObjectForKey:@"name"];
        self.time = [decoder decodeObjectForKey:@"time"];
    }
    return self;
}

+ (YGPolicyItemModel *)modelWithDictionary:(NSDictionary *)item {
    YGPolicyItemModel *ygPolicyItem = [[YGPolicyItemModel alloc] init];
    ygPolicyItem.itemId = item[@"ItemID"];
    if (ygPolicyItem.itemId.length < 1) {
        return nil;
    }
    NSString *name = item[@"Name"];
    if (!([name isEqualToString:YGMP_WiFi]||
          [name isEqualToString:YGMP_Application] ||
          [name isEqualToString:YGMP_UsbPlugAudit]||
          [name isEqualToString:YGMP_UsbDeviceCtrl])) {
        return nil;
    }
    ygPolicyItem.name = name;
    ygPolicyItem.itemIndexOf = item[@"ItemIndexOf"];
    ygPolicyItem.time = item[@"Time"];
    return ygPolicyItem;
}
@end
