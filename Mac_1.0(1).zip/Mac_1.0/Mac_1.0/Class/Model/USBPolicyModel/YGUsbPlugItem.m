//
//  YGUsbPlugItem.m
//  Mac_1.0
//
//  Created by xin on 2019/1/27.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "YGUsbPlugItem.h"

@implementation YGUsbPlugItem


- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.Group forKey:@"Group"];
    [encoder encodeObject:self.NameValue forKey:@"NameValue"];
    [encoder encodeObject:self.ID forKey:@"ID"];
    [encoder encodeObject:[NSNumber numberWithInteger:self.usbPlugType] forKey:@"usbPlugType"];
    [encoder encodeObject:self.usbClass forKey:@"usbClass"];
}

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.NameValue = [decoder decodeObjectForKey:@"NameValue"];
        self.ID = [decoder decodeObjectForKey:@"ID"];
        self.usbPlugType = [[decoder decodeObjectForKey:@"usbPlugType"] integerValue];
        self.usbClass = [decoder decodeObjectForKey:@"usbClass"];
        self.Group = [decoder decodeObjectForKey:@"Group"];
    }
    return self;
}

+ (YGUsbPlugItem *)USBPlugItemWithDict:(NSDictionary *)dict {
    YGUsbPlugItem *pItem = [[YGUsbPlugItem alloc] init];
    pItem.Group = dict[@"Group"];
    pItem.NameValue = dict[@"NameValue"];
    pItem.ID = dict[@"ID"]?dict[@"ID"]:@"";
    return pItem;
}

- (void)setGroup:(NSString *)Group {
    if (Group) {
        _Group = Group;
        [self setUsbPlugTypeWithIDString:Group];
    }
}

- (void)setUsbPlugTypeWithIDString:(NSString *)ID {
    if (!ID) {
        return;
    }
    if ([ID isEqualToString:@"All"]) {
        self.usbPlugType = UsbPlugTypeAllOfUsb;
    }else if ([ID isEqualToString:@"Reg"]) {
        self.usbPlugType = UsbPlugTypeRegistered;
    }else if ([ID isEqualToString:@"UnReg"]) {
        self.usbPlugType = UsbPlugTypeUnregistered;
    }else if ([ID isEqualToString:@"Class"]) {
        self.usbPlugType = UsbPlugTypeUSBClass;
    }else if ([ID isEqualToString:@"UnClass"]) {
        self.usbPlugType = UsbPlugTypeUSBUnClass;
    } else if ([ID isEqualToString:@"Usb"]) {
        self.usbPlugType = UsbPlugTypeDesignationUsb;
    }
    else{
        if (ID.length > 0) {
            self.usbPlugType = UsbPlugTypeDesignationUsb;// 指定的某个USB
//            self.ID = ID;
        }
    }
}

/** isCoincidence
 是否符合该策略项
 @return 返回1是符合 返回0是不符合 返回2是不在这条里面
 */
- (NSInteger)isCoincidenceWithUSBModel:(USBModel *)model  {
    USBModel *current_model = [model qunueSelectFromUsbTableWithModel:model];
    switch (self.usbPlugType) {
        case UsbPlugTypeUnKnow: {
            // 不知道类型  首先就是说明不是USB存储设备
            if ([current_model.type isEqualToString:@"UN08100000"])
                return 1;
            return 0;
        }
        case UsbPlugTypeAllOfUsb: {
            // 所有usb那么就是什么类型的都符合
            return 1;
        }
        case UsbPlugTypeRegistered: {
            if (current_model.registered == 1) {
                if (current_model.bsd_name.length > 0) {
                    return 1;
                }
                return 2;
            }
            return 0;
        }
        case UsbPlugTypeUnregistered: {
            if (current_model.registered == 0) {
                if (current_model.bsd_name.length > 0) {
                    return 1;
                }
                return 2;
            }
            return 0;
        }
        case UsbPlugTypeDesignationUsb: {
            // usb的唯一标识  等于  ID
            if ([self.ID rangeOfString:current_model.locationID].location != NSNotFound)
                return 1;
            return 0;
        }
            case UsbPlugTypeUSBClass: {
                // 这里的self.id 就是 self.usbclass
                if ([self.ID isEqualToString:current_model.type])
                    return 1;
                return 0;
            }
        case UsbPlugTypeUSBUnClass: {
            if (![current_model.type isEqualToString:@"CR08065000"])
                return 1; // 只要不是存储设备都是未知类型
            return 0;
        }
    }
    return 2;
}
@end
