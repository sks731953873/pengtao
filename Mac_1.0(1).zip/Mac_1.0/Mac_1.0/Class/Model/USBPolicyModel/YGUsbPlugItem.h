//
//  YGUsbPlugItem.h
//  Mac_1.0
//
//  Created by xin on 2019/1/27.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "USBModel.h"

typedef NS_ENUM(NSInteger){
    UsbPlugTypeUnKnow, // 备用
    UsbPlugTypeAllOfUsb, // 全部usb设备
    UsbPlugTypeRegistered,// 已注册的USB
    UsbPlugTypeUnregistered, // 未注册的USB
    UsbPlugTypeDesignationUsb, // 指定的某个usb
    UsbPlugTypeUSBClass, // 某种USB类型
    UsbPlugTypeUSBUnClass // 未知的USB类型
} UsbPlugType;

@interface YGUsbPlugItem : NSObject

@property (nonatomic, copy) NSString *Group;
@property (nonatomic, copy) NSString *NameValue;
@property (nonatomic, copy) NSString *ID;
@property (nonatomic, assign) UsbPlugType usbPlugType;
@property (nonatomic, copy) NSString *usbClass;

+ (YGUsbPlugItem *)USBPlugItemWithDict:(NSDictionary *)dict;

/** isCoincidence
 是否符合该策略项
 @return 返回1是符合 返回0是不符合 返回2是不在这条里面
 */
- (NSInteger)isCoincidenceWithUSBModel:(USBModel *)model;
@end


