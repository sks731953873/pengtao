//
//  YGUSBDeviceModel.h
//  Mac_1.0
//
//  Created by xin on 2019/3/10.
//  Copyright © 2019 infogo. All rights reserved.
//
// 用来存储socket报文获取usb信息的表
#import <Foundation/Foundation.h>



@interface YGUSBDeviceModel : NSObject

@property (nonatomic, assign) NSInteger identify;
/** 设备唯一标识*/
@property (nonatomic, copy)   NSString *USBID;
/** 流水号*/
@property (nonatomic, assign) NSInteger serial;


+ (YGUSBDeviceModel *)model;
/**在数据库中创建USBDeviceTable表*/
- (void)qunueCreateUSBDeviceTable;

/** USBDeviceTable表插入完整数据*/
- (void)qunueInsertUSBDeviceTable;

- (NSArray *)qunueSelectFromUSBDeviceTable;

// 通过唯一标识查找model
- (YGUSBDeviceModel *)qunueSelectFromUSBDeviceTableWithUsbID:(NSString *)usbID;
// 通过流水号查找model
- (YGUSBDeviceModel *)qunueSelectFromUSBDeviceTableWithSerial:(NSInteger)serial;

- (void)qunueDeleteUSBDeviceTable:(NSInteger)serial;
@end


