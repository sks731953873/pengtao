//
//  YGUsbDeviceItem.m
//  Mac_1.0
//
//  Created by xin on 2019/1/27.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "YGUsbDeviceItem.h"
const NSArray *___Gender;
// 创建初始化函数。等于用宏创建一个getter函数
#define cGenderGet (___Gender == nil ? ___Gender = [[NSArray alloc] initWithObjects:\
@"UsbDeviceTypeUnKnow",\
@"UsbDeviceTypeAllOfUsb",\
@"UsbDeviceTypeRegistered",\
@"UsbDeviceTypeUnregistered",\
@"UsbDeviceTypeDesignationUsb",\
@"UsbDeviceTypeUSBClass",\
@"UsbDeviceTypeUSBUnClass", nil] : ___Gender)
// 枚举 to 字串
#define KGenderString(type) ([cGenderGet objectAtIndex:type])
// 字串 to 枚举
#define KGenderEnum(string) ([cGenderGet indexOfObject:string])


@implementation YGUsbDeviceItem

//@property (nonatomic, copy) NSString *Group;
//@property (nonatomic, assign) NSInteger ID;
///** 需要管控的USB类型*/
//@property (nonatomic, assign) UsbDeviceType usbDeviceType;
//
///** 如果是有type是指定USBClass的就还有一个属性指向USB 的类型 如CR08065000*/
//@property (nonatomic, copy) NSString *usbClass;
//
//@property (nonatomic, copy) NSString *NameValue;
///** 管控级别  1允许 2禁止*/
//@property (nonatomic, assign) NSInteger Rule;
- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.Group forKey:@"Group"];
    [encoder encodeObject:self.NameValue forKey:@"NameValue"];
    [encoder encodeObject:self.ID forKey:@"ID"];
    [encoder encodeObject:[NSNumber numberWithInteger:self.usbDeviceType] forKey:@"usbDeviceType"];
    [encoder encodeObject:self.usbClass forKey:@"usbClass"];
    [encoder encodeObject:[NSNumber numberWithInteger:self.Rule] forKey:@"Rule"] ;
}

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.NameValue = [decoder decodeObjectForKey:@"NameValue"];
        self.ID = [decoder decodeObjectForKey:@"ID"];
        self.usbDeviceType = [[decoder decodeObjectForKey:@"usbDeviceType"] integerValue];
        self.usbClass = [decoder decodeObjectForKey:@"usbClass"];
        self.Rule = [[decoder decodeObjectForKey:@"Rule"] integerValue];
        self.Group = [decoder decodeObjectForKey:@"Group"];

    }
    return self;
}

+ (YGUsbDeviceItem *)USBDeviceItemWithDict:(NSDictionary *)dict {
    YGUsbDeviceItem *dItem = [[YGUsbDeviceItem alloc] init];
    dItem.Group = dict[@"Group"];
    if (dItem.usbDeviceType == UsbDeviceTypeDesignationUsb) {
        dItem.ID = dict[@"ID"];
    } else if (dItem.usbDeviceType == UsbDeviceTypeUSBClass) {
        dItem.usbClass = dict[@"ID"];
    }
    dItem.NameValue = dict[@"NameValue"];
    [dItem setRuleWithRuleString:dict[@"Rule"]];
    return dItem;
}

- (void)setGroup:(NSString *)Group {
    if (Group) {
        _Group = Group;
        [self setUsbDeviceTypeWithIDString:Group];
    }
}

- (void)setUsbDeviceTypeWithIDString:(NSString *)ID {
    if (!ID) {
        return;
    }
    if ([ID isEqualToString:@"All"]) {
        self.usbDeviceType = UsbDeviceTypeAllOfUsb;
    }else if ([ID isEqualToString:@"Reg"]) {
        self.usbDeviceType = UsbDeviceTypeRegistered;
    }else if ([ID isEqualToString:@"UnReg"]) {
        self.usbDeviceType = UsbDeviceTypeUnregistered;
    }else if ([ID isEqualToString:@"Class"]) {
        self.usbDeviceType = UsbDeviceTypeUSBClass;
    }else if ([ID isEqualToString:@"UnClass"]) {
        self.usbDeviceType = UsbDeviceTypeUSBUnClass;
    } else if ([ID isEqualToString:@"Usb"]) {
        self.usbDeviceType = UsbDeviceTypeDesignationUsb;
    }
    else{
        if (ID.length> 0) {
            self.usbDeviceType = UsbDeviceTypeDesignationUsb;// 指定的某个USB
            self.ID = ID;
        }
    }
}

- (void)setRuleWithRuleString:(NSString *)rule {
    if (!rule) {
        return;
    }
    // 放开
    if  ([rule isEqualToString:@"Allow"]) {
        self.Rule = 1;
    }
    // 禁止
    else if ([rule isEqualToString:@"Deny"]) {
        self.Rule = 2;
    }
}
/** isCoincidence
    是否符合该策略项
 @return 返回1是符合 返回0是不符合 返回2是不在这条里面
 */
- (NSInteger)isCoincidenceWithUSBModel:(USBModel *)model  {
    USBModel *current_model = [model qunueSelectFromUsbTableWithModel:model];
//    NSInteger num = 0;
    switch (self.usbDeviceType) {
        case UsbDeviceTypeUnKnow: {
            // 不知道类型  首先就是说明不是USB存储设备  不在管控区间
            return 2;
        }
        case UsbDeviceTypeAllOfUsb: {
            // 所有usb那么就是什么类型的都符合
            return 1;
        }
        case UsbDeviceTypeRegistered: {
            // 怎么知道是否注册了呢
            if (current_model.registered == 1)
                return 1;
            break;
        }
        case UsbDeviceTypeUnregistered: {
            if (current_model.registered == 0)
                return 1;
            break;
        }
        case UsbDeviceTypeDesignationUsb: {
            // usb的唯一标识  等于  ID
            if ([self.ID rangeOfString:current_model.locationID].location != NSNotFound)
                return 1;
            return 2;
        }
        case UsbDeviceTypeUSBClass: {
            if ([self.usbClass isEqualToString:current_model.type])
                return 1;
            return 2;
        }
        case UsbDeviceTypeUSBUnClass: {
            if (![current_model.type isEqualToString:@"CR08065000"]) 
                return 1; // 只要不是存储设备，该设备就是未知类型
            return 2;
        }
    }
    return 0;
}



- (NSString *)description {
    return [NSString stringWithFormat:@"\n <%@>\n{\n  Group = [%@]\n  ID = [%@]\n  usbDeviceType = [%@]\n  NameValue = [%@]\n  usbClass = [%@]\n  Rule = [%@]\n}\n",
            [self class],
            _Group,
            _ID,
            KGenderString(_usbDeviceType),
            _NameValue,
            self.usbClass,
            @(_Rule)];
}
@end
