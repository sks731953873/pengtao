//
//  YGPolicyUsbDeviceCtrlModel.m
//  Mac_1.0
//
//  Created by xin on 2019/1/27.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "YGPolicyUsbDeviceCtrlModel.h"

@implementation YGPolicyUsbDeviceCtrlModel

//@property (nonatomic, assign) NSInteger AgentID;
//@property (nonatomic, strong) NSMutableArray *Body;
//@property (nonatomic, assign) NSInteger ItemID;
//@property (nonatomic, copy) NSString *ItemName;
//@property (nonatomic, copy) NSString *ItemTime;
//@property (nonatomic, assign) NSInteger Result;
- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:[NSNumber numberWithInteger:self.AgentID] forKey:@"AgentID"];
    [encoder encodeObject:self.Body forKey:@"Body"];
    [encoder encodeObject:[NSNumber numberWithInteger:self.ItemID] forKey:@"ItemID"];
    [encoder encodeObject:[NSNumber numberWithInteger:self.Result] forKey:@"Result"];
    [encoder encodeObject:self.ItemName forKey:@"ItemName"];
    [encoder encodeObject:self.ItemTime forKey:@"ItemTime"] ;
}

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.AgentID = [[decoder decodeObjectForKey:@"AgentID"] integerValue];
        self.Body = [decoder decodeObjectForKey:@"Body"];
        self.ItemID = [[decoder decodeObjectForKey:@"ItemID"] integerValue];
        self.Result = [[decoder decodeObjectForKey:@"Result"] integerValue];
        self.ItemName = [decoder decodeObjectForKey:@"ItemName"];
        self.ItemTime = [decoder decodeObjectForKey:@"ItemTime"];
    }
    return self;
}
- (NSMutableArray *)Body {
    if (!_Body) {
        _Body = [NSMutableArray array];
    }
    return _Body;
}


- (NSString *)description {
    return [NSString stringWithFormat:@"\n <%@>\n{\n  AgentID = [%@]\n  ItemID = [%@]\n  ItemName = [%@]\n  ItemTime = [%@]\n  Result = [%@]\n  Body = [%@]\n}\n",
            [self class],
            @(_AgentID),
            @(_ItemID),
            _ItemName,
            _ItemTime,
            @(_Result),
            _Body];
}
@end
