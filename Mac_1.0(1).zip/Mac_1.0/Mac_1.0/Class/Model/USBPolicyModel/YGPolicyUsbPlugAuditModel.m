//
//  YGPolicyUsbPlugAuditModel.m
//  Mac_1.0
//
//  Created by xin on 2019/1/27.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "YGPolicyUsbPlugAuditModel.h"

@implementation YGPolicyUsbPlugAuditModel

//@property (nonatomic, assign) NSInteger AgentID;
//@property (nonatomic, assign) NSInteger ItemID;
//@property (nonatomic, copy) NSString *ItemName;
//@property (nonatomic, copy) NSString *ItemTime;
//@property (nonatomic, strong) NSMutableArray *Body;

- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:[NSNumber numberWithInteger:self.AgentID] forKey:@"AgentID"];
    [encoder encodeObject:self.Body forKey:@"Body"];
    [encoder encodeObject:[NSNumber numberWithInteger:self.ItemID] forKey:@"ItemID"];
    [encoder encodeObject:self.ItemName forKey:@"ItemName"];
    [encoder encodeObject:self.ItemTime forKey:@"ItemTime"] ;
}

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.AgentID = [[decoder decodeObjectForKey:@"AgentID"] integerValue];
        self.Body = [decoder decodeObjectForKey:@"Body"];
        self.ItemID = [[decoder decodeObjectForKey:@"ItemID"] integerValue];
        self.ItemName = [decoder decodeObjectForKey:@"ItemName"];
        self.ItemTime = [decoder decodeObjectForKey:@"ItemTime"];
    }
    return self;
}

- (NSMutableArray *)Body {
    if (!_Body) {
        _Body = [NSMutableArray array];
    }
    return _Body;
}

- (BOOL)isCoincidenceBodyWithUSBModel:(USBModel *)usb_model {
    if (self.Body.count < 1)
        return NO;
    for (YGUsbPlugItem *item in self.Body) {
        switch ([item isCoincidenceWithUSBModel:usb_model]) {
            case 0: {
                continue;
            }
            case 1: {
                return YES;
            }
            case 2: {
                continue;
            }
        }
    }
    return NO;
}

- (NSString *)description {
    return [NSString stringWithFormat:@"\n <%@>\n{\n  AgentID = [%@]\n  ItemID = [%@]\n  ItemName = [%@]\n  ItemTime = [%@]\n  Body = [%@]\n}\n",
            [self class],
            @(_AgentID),
            @(_ItemID),
            _ItemName,
            _ItemTime,
            _Body];
}
@end
