//
//  YGPolicyUsbPlugAuditModel.h
//  Mac_1.0
//
//  Created by xin on 2019/1/27.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YGUsbPlugItem.h"


@interface YGPolicyUsbPlugAuditModel : NSObject

@property (nonatomic, assign) NSInteger AgentID;
@property (nonatomic, assign) NSInteger ItemID;
@property (nonatomic, copy) NSString *ItemName;
@property (nonatomic, copy) NSString *ItemTime;
@property (nonatomic, strong) NSMutableArray *Body;
/** 是否需要进行USB插拔上报*/
- (BOOL)isCoincidenceBodyWithUSBModel:(USBModel *)usb_model;
@end


