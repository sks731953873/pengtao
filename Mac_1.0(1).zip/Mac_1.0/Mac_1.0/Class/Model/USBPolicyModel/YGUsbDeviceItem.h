//
//  YGUsbDeviceItem.h
//  Mac_1.0
//
//  Created by xin on 2019/1/27.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "USBModel.h"

typedef NS_ENUM(NSInteger){
    UsbDeviceTypeUnKnow, // 备用
    UsbDeviceTypeAllOfUsb, // 全部usb设备
    UsbDeviceTypeRegistered,// 已注册的USB
    UsbDeviceTypeUnregistered, // 未注册的USB
    UsbDeviceTypeDesignationUsb, // 指定的某个usb
    UsbDeviceTypeUSBClass, // 某种USB类型
    UsbDeviceTypeUSBUnClass // 未知的USB类型
} UsbDeviceType;

@interface YGUsbDeviceItem : NSObject

@property (nonatomic, copy) NSString *Group;
@property (nonatomic, copy) NSString *ID;
/** 需要管控的USB类型*/
@property (nonatomic, assign) UsbDeviceType usbDeviceType;

/** 如果是有type是指定USBClass的就还有一个属性指向USB 的类型 如CR08065000*/
@property (nonatomic, copy) NSString *usbClass;

@property (nonatomic, copy) NSString *NameValue;
/** 管控级别  1允许 2禁止*/
@property (nonatomic, assign) NSInteger Rule;
+ (YGUsbDeviceItem *)USBDeviceItemWithDict:(NSDictionary *)dict;
- (void)setUsbDeviceTypeWithIDString:(NSString *)ID;
- (void)setRuleWithRuleString:(NSString *)rule;
- (NSInteger)isCoincidenceWithUSBModel:(USBModel *)model;

@end


