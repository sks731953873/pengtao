//
//  YGUSBDeviceModel.m
//  Mac_1.0
//
//  Created by xin on 2019/3/10.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "YGUSBDeviceModel.h"
#import "YGDataBase.h"


@interface YGUSBDeviceModel ()

@property (nonatomic, strong) YGDataBase *db;

@end

@implementation YGUSBDeviceModel

- (YGDataBase *)db {
    if (!_db) {
        _db = [YGDataBase shareFMDataBase];
    }
    return _db;
}

+ (YGUSBDeviceModel *)model {
    return [[YGUSBDeviceModel alloc] init];
}

#pragma mark fmdb
/**
 在数据库中创建USBDeviceTable表
 */
- (void)qunueCreateUSBDeviceTable {
    NSString *createString = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS USBDeviceTable(identify INTEGER PRIMARY KEY AUTOINCREMENT, USBID TEXT, serial INTEGER)"];
    if (self.db.queue) {
        [self.db.queue inDatabase:^(FMDatabase *db) {
            BOOL b = [db executeUpdate:createString];
            if (!b)
                HXINFOLOG(@"create USBDeviceTable is %@", b? @"success": @"faild");
        }];
    }
}

/** USBDeviceTable表插入完整数据*/
- (void)qunueInsertUSBDeviceTable {
    [self qunueCreateUSBDeviceTable];
    [self.db.queue inDatabase:^(FMDatabase *db) {
        BOOL insert = [db executeUpdate:@"INSERT INTO USBDeviceTable (USBID,serial) VALUES (?,?)",
                       self.USBID,
                       [NSNumber numberWithInteger:self.serial]];
        if (insert) {
            HXINFOLOG(@"FMDB 添加成员成功!!![%@]", self);
        }else{
            HXINFOLOG(@"FMDB 添加成员失败~~~");
        }
    }];
}

- (NSArray *)qunueSelectFromUSBDeviceTable {
    if (![self.db isHasTable:@"USBDeviceTable"]) {
        return nil;
    }
    __block NSMutableArray *array = [NSMutableArray array];
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM USBDeviceTable"];
    [_db.queue inDatabase:^(FMDatabase *db) {
        FMResultSet *result = [db executeQuery:sql];
        while ([result next]) {
            YGUSBDeviceModel *model = [YGUSBDeviceModel model];
            model.identify = [result intForColumn:@"identify"];
            model.USBID = [result stringForColumn:@"USBID"];
            model.serial = [result intForColumn:@"serial"];
            [array addObject:model];
        }
    }];
    return array;
}

// 通过唯一标识查找model
- (YGUSBDeviceModel *)qunueSelectFromUSBDeviceTableWithUsbID:(NSString *)usbID {
    if (![self.db isHasTable:@"USBDeviceTable"]) {
        return nil;
    }
    __block YGUSBDeviceModel *usbModel = nil;
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM USBDeviceTable where USBID = '%@'", usbID];
    [_db.queue inDatabase:^(FMDatabase *db) {
        FMResultSet *result = [db executeQuery:sql];
        while ([result next]) {
            usbModel = [YGUSBDeviceModel model];
            usbModel.identify = [result intForColumn:@"identify"];
            usbModel.USBID = [result stringForColumn:@"USBID"];
            usbModel.serial = [result intForColumn:@"serial"];
        }
    }];
    return usbModel;
}
// 通过流水号查找model
- (YGUSBDeviceModel *)qunueSelectFromUSBDeviceTableWithSerial:(NSInteger)serial {
    if (![self.db isHasTable:@"USBDeviceTable"]) {
        return nil;
    }
    __block YGUSBDeviceModel *usbModel = nil;
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM USBDeviceTable where serial = '%@'", @(serial)];
    [_db.queue inDatabase:^(FMDatabase *db) {
        FMResultSet *result = [db executeQuery:sql];
        while ([result next]) {
            usbModel = [YGUSBDeviceModel model];
            usbModel.identify = [result intForColumn:@"identify"];
            usbModel.USBID = [result stringForColumn:@"USBID"];
            usbModel.serial = [result intForColumn:@"serial"];
        }
    }];
    return usbModel;
}

- (void)qunueDeleteUSBDeviceTable:(NSInteger)serial{
    [self.db.queue inDatabase:^(FMDatabase *db) {
        if ([db executeUpdate:@"DELETE FROM USBDeviceTable WHERE serial = ?", @(serial)]){
            HXINFOLOG(@"Delete [%ld] success", serial);
        }else{
            HXINFOLOG(@"Delete [%ld] faild", serial);
        }
    }];
}

- (NSString *)description {
    return [NSString stringWithFormat:@"\n <%@>\n{\n  identity = [%@]\n  USBID = [%@]\n  serial = [%@]\n}\n ",
            [self class],
            @(_identify),
            _USBID,
            @(_serial)];
}


@end
