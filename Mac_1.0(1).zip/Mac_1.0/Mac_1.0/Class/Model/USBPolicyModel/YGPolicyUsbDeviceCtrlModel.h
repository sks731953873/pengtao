//
//  YGPolicyUsbDeviceCtrlModel.h
//  Mac_1.0
//
//  Created by xin on 2019/1/27.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YGUsbDeviceItem.h"


@interface YGPolicyUsbDeviceCtrlModel : NSObject
@property (nonatomic, assign) NSInteger AgentID;
@property (nonatomic, strong) NSMutableArray *Body;
@property (nonatomic, assign) NSInteger ItemID;
@property (nonatomic, copy) NSString *ItemName;
@property (nonatomic, copy) NSString *ItemTime;
@property (nonatomic, assign) NSInteger Result;
@end


