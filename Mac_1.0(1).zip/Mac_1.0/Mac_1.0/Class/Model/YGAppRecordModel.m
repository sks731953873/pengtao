//
//  YGAppRecordModel.m
//  Mac_1.0
//
//  Created by apple on 2016/12/26.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import "YGAppRecordModel.h"
#import "YGAppItemList.h"

@implementation YGAppRecordModel

- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:[NSNumber numberWithInteger:self.policyType] forKey:@"policyType"];
    [encoder encodeObject:self.ItemList forKey:@"ItemList"];
    [encoder encodeObject:[NSNumber numberWithInt:self.lockTime] forKey:@"lockTime"];
    [encoder encodeObject:[NSNumber numberWithBool:self.isLock] forKey:@"isLock"];
    [encoder encodeObject:[NSNumber numberWithBool:self.isOutNet] forKey:@"isOutNet"];
    [encoder encodeObject:[NSNumber numberWithBool:self.isRecord] forKey:@"isRecord"];
    [encoder encodeObject:self.ItemTime forKey:@"ItemTime"];
}

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.policyType = [[decoder decodeObjectForKey:@"policyType"] integerValue];
        self.ItemList = [decoder decodeObjectForKey:@"ItemList"];
        self.lockTime = [[decoder decodeObjectForKey:@"lockTime"] intValue];
        self.isLock = [[decoder decodeObjectForKey:@"isLock"] boolValue];
        self.isOutNet = [[decoder decodeObjectForKey:@"isOutNet"] boolValue];
        self.isRecord = [[decoder decodeObjectForKey:@"isRecord"] boolValue];
        self.ItemTime = [decoder decodeObjectForKey:@"ItemTime"];
    }
    return self;
}


+ (YGAppRecordModel *)Model{
    return [[YGAppRecordModel alloc] init];
}

- (BOOL)isEqualToYGAppRecordModel:(YGAppRecordModel *)recordModel
{
    if (!self && !recordModel){
        return YES;
    }
    // 如果是完全相同的对象，就省去后面的判断
    if (self == recordModel) return YES;
    
    // 如果object的类型不对，就不需要比较
    if (![recordModel isKindOfClass:self.class]) return NO;
    
    // 基本数据类型
    BOOL result = (self.policyType == recordModel.policyType && self.lockTime == recordModel.lockTime && self.isRecord == recordModel.isRecord && self.isLock == recordModel.isLock && self.isOutNet == recordModel.isOutNet);
    if (!result) return result;
    
    BOOL listCountEqual = (self.ItemList.count == recordModel.ItemList.count);
    if (![self.ItemTime isEqualToString:recordModel.ItemTime]) {
        return NO;
    }
    // 两个数组个数不等 既内容不等
    if (!listCountEqual) return listCountEqual;
    // 两个数组内字段不同则不等（包括顺序）
    for (int i = 0; i < self.ItemList.count; i++) {
        YGAppItemList *ygApp1 = self.ItemList[i];
        YGAppItemList *ygApp2 = recordModel.ItemList[i];
        BOOL itemListResult = [ygApp1 isEqualToYGAppItemList:ygApp2];
        if (!itemListResult && (ygApp1 || ygApp2)) {
            return itemListResult;
        }
    }
    
    return YES;
}

- (NSUInteger)hash
{
    return self.policyType + self.ItemList.hash + self.lockTime + self.isLock + self.isOutNet + self.isRecord;
}

- (BOOL)isEqual:(YGAppRecordModel *)object
{
    return [self isEqualToYGAppRecordModel:object];
}

@end
