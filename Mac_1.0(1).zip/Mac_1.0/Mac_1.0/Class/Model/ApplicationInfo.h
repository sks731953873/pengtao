//
//  ApplicationInfo.h
//  Mac_1.0
//
//  Created by apple on 2016/11/25.
//  Copyright © 2016年 infogo. All rights reserved.
//
//  运行软件类
#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>
@interface ApplicationInfo : NSObject<NSCoding>
/**进程本地名称*/
@property (nonatomic, copy) NSString              * ApplicationName;
/**进程id*/
@property (nonatomic, copy) NSString              * ApplicationProcessID;
/**com.xxx.xxx  进程名称 */
@property (nonatomic, copy) NSString              * bundleID;
/**应用路径*/
@property (nonatomic, copy) NSString              * ApplicationPath;
/** 进程信息*/
@property (nonatomic, strong) NSRunningApplication  * runningApplication;
/**安装日期*/
@property (nonatomic, copy) NSString              * createDate;
/**应用使用者*/
@property (nonatomic, copy) NSString              * userName;
/**应用icon*/
@property (nonatomic, strong) NSImage               * iconImage;

/** 应用创建时间*/
@property (nonatomic, copy) NSString              *createTime;
/** 应用删除时间*/
@property (nonatomic, copy) NSString              *removeTime;
/** 应用版本号*/
@property (nonatomic, copy) NSString              *bundleVersion;
@end
