//
//  YGWifiRecordModel.h
//  Mac_1.0
//
//  Created by apple on 2016/12/28.
//  Copyright © 2016年 infogo. All rights reserved.
//AgentID, ItemID, ItemTime, IsEnable这几个参数没有暂时没有用到

#import <Foundation/Foundation.h>

@interface YGWifiRecordModel : NSObject<NSCoding>
/** wifi策略的AgentID*/
@property (nonatomic, copy) NSString *agentID;
/** wifi策略的ItemID*/
@property (nonatomic, copy) NSString *ItemID;
/** wifi策略的下发时间*/
@property (nonatomic, copy) NSString *ItemTime;
/** */
@property (nonatomic, assign) BOOL    isEnable;
/** 下发wifi策略中的每个wifi信息*/
@property (nonatomic, copy) NSArray * ItemList;

/** 初始化*/
+ (YGWifiRecordModel *)Model;
/** 比较两个YGWifiRecordModel是否相等*/
- (BOOL)isEqualToYGWifiRecordModel:(YGWifiRecordModel *)recordModel;

@end
