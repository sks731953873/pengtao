//
//  SystemInfo.m
//  Mac_1.0
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import "SystemProcessInfo.h"

@implementation SystemProcessInfo
@synthesize processID;
@synthesize processName;
@synthesize date;
@synthesize bundleID;
@end
