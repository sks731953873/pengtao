//
//  YGFileRecordModel.m
//  Mac_1.0
//
//  Created by apple on 2017/1/4.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import "YGFileRecordModel.h"
#import "YGFileItemList.h"
@implementation YGFileRecordModel
@synthesize AgentID;
@synthesize Result;
@synthesize ItemTime;
@synthesize ItemID;
@synthesize ItemList;
@synthesize IsAdd;
@synthesize IsDelete;
@synthesize IsEnable;
@synthesize IsUpdate;
@synthesize SubDirectory;


- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.AgentID forKey:@"AgentID"];
    [encoder encodeObject:self.Result forKey:@"Result"];
    [encoder encodeObject:self.ItemTime forKey:@"ItemTime"];
    [encoder encodeObject:self.ItemID forKey:@"ItemID"];
    [encoder encodeObject:self.ItemList forKey:@"ItemList"];
    [encoder encodeObject:[NSNumber numberWithBool:self.IsAdd] forKey:@"IsAdd"];
    [encoder encodeObject:[NSNumber numberWithBool:self.IsDelete] forKey:@"isDelete"];
    [encoder encodeObject:[NSNumber numberWithBool:self.IsEnable] forKey:@"IsEnable"];
    [encoder encodeObject:[NSNumber numberWithBool:self.IsUpdate] forKey:@"IsUpdate"];
    [encoder encodeObject:[NSNumber numberWithBool:self.SubDirectory] forKey:@"SubDirectory"];

}

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.AgentID = [decoder decodeObjectForKey:@"AgentID"];
        self.ItemTime = [decoder decodeObjectForKey:@"ItemTime"];
        self.ItemID = [decoder decodeObjectForKey:@"ItemID"];
        self.ItemList = [decoder decodeObjectForKey:@"ItemList"];
        self.Result = [decoder decodeObjectForKey:@"Result"];

        self.IsAdd = [[decoder decodeObjectForKey:@"IsAdd"] boolValue];
        self.IsDelete = [[decoder decodeObjectForKey:@"IsDelete"] boolValue];
        self.IsEnable = [[decoder decodeObjectForKey:@"IsEnable"] boolValue];
        self.IsUpdate = [[decoder decodeObjectForKey:@"IsUpdate"] boolValue];
        self.SubDirectory = [[decoder decodeObjectForKey:@"SubDirectory"] boolValue];
        
    }
    return self;
}

/**初始化*/
+ (YGFileRecordModel *)Model{
    return [[YGFileRecordModel alloc] init];
}

/** 比较两个YGFileRecordModel是否相同*/
- (BOOL)isEqualToYGFileRecordModel:(YGFileRecordModel *)list
{
    if (!self && !list) {
        return YES;
    }
    // 如果是完全相同的对象，就省去后面的判断
    if (self == list) return YES;
    // 如果object的类型不对，就不需要比较
    if (![list isKindOfClass:self.class]) return NO;
    // 基本数据类型
    BOOL result = (self.IsEnable == list.IsEnable && self.IsAdd == list.IsEnable && self.IsDelete == list.IsDelete && self.IsUpdate == list.IsUpdate && self.SubDirectory == list.SubDirectory);
    if (!result) return result;
    // 两个数组内字段不同则不等（包括顺序）
    for (int i = 0; i < self.ItemList.count; i++) {
        YGFileItemList *ygFile1 = self.ItemList[i];
        YGFileItemList *ygFile2 = list.ItemList[i];
        BOOL itemListResult = [ygFile1 isEqualToYGFileItemList:ygFile2];
        if (!itemListResult && (ygFile1 || ygFile2)) {
            return itemListResult;
        }
    }

    // 对象类型,两个对象为nil时isEqual:的结果为0(NO),所以需要专门处理
    // 两个对象都为nil时  跳过
    if (self.AgentID || list.AgentID) {
        if (![self.AgentID isEqualToString:list.AgentID]) return NO;
    }
    if (self.Result || list.Result) {
        if (![self.Result isEqualToString:list.Result]) return NO;
    }
    if (self.ItemID || list.ItemID) {
        if (![self.ItemID isEqualToString:list.ItemID]) return NO;
    }
    if (self.ItemTime || list.ItemTime) {
        if (![self.ItemTime isEqualToString:list.ItemTime]) return NO;
    }
    return YES;
}

- (NSUInteger)hash
{
    return self.AgentID.hash + self.Result.hash + self.ItemID.hash + self.ItemTime.hash + self.IsEnable + self.IsDelete + self.IsAdd + self.SubDirectory;
}

- (BOOL)isEqual:(YGFileRecordModel *)object
{
    return [self isEqualToYGFileRecordModel:object];
}
@end
