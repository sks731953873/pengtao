//
//  YGWifiItemList.m
//  Mac_1.0
//
//  Created by apple on 2016/12/28.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import "YGWifiItemList.h"


@implementation YGWifiItemList
@synthesize SSID;
@synthesize APMac;// bssid
@synthesize Remark;


- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.SSID forKey:@"SSID"];
    [encoder encodeObject:self.APMac forKey:@"APMac"];
    [encoder encodeObject:self.Remark forKey:@"Remark"];
    }

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.SSID = [decoder decodeObjectForKey:@"SSID"];
        self.APMac = [decoder decodeObjectForKey:@"APMac"];
        self.Remark = [decoder decodeObjectForKey:@"Remark"];
    }
    return self;
}


+ (YGWifiItemList *)List{
    return [[YGWifiItemList alloc] init];
}

- (BOOL)isEqualToYGWifiItemList:(YGWifiItemList *)list
{
    if (!self && !list){
        return YES;
    }
    // 如果是完全相同的对象，就省去后面的判断
    if (self == list) return YES;
    // 如果object的类型不对，就不需要比较
    if (![list isKindOfClass:self.class]) return NO;
    
    // 对象类型,两个对象为nil时isEqual:的结果为0(NO),所以需要专门处理
    if (self.SSID || list.SSID) {
        if (![self.SSID isEqualToString:list.SSID]) return NO;
    }
    if (self.APMac || list.APMac) {
        if (![self.APMac isEqualToString:list.APMac]) return NO;
    }
    if (self.Remark || list.Remark) {
        if (![self.Remark isEqualToString:list.Remark]) return NO;
    }
    return YES;
}

- (NSUInteger)hash
{
    return self.SSID.hash + self.APMac.hash + self.Remark.hash;
}

- (BOOL)isEqual:(YGWifiItemList *)object
{
    return [self isEqualToYGWifiItemList:object];
}
@end
