//
//  YGFileItemList.m
//  Mac_1.0
//
//  Created by apple on 2017/1/4.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import "YGFileItemList.h"

@implementation YGFileItemList
@synthesize SDCardType;
@synthesize FilePath;
@synthesize Remark;


- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.FilePath forKey:@"FilePath"];
    [encoder encodeObject:self.Remark forKey:@"Remark"];
    [encoder encodeObject:[NSNumber numberWithInteger:self.SDCardType] forKey:@"SDCardType"];
}

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.FilePath = [decoder decodeObjectForKey:@"FilePath"];
        self.Remark = [decoder decodeObjectForKey:@"Remark"];
        self.SDCardType = [[decoder decodeObjectForKey:@"SDCardType"] integerValue];
    }
    return self;
}

/**初始化*/
+ (YGFileItemList *)List{
    return [[YGFileItemList alloc] init];
}

/** 比较两个YGAppItemList是否相同*/
- (BOOL)isEqualToYGFileItemList:(YGFileItemList *)list
{
    if (!list && !list){
        return YES;
    }
    // 如果是完全相同的对象，就省去后面的判断
    if (self == list) return YES;
    // 如果object的类型不对，就不需要比较
    if (![list isKindOfClass:self.class]) return NO;
    // 基本数据类型
    BOOL result = (self.SDCardType == list.SDCardType);
    
    if (!result) return result;
    
    // 对象类型,两个对象为nil时isEqual:的结果为0(NO),所以需要专门处理
    // 两个对象都为nil时  跳过
    if (self.FilePath || list.FilePath) {
        if (![self.FilePath isEqualToString:list.FilePath]) return NO;
    }
    if (self.Remark || list.Remark) {
        if (![self.Remark isEqualToString:list.Remark]) return NO;
    }
    return YES;
}

- (NSUInteger)hash
{
    return self.Remark.hash + self.FilePath.hash + self.SDCardType;
}

- (BOOL)isEqual:(YGFileItemList *)object
{
    return [self isEqualToYGFileItemList:object];
}

@end
