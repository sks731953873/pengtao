//
//  ArchitectureView.h
//  Mac_1.0
//
//  Created by xin on 2019/1/24.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface ArchitectureView : NSView

@property (strong, nonatomic) NSImageView * imageView;
@property (copy, nonatomic) NSString * content;
@property (strong, nonatomic) NSTextField * text;
- (instancetype)initWithFrame:(NSRect)frameRect;
@end


