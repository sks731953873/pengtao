//
//  MyWebView.m
//  Mac_1.0
//
//  Created by apple on 2017/11/3.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import "MyWebView.h"

@implementation MyWebView

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

-(void)willOpenMenu:(NSMenu *)menu withEvent:(NSEvent *)event {
    for (NSMenuItem *menuItem in menu.itemArray) {
//        NSString *identifier = menuItem.identifier;
//        if ([identifier isEqual: @"WKMenuItemIdentifierReload"]) {
//            menuItem.action = @selector(menuClick:);
//        }
        menuItem.hidden = YES;
    }
}

// 重写reload方法∫∫
- (void)menuClick:(id)sender {
    
}

@end
