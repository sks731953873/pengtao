//
//  ArchitectureView.m
//  Mac_1.0
//
//  Created by xin on 2019/1/24.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "ArchitectureView.h"

@implementation ArchitectureView

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}
- (instancetype)initWithFrame:(NSRect)frameRect{
    self = [super initWithFrame:frameRect];
    if (self) {
        [self setUIWithFrame:frameRect];
    }
    return self;
}

- (void)setUIWithFrame:(NSRect)frameRect{
//    self.imageView = [[NSImageView alloc]initWithFrame:CGRectMake(10, 10, 30, 30)];
//    [self.imageView setImage:[NSImage imageNamed:@"111"]];
//    [self addSubview:self.imageView ];

//    self.text = [[NSTextField alloc] initWithFrame:CGRectMake(CGRectGetMaxX(self.imageView.frame)+10, CGRectGetMinY(self.imageView.frame), 100, 20)];
    self.text = [[NSTextField alloc] initWithFrame:CGRectMake(10, 2, frameRect.size.width, 20)];
    self.text.bordered = NO;
    self.text.font = [NSFont systemFontOfSize:10];
    self.text.editable = NO;
    self.text.backgroundColor = [NSColor clearColor];
    [self addSubview:self.text];

}
- (void)setContent:(NSString *)content{
    _content = content;
    NSRect rect = [self getStringLength:content];
    rect.size.height = 20;
    rect.origin = CGPointMake(10, 2);
    rect.size.width += 20;
    [self.text setFrame:rect];
    self.text.stringValue = content;
}

- (NSRect)getStringLength:(NSString *)string {
    NSDictionary *attributes = @{NSFontAttributeName:[NSFont systemFontOfSize:10],};
    NSRect textSize =[string boundingRectWithSize:NSMakeSize(MAXFLOAT, 100) options:NSStringDrawingTruncatesLastVisibleLine attributes:attributes context:nil];
    return textSize;
}

@end
