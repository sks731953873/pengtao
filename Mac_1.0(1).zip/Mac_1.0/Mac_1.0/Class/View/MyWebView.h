//
//  MyWebView.h
//  Mac_1.0
//
//  Created by apple on 2017/11/3.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import <WebKit/WebKit.h>

@interface MyWebView : WKWebView

@end
