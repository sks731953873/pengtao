//
//  YGButton.h
//  Mac_1.0
//
//  Created by apple on 2016/11/8.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface YGButton : NSButton
/**设置按钮的背景颜色*/
@property (nonatomic, strong) NSColor * backgroundColor;
/**title字体颜色*/
@property (nonatomic, strong) NSColor * titleColor;
/**显示在button上的字*/
@property (nonatomic, strong) NSString * titleString;

@end
