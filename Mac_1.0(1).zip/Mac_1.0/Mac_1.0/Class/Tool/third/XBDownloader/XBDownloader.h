//
//  XBDownloader.h
//  07-断点下载
//
//  Created by xshenpan on 16/5/27.
//  Copyright © 2016年 xshenpan. All rights reserved.
//

#import "XBDownloadManager.h"
#import "XBDownloadTaskInfo.h"