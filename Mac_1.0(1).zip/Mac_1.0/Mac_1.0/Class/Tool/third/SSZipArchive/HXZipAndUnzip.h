//
//  HXZipAndUnzip.h
//  Mac_1.0
//
//  Created by xin on 2019/3/7.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HXZipAndUnzip : NSObject


- (NSData *)gzipInflate:(NSData*)data;
- (NSData *)gzipDeflate:(NSData*)data;

@end

NS_ASSUME_NONNULL_END
