//
//  YGNetAuth.h
//  Mac_1.0
//
//  Created by apple on 2017/3/8.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YGNetAuthModel.h"

@interface YGNetHttpRequestObject : NSObject


/** 获取身份认证的方式
 // serverAddress 服务器地址
 // return :
 */
+ (BOOL)YGNetHttpPolicyCheckItemGetAuthType:(NSString *)serverAddress deviceID:(NSString *)deviceID andModel:(YGNetAuthModel **)model;

/**GetAuthMes
 获取启用安检项开关和规范ID*/
+ (BOOL)YGNetHttpPolicyCheckItemGetAuthMes:(NSString *)serverAddress deviceid:(NSString*)deviceID model:(YGNetAuthModel **)model;

/** 根据策略ID获取安检项ID*/
+ (NSString *)YGNetHttpPolicyCheckItemXml:(NSString *)serverAddress andPolicyID:(NSInteger)policyID;


/** 根据安检项ID获取XML报文 -->单个itemid获取单个安检项信息*/
+ (NSString *)YGNetHttpPolicyCheckItemGetPolicy:(NSString *)serverAddress andItemID:(NSString *)itemID;


/** 上报所有安检的结果*/
+ (NSString *)YGNetHttpPolicyCheckItemMobileResult:(NSString *)serverAddress deviceID:(NSString *)deviceID model:(YGNetAuthModel *)model resultItems:(NSString *)resultItems resultXML:(NSString *)resultXML;
/** 字符串替换为空*/
NSString * ReplaceString(NSString *pString, NSString *lString);
/** 发送msg提示信息*/
+ (void)postNotificationToControllerForMessage:(NSString *)message;
@end
