 //#include <stdio.h>
//#include <stdlib.h> 
//#include <string.h> 
//#include <unistd.h> 
//#include <sys/ioctl.h>
//#include <sys/types.h>
//#include <netinet/in.h>
//#include <netdb.h> 
//#include <arpa/inet.h> 
//#include <sys/sockio.h>
//#include <net/if.h>
//#include <errno.h> 
//#include <net/if_dl.h> 
//#include <sys/socket.h> // Per msqr
//#include <sys/sysctl.h>
//#include "sys/utsname.h"

//#include <sys/types.h>
//
//#include <sys/stat.h>
//
//#include <ifaddrs.h>

#import "YGTool.h"
#import "HardwareAssets.h"
#import <SystemConfiguration/CaptiveNetwork.h>// 获取wifi端口en1？
#include <netdb.h>// 网络状态
#import <SystemConfiguration/SystemConfiguration.h>//网络状态
#import "CommonFunc.h"
#import <sys/mount.h>// 获取硬盘大小
#import <CommonCrypto/CommonDigest.h>// md5
#import "YGFileDefault.h"

#import <CoreFoundation/CoreFoundation.h>// lock
#import <IOKit/IOKitLib.h>//lock
#import <Cocoa/Cocoa.h>
#import "USBVolumeModel.h"
@implementation YGTool

// 示例:Src="aaabbbccc" GetSubStr(Src,  "aaa", "ccc", Dst,sizeof(Dst)) Dst="bbb"
// return 指向Src地址的位置, 失败返回NULL
const char *GetSubStr(const char * Src, char *First, char *Last, char *Dst, size_t DstLen)
{
	const char *pLast = NULL;
	const char *pFirst = NULL;
	if(NULL == Src || NULL == Dst)
		return NULL;
    
	memset(Dst, 0, DstLen);
	if (First == NULL)
	{
		if(Last == NULL)
			return NULL;
		pLast = strstr(Src, Last);
		if (pLast)
		{
			size_t nLen = pLast - Src;
			if (nLen >= DstLen)
				nLen = DstLen - 1;
			memcpy(Dst, Src, nLen);
			return Src;
		}else{
			return NULL;
		}
	}
	pFirst = strstr(Src, First);
	if (pFirst)
	{
		pFirst += strlen(First);
		if(NULL == Last)
		{
			strncpy(Dst, pFirst, DstLen -1);
			return (char *)pFirst;
		}else{
			pLast = strstr(pFirst, Last);
			if (pLast)
			{
				size_t nLen = pLast - pFirst;
				if (nLen >= DstLen)
					nLen = DstLen - 1;
                
				memcpy(Dst, pFirst, nLen);
				return (char *)pFirst;
			}else
				return NULL;
		}
	}
	return NULL;
}

/******************************************************************************
 函数名称 : NSString* base64Encode(NSData *data)
 函数描述 : 文本数据转换为base64格式字符串
 输入参数 : (NSData *)data
 输出参数 : N/A
 返回参数 : (NSString *)
 备注信息 : 这里在转码之后加了特殊的字符串替换操作
 ******************************************************************************/
NSString* base64Encode(NSData *data)
{
    static char base64EncodingTable[64] = {
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
        'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
        'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
        'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'
    };
    
    int length = (int)[data length];
    unsigned long ixtext, lentext;
    long ctremaining;
    unsigned char input[3], output[4];
    short i, charsonline = 0, ctcopy;
    const unsigned char *raw;
    NSMutableString *result;
    lentext = [data length];
    if (lentext < 1)
        return @"";

    result = [NSMutableString stringWithCapacity: lentext];
    raw = [data bytes];
    ixtext = 0;
    while (true) {
        ctremaining = lentext - ixtext;
        
        if (ctremaining <= 0)
            break;        
        
        for (i = 0; i < 3; i++) {
            unsigned long ix = ixtext + i;
            if (ix < lentext)
                input[i] = raw[ix];
            else
                input[i] = 0;
        }
        output[0] = (input[0] & 0xFC) >> 2;
        output[1] = ((input[0] & 0x03) << 4) | ((input[1] & 0xF0) >> 4);
        output[2] = ((input[1] & 0x0F) << 2) | ((input[2] & 0xC0) >> 6);
        output[3] = input[2] & 0x3F;
        ctcopy = 4;
        switch (ctremaining) {
            case 1:
                ctcopy = 2;
                break;
            case 2:
                ctcopy = 3;
                break;
        }
        for (i = 0; i < ctcopy; i++)
            [result appendString: [NSString stringWithFormat: @"%c", base64EncodingTable[output[i]]]];
        for (i = ctcopy; i < 4; i++)
            [result appendString: @"="];
        ixtext += 3;
        charsonline += 4;
        if ((length > 0) && (charsonline >= length))
            charsonline = 0;
    }     
    result = (NSMutableString *)[result stringByReplacingOccurrencesOfString:@"=" withString:@":"];
    result = (NSMutableString *)[result stringByReplacingOccurrencesOfString:@"+" withString:@","];
    result = (NSMutableString *)[result stringByReplacingOccurrencesOfString:@"/" withString:@"."];
    return result;
}



BOOL writeFile(id content, NSString *fileName)
{
//    NSLock *lock = [[NSLock alloc] init];
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
//    [lock lock];
    @try {
        [userDefaults setObject:content forKey:fileName];
    }
    @catch (NSException* e) {
        HXINFOLOG(@"writeFile--Exception: %@", e);
    }
    @finally {
        BOOL result = [userDefaults synchronize];
        
//        [lock unlock];
        return result;
    }
}

id readFile (NSString* fileName)
{
//    NSLock *lock = [[NSLock alloc] init];
//    [lock lock];
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    id file = [userDefaults objectForKey:fileName];
//    [lock unlock];
    return file;
}


/**执行appleSctipt*/
NSString *DoShellScript(NSString * inScript)
{
    if (inScript.length < 1){
        return nil;
    }
    if ([NSThread isMainThread]) {
        NSDictionary *error = [NSDictionary new];
        NSString *script = [NSString stringWithFormat:@"do shell script \"%@\"", inScript];
        NSAppleScript *appleScript = [[NSAppleScript alloc] initWithSource:script];
        NSAppleEventDescriptor *des = [appleScript executeAndReturnError:&error];
        if ((NSNull *)error == [NSNull null]) {
            return nil;
        }
        return [des stringValue];
    }else{
        __block NSString *result;
        dispatch_sync(dispatch_get_main_queue(), ^{
            NSDictionary *error = [NSDictionary new];
            NSString *script = [NSString stringWithFormat:@"do shell script \"%@\"", inScript];
            NSAppleScript *appleScript = [[NSAppleScript alloc] initWithSource:script];
            NSAppleEventDescriptor *des = [appleScript executeAndReturnError:&error];
            if ((NSNull *)error == [NSNull null]) {
                result = nil;
            }else{
                result = [des stringValue];
            }
        });
        return result;
    }
}

NSString *httpPost(NSString * urlString)
{
    //初始化http请求,并自动内存释放
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    request.timeoutInterval = 5.0f;
    [request setURL:[NSURL URLWithString:urlString]];
    [request setHTTPMethod:@"POST"];
    NSString *contentType = [NSString stringWithFormat:@"text/html"];
    [request addValue:contentType forHTTPHeaderField:@"Content-Type"];
    NSHTTPURLResponse *urlResponse = nil;
    NSError *error;
    //同步返回请求，并获得返回数据
    NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&urlResponse error:&error];
    // NSString *result = [[NSString alloc] initWithData:responseData encoding:NSASCIIStringEncoding];
    unsigned long gbk_encode = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSString *result = [[NSString alloc] initWithData:responseData encoding:gbk_encode];
    //请求返回状态，并且stausCode 值为 0
    NSInteger lenthNum = urlResponse.statusCode;
    if (lenthNum >= 200 && lenthNum < 300){
//        HXINFOLOG(@"服务器通了");
        HXINFOLOG(@"response code:%ld, length:%lu, result:[%@]",lenthNum, (unsigned long)[responseData length], error.domain);

    }
    save_local_Log(@"http/https", [NSString stringWithFormat:@"response code:%ld, length:%lu, result:[%@]",lenthNum, (unsigned long)[responseData length], error.domain]);
    GetDeviceID(result);// 存deviceID;
    return result;
}

NSString * getDevXml()
{
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];

    NSString *capacity = TotalDiskSpace();
    // add by 2018年04月12日  增加两个节点 版本号和安装时间
    NSString *InstallTime = readFile(@"firstLaunch");
    NSString *pDevXml=[NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"gb2312\"?><MSAC><DeviceName>%@</DeviceName><OS>%@</OS><Ip>%@</Ip><Mac>%@</Mac><IeVersion>Safari</IeVersion><DiskSize>%@</DiskSize><GateWay></GateWay><DiskId>%@</DiskId><CPU>%@</CPU><Mark>%@</Mark><ClientVersion>%@</ClientVersion><InstallTime>%@</InstallTime></MSAC>",
                       readFile(@"computerName") ,// appledeiMac
                       readFile(@"SystemVersion"),
                       getIPAddress(),
                       getMacStr(),
                       capacity,
                       GetUUID(),
                       GetCPU(),//Intel(R) Core(TM) i5-4260U CPU @ 1.40GHz
                       GetMarkForMainThread(),
                       infoDictionary[@"CFBundleShortVersionString"],
                       InstallTime];
//                       [YGFileDefault readInfoFrom:@"firstLaunch"]];//255.255.255.0


//    pDevXml = [pDevXml stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//    pDevXml =  [pDevXml stringByReplacingOccurrencesOfString:@"/" withString:@"%2F"];
    
//    pDevXml = [CommonFunc base64StringFromText:pDevXml];

    NSData * data = [pDevXml dataUsingEncoding:NSUTF8StringEncoding];
    pDevXml = base64Encode(data);
    return pDevXml;
}

NSString *TotalDiskSpace(){
    NSDictionary * fattribute = [[NSFileManager defaultManager] attributesOfFileSystemForPath:NSHomeDirectory() error:nil];
    NSNumber *number = [fattribute objectForKey:NSFileSystemSize];
    NSString * diskNumber = [NSString stringWithFormat:@"%0.2f GB", number.floatValue/1000/1000/1000];
    return diskNumber;
}

// 截取http请求回应报文中的AgentID
NSString *GetDeviceID(NSString *code){
    NSString * deviceID = nil;
    NSArray *arr = [code componentsSeparatedByString:@","];
    for (NSString *str in arr) {
        if ([str rangeOfString:@"DeviceID"].location != NSNotFound && str.length > 10) {
            deviceID = CutOffStringBetweenBoth(str, @"'", @"'");
            break;
        }
    }
    if (deviceID) {
        HXINFOLOG(@"http取到了deviceID:%@", deviceID);
        writeFile(deviceID, kAgentID);
    }else{
        HXINFOLOG(@"http取deviceID失败");
    }
    return deviceID;
}


// 清除空格和换行
NSString *ClearWhiteSpace(NSString *string)
{
    return [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

/** 获取本地语言*/
NSString *getPreferredLanguage(){
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    NSArray * allLanguages = [defaults objectForKey:@"AppleLanguages"];
    NSString * preferredLang = [allLanguages objectAtIndex:0];
//    HXINFOLOG(@"当前语言:%@", preferredLang);
    return preferredLang;
}



/** 传入路径 返回文件信息字典*/
NSDictionary *CheckFileDate(NSString *path)
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSDictionary *fileAttributes = [fileManager attributesOfItemAtPath:path error:nil];
    //    NSDictionary *fileAttributes = [fileManager fileAttributesAtPath:path traverseLink:YES];
    if (![fileManager fileExistsAtPath:path])
        return nil;
    if (fileAttributes != nil) {
        NSNumber *fileSize= [fileAttributes objectForKey:NSFileSize];
        NSString *fileOwner = [fileAttributes objectForKey:NSFileOwnerAccountName];
        NSDate *creationDate = [fileAttributes objectForKey:NSFileCreationDate];
        NSDate *fileModDate = [fileAttributes objectForKey:NSFileModificationDate];// 文件修改时间
        NSMutableDictionary * dic = [NSMutableDictionary dictionary];
        //文件大小
        if (fileSize) {
            [dic setValue:fileSize forKey:@"fileSize"];
        }
        //文件创建日期
        if (creationDate) {
            [dic setValue:dateToStr(creationDate) forKey:@"creationDate"];
        }
        //文件所有者
        if (fileOwner) {
            [dic setValue:fileOwner forKey:@"fileOwner"];
        }
        //文件修改日期
        if (fileModDate) {
            NSString* s1 = dateToStr(fileModDate);
            [dic setValue:s1 forKey:@"fileModDate"];
        }
        return dic;
    }
    else {
        HXINFOLOG(@"Path (%@) is invalid.", path);
        return nil;
    }
    return nil;
}

NSString *dateToStr(NSDate *date)
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];//创建一个日期格式化器
    dateFormatter.dateFormat = YGCURRENTTIMETYPEONE;//指定转date得日期格式化形式
    return [dateFormatter stringFromDate:date];
}

/**字符串转gbk*/
char *StringToGbk(NSString *string)
{
    // 方法1
    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    if (!enc) {
        return nil;
    }
    NSData * data = [string dataUsingEncoding:enc];
    //    NSData * data = [string dataUsingEncoding:-2147482063];
    /*
     转码之后的data转换成字符串会自增几个字节的字符(并不知道为什么)
     所以这里做截取操作
     */
    long num1 = [data length];
    char *buff = (char *)[data bytes];
    long num2 = strlen(buff);
    if (num1 < num2) {
//        NSLog(@"gbk转码出问题0.\n[%s]\n", buff);
        buff = left(buff, buff, (int)num1);
//        NSLog(@"切割后的buff：[%s]\n", buff);
    }
//    // 方法2
//    char * hBuff = malloc(num1);
//    sprintf(hBuff, "%s", [data bytes]);
//    long num3 = strlen(hBuff);
//    if (!(num1 == num3)) {
//        printf("转码错误 hbuff = [%s]\n", hBuff);
//    }
//    
//    if (hBuff) {
//        free(hBuff);
//    }
    return buff;
    
}

/**
 截取SERIAL
 
 urlString        总字符串
 aims1            节点一
 aims2            节点二
 return           节点一和节点二中间的字符串  如果不存在这两个节点则返回nil
 */
NSString *CutOffStringBetweenBoth(NSString *urlString, NSString *aims1, NSString *aims2)
{
    if (!urlString) return nil;
    NSRange range1 = [urlString rangeOfString:aims1];// 从前搜索
    NSRange range2 = [urlString rangeOfString:aims2 options:NSBackwardsSearch];// 从末尾搜索
    if (range1.location == NSNotFound || range2.location == NSNotFound) return nil;// 两个节点出现不存在 返回nil
    NSRange range;
    NSInteger length = range2.location - range1.location - range1.length;
    NSInteger location = range1.length + range1.location;
    if (range1.length < 1 || range2.length < 1) {
        return nil;
    }
    range.length = length;
    range.location = location;
    NSString * serial = [urlString substringWithRange:range];
    return serial;
}



/**
 * 传入一个date   返回date与现在的时间间隔
 */
NSString *DateTimeDifferenceWithStartTime(NSString *startTime)
{
    if (!startTime) {
        HXINFOLOG(@"startTime = nil");
        return nil;
    }
    NSDateFormatter *date = [[NSDateFormatter alloc]init];
    [date setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *startD =[date dateFromString:startTime];
    NSDate *endD = [NSDate date];
    NSTimeInterval start = [startD timeIntervalSince1970]*1;
    NSTimeInterval end = [endD timeIntervalSince1970]*1;
    NSTimeInterval value = end - start;
    int second = (int)value % 60;//秒
    int minute = (int)value / 60 % 60;
    int house = (int)value / (24 * 3600)%3600;
    int day = (int)value / (24 * 3600);
    NSString *str;
    if (day != 0) {
        str = [NSString stringWithFormat:@"耗时%d天%d小时%d分%d秒",day,house,minute,second];
    }else if (day == 0 && house != 0) {
        str = [NSString stringWithFormat:@"耗时%d小时%d分%d秒",house,minute,second];
    }else if (day == 0 && house== 0 && minute!=0) {
        str = [NSString stringWithFormat:@"耗时%d分%d秒",minute,second];
    }else{
        str = [NSString stringWithFormat:@"耗时%d秒",second];
    }
    HXINFOLOG(@"\n%@\n",str);
    return str;
}

// 传入想要得到时间格式，返回当前时间
NSString *CurrentTime(NSString * dateType){
    NSDate *currentDate = [NSDate date];
    NSDateFormatter *dateformatter=[[NSDateFormatter alloc] init];
    
    [dateformatter setDateFormat:dateType];
    NSString *currentString = [dateformatter stringFromDate:currentDate];
    return currentString;
}

/*从字符串的左边截取n个字符*/
char * left(char *dst, char *src, int n)
{
    char *p = src;
    char *q = dst;
    int len = (int)strlen(src);
    if(n>len) n = len;
    while(n--) *(q++) = *(p++);
    *(q++)='\0'; /*有必要吗？很有必要*/
    return dst;
}
/*从字符串的右边截取n个字符*/
char * right(char *dst,char *src, int n)
{
    char *p = src;
    char *q = dst;
    int len = (int)strlen(src);
    if(n>len) n = len;
    p += (len-n);   /*从右边第n个字符开始，到0结束，很巧啊*/
    while((*(q++) = *(p++)));
    return dst;
}

/** IOKit --- 锁屏*/
BOOL LockScreen()
{
    BOOL isLock = false;
    io_registry_entry_t reg = IORegistryEntryFromPath(kIOMasterPortDefault, "IOService:/IOResources/IODisplayWrangler");
    if (reg) {
        IORegistryEntrySetCFProperty(reg, CFSTR("IORequestIdle"), kCFBooleanTrue);
        IOObjectRelease(reg);
        isLock = true;
    }
    HXINFOLOG(@"锁屏LockScreen");
    return isLock;
}
/** 关闭WiFi*/
void closeWifi()
{
    NSString *ifname = GetWifiEn();
    if (!ifname) {
        return;
    }
    NSString *script = [NSString stringWithFormat:@"networksetup -setairportpower %@ off", ifname];
    DoShellScript(script);
}
/** 开启WiFi*/
void openWifi(){
    NSString *ifname = GetWifiEn();
    if (!ifname) {
        return;
    }
    NSString *script = [NSString stringWithFormat:@"networksetup -setairportpower %@ on", ifname];
    DoShellScript(script);
}
/** 获取WiFi端口号 ----  至少目前是*/
NSString *GetWifiEn(){
    NSArray *ifs = (__bridge_transfer NSArray *)CNCopySupportedInterfaces();
    NSString *ifname;
    for (NSString * str in ifs) {
        ifname = str;
    }
    if (ifname.length < 1){
        return nil;
    }
    return ifname;
}


/**
 * 网络是否连通。
 *
 * @ return 网络状态枚举值
 * @ return YES 网络通畅
 * @ return NO 网络不通
 */
BOOL IsConnectedToNetwork()
{
    // Create zero addy
    struct sockaddr_in zeroAddress;
    bzero(&zeroAddress, sizeof(zeroAddress));
    zeroAddress.sin_len = sizeof(zeroAddress);
    zeroAddress.sin_family = AF_INET;
    
    // Recover reachability flags
    SCNetworkReachabilityRef defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr *)&zeroAddress);
    SCNetworkReachabilityFlags flags;
    
    BOOL didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags);
    CFRelease(defaultRouteReachability);
    
    if (!didRetrieveFlags){
        printf("Error. Could not recover network reachability flags\n");
        return NO;
    }
    
    BOOL isReachable = ((flags & kSCNetworkFlagsReachable) != 0);
    BOOL needsConnection = ((flags & kSCNetworkFlagsConnectionRequired) != 0);
    return (isReachable && !needsConnection) ? YES : NO;
}


/** 向服务器发送http请求，和服务器断网*/
void CutOffNet(NSString *msg){
    msg = [msg stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString * outNet = [NSString stringWithFormat:@"http://%@/phpdir/trade.php?tradecode=cutoff_net&device_id=%@&tradetype=authcheck&mod=a&msg=%@", readFile(kServerAddress), readFile(kAgentID), msg];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString * backStr = httpPost(outNet);
        backStr = [CommonFunc replaceUnicode:backStr];
        HXINFOLOG(@"back[%@]", backStr);
    });
}
#pragma mark 获取Safari当前浏览网站的url
/******************************************************************************
 函数名称 : NSArray *GetURLOfEveryWindowFromSafari()
 函数描述 : 获取本地自带浏览器当前浏览记录
 输入参数 : N/A
 输出参数 : N/A
 返回参数 : NSArray url数组
 备注信息 :
 ******************************************************************************/
NSArray *GetURLOfEveryWindowFromSafari(){
    // 获取本地自带浏览器当前浏览记录
    NSDictionary *error = [NSDictionary new];
    NSString *script =  @"tell application \"Safari\" to get URL of tab of every window";
    NSAppleScript *appleScript = [[NSAppleScript new] initWithSource:script];
    NSAppleEventDescriptor *des = [appleScript executeAndReturnError:&error];
    long first = [des numberOfItems];
    NSMutableArray * urlArr = [NSMutableArray array];
    for (int i = 1; i <= first; i++){
        NSAppleEventDescriptor * des2 = [des descriptorAtIndex:i];
        long second = [des2 numberOfItems];
        for (int j = 1; j <= second; j++) {
            NSAppleEventDescriptor *des3 = [des2 descriptorAtIndex:j];
            NSString *url = [des3 stringValue];
            if (url.length < 1) {
                continue;
            }
            [urlArr addObject:[des3 stringValue]];
        }
    }
    if ((NSNull *)error == [NSNull null]) {
        HXINFOLOG(@"get safari url faild");
    }
    return urlArr;
}


double current_Time_Stamp() {
    NSDate *sendDate = [NSDate date];
    NSTimeInterval time = [sendDate timeIntervalSince1970];
    return time;
}

#pragma mark 万能卸载码
+ (BOOL)isUnInstallKey:(NSString *)code {
    if ([code isEqualToString:@"asmmdmimc"]) {
        return YES;
    }

    NSString *timeString = CurrentTime(YGCURRENTTIMETYPETHREE);
    long num = [timeString  longLongValue];
    for (int i = 0; i < 16; i++) {
        NSString *localMd5 = [YGTool getLocalMd5String:(num+i)];
        if ([localMd5 isEqualToString:code]) {
            return YES;
        }
    }
    for (int i = 1; i < 15; i++) {
        NSString *localMd5 = [YGTool getLocalMd5String:(num - i)];
        if ([localMd5 isEqualToString:code]) {
            return YES;
        }
    }
    return NO;
}
+ (NSString *)getLocalMd5String:(long)num {
    num += 13;
    num *= 13;
    num /= 11;
    NSString *codeMd5 = [YGTool md5:[NSString stringWithFormat:@"%ld", num]];
    NSString *rCodeMd5 = [YGTool replaceMD5:codeMd5];
    return rCodeMd5;
}
/** iOS系统自带的MD5加密*/
+ (NSString *) md5:(NSString *) input {
    const char *cStr = [input UTF8String];
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    CC_MD5( cStr, (CC_LONG)strlen(cStr), digest ); // This is the md5 call

    NSMutableString *output = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];

    for(int i = 0; i < CC_MD5_DIGEST_LENGTH; i++) {
        [output appendFormat:@"%02x", digest[i]];
    }
    return  output;
}

+ (NSString *)replaceMD5:(NSString *)string {
    NSString *rString = [string substringToIndex:6];
    rString = [rString stringByReplacingOccurrencesOfString:@"a" withString:@"1"];
    rString = [rString stringByReplacingOccurrencesOfString:@"b" withString:@"2"];
    rString = [rString stringByReplacingOccurrencesOfString:@"c" withString:@"3"];
    rString = [rString stringByReplacingOccurrencesOfString:@"d" withString:@"4"];
    rString = [rString stringByReplacingOccurrencesOfString:@"e" withString:@"5"];
    rString = [rString stringByReplacingOccurrencesOfString:@"f" withString:@"6"];
    return rString;
}

#pragma mark ARP表
/* 为了解决切换vlan时（客户端登录和注销时触发），导致终端断网（原因是arp表没有及时更新）*/
/** 将arp移动到ASM目录下*/
+ (void) appleScriptMoveArpToDocumentASM{
//    NSArray *paths =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
//    NSString *documentDirectory = [paths objectAtIndex:0];
    NSString *filePath = [kCachesDirictory stringByAppendingPathComponent:@"/IMC/cfg"];
    BOOL createPathOk = YES;
    if (![[NSFileManager defaultManager] fileExistsAtPath:filePath isDirectory:&createPathOk]) {
        // 目录不存先创建
        [[NSFileManager defaultManager] createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:nil];
    }
    NSDictionary * error = [NSDictionary new];
    NSString *script =  [NSString stringWithFormat:@"do shell script \"cp /usr/sbin/arp %@;  chown root %@/arp ;  chmod u+s %@/arp \" with administrator privileges", filePath, filePath, filePath];
    NSAppleScript *appleScript = [[NSAppleScript alloc] initWithSource:script];
    NSAppleEventDescriptor *des = [appleScript executeAndReturnError:&error];
    NSString * str = [des stringValue];
    if ((NSNull *)error == [NSNull null]) {
        save_local_Log(@"Apple Script", [NSString stringWithFormat:@"Apple Script执行成功--appleScriptMoveArpToDocumentASM--[%@]", str]);
    }else{
        save_local_Log(@"Apple Script", [NSString stringWithFormat:@"Apple Script执行失败--appleScriptMoveArpToDocumentASM--[%@]-[%@]", str, [error description]]);
    }
}

+ (BOOL)isHasArpTable {
    NSString *filePath = [kCachesDirictory stringByAppendingPathComponent:@"/IMC/cfg/arp"];
    return [[NSFileManager defaultManager] fileExistsAtPath:filePath];
}
/** 清空arp表记录*/
+ (void)appleScriptClearArpTable {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (![YGTool isHasArpTable]) {
            [YGTool appleScriptMoveArpToDocumentASM];
        }
//        NSArray *paths =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
//        NSString *documentDirectory = [paths objectAtIndex:0];
        NSString *filePath = [kCachesDirictory stringByAppendingPathComponent:@"/IMC/cfg"];
        NSDictionary * error = [NSDictionary new];
        NSString *script =  [NSString stringWithFormat:@"do shell script \" %@/arp -a -d \"", filePath];
        NSAppleScript *appleScript = [[NSAppleScript alloc] initWithSource:script];
        NSAppleEventDescriptor *des = [appleScript executeAndReturnError:&error];
        NSString * str = [des stringValue];
        if ((NSNull *)error == [NSNull null]||error.count ==0 )  {
            save_local_Log(@"Apple Script", [NSString stringWithFormat:@"Apple Script执行成功--appleScriptClearArpTable--[%@]", [str stringByReplacingOccurrencesOfString:@"\r" withString:@"\n"]]);
        }else{
            save_local_Log(@"Apple Script", [NSString stringWithFormat:@"Apple Script执行成功--appleScriptClearArpTable--[%@]-[%@]", [str stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]], [error description]]);
        }

    });


    // 另外一种方式
    //    NSTask *task;
    //    task = [[NSTask alloc] init];
    //    NSString *arpString = [NSString stringWithFormat:@"%@/arp",filePath];
    //    [task setLaunchPath: arpString];
    //    //ioreg -rd1 -c IOPlatformExpertDevice | grep -E '(UUID)'
    //    NSArray *arguments;
    //    arguments = [NSArray arrayWithObjects: @"-a", @"-d",nil];
    //    [task setArguments: arguments];
    //
    //    NSPipe *pipe;
    //    pipe = [NSPipe pipe];
    //    [task setStandardOutput: pipe];
    //    NSFileHandle *file;
    //    file = [pipe fileHandleForReading];
    //    [task launch];
    //    NSData *data;
    //    data = [file readDataToEndOfFile];
    //
    //    NSString *string = [[NSString alloc] initWithData: data encoding: NSUTF8StringEncoding];
    //    NSLog(@"%@", string);

}

/**
 十进制转换十六进制

 @param decimal 十进制数
 @return 十六进制数
 */
+ (NSString *)getHexByDecimal:(NSInteger)decimal {

    NSString *hex =@"";
    NSString *letter;
    NSInteger number;
    for (int i = 0; i<9; i++) {

        number = decimal % 16;
        decimal = decimal / 16;
        switch (number) {
            case 10:
                letter =@"a"; break;
            case 11:
                letter =@"b"; break;
            case 12:
                letter =@"c"; break;
            case 13:
                letter =@"d"; break;
            case 14:
                letter =@"e"; break;
            case 15:
                letter =@"f"; break;
            default:
                letter = [NSString stringWithFormat:@"%ld", number];
        }
        hex = [letter stringByAppendingString:hex];
        if (decimal == 0) {

            break;
        }
    }
    return hex;
}

// 16进制转10进制
+ (NSInteger) numberHexString:(NSString *)aHexString {
    // 为空,直接返回.
    if (nil == aHexString) {
        return [aHexString integerValue];
    }
    NSScanner * scanner = [NSScanner scannerWithString:aHexString];
    unsigned long long longlongValue;
    [scanner scanHexLongLong:&longlongValue];
    //将整数转换为NSNumber,存储到数组中,并返回.
    NSNumber * hexNumber = [NSNumber numberWithLongLong:longlongValue];
    return hexNumber.integerValue;
}

#pragma mark usb推出
/** Launched through the path*/
+ (BOOL)AppleScriptAtMTLaunchedThroughTheUrlPath:(NSURL *)urlPath withPath:(NSString *)path {
    __block BOOL result = NO;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        result = [YGTool AppleScriptLaunchedThroughTheUrlPath:urlPath withPath:path];;
    });
    return result;
}

+ (BOOL)AppleScriptLaunchedThroughTheUrlPath:(NSURL *)urlPath withPath:(NSString *)path {
    NSDictionary *error = [NSDictionary new];
    NSString *script = [NSString stringWithFormat:@"do shell script \"/usr/sbin/diskutil unmount %@\"", urlPath];
    NSAppleScript *appleScript = [[NSAppleScript alloc] initWithSource:script];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSAppleEventDescriptor *des = nil;
    if ([fileManager fileExistsAtPath:urlPath.path]) {
        des = [appleScript executeAndReturnError:&error];
    }
    if ((NSNull *)error == [NSNull null] || error.count == 0) {
        return YES;
    } else {
        //
        sleep(1);
        NSDictionary *error2 = [NSDictionary new];
        NSString *script1 = [NSString stringWithFormat:@"do shell script \"/usr/sbin/diskutil unmount %@\"", path];
        NSAppleScript *appleScript1 = [[NSAppleScript alloc] initWithSource:script1];
        NSFileManager *fileManager1 = [NSFileManager defaultManager];
        NSAppleEventDescriptor *des1 = nil;
        if ([fileManager1 fileExistsAtPath:urlPath.path]) {
            des1 = [appleScript1 executeAndReturnError:&error2];
        }
        if ((NSNull *)error2 == [NSNull null]|| error2.count == 0)
            return YES;
        else{
            sleep(1);
            NSDictionary *error3 = [NSDictionary new];
            NSString *script2 = [NSString stringWithFormat:@"do shell script \"/usr/sbin/diskutil unmount %@\"", urlPath];
            NSAppleScript *appleScript2 = [[NSAppleScript alloc] initWithSource:script2];
            NSFileManager *fileManager2 = [NSFileManager defaultManager];
            NSAppleEventDescriptor *des2 = nil;
            if ([fileManager2 fileExistsAtPath:urlPath.path]) {
                des2 = [appleScript2 executeAndReturnError:&error2];
            }
            if ((NSNull *)error3 == [NSNull null]|| error3.count == 0)
                return YES;
            else{
                return NO;
            }
            return NO;
        }
    }
    HXINFOLOG(@"%@", [des stringValue]);
    return YES;
}

+ (NSString *)getCurrentUserName {
    char path[1024];
    CFStringRef name = CSCopyUserName(true);
    CFStringGetCString(name, path, sizeof(path), kCFStringEncodingUTF8);
    CFRelease(name);
    NSString *nameString = [NSString stringWithUTF8String:path];
    if (nameString.length > 0) {
        return nameString;
    }
    NSArray *paths =NSSearchPathForDirectoriesInDomains(NSApplicationDirectory,NSAllDomainsMask, YES);
    if (paths.count < 1) {
        return @"User";
    }
    NSString *directory = [paths objectAtIndex:0];
    return [[directory stringByReplacingOccurrencesOfString:@"Applications" withString:@""] lastPathComponent];
}
@end

