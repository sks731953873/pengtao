//
//  NSData+UTF8.h
//  Mac_1.0
//
//  Created by Xin on 2017/4/30.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (UTF8)
- (NSString *)utf8String;
@end
