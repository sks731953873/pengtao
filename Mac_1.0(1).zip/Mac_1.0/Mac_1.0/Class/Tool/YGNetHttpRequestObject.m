//
//  YGNetAuth.m
//  Mac_1.0
//
//  Created by apple on 2017/3/8.
//  Copyright © 2017年 infogo. All rights reserved.
//
// 拿到deviceid 之后启动socket  通过js上报软硬件信息~~~
#import "YGNetHttpRequestObject.h"
#import "YGTool.h"

#define net_http_request @"netauth_http_request"

@implementation YGNetHttpRequestObject

// 所有由于网络原因导致的自动认证失败都不改变 isNetAuth的值，只是跳过这次的自动认证，等待到下个自动认证周期时间点到达，然后在进行自动认证。

/** 获取身份认证的方式
 serverAddress 服务器地址
 return :
 */
+ (BOOL)YGNetHttpPolicyCheckItemGetAuthType:(NSString *)serverAddress deviceID:(NSString *)deviceID andModel:(YGNetAuthModel **)model{
    NSString * urlString = [NSString stringWithFormat:@"http://%@/a/ajax.php?tradecode=PolicyCheckItem&type=getauthtype&deviceid=%@&roleid=%@", serverAddress, deviceID, @((*model).RoleID)];
    NSError *error = nil;
    NSString *pRet = httpRequestPost(urlString, &error);
    if (pRet.length < 1) {
        (*model).getAuthType = @"";
        return NO;
    }
    if (XInclusionRelationshipExists(pRet, @"'NoAuth'")) {
        //  无账号密码认证
        (*model).getAuthType = @"NoAuth";
        return [YGNetHttpRequestObject YGNetHttpNetAuthDev:serverAddress deviceID:deviceID type:@"NoAuth" andModel:model];
    }else if (XInclusionRelationshipExists(pRet, @"'User'")) {
        //  账号密码认证
        (*model).getAuthType = @"User";
        // 询问是否重注册和强制下线
        BOOL lifeTime = [YGNetHttpRequestObject YGNetHttpPolicyCheckItemLifetime:serverAddress userName:(*model).username];
        if (!lifeTime) {
            (*model).IsNetAuth = 0;
            return NO;
        }
        return [YGNetHttpRequestObject YGNetHttpNetAuthDev:serverAddress deviceID:deviceID type:@"User" andModel:model];
    }else if (XInclusionRelationshipExists(pRet, @"'Stop'")) {
        //  禁止认证
        (*model).IsNetAuth = 0;
        [YGNetHttpRequestObject postNotificationToControllerForMessage:@"自动认证失败:禁止客户端认证！"];
    }else if (XInclusionRelationshipExists(pRet, @"'Isolation'")) {
        (*model).IsNetAuth = 0;
        [YGNetHttpRequestObject postNotificationToControllerForMessage:@"自动认证失败:客户端已被隔离！"];
        //  设备被隔离
    }else if (XInclusionRelationshipExists(pRet, @"NotLive")) {
        //  设备被删除
        (*model).IsNetAuth = 0;
        [YGNetHttpRequestObject postNotificationToControllerForMessage:@"自动认证失败:客户端设备已删除！"];
    }else if (XInclusionRelationshipExists(pRet, @"'Registered'")) {
        // web页面选择了重注册
        (*model).IsNetAuth = 0;
        [YGNetHttpRequestObject postNotificationToControllerForMessage:@"自动认证失败:客户端设备需要手动注册！"];
    }else if (XInclusionRelationshipExists(pRet, @"AutoRegistered")) {
        // 客户端需要自动认证
        (*model).IsNetAuth = 0;
        [YGNetHttpRequestObject postNotificationToControllerForMessage:@"自动认证失败:客户端设备需要自动注册！"];
    }else if (XInclusionRelationshipExists(pRet, @"Error Client")) {
        (*model).IsNetAuth = 0;
        [YGNetHttpRequestObject postNotificationToControllerForMessage:@"客户端出现 网络异常等情况"];
    }
    else if (XInclusionRelationshipExists(pRet, @"Error")) {
        [YGNetHttpRequestObject postNotificationToControllerForMessage:@"自动认证失败:获取认证方式异常，无法正常进行自动认证，请点击通知手动进行认证！"];
        (*model).IsNetAuth = 0;
    }
    else {
        // 什么都不属于
//        (*model).IsNetAuth = 0;
    }
    return NO;
}


/** net_auth入网请求 获取policyID*/
+ (BOOL)YGNetHttpNetAuthDev:(NSString *)serverAddress deviceID:(NSString *)deviceID type:(NSString*)type andModel:(YGNetAuthModel **)model {
    NSString *username = [type isEqualToString:@"User"]? (*model).username:@"";
    NSString *password = [type isEqualToString:@"User"]? (*model).password:@"";
    NSString *urlString =[NSString stringWithFormat:@"http://%@/a/ajax.php?tradecode=net_auth&NewMobile=1&user_name=%@&password=%@&saveuserpass=1&type=%@&deviceid=%@",
                          serverAddress,
                          username,
                          password,
                          type,
                          deviceID];
    NSError *error = nil;
    NSString *pRet = httpRequestPost(urlString, &error);
    if (pRet.length < 1) {
        // 可能是断网了(网络超时)
        return NO;
    }
    if (XInclusionRelationshipNotExists(pRet, @"RoleID")) {
#warning 要添加提示弹窗
        if  (XInclusionRelationshipExists(pRet, @"_res =")) {
            NSString *res = CutOffStringBetweenBoth(pRet, @"__res = '", @"'");
            if (res.length > 0) {
                [YGNetHttpRequestObject postNotificationToControllerForMessage:res];
            }
        }
        (*model).IsNetAuth = 0;
        return NO;// 不包含 可能是账号密码错误      提示弹窗
    }
    NSString * RoleID = nil;
    NSArray *arr = [pRet componentsSeparatedByString:@","];
    int tag = 0;
    for (NSString *str in arr) {
        if (XInclusionRelationshipExists(str, @"RoleID") && str.length > 1) {
            RoleID = CutOffStringBetweenBoth(str, @"'", @"'");
            if (RoleID.length > 0) {
                (*model).RoleID = [RoleID integerValue];
                tag++;
            }
        }else if (XInclusionRelationshipExists(str, @"IsSafeCheck")) {
            NSString *IsSafeCheck = CutOffStringBetweenBoth(str, @"'", @"'");
            if (IsSafeCheck.length > 0) {
                (*model).IsSafeCheck = [IsSafeCheck integerValue];
                tag++;
            }
        }else if (XInclusionRelationshipExists(str, @"PolicyID")) {
            NSString *PolicyID = CutOffStringBetweenBoth(str, @"'", @"'");
            if (PolicyID.length > 0) {
                (*model).PolicyID = [PolicyID integerValue];
            }
        }
        if (tag == 3) {break;}
    }
    return YES;
}



/**
 获取启用安检项开关、规范id和roleid
 serverAddress:服务器地址
 return:
 */
+ (BOOL)YGNetHttpPolicyCheckItemGetAuthMes:(NSString *)serverAddress deviceid:(NSString*)deviceID model:(YGNetAuthModel **)model {
    NSString *urlString = [NSString stringWithFormat:@"http://%@/a/ajax.php?tradecode=PolicyCheckItem&type=getauthmes&deviceid=%@", serverAddress, deviceID];
    NSError *error = nil;
    NSString *pRet = httpRequestPost(urlString, &error);
    if (pRet.length < 1) {
        // 可能网络超时
        return NO;
    }
    //
    pRet = CutOffStringBetweenBoth(pRet, @"'", @"'");
    NSArray *array = [pRet componentsSeparatedByString:@"#infogo#"];

    if (array.count != 3) {
        (*model).IsSafeCheck = 0;
        return NO;
    }
    (*model).IsSafeCheck = [array[0] integerValue];
    (*model).PolicyID = [array[1] integerValue];
    (*model).RoleID = [array[2] integerValue];
    return YES;
}


/** 根据策略ID获取安检项ID-->获取所有的安检项ID*/
+ (NSString *)YGNetHttpPolicyCheckItemXml:(NSString *)serverAddress andPolicyID:(NSInteger)policyID {
    NSString *urlString = [NSString stringWithFormat:@"http://%@/a/ajax.php?tradecode=PolicyCheckItem&type=xml&policyid=%@", serverAddress, @(policyID)];
    NSError *error = nil;
    NSString *pRet = httpRequestPost(urlString, &error);
    pRet = ReplaceString(pRet, @"__res = ");
    pRet = ReplaceString(pRet, @"'");
    return pRet;

}

/** 根据安检项ID获取XML报文 -->单个itemid获取单个安检项信息*/
+ (NSString *)YGNetHttpPolicyCheckItemGetPolicy:(NSString *)serverAddress andItemID:(NSString *)itemID {
    NSString *urlString = [NSString stringWithFormat:@"http://%@/a/ajax.php?tradecode=policycheckitem&type=getpolicy&itemid=%@", serverAddress, itemID];
    NSError *error = nil;
    NSString *pRet = httpRequestPost(urlString, &error);
    return pRet;
}

/** 上报所有的结果*/
+ (NSString *)YGNetHttpPolicyCheckItemMobileResult:(NSString *)serverAddress deviceID:(NSString *)deviceID model:(YGNetAuthModel *)model resultItems:(NSString *)resultItems resultXML:(NSString *)resultXML{
    NSString *urlString = [NSString stringWithFormat:@"http://%@/a/ajax.php?tradecode=mobileresult&deviceid=%@&policyid=%@&roleid=%@&is_safecheck=%@&LastAuthID=0&itemsid=%@&checkres=%@",
                           serverAddress,
                           deviceID,
                           @(model.PolicyID),
                           @(model.RoleID),
                           @(model.IsSafeCheck),
                           resultItems,
                           resultXML];
    NSError *error = nil;
    NSString *pRet = httpRequestPost(urlString, &error);
    return pRet;
}
/** 新增获取重注册*/
+ (BOOL)YGNetHttpPolicyCheckItemLifetime:(NSString *)serverAddress userName:(NSString *)userName {
    if (userName.length < 1) {
        [YGNetHttpRequestObject postNotificationToControllerForMessage:@"自动认证失败:账号密码不能为空，请手动认证！"];
        return NO;
    }
    NSString *urlString = [NSString stringWithFormat:@"http://%@/a/ajax.php?tradecode=PolicyCheckItem&type=lifetime&user=%@", serverAddress, userName];
    NSError *error = nil;
    NSString *pRet = httpRequestPost(urlString, &error);
    if (pRet.length < 1) {
        // 默认为网络原因
        return NO;
    }
    if (XInclusionRelationshipExists(pRet, @"OverDue")) {
        [YGNetHttpRequestObject postNotificationToControllerForMessage:@"自动认证失败:认证账号已经超过使用期限，请手动认证！"];
        return NO;
    }else if (XInclusionRelationshipExists(pRet, @"NoExist")) {
        [YGNetHttpRequestObject postNotificationToControllerForMessage:@"自动认证失败:认证账号不存在，请手动认证！"];
        return NO;
    }
    return YES;
}

/** Http请求方法->传入链接；返回报文，接收请求error*/
NSString *httpRequestPost(NSString * urlString, NSError **error)
{
    urlString = [urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    //初始化http请求,并自动内存释放
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    request.timeoutInterval = 5.0f;
    [request setURL:[NSURL URLWithString:urlString]];
    [request setHTTPMethod:@"POST"];
    NSString *contentType = [NSString stringWithFormat:@"text/html"];
    [request addValue:contentType forHTTPHeaderField:@"Content-Type"];
    NSHTTPURLResponse *urlResponse = nil;

    //同步返回请求，并获得返回数据
    NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&urlResponse error:error];
    // NSString *result = [[NSString alloc] initWithData:responseData encoding:NSASCIIStringEncoding];
    unsigned long gbk_encode = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSString *result = [[NSString alloc] initWithData:responseData encoding:gbk_encode];
    //请求返回状态，并且stausCode 值为 0
    NSInteger lenthNum = urlResponse.statusCode;
    //    NSLog(@"response code:%ld, length:%lu, result:[%@]",lenthNum, (unsigned long)[responseData length], error.domain);
    if (lenthNum >= 200 && lenthNum < 300){
//        HXINFOLOG(@"服务器通了= \n\n[%@]\n\n[%@]", urlString, result);
    } else {
        HXINFOLOG(@"returningResponse = [%@] error = [%@]", urlResponse, *error);
        save_local_Log(net_http_request, [NSString stringWithFormat:@"response code:%ld, length:%lu, result:[%@]",lenthNum, (unsigned long)[responseData length], (*error).domain]);
    }
    save_local_Log(net_http_request, [NSString stringWithFormat:@"[%@\n response code:%ld]\n{%@}", urlString, lenthNum, result]);
    return result;
}


NSString * ReplaceString(NSString *pString, NSString *lString) {
    return [pString stringByReplacingOccurrencesOfString:lString withString:@""];
}


#pragma mark 全局通知

+ (void)postNotificationToControllerForMessage:(NSString *)message {
    if ([NSThread isMainThread]) {
        NSNotification* notification = [NSNotification notificationWithName:@"RecvReportSendMsg" object:message];
        [[NSNotificationCenter defaultCenter] postNotification:notification];
    } else {
        dispatch_async(dispatch_get_main_queue(), ^{
            [YGNetHttpRequestObject postNotificationToControllerForMessage:message];
        });
    }
}
/** http请求网络404或者505时调用*/
+ (void)postNetErrorNotification {
    [YGNetHttpRequestObject postNotificationToControllerForMessage:@"网络不通，自动认证失败"];
}
@end
