//
//  YGFileDefault.h
//  Mac_1.0
//
//  Created by apple on 2016/12/9.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YGFileDefault : NSObject

/**通过读取本地文件获取默认ip地址*/
NSString * ReadFileDefault(void);

+ (void)WriteFileDefault:(NSString *)ipDefault;
/** 将数据写入.app文件*/
+ (BOOL)writeInfo:(NSString *)content toPath:(NSString *)filePath;
/** 从.app路径下的文件夹取信息*/
+ (id)readInfoFrom:(NSString *)filePath;
@end
