//
//  ViewController.h
//  test003
//
//  Created by jinlong han on 11-10-26.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//
#import <Foundation/Foundation.h>


@interface  YGTool: NSObject


// 示例:Src="aaabbbccc" GetSubStr(Src,  "aaa", "ccc", Dst,sizeof(Dst)) Dst="bbb"
// return 指向Src地址的位置, 失败返回NULL
const char *GetSubStr(const char * Src, char *First, char *Last, char *Dst, size_t DstLen);
/**存入本地*/
BOOL writeFile(id content, NSString *fileName);
/**从本地读取*/
id readFile (NSString* fileName);
/**转码*/
NSString* base64Encode(NSData *data);


/**执行do shell script*/
NSString *DoShellScript(NSString * inScript);

/**http请求*/
NSString *httpPost(NSString * urlString);

/**拼接成硬件信息报文*/
NSString *getDevXml(void);

// 硬盘大小
NSString *TotalDiskSpace(void);


/**清除字符串开始和结尾的空白字符*/
NSString *ClearWhiteSpace(NSString *string);

/** 获取本地语言*/
NSString *getPreferredLanguage(void);


/**
 获取文件属性
 //文件大小          NSNumber   有问题    .app文件 return 102/204
 //文件创建日期       NSString
 //文件所有者        NSString
 //文件修改日期       NSString
 */
NSDictionary *CheckFileDate(NSString *path);

/**将时间类型date转换成上报报文格式的时间*/
NSString *dateToStr(NSDate *date);


/**字符串转gbk*/
char *StringToGbk(NSString *string);


/** 截取SERIAL
 urlString        总字符串
 aims1            节点一
 aims2            节点二
 return           节点一和节点二中间的字符串
 */
NSString *CutOffStringBetweenBoth(NSString *urlString, NSString *aims1, NSString *aims2);


/**
 * 传入一个date   返回date与现在的时间间隔
 */
NSString *DateTimeDifferenceWithStartTime(NSString *startTime);

/*从字符串的左边截取n个字符*/
char * left(char *dst,char *src, int n);
/*从字符串的右边截取n个字符*/
char * right(char *dst,char *src, int n);
/** 传入想要得到时间格式，返回当前时间*/
NSString *CurrentTime(NSString * dateType);

#pragma mark  功能
/**  锁屏 */
BOOL LockScreen(void);
/**关闭wifi*/
void closeWifi(void);
/**开启wifi*/
void openWifi(void);

/**
 * 网络是否连通。
 *
 * @return 网络状态枚举值
 * @retval YES 网络通畅
 * @retval NO 网络不通
 */
BOOL IsConnectedToNetwork(void);
/** 发送http请求断开服务器网络*/
void CutOffNet(NSString *msg);

/******************************************************************************
 函数名称 : NSArray *GetURLOfEveryWindowFromSafari()
 函数描述 : 获取本地自带浏览器当前浏览记录
 输入参数 : N/A
 输出参数 : N/A
 返回参数 : NSArray url数组
 备注信息 :
 ******************************************************************************/
NSArray *GetURLOfEveryWindowFromSafari(void);


double current_Time_Stamp(void);
/** 万能卸载码*/
+ (BOOL)isUnInstallKey:(NSString *)code;

#pragma mark ARP表操作
/** 清空arp表记录*/
+ (void) appleScriptClearArpTable;

/** 将arp移动到ASM目录下*/
+ (void) appleScriptMoveArpToDocumentASM;

/** 判斷arp是否存在*/
+ (BOOL)isHasArpTable;


/**
 十进制转换十六进制

 @param decimal 十进制数
 @return 十六进制数
 */
+ (NSString *)getHexByDecimal:(NSInteger)decimal;


/** 16进制转10进制*/
+ (NSInteger) numberHexString:(NSString *)aHexString;

+ (NSString *)fileSizeAtPath:(NSString *)path;
+ (BOOL)AppleScriptAtMTLaunchedThroughTheUrlPath:(NSURL *)urlPath withPath:(NSString *)path;
+ (NSString *)getCurrentUserName;
@end
