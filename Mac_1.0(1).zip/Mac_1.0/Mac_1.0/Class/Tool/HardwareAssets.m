//
//  HardwareAssets.m
//  Mac_1.0
//
//  Created by apple on 2016/11/7.
//  Copyright © 2016年 infogo. All rights reserved.
//
#include <arpa/inet.h>
#include <errno.h>
#include <net/if.h>
#include <net/if_dl.h>
#include <netdb.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/sockio.h>
#include <sys/socket.h> // Per msqr
#include <sys/sysctl.h>
#include "sys/utsname.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <ifaddrs.h>
#import "YGTool.h"
#import "HardwareAssets.h"
#import "YGifaddrs.h"

//#include <sys/socket.h>
//#import <netinet/in.h>
#import <netinet6/in6.h>
//#import <arpa/inet.h>
//#import <ifaddrs.h>
//#include <netdb.h>
//#import <SystemConfiguration/SCNetworkReachability.h>
//#import "getgateway.h"
//#import <arpa/inet.h>

@implementation HardwareAssets

- (NSString *)MACADDRESS
{
//    kern_return_t kr;
    CFMutableDictionaryRef matchDict;
    io_iterator_t iterator;
    io_registry_entry_t entry;
    
    matchDict = IOServiceMatching("IOEthernetInterface");
//    kr =
    IOServiceGetMatchingServices(kIOMasterPortDefault, matchDict, &iterator);
    
    NSDictionary *resultInfo = nil;
    
    while ((entry = IOIteratorNext(iterator)) != 0)
    {
        CFMutableDictionaryRef properties=NULL;
//        kr =
        IORegistryEntryCreateCFProperties(entry,
                                               &properties,
                                               kCFAllocatorDefault,
                                               kNilOptions);
        if (properties)
        {
            resultInfo = (__bridge_transfer NSDictionary *)properties;
            NSString *bsdName = [resultInfo objectForKey:@"BSD Name"];
            NSData *macData = [resultInfo objectForKey:@"IOMACAddress"];
            if (!macData)
            {
                continue;
            }
            
            NSMutableString *macAddress = [[NSMutableString alloc] init];
            const UInt8 *bytes = [macData bytes];
            for (int i=0; i<macData.length; i++)
            {
                [macAddress appendFormat:@"%02x",*(bytes+i)];
            }
            
            //打印Mac地址
            if (bsdName && macAddress)
            {
                save_local_Log(@"hardwareAssets", [NSString stringWithFormat:@"网卡:%@\nMac地址:%@\n",bsdName,macAddress]);
                return macAddress;
            }
        }
    }
    IOObjectRelease(iterator);
    return nil;
}

// Return the local MAC addy

// Courtesy of FreeBSD hackers email list

// Accidentally munged during previous update. Fixed thanks to mlamb.

//- (NSString *)getMac:( id )arg
NSString *getMacStr()
{
    int                 mib[6];
    size_t              len;
    char                *buf;
    unsigned char       *ptr;
    struct if_msghdr    *ifm;
    struct sockaddr_dl  *sdl;
    mib[0] = CTL_NET;
    mib[1] = AF_ROUTE;
    mib[2] = 0;
    mib[3] = AF_LINK;
    mib[4] = NET_RT_IFLIST;
    NSString *en = [HardwareAssets appleScriptForRourerAtMainThread];
    if (!en) {
        return @"00:00:00:00:00:00";
    }
    if ((mib[5] = if_nametoindex([en UTF8String])) == 0) {
        printf("Error: if_nametoindex error/n");
        return NULL;
    }
    if (sysctl(mib, 6, NULL, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 1/n");
        return NULL;
    }
    if ((buf = malloc(len)) == NULL) {
        printf("Could not allocate memory. error!/n");
        return NULL;
    }
    if (sysctl(mib, 6, buf, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 2");
        return NULL;
    }
    ifm = (struct if_msghdr *)buf;
    sdl = (struct sockaddr_dl *)(ifm + 1);
    ptr = (unsigned char *)LLADDR(sdl);
    NSString *outstring = [NSString stringWithFormat:@"%02x:%02x:%02x:%02x:%02x:%02x", *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    free(buf);
    return [outstring uppercaseString];
}

/*
 <HardInfo>
 <Type></Type>
 <Name></Name>
 <Vendor></Vendor>
 <Prop></Prop>
 <ChangeTime>2013-07-03</ChangeTime>
 </HardInfo>
 */
+ (NSString * )HardwareData
{
    NSString * cpu = GetCPU();
//    NSString * kernel = GetKernel();
    NSString * disk = TotalDiskSpace();
    NSString * memory = GetRAM();
    NSArray * cpuStr = [cpu componentsSeparatedByString:@"@"];
    NSString *cpuHz = cpu;
    if (cpuStr.count == 2) {
        cpuHz = cpuStr[1];
    }
//    <HardInfo><Type>Kernelnumber</Type><State>Add</State><Name>%@</Name><Vendor></Vendor><Prop>%@</Prop><ChangeTime>ComputerTime</ChangeTime></HardInfo>   kernel, kernel,
    NSString * dataString = [NSString stringWithFormat:@"<HardInfo><Type>Disk</Type><State>Add</State><Name>%@</Name><Vendor></Vendor><Prop>%@</Prop><ChangeTime>ComputerTime</ChangeTime></HardInfo><HardInfo><Type>CPU</Type><State>Add</State><Name>%@</Name><Vendor></Vendor><Prop>%@</Prop><ChangeTime>ComputerTime</ChangeTime></HardInfo><HardInfo><Type>Memory</Type><State>Add</State><Name>%@GB</Name><Vendor></Vendor><Prop>%@GB</Prop><ChangeTime>ComputerTime</ChangeTime></HardInfo>", disk, disk, cpu, cpuHz, memory, memory];
    return dataString;
}

/*
 System Software Overview:
 
 System Version: macOS 10.12 (16A323)
 Kernel Version: Darwin 16.0.0
 Boot Volume: Macintosh HD
 Boot Mode: Normal
 Computer Name: apple的iMac
 User Name: apple (apple)
 Secure Virtual Memory: Enabled
 System Integrity Protection: Enabled
 Time since boot: 2:38
 */
/** 软件信息概述存到本地*/
- (void)getMACInfo
{
    NSString * macInfo =[self system_profiler:@[@"SPSoftwareDataType", @"SPSerialATADataType"]];
    if (!macInfo) {
        return;
    }
    NSArray * array = [macInfo componentsSeparatedByString:@"\n"];
    for (NSString * str in array) {
        if([self contain:str string:@"System Version"]){//macOS 10.12 (16A323)
            NSString * SystemVersion = ClearWhiteSpace(str);
            SystemVersion = [self cutString:SystemVersion];
            BOOL isMac = [SystemVersion rangeOfString:@"mac"].location != NSNotFound;
            if (isMac) {
                SystemVersion = [SystemVersion stringByReplacingOccurrencesOfString:@"mac" withString:@"Mac"];
            }else{
                SystemVersion = [NSString stringWithFormat:@"Mac%@", SystemVersion];
            }
            writeFile(SystemVersion, @"SystemVersion");
        }else if([self contain:str string:@"User Name"]){//apple (apple)
            NSString * userName = ClearWhiteSpace(str);
            userName = [self cutString:userName];
            writeFile(userName, @"pcuserName");
        }else if([self contain:str string:@"Computer Name"]){//apple的iMac
            NSString * computerName = ClearWhiteSpace(str);
            computerName = [self cutString:computerName];
            writeFile(computerName, @"computerName");
        }else if ([self contain:str string:@"Capacity"]){// 500.11 GB (500,107,862,016 bytes)
            NSString * Capacity = ClearWhiteSpace(str);
            Capacity = [self cutString:Capacity];
            NSString * byte1 = CutOffStringBetweenBoth(Capacity, @"(", @")");
            NSString * byte2 = CutOffStringBetweenBoth(readFile(@"Capacity"), @"(", @")");
            byte1 = [byte1 stringByReplacingOccurrencesOfString:@"," withString:@""];
            byte2 = [byte2 stringByReplacingOccurrencesOfString:@"," withString:@""];
            if (!([byte1 longLongValue] < [byte2 longLongValue])) {
                Capacity = [Capacity stringByReplacingOccurrencesOfString:@"," withString:@""];
                writeFile(Capacity, @"Capacity");
            }
        }
            
    }
//    [self diskOfAllSizeMBytes];
}

- (CGFloat)diskOfAllSizeMBytes{
    CGFloat size = 0.0;
    NSError *error;
    NSString * userName = NSUserName();
    NSDictionary *dic = [[NSFileManager defaultManager] attributesOfFileSystemForPath:NSHomeDirectoryForUser(userName) error:&error];
    if (error) {
        HXINFOLOG(@"%@", error.localizedDescription);
    }else{
        NSNumber *number = [dic objectForKey:NSFileSystemSize];
        size = [number floatValue] / 1020 / 1024;
        
    }
    return size;
}


// 获取文件夹的大小
-(float)getFreeDiskspace {
    float totalSpace;
    float totalFreeSpace = 0;
    NSError *error = nil;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSDictionary *dictionary = [[NSFileManager defaultManager] attributesOfFileSystemForPath:[paths lastObject] error: &error];
    
    if (dictionary) {
        NSNumber *fileSystemSizeInBytes = [dictionary objectForKey: NSFileSystemSize];
        NSNumber *freeFileSystemSizeInBytes = [dictionary objectForKey:NSFileSystemFreeSize];
        totalSpace = [fileSystemSizeInBytes floatValue];
        totalFreeSpace = [freeFileSystemSizeInBytes floatValue];
        HXINFOLOG(@"Memory Capacity of %f GB with %f GB Free memory available.", ((totalSpace/1024.0f)/1024.0f/1024.0f), ((totalFreeSpace/1024.0f)/1024.0f)/1024.0f);
    } else {
        HXINFOLOG(@"Error Obtaining System Memory Info: Domain = %@, Code = %ld", [error domain], (long)[error code]);
    }
    return totalFreeSpace;
}

/** 调用system_profiler:穿入字符串数组 返回信息字符串*/
- (NSString *)system_profiler:(NSArray *)arr
{
    NSString * launchPath = @"/usr/sbin/system_profiler";
    NSFileManager * fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:launchPath]){
        HXINFOLOG(@"没有/usr/sbin/system_profiler");
        return nil;
    }
    NSTask *task = [[NSTask alloc] init];
    [task setLaunchPath:@"/usr/sbin/system_profiler"];
    task.arguments = arr;
    NSPipe *outputPipe = [NSPipe pipe];
    [task setStandardOutput:outputPipe];
    [task launch];
    [task waitUntilExit];
    NSFileHandle * read = [outputPipe fileHandleForReading];
    NSData * dataRead = [read readDataToEndOfFile];
    NSString * stringRead = [[NSString alloc] initWithData:dataRead encoding:NSUTF8StringEncoding];
    return stringRead;
}

NSString *getIPAddress()
{
    NSString *address = @"error";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    NSString *en = [HardwareAssets appleScriptForRourerAtMainThread];
    if (!en) {
        return address;
    }
        
    if (success == 0) {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        while(temp_addr != NULL) {
            if(temp_addr->ifa_addr->sa_family == AF_INET) {
                // Check if interface is en0 which is the wifi connection on the iPhone
                if([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:en]) {
                    // Get NSString from C String
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                }
            }
            temp_addr = temp_addr->ifa_next;
        }
    }
    // Free memory
    freeifaddrs(interfaces);
    return address;
}

NSString* GetUUID(){
    NSTask *task = [[NSTask alloc] init];
    [task setLaunchPath: @"/usr/sbin/ioreg"];
    //ioreg -rd1 -c IOPlatformExpertDevice | grep -E '(UUID)'
    NSArray *arguments;
    arguments = [NSArray arrayWithObjects: @"-rd1", @"-c",@"IOPlatformExpertDevice",nil];
    [task setArguments: arguments];
    
    NSPipe *pipe = [NSPipe pipe];
    [task setStandardOutput: pipe];
    NSFileHandle *file = [pipe fileHandleForReading];
    [task launch];
    NSData *data = [file readDataToEndOfFile];
    
    NSString *string = [[NSString alloc] initWithData: data encoding: NSUTF8StringEncoding];
    //NSLog (@"grep returned:n%@", string);
    NSString *key = @"IOPlatformUUID";
    NSRange range = [string rangeOfString:key];
    
    NSInteger location = range.location + [key length] + 5;
    NSInteger length = 32 + 4;
    range.location = location;
    range.length = length;
    NSString *UUID = [string substringWithRange:range];
    UUID = [UUID stringByReplacingOccurrencesOfString:@"-" withString:@""];
    return UUID;
}


//Intel(R) Core(TM) i5-4260U CPU @ 1.40GHz
#pragma mark CPU
NSString * GetCPU()
{
    NSString *script =  @"sysctl -n machdep.cpu.brand_string";
    return DoShellScript(script);
}

//8 GB RAM
//sysctl -n hw.memsize | awk '{print $0/1073741824" GB RAM"}';
NSString * GetRAM()
{
    NSString *script = @"sysctl -n hw.memsize | awk '{print $0/1073741824}';";
    return DoShellScript(script);
}
// 内核
NSString *GetKernel()
{
    NSString *sctipt = @"sysctl -n machdep.cpu.core_count";
    return DoShellScript(sctipt);
}
// echo -e "$(sysctl -n hw.model)"    iMac14,4
NSString *GetModel()
{
    NSString *sctipt = @"sysctl -n hw.model";
    return DoShellScript(sctipt);
}



#pragma mark mark 255.255.255.0
NSString *GetMarkForMainThread(){
    return GetMark();
//    if ([NSThread isMainThread]) {
//        return GetMark();
//    }else{
//        __block NSString *mark;
//        dispatch_sync(dispatch_get_main_queue(), ^{
//            mark = GetMark();
//        });
//        return mark;
//    }
}
NSString *GetMark(){
    if ([[[HardwareAssets alloc] init] routerIp]){
        return readFile(@"ifa_netmask");
    }

    NSDictionary * error = [NSDictionary new];
    NSString *hRouter = [HardwareAssets appleScriptForRourerAtMainThread];
    if (hRouter.length < 2) {
        return NULL;
    }
    NSString *script =  [NSString stringWithFormat:@"do shell script \"ipconfig getpacket %@ | grep subnet_mask\"", hRouter];
//    NSString *scropt = @"do shell script \"networksetup -setairportnetwork en1 YanJiuYuan3080 infogogo\"";// 登录wifi
//    security find-generic-password -D "AirPort network password" -a "YanJiuYuan3080" -gw   获取WiFi密码
//    networksetup -setairportpower en0 on  // 这个不知道做什么的  getairportpower
    //defaults write com.apple.screensaver askForPasswordDelay -int 0     // 锁屏之后多少时间输密码
//    NSString *script =  @"do shell script \"defaults write com.apple.screensaver askForPasswordDelay -int 1800\"";
    NSAppleScript *appleScript = [[NSAppleScript alloc] initWithSource:script];
    NSAppleEventDescriptor *des = [appleScript executeAndReturnError:&error];
    NSString * str = [des stringValue];
    if (((NSNull *)error == [NSNull null]) || [str componentsSeparatedByString:@":"].count < 2) {
        HXINFOLOG(@"Apple Script执行失败--GetMark");
        return NULL;
    }
    return [str stringByReplacingOccurrencesOfString:@"subnet_mask (ip):" withString:@""];
}


/**  字符串str1中是否包含有字符串str2 */
- (BOOL)contain:(NSString *)str1 string:(NSString *)str2
{
    return [str1 rangeOfString:str2].location != NSNotFound;
}


// 截取字符串
- (NSString *)cutString:(NSString *)string
{
    NSArray * arr = [string componentsSeparatedByString:@": "];
    if (arr.count != 2) {
        HXINFOLOG(@"错误的字段");
        return nil;
    }
    if ([arr[1] isEqualToString:@" "]) {
        return @" NULL ";
    }
    return arr[1];
}


- (struct ifaddrs *) routerIp {
    
//    NSString *address = @"error";
    struct ifaddrs *current_addr = NULL;
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    
    int success = 0;
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    
    NSString * hRouter = [HardwareAssets appleScriptForRourerAtMainThread];
    if (!hRouter) {
        return nil;
    }
    if (success == 0)
    {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        //*/
        while(temp_addr != NULL)
        /*/
         int i=255;
         while((i--)>0)
         //*/
        {
            if(temp_addr->ifa_addr->sa_family == AF_INET)
            {
                // Check if interface is en0 which is the wifi connection on the iPhone
                // en是物理或者无线  lo是本地ip
//                NSLog(@"temp_addr->ifa_name = %s", temp_addr->ifa_name);
                if([[NSString stringWithUTF8String:temp_addr->ifa_name] hasPrefix:hRouter])
                {
                    // Get NSString from C String //ifa_addr
                    //ifa->ifa_dstaddr is the broadcast address, which explains the "255's"
                    current_addr = temp_addr;
                    
 //                   address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                    
                    //routerIP----192.168.1.255 广播地址
//                    NSLog(@"broadcast address--%@",[NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_dstaddr)->sin_addr)]);
                    //--192.168.1.106 本机地址
//                    NSLog(@"local device ip--%@",[NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)]);
                    //--255.255.255.0 子网掩码地址
//                    NSLog(@"netmask--%@",[NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_netmask)->sin_addr)]);
                    writeFile([NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_netmask)->sin_addr)], @"ifa_netmask");
                    
                    //--en0 端口地址
//                    NSLog(@"interface--%@",[NSString stringWithUTF8String:temp_addr->ifa_name]);
                    
//                    NSLog(@" ifa_name-- %@", [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_name)->sin_addr)]);
//                    NSLog(@" ifa_flags -- %u", ((unsigned int)temp_addr->ifa_flags));
                }
                
            }
            
            temp_addr = temp_addr->ifa_next;
        }
    }
    
    // Free memory
    freeifaddrs(interfaces);
    return current_addr;
}

+ (NSString *)appleScriptForRourerAtMainThread{
    
    if ([NSThread isMainThread]) {
        return [HardwareAssets routerEn];
    }else{
        __block NSString *en = nil;
        dispatch_sync(dispatch_get_main_queue(), ^{
            en = [HardwareAssets routerEn];
        });
        return en;
    }
}
// 通过路由表获取当前联网的端口 NSAppleScript只能在主线程执行
+ (NSString *)routerEn
{
    NSDictionary * error = nil;
    NSString * en;
    NSString *script = @"do shell script \"route -n get default | grep interface\"";
    NSAppleScript *appleScript = [[NSAppleScript alloc] initWithSource:script];
    NSAppleEventDescriptor *des = [appleScript executeAndReturnError:&error];
    NSString * str = [des stringValue];
    if ((NSNull *)error == [NSNull null]) {
        return nil;
    }
    en = [str stringByReplacingOccurrencesOfString:@"interface: " withString:@""];// 替换
    en = [en stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if (des) {
        des = nil;
        appleScript = nil;
        error = nil ;
    }
    return en;
}
@end
