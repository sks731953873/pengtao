//
//  YGButton.m
//  Mac_1.0
//
//  Created by apple on 2016/11/8.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import "YGButton.h"

@implementation YGButton
@synthesize backgroundColor;
@synthesize titleColor;
@synthesize titleString;

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // 设置背景颜色
    if(self.backgroundColor != nil) {
        [self.backgroundColor set];
        NSRectFill(self.bounds);
    // Drawing code here.
    }
    //绘制文字
    if(self.titleString != nil) {
        NSColor *color = self.titleColor ? self.titleColor : [NSColor blackColor];
        NSMutableParagraphStyle * paraStyle = [[NSMutableParagraphStyle alloc] init];
        [paraStyle setParagraphStyle:[NSParagraphStyle defaultParagraphStyle]];
        [paraStyle setAlignment:NSCenterTextAlignment];
        //[paraStyle setLineBreakMode:NSLineBreakByTruncatingTail];
        NSDictionary * attrButton = [NSDictionary dictionaryWithObjectsAndKeys:[NSFont fontWithName:@"Verdana"size:16],NSFontAttributeName, color,NSForegroundColorAttributeName, paraStyle,NSParagraphStyleAttributeName,nil];
        NSAttributedString * btnString = [[NSAttributedString alloc]initWithString:self.titleString attributes:attrButton];
        [btnString drawInRect:NSMakeRect(0,0,self.frame.size.width,self.frame.size.height)];
    }
}

@end
    
