//
//  YGFileDefault.m
//  Mac_1.0
//
//  Created by apple on 2016/12/9.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import "YGFileDefault.h"
#import "YGTool.h"
@implementation YGFileDefault

/*
    在下载目录下找  找到了就穿给默认存储路径
 */
NSString * FindDownloadFile()
{
    NSString * ip = readFile(kServerAddress);
    if (ip.length < 1) {
        NSArray *paths =NSSearchPathForDirectoriesInDomains(NSDownloadsDirectory,NSUserDomainMask, YES);
        NSString *documentDirectory = [paths objectAtIndex:0];
        NSString *fileName = [NSString stringWithFormat:@"imc_mac/imc_mac.cfg"];
        NSString *logFilePath = [documentDirectory stringByAppendingPathComponent:fileName];
        NSFileManager* fm = [NSFileManager defaultManager];
        NSData* data = [fm contentsAtPath:logFilePath];
        if (data == nil) {
            return @"";// download下也没有
        }
        NSString * ipDefault =[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        ipDefault = [ipDefault stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        writeFile(ipDefault, kServerAddress);
        [fm removeItemAtPath:fileName error:nil];
        return ipDefault;
    }
    return ip;
}

NSString * ReadFileDefault(void) {
    NSString *ipDefault = [YGFileDefault ReadFileDefault];
    if (ipDefault.length<1) {
        ipDefault = FindDownloadFile();
        if (ipDefault.length < 1)
            return nil;
        else
            [YGFileDefault WriteFileDefault:ipDefault];
        return ipDefault;
    }
    writeFile(ipDefault, @"ipDefault");
    return ipDefault;
}

+ (NSString *)ReadFileDefault {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    //定义记录文件全名以及路径的字符串filePath
    NSString *filePath = [kCachesDirictory stringByAppendingPathComponent:@"/IMC/cfg"];
    NSString *filePath1 = [filePath stringByAppendingPathComponent:@"/imc_mac.cfg"];
    //查找文件，如果不存在，就创建一个文件
    if (![fileManager fileExistsAtPath:filePath1]) {
        BOOL f2 = [fileManager createFileAtPath:filePath1 contents:nil attributes:nil];
        if (!f2)
            return @"";
    }
    // 先读
    NSData* data = [fileManager contentsAtPath:filePath1];
    NSString * readString =[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    if (readString.length<1)
        return @"";
    else
        return [readString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

+ (void)WriteFileDefault:(NSString *)ipDefault {
    NSString *filePath = [kCachesDirictory stringByAppendingPathComponent:@"/IMC/cfg"];
    NSString *filePath1 = [filePath stringByAppendingPathComponent:@"/imc_mac.cfg"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:filePath]) {
        BOOL f1 = [fileManager createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:nil];
        if (!f1) {
            HXINFOLOG(@"创建[%@]失败", filePath);
            return;
        }
    }
    if (![fileManager fileExistsAtPath:filePath1]) {
        BOOL f2 = [fileManager createFileAtPath:filePath1 contents:nil attributes:nil];
        if (!f2){
            HXINFOLOG(@"创建[%@]失败", filePath1);
            return;
        }
    }
    NSFileHandle  *outFile = [NSFileHandle fileHandleForWritingAtPath:filePath1];
    if(outFile == nil) {
        HXINFOLOG(@"Open of file for writing failed");
        return;
    }
    //找到并定位到outFile的末尾位置(在此后追加文件)
    [outFile seekToEndOfFile];
    //读取inFile并且将其内容写到outFile中
    NSData * buffer = [ipDefault dataUsingEncoding:NSUTF8StringEncoding];
    [outFile writeData:buffer];
    //关闭读写文件
    [outFile closeFile];
}

/*
往应用程序目录下写入东西有权限问题，写入会失败。已经没有使用下面的两个方法了
 */
/** 将数据写入.app文件*/
+ (BOOL)writeInfo:(NSString *)content toPath:(NSString *)filePath {
    NSString *documentDirectory = kCachesDirictory;
    //定义记录文件全名以及路径的字符串filePath
    NSString *filePath1 = [documentDirectory stringByAppendingPathComponent:@"/IMC"];
//    NSString * mainPath = [[NSBundle mainBundle] resourcePath];
    NSString *path = [filePath1 stringByAppendingPathComponent:[filePath stringByAppendingString:@".cfg"]];
    //5、创建数据缓冲区
    NSMutableData  *writer = [[NSMutableData alloc] init];
    //6、将字符串添加到缓冲中
    [writer appendData:[content dataUsingEncoding:NSUTF8StringEncoding]];
    //7、将其他数据添加到缓冲中
    //将缓冲的数据写入到文件中
    return [writer writeToFile:path atomically:YES];
}

/** 从.app路径下的文件夹取信息*/
+ (id)readInfoFrom:(NSString *)filePath {
    NSString *fileName = [filePath stringByAppendingString:@".cfg"];
    //创建文件管理器
    NSFileManager *fileManager = [NSFileManager defaultManager];
    //获取路径
    NSString *documentDirectory = kCachesDirictory;
    //定义记录文件全名以及路径的字符串filePath
    NSString *filePath1 = [documentDirectory stringByAppendingPathComponent:@"/IMC"];
    [fileManager changeCurrentDirectoryPath:[filePath stringByExpandingTildeInPath]];
    //获取文件路径
    NSString* path = [filePath1 stringByAppendingPathComponent:fileName];
    NSData* reader = [NSData dataWithContentsOfFile:path];
    return [[NSString alloc] initWithData:reader encoding:NSUTF8StringEncoding];
}
@end
