//
//  SoftwareList.m
//  Mac_1.0
//
//  Created by apple on 2016/11/8.
//  Copyright © 2016年 infogo. All rights reserved.
//
// 使用nsworkspace 需要添加库AppKit
#import "SoftwareList.h"
#import <AppKit/AppKit.h>
#import "YGTool.h"
#import "SystemProcessInfo.h"
#import "ApplicationInfo.h"
@interface SoftwareList ()
{
    NSMutableArray * allAppList;
    NSMutableArray * allAppPath;
}
@end

@implementation SoftwareList
#pragma mark 进程列表
+ (NSArray *)runningSystemProcessInfo
{
    NSMutableArray *systemProcessArr = [NSMutableArray array];
    NSWorkspace *workSpace = [NSWorkspace sharedWorkspace];
    NSArray * processArray = [workSpace runningApplications];
    for (NSRunningApplication * runningApp in processArray) {
        SystemProcessInfo *systemProcess = [[SystemProcessInfo alloc] init];
        systemProcess.bundleID = runningApp.bundleIdentifier;
        systemProcess.processID = runningApp.processIdentifier;
        systemProcess.processName = runningApp.localizedName;
        systemProcess.date = runningApp.launchDate;
//        NSLog(@"name = %@\n date = %@", systemProcess.processName, dateToStr(runningApp.launchDate));//  程序启动时间
        [systemProcessArr addObject:systemProcess];
    }
    return systemProcessArr;
}


// <?xml version="1.0" encoding="gbk"?><ASM><TradeCode>ReportSoftChanged</TradeCode><AgentID>2</AgentID><SoftInfo><State>Add</State><SoftName>IMC安全桌面</SoftName><SoftVersion>1.0</SoftVersion><InstallDate>2016-11-21 17:38:12</InstallDate><IconName>default.ico</IconName><SoftSize>10.55MB</SoftSize><Frequency>有时</Frequency><LastUseDate></LastUseDate><ChangeTime>2016-11-21 17:38:12</ChangeTime></SoftInfo></ASM>]

#pragma mark 运行软件列表
+ (NSArray *)runningSoftwareList
{
    NSWorkspace *sharedWorkspace = [NSWorkspace sharedWorkspace];
    NSArray * apps = [sharedWorkspace valueForKeyPath:@"launchedApplications"];//.NSApplicationName
    
    NSMutableArray * runningSoft = [NSMutableArray array];
    NSWorkspace * wk = [NSWorkspace sharedWorkspace];
    for (int i = 0; i < apps.count; i++) {
        ApplicationInfo * appInfo = [[ApplicationInfo alloc] init];
        appInfo.ApplicationName = [apps[i] objectForKey:@"NSApplicationName"];
        appInfo.ApplicationPath = [apps[i] objectForKey:@"NSApplicationPath"];
        appInfo.ApplicationProcessID = [apps[i] objectForKey:@"NSApplicationProcessIdentifier"];
//        NSRunningApplication * aeawew = [apps[i] objectForKey:@"NSWorkspaceApplicationKey"];
//        NSLog(@"name = %@\n\n time = %@", aeawew.localizedName, dateToStr(aeawew.launchDate));
//        DateTimeDifferenceWithStartTime(dateToStr(aeawew.launchDate));
        appInfo.runningApplication = [apps[i] objectForKey:@"NSWorkspaceApplicationKey"];
        appInfo.bundleID = [apps[i] objectForKey:@"NSApplicationBundleIdentifier"];
        appInfo.userName = NSUserName();
        appInfo.iconImage = [wk iconForFile:appInfo.ApplicationPath];
        NSDictionary * dic = CheckFileDate(appInfo.ApplicationPath);
        appInfo.createDate = dic[@"creationDate"];
        [runningSoft addObject:appInfo];
//        i = apps.count;// .test
    }
    return runningSoft;
}

+ (NSArray *)runningAPPName{
    NSWorkspace *sharedWorkspace = [NSWorkspace sharedWorkspace];
    NSArray * apps = [sharedWorkspace valueForKeyPath:@"launchedApplications.NSApplicationName"];//.NSApplicationName
    return apps;
}

//运行进程信息
- (NSArray *)runningSystemProcess
{
    NSWorkspace * sharedWorkspace = [NSWorkspace sharedWorkspace];
    NSArray *runningSystemProcess = [sharedWorkspace runningApplications];
    for (NSRunningApplication * app in runningSystemProcess) {
        NSLog(@"nsrunningApp=%@", app);
    }
    return nil;
}
#pragma mark 获取mac上所有.app应用
/**
 获取mac上所有的软件信息（屏蔽了苹果公司的初始软件）
 return   数组中的字典是每个软件的信息
 用do shell 不会报一个black的错
 */
+ (NSDictionary *)allAppList
{
    NSTask * task = [[NSTask alloc] init];
    [task setLaunchPath:@"/usr/sbin/system_profiler"];
    //    task.arguments = @[@"SPApplicationsDataType > list_of_all_apps.txt"];
    task.arguments = @[@"-xml", @"SPApplicationsDataType"];
    //    task.arguments = @[@"SPApplicationsDataType"];
    //    task.arguments = @[@"SPSoftwareDataType"];
    NSPipe *outputPipe = [NSPipe pipe];
    [task setStandardOutput:outputPipe];
    [task launch];
    
    NSFileHandle * read = [outputPipe fileHandleForReading];
    NSData * dataRead = [read readDataToEndOfFile];
    NSString * stringRead = [[NSString alloc] initWithData:dataRead encoding:NSUTF8StringEncoding];
    [task waitUntilExit];
//    NSDictionary * error = [NSDictionary new];
//    NSLog(@"allAppList1 = [%@]", [NSThread currentThread]);
//    NSString *script =  @"do shell script \"/usr/sbin/system_profiler -xml SPApplicationsDataType\"";
//    NSAppleScript *appleScript = [[NSAppleScript alloc] initWithSource:script];
//    NSAppleEventDescriptor *des = [appleScript executeAndReturnError:&error];
//    NSLog(@"allAppList2 = [%@]", [NSThread currentThread]);
//    NSString * str = [des stringValue];
//    if ((NSNull *)error == [NSNull null]) {
//        NSLog(@"allAppList获取全部app失败");
//    }
    SoftwareList *list = [[SoftwareList alloc] init];
    NSDictionary * listArr = [list CreatePlist:stringRead];
    
    return listArr;
}

#pragma mark plist
- (NSDictionary *)CreatePlist:(NSString *)str
{
    if (!str) {
        return nil;
    }
    NSData* plistData = [str dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
    NSPropertyListFormat format;
    NSDictionary *plist = [NSPropertyListSerialization propertyListWithData:plistData options:NSPropertyListImmutable format:&format error:&error];
    if(!plist){
        NSLog(@"Error: %@",error);
    }
    return [self appDictionaryToApplicationInfo:plist];
//    return plist;
}
/*
 <dict>
 <key>_name</key>
 <string>SogouInput</string>
 <key>has64BitIntelCode</key>
 <string>no</string>
 <key>lastModified</key>
 <date>2016-11-07T00:34:20Z</date>
 <key>obtained_from</key>
 <string>identified_developer</string>
 <key>path</key>
 <string>/Library/Input Methods/SogouInput.app</string>
 <key>runtime_environment</key>
 <string>arch_x86</string>
 <key>signed_by</key>
 <array>
 <string>Developer ID Application: Beijing Sogou Technology Development Co.,Ltd. (DFD88F82SU)</string>
 <string>Developer ID Certification Authority</string>
 <string>Apple Root CA</string>
 </array>
 <key>version</key>
 <string>3.8.0.2054</string>
 </dict>
 */

/** 将字典类的app信息转换成app类*/
- (NSDictionary *)appDictionaryToApplicationInfo:(NSDictionary *)dic
{
    allAppList = [NSMutableArray array];
    NSMutableDictionary *appList = [NSMutableDictionary dictionary];
    for (NSDictionary * str in dic) {
        NSArray * arr = [str valueForKey:@"_items"];

        for (NSDictionary *appInfoDicForLocal in arr) {
            if ([[appInfoDicForLocal valueForKey:@"obtained_from"] isEqualToString:@"apple"]) {
                continue;
            }
            
            // 获取app图片
            NSString * path = [appInfoDicForLocal valueForKey:@"path"];
            if ([path componentsSeparatedByString:@".app"].count>2) {
                continue;
            }
            NSWorkspace *wk = [NSWorkspace sharedWorkspace];
            NSImage *image = [wk iconForFile:path];
            
            NSMutableDictionary * dic = [NSMutableDictionary dictionaryWithDictionary:CheckFileDate(path)];
            [dic addEntriesFromDictionary:appInfoDicForLocal];
//            [allAppList addObject:dic];
            if ([dic[@"_name"] isEqualToString:@"infogo"]){
                
            }
            ApplicationInfo *app = [ApplicationInfo new];
            app.ApplicationName = [NSString stringWithFormat:@"%@", dic[@"_name"]];
            app.ApplicationPath = [NSString stringWithFormat:@"%@", dic[@"path"]];
            NSString *version = [NSString stringWithFormat:@"%@", dic[@"version"]];
            if (version.length < 1) {
                app.bundleVersion = @"1.0";
            }else{
                app.bundleVersion = version;
            }
            app.createTime = [NSString stringWithFormat:@"%@", dic[@"creationDate"]];
            app.iconImage = image;
            [appList setObject:app forKey:app.ApplicationPath];
        }
    }
    return appList;
}


- (NSString *)uploadString:(NSDictionary *)dicInfo
{
    NSMutableString * pString = [NSMutableString string];
    for (NSString * path in dicInfo) {
        ApplicationInfo *dic = dicInfo[path];
        
        NSString *creationDate = dic.createTime;
//        NSString *lastModified = dateToStr(dic[@"lastModified"]);
        NSString *removeDate = dic.removeTime;
        NSString * string = [NSString stringWithFormat:@"<SoftInfo><SoftName>%@</SoftName><SoftID>null</SoftID><SoftVersion>%@</SoftVersion><InstallDate>%@</InstallDate><IconName>default.icon</IconName><SoftSize>null</SoftSize><Frequency>经常</Frequency><LastUseDate>%@</LastUseDate></SoftInfo>",
                             dic.ApplicationName,
                             dic.bundleVersion,
                             creationDate,
                             removeDate];
        if ([dic.ApplicationName isEqualToString:@"testRealReachability"]) {
            
        }
        pString = [NSMutableString stringWithFormat:@"%@%@", pString, string];
    }
    return pString;
}



@end
