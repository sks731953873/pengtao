//
//  SoftwareList.h
//  Mac_1.0
//
//  Created by apple on 2016/11/8.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SoftwareList : NSObject <NSXMLParserDelegate>


/**获取每个软件的信息，返回的数组内是字典*/
+ (NSDictionary *)allAppList;


/**运行应用列表*/
+ (NSArray *)runningSoftwareList;


/**运行进程列表*/
+ (NSArray *)runningSystemProcessInfo;

/** 拼装上报软件信息*/
- (NSString *)uploadString:(NSDictionary *)array;
@end
