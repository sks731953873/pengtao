//
//  YGNetAuth.m
//  Mac_1.0
//
//  Created by apple on 2017/3/8.
//  Copyright © 2017年 infogo. All rights reserved.
//
// 拿到deviceid 之后启动socket  通过js上报软硬件信息~~~
#import "YGNetAuth.h"
#import "YGTool.h"


@implementation YGNetAuth

+ (NSString *)netRegDev6000:(NSString *)ipAddress{

//    NSString *urlString = [NSString stringWithFormat:@"http://%@/a/ajax.php?tradecode=getdeviceinfoprocess&gettype=control&depart_id=0&username=iphone&tel=&remark=iosagent&device_id=&positions=&dev_xml=%@&is_mobile=1&is_guest=0&os_platform=IOS",
//                           ipAddress,// 服务器地址
//                           getDevXml()] ;

    NSString *urlString = [NSString stringWithFormat:@"http://%@/a/ajax.php?tradecode=getdeviceinfoprocess&gettype=control&depart_id=0&username=iphone&tel=&remark=iosagent&device_id=&positions=&is_mobile=1&is_guest=0&os_platform=IOS&encode=1&dev_xml=%@", ipAddress, getDevXml()];
    NSString *pRet = httpPost(urlString);
    if ([pRet rangeOfString:@"DeviceID"].location == NSNotFound) {
        return nil;
    }
    NSString *deviceID = CutOffStringBetweenBoth(pRet, @"\"DeviceID\": '", @"',");
    return deviceID;
}



@end
