//
//  YGNetAuth.h
//  Mac_1.0
//
//  Created by apple on 2017/3/8.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YGNetAuth : NSObject
+ (NSString *)netRegDev6000:(NSString *)ipAddress;

@end
