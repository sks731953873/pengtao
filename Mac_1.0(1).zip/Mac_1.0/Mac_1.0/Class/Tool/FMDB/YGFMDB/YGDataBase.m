//
//  YGDataBase.m
//  Infogo
//
//  Created by Xin on 2017/4/14.
//  Copyright © 2017年 Infogo. All rights reserved.
//
/**
 NULL，值是NULL
 INTEGER，值是有符号整形，根据值的大小以1,2,3,4,6或8字节存放
 REAL，值是浮点型值，以8字节IEEE浮点数存放
 TEXT，值是文本字符串，使用数据库编码（UTF-8，UTF-16BE或者UTF-16LE）存放
 BLOB，二进制数据（iOS的NSData）
 */

#import "YGDataBase.h"

@interface YGDataBase ()

@end

@implementation YGDataBase

+ (YGDataBase *)shareFMDataBase{
    static YGDataBase *DB = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        DB = [[YGDataBase alloc] init];
        [DB ygQueue];
    });
    return DB;
}

- (void)ygQueue{
//    NSString *docsdir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
//    NSString *filePath = [docsdir stringByAppendingString:@"/FMDBAPP.sqlite"];
    NSString *docsdir = [kCachesDirictory stringByAppendingPathComponent:@"IMC/db"];
    NSFileManager *manager = [NSFileManager defaultManager];
    if (![manager fileExistsAtPath:docsdir]) {
        [manager createDirectoryAtPath:docsdir withIntermediateDirectories:YES attributes:nil error:nil];
    }
    NSString *filePath = [docsdir stringByAppendingPathComponent:@"FMDBBYPOLICY.sqlite"];
    _queue = [FMDatabaseQueue databaseQueueWithPath:filePath];
//    HXINFOLOG(@"filePath for FMDB = [%@]", filePath);
}
#pragma mark TOOL
- (BOOL)isHasTable:(NSString *)tableName{
    __block BOOL result = NO;
    [_queue inDatabase:^(FMDatabase *db) {
        FMResultSet *rs = [db executeQuery:@"select count(*) as 'count' from sqlite_master where type ='table' and name = ?", tableName];
        while ([rs next]) {
            // just print out what we've got in a number of formats.
            NSInteger count = [rs intForColumn:@"count"];
            if (0 == count)
            {
                result = NO;
            }
            else
            {
                result = YES;
            }
        }
    }];
    return result;
}
#pragma mark 对APP类进行数据库操作
/**
 @ qunueCreateAppTable:
 @
 @ 如果App表不存在就创建一个App表
 @ return void
 */
- (void)qunueCreateAppTable{
    NSString *createAppString = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS App(ApplicationName text, bundleVersion text, type text, identifier text, createTime text, removeTime text)"];
    
    [_queue inDatabase:^(FMDatabase *db) {
        BOOL b = [db executeUpdate:createAppString];
        HXINFOLOG(@"create Table is %@", b? @"success": @"faild");
    }];
}


/**
 @ qunueInsertAllApp:
 @ app -- YGApp
 @ 将传入的YGApp数组插入数据库
 @ return void
 */
- (void)qunueInsertAllApp:(NSArray *)apps{
    for (ApplicationInfo *app in apps) {
        [self qunueInsertApp:app];
    }
}

/**
    @ qunueInsertApp:
    @ app -- YGApp
    @ 将传入的YGApp类插入数据库
    @ return void
 */
- (void)qunueInsertApp:(ApplicationInfo *)app{
    [_queue inDatabase:^(FMDatabase *db) {
//        BOOL insert;
//        BOOL insert = [db executeUpdate:@"INSERT INTO App (App_name, bundleVersion, type, identifier, createTime, removeTime) VALUES (?,?,?,?,?,?)", app.ApplicationName, app., app.applicationType, app.applicationIdentifier, app.createTime, app.removeTime];
//        if (insert) {
//            NSLog(@"FMDB 添加成员成功!!!");
//        }else{
//            NSLog(@"FMDB 添加成员失败~~~");
//        }
    }];
}
/**
 qunueGetApp:
 @
 @从数据库内取出所有的App
 @return App组成的数组
 */
- (NSArray *)qunueGetAllApp{
    __block NSMutableArray *dataArray = nil;
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM App"];
    [_queue inDatabase:^(FMDatabase *db) {
        dataArray = [NSMutableArray array];
        FMResultSet *result = [db executeQuery:sql];
        while ([result next]) {
            // 从表单里面取
//            YGApp *app = [YGApp new];
//            app.appName = [result stringForColumn:@"App_name"];
//            app.applicationIdentifier = [result stringForColumn:@"identifier"];
//            app.applicationType = [result stringForColumn:@"type"];
//            app.bundleVersion = [result stringForColumn:@"bundleVersion"];
//            app.createTime = [result stringForColumn:@"createTime"];
//            app.removeTime = [result stringForColumn:@"removeTime"];
//            [dataArray addObject:app];
        }
        [result close];
        
    }];
    return dataArray;
}

/**
 qunueSelectApp:
 @
 @从数据库内查找该app
 @app 要查找的
 @return 返回查找到的app
 */
- (ApplicationInfo *)qunueSelectApp:(ApplicationInfo *)app{
    __block ApplicationInfo *returnApp = nil;
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM App WHERE identifier = '%@'", app.bundleID];
    [_queue inDatabase:^(FMDatabase *db) {
        returnApp = [ApplicationInfo new];
        FMResultSet *result = [db executeQuery:sql];
        if ([result next]) {
//            returnApp.appName = [result stringForColumn:@"App_name"];
//            returnApp.applicationIdentifier = [result stringForColumn:@"identifier"];
//            returnApp.applicationType = [result stringForColumn:@"type"];
//            returnApp.bundleVersion = [result stringForColumn:@"bundleVersion"];
//            returnApp.createTime = [result stringForColumn:@"createTime"];
//            returnApp.removeTime = [result stringForColumn:@"removeTime"];
        }
        
        [result close];
        
    }];
    return returnApp;
}
/**
 @ qunueDeleteApp:
 @
 @ 从数据库内删除该app
 @ app 要删除的
 @ return nil
 */
- (void)qunueDeleteApp:(ApplicationInfo *)app{
    [_queue inDatabase:^(FMDatabase *db) {
        if ([db executeUpdate:@"DELETE FROM App WHERE App_name = ?", app.ApplicationName]){
            HXINFOLOG(@"Delete [%@] success", app.ApplicationName);
        }else{
            HXINFOLOG(@"Delete [%@] faild", app.ApplicationName);
        }
    }];
}

/**
 @ qunueUpdataApp:
 @
 @ 从数据库内更新App全部信息
 @ return nil
 */
- (void)qunueUpdataApp:(ApplicationInfo *)app{
    NSString *sql;
//    NSString *sql = [NSString stringWithFormat:@"UPDATE App SET App_name = '%@', bundleVersion = '%@', type = '%@', identifier = '%@', createTime = '%@', removeTime = '%@' WHERE identifier = '%@'", app.appName, app.bundleVersion, app.applicationType, app.applicationIdentifier, app.createTime, app.removeTime, app.applicationIdentifier];
    [_queue inDatabase:^(FMDatabase *db) {
        BOOL b = [db executeUpdate:sql];
        if (b) {
//            NSLog(@"UPDATE [%@] 成功", app.appName);
        }else{
//            NSLog(@"UPDATE [%@] 失败", app.appName);
        }
    }];
}


/**
 @ qunueUpdataApp:
 @
 @ 从数据库内更新App的identifier
 @ return nil
 */
- (void)qunueUpdataAppidentifier:(ApplicationInfo *)app{
//    NSString *sql = [NSString stringWithFormat:@"UPDATE App SET App_name = '%@', bundleVersion = '%@', type = '%@' WHERE identifier = '%@'", app.appName, app.bundleVersion, app.applicationType, app.applicationIdentifier];
    NSString *sql;
    [_queue inDatabase:^(FMDatabase *db) {
        BOOL b = [db executeUpdate:sql];
        if (b) {
//            NSLog(@"UPDATE [%@] 成功", app.appName);
        }else{
//            NSLog(@"UPDATE [%@] 失败", app.appName);
        }
    }];
}
/**
 @ qunueDeleteAllApp:
 @
 @ 从数据库内删除所有的App
 @ return nil
 */
- (void)qunueDeleteAllApp{
    NSString *sqlStr = [NSString stringWithFormat:@"DELETE FROM App"];
    [_queue inDatabase:^(FMDatabase *db) {
        if (![db executeUpdate:sqlStr]) {
            HXINFOLOG(@"Erase table 失败");
        }else{
            HXINFOLOG(@"Erase table 成功");
        }
    }];
}
@end
