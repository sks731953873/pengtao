//
//  YGDataBase.h
//  Infogo
//
//  Created by Xin on 2017/4/14.
//  Copyright © 2017年 Infogo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDB.h"
#import "ApplicationInfo.h"
@interface YGDataBase : NSObject

@property (nonatomic, strong) FMDatabase *dataBase;
@property (nonatomic, strong) FMDatabaseQueue *queue;

+ (YGDataBase *)shareFMDataBase;

/**
 @ qunueCreateAppTable:
 @
 @ 如果App表不存在就创建一个App表
 @ return void
 */
- (void)qunueCreateAppTable;

/**
 @ qunueInsertAllApp:
 @ app -- YGApp
 @ 将传入的YGApp数组插入数据库
 @ return void
 */
- (void)qunueInsertAllApp:(NSArray *)apps;

/**
 @ qunueInsertApp:
 @ app -- YGApp
 @ 将传入的单个YGApp类插入数据库
 @ return void
 */
- (void)qunueInsertApp:(ApplicationInfo *)app;

/**
 @ qunueGetApp:
 @
 @ 从数据库内取出所有的App
 @ return App组成的数组
 */
- (NSArray *)qunueGetAllApp;
/**
 @ qunueSelectApp:
 @
 @ 从数据库内查找该app
 @ app 要查找的
 @ return 返回查找到的app
*/
- (ApplicationInfo *)qunueSelectApp:(ApplicationInfo *)app;


/**
 @ qunueUpdataApp:
 @
 @ 从数据库内更新App
 @ return nil
 */
- (void)qunueUpdataApp:(ApplicationInfo *)app;

/**
 @ qunueUpdataApp:
 @
 @ 从数据库内更新App的identifier
 @ return nil
 */
- (void)qunueUpdataAppidentifier:(ApplicationInfo *)app;


/**
 @ qunueDeleteApp:
 @
 @ 从数据库内删除该app
 @ app 要删除的
 @ return nil
 */
- (void)qunueDeleteApp:(ApplicationInfo *)app;

/**
 @ qunueDeleteAllApp:
 @
 @ 从数据库内删除所有的App
 @ return nil
 */
- (void)qunueDeleteAllApp;

#pragma mark TOOL
- (BOOL)isHasTable:(NSString *)tableName;

@end
