//
//  HardwareAssets.h
//  Mac_1.0
//
//  Created by apple on 2016/11/7.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HardwareAssets : NSObject
/**第一次上报硬件信息报文*/
+ (NSString * )HardwareData;

/**返回IP地址*/
NSString *getIPAddress(void);
/**返回UUID*/
NSString* GetUUID(void);
/**返回MAC地址*/
NSString *getMacStr(void);
/**软件信息概述*/
- (void)getMACInfo;
/**获取cpu*/
NSString *GetCPU(void);
/**获取mark*/
NSString *GetMark(void);
NSString *GetMarkForMainThread(void);


NSString *GetModel(void);
NSString *GetRAM(void);
/*
    路由信息
 */
- (struct ifaddrs *)routerIp;
@end
