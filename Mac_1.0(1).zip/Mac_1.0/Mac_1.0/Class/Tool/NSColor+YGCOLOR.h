//
//  NSColor+YGCOLOR.h
//  Mac_1.0
//
//  Created by apple on 2016/11/7.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSColor (YGCOLOR)
#pragma mark - 颜色转换 IOS中十六进制的颜色转换为UIColor
+ (NSColor *) colorWithHexString: (NSString *)color;
/**返回特定的蓝色*/
+ (NSColor *)YGBlueColor;//0066CA
@end
