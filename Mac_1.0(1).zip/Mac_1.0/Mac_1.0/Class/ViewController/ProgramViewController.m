//
//  ProgramViewController.m
//  Mac_1.0
//
//  Created by apple on 2017/4/13.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import "ProgramViewController.h"

@interface ProgramViewController ()

@end

@implementation ProgramViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
}

@end
