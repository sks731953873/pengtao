	//
//  SetViewController.m
//  Mac_1.0
//
//  Created by huhood on 16/12/12.
//  Copyright (c) 2016年 infogo. All rights reserved.
//

#import "SetViewController.h"
#import "YGTool.h"
#import "YGFileDefault.h"
@interface SetViewController () <NSTableViewDelegate, NSTableViewDataSource>
{
    id _event;
#pragma mark NSTableView
    NSScrollView *_tableContainerView;
    BOOL isOpenUnInstallKey;// 是否弹出万能卸载码输入弹窗
    BOOL isProgressAlert;
}
@property (weak) IBOutlet NSButton *StartingUp;
@property (weak) IBOutlet NSButton *AutomaticBut;
@property (weak) IBOutlet NSTextField *addressText;

@property (weak) IBOutlet NSButton *chkLvDebug;
@property (weak) IBOutlet NSButton *chkLvErr;

@property (nonatomic, strong) NSAlert *save_alert;
@property (nonatomic, strong) NSAlert *clear_alert;
@property (nonatomic, strong) NSMutableArray *dataSourceArray;
@property (nonatomic, strong) NSMutableArray *fileDataSourceArray;

@end

@implementation SetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSNotificationCenter * notifi = [NSNotificationCenter defaultCenter];
    [notifi addObserver:self selector:@selector(notificationCancelAlertTo) name:@"progressCancelAlert" object:nil];

//    self.view.translatesAutoresizingMaskIntoConstraints = YES;
//    self.view.layer.masksToBounds = NO;
    [self.view setWantsLayer:YES];
    self.view.layer.backgroundColor = [NSColor whiteColor].CGColor;
    self.preferredContentSize = NSMakeSize(340, 700); // 固定大小 设置了就不可拉伸
//    [self.view.window center];
//    [self window]
    NSString *server_ip = readFile(kServerAddress);
    if (server_ip.length > 4) {
        _addressText.placeholderString = server_ip;
    }else{
        NSString * ipDefault = readFile(@"ipDefault");
        if (ipDefault.length > 4) {
            self.addressText.placeholderString = ipDefault;
        }else{
            self.addressText.placeholderString = @"请输入服务器地址";
        }
    }
    
    [self loadData];
    [self initLogLvData];// 加载日志信息
}
#pragma mark  保存
/**保存*/
- (IBAction)saveButtonClick:(id)sender {
    NSUserDefaults * _userDefalts = [NSUserDefaults standardUserDefaults];
    NSArray * addressTextArr = [_addressText.stringValue componentsSeparatedByString:@"debug"];
    NSString * addressStr;
    if([addressTextArr count] == 2){
        addressStr = addressTextArr[1];
        [_userDefalts setObject:@"debug" forKey:@"debug"];
    }else{
        addressStr = _addressText.stringValue;
        [_userDefalts setObject:@"" forKey:@"debug"];
    }
    [_userDefalts synchronize];
    
    _save_alert = [[NSAlert alloc] init];
    // 不存在端口号则判断addressStr是否为标准的ip
    addressStr = [addressStr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (addressStr.length > 1)
    {// 正确的ip
        if (self.StartingUp.state) {
            [self addAppAsLoginItem];// 开机自启
        }else{
            [self deleteAppFromLoginItem];//  取消开机自启
        }
        if (_chkLvErr.state)
            writeFile(@"errLog", @"LogLvl");
        else if (_chkLvDebug.state)
            writeFile(@"debugLog", @"LogLvl");
        else
            writeFile(@"infoLog", @"LogLvl");
        
        writeFile(addressStr, kServerAddress);
        NSString *ipDefault = ReadFileDefault();
        if (ipDefault.length < 0) {
            [YGFileDefault WriteFileDefault:ipDefault];
        }
        writeFile(self.AutomaticBut.stringValue, @"Automatic");
        writeFile(self.StartingUp.stringValue, @"StartingUp");
        [_save_alert addButtonWithTitle:@"保存成功"];
        [_save_alert setMessageText:@"成功"];
        [_save_alert setInformativeText:@"保存成功!"];
        [_save_alert setAlertStyle:NSInformationalAlertStyle];
        
    }else{
        [_save_alert addButtonWithTitle:@"确认"];
        //    [alert addButtonWithTitle:@"Cancel"];
        [_save_alert setMessageText:@"提示"];
        [_save_alert setInformativeText:@"所填信息错误，请填写正确格式的服务器地址。"];
        [_save_alert setAlertStyle:NSWarningAlertStyle];
    }
    [_save_alert runModal];
    _save_alert = nil;
//    [_save_alert beginSheetModalForWindow:[NSApp keyWindow] completionHandler:^(NSModalResponse returnCode) {}];
}

//响应Sheet的按钮事件
- (void)alertSheetDidEnd:(NSAlert *)alert returnCode:(NSInteger)returnCode
{
    NSLog(@"%@", alert.messageText);
    if (returnCode == 1)
    {
        NSLog(@"alternateButton clicked!");
        exit(0);
        //  下面的有二级页面就会失败
        //        NSApplication *app = [NSApplication sharedApplication];
        //        [app terminate:self];
    }
    else if(returnCode == 0)
    {
        NSLog(@"点击了返回，所以什么事都不做");
    }
}
#pragma mark 返回
/**返回*/
- (IBAction)backButton:(id)sender {
    if (_event) {
        [NSEvent removeMonitor:_event];
        _event = nil;
    }
//    [self dismissController:nil];
    [self dismissController:self];
}
#pragma mark 清除网页缓存
- (IBAction)clear:(id)sender {
    writeFile(@"", kServerAddress);
    NSString *libraryDir = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES)[0];
    NSString *bundleId  =  [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleIdentifier"];
    NSString *webkitFolderInLib = [NSString stringWithFormat:@"%@/WebKit",libraryDir];
    NSString *webKitFolderInCaches = [NSString
                                      stringWithFormat:@"%@/Caches/%@",libraryDir,bundleId];
    NSString *webKitFolderInCachesfs = [NSString
                                        stringWithFormat:@"%@/Caches/%@/fsCachedData",libraryDir,bundleId];
    
    NSError *error;
    NSFileManager *fm = [NSFileManager defaultManager];
    /* iOS8.0 WebView Cache的存放路径 */
    if ([fm fileExistsAtPath:webKitFolderInCaches]){
        [fm removeItemAtPath:webKitFolderInCaches error:&error];
        NSLog(@" webKitFolderInCaches file path = [%@]", webKitFolderInCaches);
    }
    
    if ([fm fileExistsAtPath:webkitFolderInLib]){
        [[NSFileManager defaultManager] removeItemAtPath:webkitFolderInLib error:nil];
        
        NSLog(@"webKitFolderInLib file path = [%@]", webkitFolderInLib);
    }
    
    /* iOS7.0 WebView Cache的存放路径 */
    if ([fm fileExistsAtPath:webKitFolderInCachesfs]){
        [[NSFileManager defaultManager] removeItemAtPath:webKitFolderInCachesfs error:&error];
    
        NSLog(@" webKitFolderInCachesfs file path = [%@]", webKitFolderInCachesfs);
    }
    
    if ([self.addressText.stringValue isEqualToString:@"clear"]){
        NSString*appDomain = [[NSBundle mainBundle] bundleIdentifier];
        [[NSUserDefaults standardUserDefaults] removePersistentDomainForName:appDomain];
    }
    
    [self loadData];
    
    self.clear_alert = [[NSAlert alloc] init];
    [self.clear_alert addButtonWithTitle:@"确认"];
    [self.clear_alert setMessageText:@"提示"];
    [self.clear_alert setInformativeText:@"缓存已清除"];
    [self.clear_alert setAlertStyle:NSWarningAlertStyle];
    [self.clear_alert beginSheetModalForWindow:[NSApp keyWindow] completionHandler:^(NSModalResponse returnCode) {
        
    }];
}


- (void)loadData
{
    NSString * ip = readFile(kServerAddress);
    if (ip) {
        self.addressText.stringValue = ip;
    }
    
    self.StartingUp.state = [readFile(@"StartingUp") isEqualToString:@"1"];
    self.AutomaticBut.state = [readFile(@"Automatic") isEqualToString:@"1"];
}

#pragma mark 开机启动代码

- (void)addAppAsLoginItem{
    NSString * appPath = [[NSBundle mainBundle] bundlePath];
    //获取程序的路径
    // 比如, /Applications/test.app
    CFURLRef url = (__bridge CFURLRef)[NSURL fileURLWithPath:appPath];
    // 创建路径的引用
    // 我们只为当前用户添加启动项,所以我们用kLSSharedFileListSessionLoginItems
    // 如果要为全部用户添加,则替换为kLSSharedFileListGlobalLoginItems
    LSSharedFileListRef loginItems = LSSharedFileListCreate(NULL,                                                      kLSSharedFileListSessionLoginItems, NULL);
    if (loginItems) {
        //将项目插入启动表中.
        LSSharedFileListItemRef item = LSSharedFileListInsertItemURL(loginItems,                                                      kLSSharedFileListItemLast, NULL, NULL, url, NULL, NULL);
        if (item){
            CFRelease(item);
        }
    }
    if (loginItems){
        CFRelease(loginItems);
    }
}

-(void) deleteAppFromLoginItem{
    NSString * appPath = [[NSBundle mainBundle] bundlePath];
    //获取程序的路径
    // 比如, /Applications/test.app
    CFURLRef url = nil;
//    = (__bridge CFURLRef)[NSURL fileURLWithPath:appPath];
    // 创建引用.
    LSSharedFileListRef loginItems = LSSharedFileListCreate(NULL, kLSSharedFileListSessionLoginItems, NULL);
    if (loginItems) {
        UInt32 seedValue;
        //获取启动项列表并转换为NSArray,这样方便取其中的项
        NSArray  *loginItemsArray = (__bridge_transfer NSArray *)LSSharedFileListCopySnapshot(loginItems, &seedValue);
        for(int i = 0 ; i< [loginItemsArray count]; i++){
            LSSharedFileListItemRef itemRef = (__bridge LSSharedFileListItemRef)loginItemsArray[i];
            //用URL来解析项
            CFErrorRef error = nil ;
            url = LSSharedFileListItemCopyResolvedURL(itemRef, 0, &error);
            NSString * urlPath = [(__bridge_transfer NSURL*)url path];
            if (urlPath.length > 0) {
//            if (LSSharedFileListItemResolve(itemRef, 0, (CFURLRef*) &url, NULL) == noErr) {
                if ([urlPath compare:appPath] == NSOrderedSame){
                LSSharedFileListItemRemove(loginItems,itemRef);                             }
            }
            
        }

//        for(id itemRef in loginItemsArray){
//            if (LSSharedFileListItemResolve((__bridge LSSharedFileListItemRef)itemRef, 0, (CFURLRef*) &url, NULL) == noErr) {
//                NSString * urlPath = [(__bridge NSURL*)url path];
//                if ([urlPath compare:appPath] == NSOrderedSame){
//                    LSSharedFileListItemRemove(loginItems,(__bridge LSSharedFileListItemRef)(itemRef));
//                }
//            }
//        }
    }

}


-(void)awakeFromNib{
    [super awakeFromNib];
    // 监听键盘
    __weak typeof(self) weakSelf = self;
    _event = [NSEvent addLocalMonitorForEventsMatchingMask:NSEventMaskKeyDown handler:^NSEvent * _Nullable(NSEvent * _Nonnull aEvent) {
        __strong typeof(weakSelf) strongSelf = weakSelf;

        if (aEvent.keyCode == 36 || aEvent.keyCode == 76){
            if (strongSelf.save_alert) {
                [NSApp endSheet:[strongSelf.save_alert window]];
                [[strongSelf.save_alert window]orderOut:nil];
                strongSelf.save_alert = nil;
                NSLog(@"1");
            }else if (strongSelf.clear_alert){
                [NSApp endSheet:[strongSelf.clear_alert window]];
                [[strongSelf.clear_alert window] orderOut:nil];
                strongSelf.clear_alert = nil;
                NSLog(@"2");
            }else if (strongSelf.dataSourceArray!=nil || isOpenUnInstallKey|| isProgressAlert
                      ){
                return aEvent;
            }else {
                [strongSelf saveButtonClick:nil];
                NSLog(@"3");
                return nil;
            }
        }
        return aEvent;//返回事件，让事件继续传递
    }];
    
}
#pragma mark 万能卸载码
- (IBAction)UniversalUnloadCode:(id)sender {
    NSAlert *alert = [NSAlert new];
    [alert addButtonWithTitle:@"确定"];
    [alert addButtonWithTitle:@"取消"];
    [alert setMessageText:@"停用安全策略"];
//    [alert setInformativeText:@"如果确定删除，删除的文本不能再找回!"];
    [alert setAlertStyle:NSInformationalAlertStyle];
    NSTextField *textField = [[NSTextField alloc] initWithFrame:CGRectMake(110, 50, 100, 20)];
    textField.stringValue = @"";
    textField.placeholderString = @"请输入";
    textField.font = [NSFont systemFontOfSize:12.0f];
    textField.editable = YES;
    textField.textColor = [NSColor blackColor];
    textField.drawsBackground = YES;
    textField.bordered = YES;
    textField.focusRingType = NSFocusRingTypeNone;
    textField.translatesAutoresizingMaskIntoConstraints = YES;
    [[[alert window] contentView] addSubview:textField];
    isOpenUnInstallKey = YES;
    [alert beginSheetModalForWindow:[self.view window] completionHandler:^(NSModalResponse returnCode) {
        if(returnCode == NSAlertFirstButtonReturn){
            NSString *tString = textField.stringValue.length > 0? textField.stringValue: @"";
            NSString *wnxzm = readFile(@"UnInstallKey");
            if (tString.length > 0 && ([tString isEqualToString:wnxzm]||[YGTool isUnInstallKey:tString])) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    // 发送通知 告知停止所有策略
                    NSNotification *notification1 = [NSNotification notificationWithName:@"releasePolicyTimer" object:nil];
                    [[NSNotificationCenter defaultCenter] postNotification:notification1];
                    NSNotification* notification2 = [NSNotification notificationWithName:@"RecvReportSendMsg" object:@"停用安全策略已生效"];
                    writeFile(@"", @"PolicyTime");
                    writeFile(@"", @"sysPolicyTime");
                    [[NSNotificationCenter defaultCenter] postNotification:notification2];
                });
                save_local_Log(@"UnInstallKey", @"停用安全策略输入正确，停止策略通知");
            }else {
                dispatch_async(dispatch_get_main_queue(), ^{
                    NSNotification* notification = [NSNotification notificationWithName:@"RecvReportSendMsg" object:@"停用安全策略输入错误,请重试"];
                    [[NSNotificationCenter defaultCenter] postNotification:notification];
                });
            }
        }else if(returnCode == NSAlertSecondButtonReturn){
            NSLog(@"停用安全策略点击返回");
        }
        self->isOpenUnInstallKey = NO;
    }];
}
#pragma mark 上传日志
- (IBAction)uploadLogFile:(id)sender {
    
    // 生成数据源
    NSString *documentDirectory = kCachesDirictory;
    //定义记录文件全名以及路径的字符串filePath
    NSString *filePath = [documentDirectory stringByAppendingPathComponent:@"/IMC"];
    // 日志的目录路径
    NSString *basePath = [NSString stringWithFormat:@"%@/Logs/",filePath];
    NSError *error = nil;
    NSArray* files = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:basePath error:&error];
    _fileDataSourceArray = [NSMutableArray array];
    _dataSourceArray = [NSMutableArray array];
    for (NSString * file in files) {
        if (XInclusionRelationshipExists(file, @".log")) {
            [_fileDataSourceArray addObject:file];
        }
    }
    _fileDataSourceArray = [NSMutableArray arrayWithArray:[_fileDataSourceArray sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        return [obj1 compare:obj2];
    }]];
    // 1.点击上传日志，显示本地日志目录
    [self createAlert];
    // 2.获取勾选列表
    // 3.将列表穿入logmanager类 上传服务器


}


- (void)initTableView{
    if (_tableContainerView) {
        _tableContainerView = nil;
    }
    // create a table view and a scroll view
    _tableContainerView = [[NSScrollView alloc] initWithFrame:NSMakeRect(30, 50, 250, 200)];
    _tableContainerView.horizontalScrollElasticity = NSScrollElasticityNone;
    _tableContainerView.verticalScrollElasticity = NSScrollElasticityNone;
    NSTableView * tableView = [[NSTableView alloc] initWithFrame:NSMakeRect(0, 0, 200, 200)];

    // create columns for our table
    NSTableColumn * column1 = [[NSTableColumn alloc] initWithIdentifier:@"Col1"];
    NSTableColumn * column2 = [[NSTableColumn alloc] initWithIdentifier:@"Col2"];
    [column1 setWidth:198];
    column1.maxWidth = 198;
    column1.minWidth = 198;
    [column2 setWidth:45];
    column2.maxWidth = 45;
    NSString *lang = getPreferredLanguage();
    if([lang rangeOfString:@"zh-Hant"].location != NSNotFound || [lang rangeOfString:@"zh-Hans"].location != NSNotFound){
        // 当系统语言是中文或繁体中文时
        [column1 setTitle:@"文件名称"];
        [column2 setTitle:@""];
    }else{
        //其它语言的情况下
        [column1 setTitle:@"file Name"];
        [column2 setTitle:@""];
    }
    // generally you want to add at least one column to the table view.
    [tableView addTableColumn:column1];
    [tableView addTableColumn:column2];
    [tableView setDelegate:self];
    [tableView setDataSource:self];
    [tableView reloadData];
    // embed the table view in the scroll view, and add the scroll view to our window.
    [_tableContainerView setDocumentView:tableView];

    [_tableContainerView setHasVerticalScroller:YES];
}

#pragma mark tableView代理
-(NSInteger)numberOfRowsInTableView:(NSTableView *)tableView{
//    NSLog(@"setviewcontroller cell num  = %ld", _dataSourceArray.count);
    return _fileDataSourceArray.count;
}

/** 点击cell是否可选中， NO不可选中，即无反应*/
- (BOOL)tableView:(NSTableView *)tableView shouldSelectRow:(NSInteger)row {
    return NO;
}
-(id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    return nil;
}
- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row{
    return 58;
}
- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    NSString *strIdt=[tableColumn identifier];
    NSTableCellView *aView = [tableView makeViewWithIdentifier:strIdt owner:self];
    if (!aView)
        aView = [[NSTableCellView alloc]initWithFrame:CGRectMake(0, 0, tableColumn.width, 58)];
    else
        for (NSView *view in aView.subviews)[view removeFromSuperview];


    if ([strIdt isEqualToString:@"Col1"]) {
        NSTextField *textField = [[NSTextField alloc] initWithFrame:CGRectMake(15, 20, 200, 17)];
        textField.stringValue = [NSString stringWithFormat:@"%@",_fileDataSourceArray[row]];
        textField.font = [NSFont systemFontOfSize:12.0f];
        textField.editable = NO;
        textField.textColor = [NSColor blackColor];
        textField.drawsBackground = NO;
        textField.bordered = NO;
        textField.focusRingType = NSFocusRingTypeNone;
        textField.translatesAutoresizingMaskIntoConstraints = YES;
        [aView addSubview:textField];
    }else{
        NSButton *switchButton = [[NSButton alloc] initWithFrame:CGRectMake(10, 20, 50, 17)];
        switchButton.title = @"";
        [switchButton setButtonType:NSButtonTypeSwitch];
        [switchButton setTarget:self];
        [switchButton setAction:@selector(switchButtonClick:)];
        switchButton.tag = row;
        [aView addSubview:switchButton];
    }
    return aView;
}

- (void)switchButtonClick:(NSButton *)sender {
    if (sender.state == 1) {
        [_dataSourceArray addObject:_fileDataSourceArray[sender.tag]];
    }else {
        [_dataSourceArray removeObject:_fileDataSourceArray[sender.tag]];
    }
}
- (void)createAlert{
    [self initTableView];
    NSString *messageTitle = @"IMC";
    NSString *defaultButtonTitle = @"cancel";
    NSString *alternateButtonTitle = @"upload";
    NSString *lang = getPreferredLanguage();
    if([lang rangeOfString:@"zh-Hant"].location != NSNotFound || [lang rangeOfString:@"zh-Hans"].location != NSNotFound){
        // 当系统语言是中文或繁体中文时
        defaultButtonTitle = @"关闭";
        alternateButtonTitle = @"上传";
    }else{
        //其它语言的情况下
        defaultButtonTitle = @"cancel";
    }
    NSAlert *alert = [NSAlert new];
    [alert setMessageText:messageTitle];
    [alert addButtonWithTitle:defaultButtonTitle];
    [alert addButtonWithTitle:alternateButtonTitle];

    [alert setAlertStyle:NSAlertStyleWarning];
    //    NSImage *icon = [NSImage imageNamed:@"icon.png"];
    //    [alert setIcon:icon];
    [alert layout];
    NSPanel *panel = (NSPanel *)[alert window];

    NSView* contentView = [panel contentView];
    // Get original sizes
    NSRect rect2 = NSMakeRect(0, 0, _tableContainerView.frame.size.width+50, _tableContainerView.frame.size.height+200);
    [panel setFrame:rect2 display:YES];
//    NSTableView *accessoryView = [[NSTableView alloc] init];
//    // accessoryView为要添加的NSTableView
//    [accessoryView setFrame:rect2];
    [contentView addSubview:_tableContainerView];
    NSWindow *win = [self.view window];
    [alert beginSheetModalForWindow:win completionHandler:^(NSModalResponse returnCode) {
        if (returnCode == NSAlertFirstButtonReturn) {
            // 点击关闭close cancel
            self.dataSourceArray = nil;
            self.fileDataSourceArray = nil;
        }else {
            // 点击提交upload
            if (self.dataSourceArray.count > 0) {
                self->isProgressAlert = YES;
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
                    [[LogManager sharedInstance] clientUploadFiles:self.dataSourceArray];
                    self.dataSourceArray = nil;
                    self.fileDataSourceArray = nil;
                });
            }
        }


    }];
}
// 进度条弹窗通知
- (void)notificationCancelAlertTo {
    isProgressAlert = NO;
}


#pragma mark 日志级别设置

- (IBAction)checkChangeLvState:(id)sender {
    NSButton *button = (NSButton *)sender;
    if (button.tag == 201) {
        if(!button.state)
        _chkLvErr.state = button.state;
    } else {
        if (button.state)
        _chkLvDebug.state = button.state;
    }


}

-(void)initLogLvData {
    NSString *logLvl = readFile(@"LogLvl");
    if ([logLvl isEqualToString:@"debugLog"]){
        // 调试级别
        
        _chkLvDebug.state = 1;
        _chkLvErr.state = 0;
    }
    else if ([logLvl isEqualToString:@"errLog"])
    {
        // 错误级别
        [self.chkLvDebug setState:1];
        [self.chkLvErr setState:1];
    }
}

@end
