//
//  YGPopViewController.h
//  Mac_1.0
//
//  Created by xin on 2019/3/10.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface YGPopViewController : NSViewController
@property (weak) IBOutlet NSTextField *message;

@property (nonatomic, copy) NSString *pop_message;

- (NSRect)getPop_messageLength;
- (NSRect)getStringLength:(NSString *)string ;

@end

NS_ASSUME_NONNULL_END
