//
//  YGPopViewController.m
//  Mac_1.0
//
//  Created by xin on 2019/3/10.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "YGPopViewController.h"

@interface YGPopViewController ()

@end

@implementation YGPopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
//    self.message.stringValue = self.pop_message;
    [self setPop_message:self.pop_message];
}

- (void)setPop_message:(NSString *)pop_message {
    if (pop_message) {
        _pop_message = pop_message;
        if (_message) {
//            NSRect rect = [self getStringLength:pop_message];
//            [_message sizeToFit];
//            [self.view.window setContentSize:rect.size];
            _message.stringValue = pop_message;

        }
    }
}

- (NSRect)getPop_messageLength {
    if (_pop_message) {
        return [self getStringLength:_pop_message];
    }
    return NSMakeRect(0, 0, 0, 0);
}
- (NSRect)getStringLength:(NSString *)string {
    NSDictionary *attributes = @{NSFontAttributeName:[NSFont systemFontOfSize:15],};
    NSRect textSize =[string boundingRectWithSize:NSMakeSize(MAXFLOAT, 100) options:NSStringDrawingTruncatesLastVisibleLine attributes:attributes context:nil];
    return textSize;
}

@end
