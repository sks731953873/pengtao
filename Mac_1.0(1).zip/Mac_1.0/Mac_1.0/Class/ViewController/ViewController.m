      //
//  ViewController.m
//  Mac_1.0
//
//  Created by apple on 2016/11/7.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import "ViewController.h"
#import "SetViewController.h"
#import <WebKit/WebKit.h>

#import "CommonFunc.h"
#import "NSColor+YGCOLOR.h"
#import "YGButton.h"
#import "YGTool.h"
#import "Singleton.h"
#import "HardwareAssets.h"
#import "YGMessageSplicing.h"
#import "YGFileDefault.h"
#import "YGNetHttpRequestObject.h"
#import "SoftwareList.h"
#pragma mark 策略
#import "YGAppItemList.h"
#import "YGAppRecordModel.h"
#import "YGWifiItemList.h"
#import "YGWifiRecordModel.h"
#import "YGPolicyItem.h"
#import "FSEventsListener.h"
#import "YGFileRecordModel.h"
#import "YGFileItemList.h"
#import "YGInternetBehaviorRecordModel.h"
#import "YGInternetBehaviorItemList.h"
#import "MyWebView.h"
#import <JavaScriptCore/JavaScriptCore.h>
#pragma mark af upload // 暂时不会用到
#import "YGNetAuthModel.h"
#import "WebJSInteractive.h"
#define VIEWRECT self.view.frame
#import "YGDownloadRequestObject.h"
#import "USBManager.h" // 新增USB管控
#import "USBRegisteredWindowController.h"

#import "USBInfoWindowController.h"
#import "USBRegistedWaitWindowController.h"

#define NotificationLock CFSTR("com.apple.springboard.lockcomplete")
#define NotificationLockChange CFSTR("com.apple.springboard.lockstate")
#define NotificationPwdUI CFSTR("com.apple.springboard.hasBlankedScreen")
#define NotificationNetwork_Change CFSTR("com.apple.system.config.network_change")


#define HXgbkEncoding CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000)

@interface ViewController ()<WKUIDelegate, WKNavigationDelegate, NSUserNotificationCenterDelegate, NSTableViewDelegate, NSTableViewDataSource, WKScriptMessageHandler>
{
    NSString * requestString;
    NSString * serialString;
    NSProgressIndicator *activityIndicator;
    NSView * backView;
#pragma mark tableView
    NSMutableArray *_dataSourceArray;
    NSScrollView *_tableContainerView;
    
    NSMutableDictionary *dicForAlertInfo;
}
@property (nonatomic, strong) Singleton * ygSingleton;

@property (nonatomic, strong) NSTimer        *SocketTimer;
@property (nonatomic, strong) NSTimer        *policyTimer;
/** 上网行为管控的计时器*/
@property (nonatomic, strong) NSTimer        *InterTimer;
@property (nonatomic, strong) MyWebView      *mainWebView;
@property (nonatomic, copy)   NSString       *ipAddress;
@property (nonatomic, strong) FSEventsListener *yListener;
/** USB监听管理*/
@property (nonatomic, strong) USBManager     *usbManager;
/**是否要上报设备信息*/
@property (nonatomic, assign) BOOL           isRequestDeverMsg;// 第一次上报流程，可能有问题
/** 显示程序黑白名单违规软件的弹窗*/
@property (nonatomic, strong) NSAlert        *alert;

@property (nonatomic, strong) HXWindowControllerCollection *WindowControllerCollection;
@property (nonatomic, strong) USBInfoWindowController *usbInfoWindowController;
/** 审核提示等待窗口*/
@property (nonatomic, strong) USBRegistedWaitWindowController *rwController;
@end

@implementation ViewController
static YGPolicyItem * hYGPolicyItem = nil;
static YGFileRecordModel * hYGFileRecordModel = nil;
static YGInternetBehaviorRecordModel * hYGInternetBehaviorRecordModel = nil;
static long long dateForWiFi;// wifi变动时间节点
static char *myObserver = "anObserver";

- (void)timerFired:(NSTimer *)sender
{
    if ([NSThread isMainThread]) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [[Singleton shareInstancetype] longConnectToSocket];
        });
    }else{
        [[Singleton shareInstancetype] longConnectToSocket];
    }
}

- (void)viewWillAppear
{
    [super viewWillAppear];
    NSString * ip = readFile(kServerAddress);
    NSString * ipDefault = readFile(@"ipDefault");
    if ((ip.length < 1) && (ipDefault.length < 1))
    {
        SetViewController * setvc = [[SetViewController alloc] init];
        [self presentViewControllerAsSheet:setvc];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
//    NSUserDefaults *defatluts = [NSUserDefaults standardUserDefaults];
//    NSDictionary *dictionary = [defatluts dictionaryRepresentation];
//    for(NSString *key in [dictionary allKeys]){
//        [defatluts removeObjectForKey:key];
//
//    }
//    [defatluts synchronize];
    self.ygSingleton = [Singleton shareInstancetype];
    self.isRequestDeverMsg = false;
    [[[HardwareAssets alloc] init] getMACInfo];
    [self createNotificationCenter];
    [self createUI];
    [self createNewWKWebView];
    //    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
//                                    NULL,
//                                    onNotifyCallback,
//                                    NotificationLock,
//                                    NULL,
//                                    CFNotificationSuspensionBehaviorDeliverImmediately);
//    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
//                                    NULL,
//                                    onNotifyCallback,
//                                    NotificationLockChange,
//                                    NULL,
//                                    CFNotificationSuspensionBehaviorDeliverImmediately);
//    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
//                                    NULL,
//                                    onNotifyCallback,
//                                    NotificationPwdUI,
//                                    NULL,
//                                    CFNotificationSuspensionBehaviorDeliverImmediately);
    [self createSocket];
    __weak typeof(self)wSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        __strong typeof(wSelf)sSelf = self;
        dispatch_async(dispatch_get_main_queue(), ^{
            [sSelf createNSTimerForHeart]; //计时器创建放在主线程
        });
    });

}


#pragma mark  启动程序后就通过http注册设备->获取deviceid->建立socket连接->通过socket发送心跳报文->目前还去服务器获取策略项
/**
    启动程序后就通过http注册设备->获取deviceid->建立socket连接->通过socket发送心跳报文->目前还去服务器获取策略项
 */
- (void)socketOfAppStart{
    __weak typeof(self) weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        //http获取deviceid 如果能获取到 就直接开启心跳 如果不能就在认证之后在webview的回执中去获取
        NSString *httpPath = [NSString stringWithFormat:@"http://%@/a/ajax.php?tradecode=getdeviceinfoprocess&gettype=control&depart_id=0&username=MacOS&tel=&remark=MacOSagent&device_id=&positions=&is_mobile=1&is_guest=0&os_platform=MacOS&encode=1&type_ext=MacOS&dev_xml=%@",
                              readFile(kServerAddress),
                              getDevXml()];
        httpPost(httpPath);// 尝试去获取deviceid
        // socket
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        dispatch_async(queue, ^{
            [strongSelf.ygSingleton firstUploadHardware];
        });
        dispatch_async(queue, ^{
            [strongSelf.ygSingleton firstUploadSoftInfo];
        });
        dispatch_async(queue, ^{
            // 连接socket之后就主动获取策略项
            [strongSelf.ygSingleton GetAgentPolicyList];
            [strongSelf.ygSingleton recvGetDeviceProperty];
        });
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0f*NSEC_PER_SEC)),dispatch_get_main_queue(), ^{
        [YGTool appleScriptClearArpTable];
    });
}

- (void)createNotificationCenter {
    NSNotificationCenter * notifi = [NSNotificationCenter defaultCenter];
    [notifi addObserver:self selector:@selector(aNotificationHandler:) name:@"RecvReportSendMsg" object:nil];
    [notifi addObserver:self selector:@selector(createSocket) name:@"createSocket" object:nil];
    [notifi addObserver:self selector:@selector(ipAddressChanged:) name:NSUserDefaultsDidChangeNotification object:nil];
    // 策略检查通知
    [notifi addObserver:self selector:@selector(CheckViolationHandling:) name:@"ViolationHandling" object:nil];
    [notifi addObserver:self selector:@selector(releasePolicyTimer:) name:@"releasePolicyTimer" object:nil];
    // 黑白程序名单违规锁屏lockForAlert------展示Alert弹窗
    [notifi addObserver:self selector:@selector(lockForAlert:) name:@"lockForAlert" object:nil];
    [notifi addObserver:self selector:@selector(cancelAlert) name:@"cancelAlert" object:nil];
    [notifi addObserver:self selector:@selector(sleepMethod:) name:@"sleepMethod" object:nil];
    // 锁屏监听
    //屏幕解锁
    [[NSDistributedNotificationCenter defaultCenter] addObserver:self
                                                        selector:@selector(sleepMethod:)
                                                            name:@"com.apple.screenIsUnlocked"
                                                          object:nil];
    //从睡眠中唤醒
    [[[NSWorkspace sharedWorkspace] notificationCenter] addObserver:self
                                                           selector:@selector(sleepMethod:)
                                                               name:NSWorkspaceDidWakeNotification
                                                             object:nil];
    // USB注册通知
    [notifi addObserver:self selector:@selector(createUsbDeviceRegistration:) name:@"UsbDeviceRegistration" object:nil];
    [notifi addObserver:self selector:@selector(createUSBInfoWindowControllerWithModel:) name:@"createUSBInfoWindowController" object:nil];
    [notifi addObserver:self selector:@selector(openUSBRegistedWaitWindowController:) name:@"openUSBRegistedWaitWindowController" object:nil];
}


- (void)createUI {
    NSView * view = [[NSView alloc] initWithFrame:NSMakeRect(VIEWRECT.origin.x, VIEWRECT.size.height - 64, VIEWRECT.size.width, 64)];
    [view setWantsLayer:YES];// 要先开启才能设置背景颜色
    view.layer.backgroundColor = [NSColor YGBlueColor].CGColor;

    YGButton * setButton = [[YGButton alloc] initWithFrame:NSMakeRect(VIEWRECT.size.width - 70, 17, 60, 30)];
    setButton.backgroundColor = [NSColor YGBlueColor];
    setButton.title = @"";//  不设置就会显示button
    setButton.titleString = @"设置";
    setButton.titleColor = [NSColor whiteColor];
    [setButton setBezelStyle:NSRoundedBezelStyle];
    [setButton setTarget:self];
    [setButton setAction:@selector(setButtonClick:)];
    [view addSubview:setButton];
    [self.view addSubview:view];
}

#pragma mark 跳转到设置界面
- (void)setButtonClick:(NSButton *)sender
{
    [self presentViewControllerAsSheet:[[SetViewController alloc] init]];
}

// 使用这个webview
- (void)createNewWKWebView
{
    WKUserContentController *contentController = [[WKUserContentController alloc] init];
    [contentController addScriptMessageHandler:self name:@"callbackHandler"];
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    config.userContentController = contentController;
    
    // 清除缓存
//    [self clearCache];
    NSRect rect = self.view.frame;
    self.mainWebView = [[MyWebView alloc] initWithFrame:NSMakeRect(rect.origin.x, rect.origin.y, rect.size.width, rect.size.height - 64) configuration:config];
    // 设置访问的URL
    self.mainWebView.UIDelegate = self;
    self.mainWebView.navigationDelegate = self;

    // 将WKWebView添加到视图
    [self.view addSubview:self.mainWebView];

    self.mainWebView.allowsBackForwardNavigationGestures = NO;

    [self refreshNet];// 通过链接加载WebView
}

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    
}

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation
{
    HXINFOLOG(@"didStartProvisionalNavigation[%d] [webView.URL absoluteString]    %@", IsConnectedToNetwork(), [webView.URL absoluteString]);
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//        
//    });
    
    if (!IsConnectedToNetwork() && [[webView.URL absoluteString] rangeOfString:@"/a/mobile/wel.html?isIphone=true"].location != NSNotFound){
        [self loadInfogoView];
    }
}



#pragma mark WKNavigationDelegate 在提交的主框架期间发生错误时调用
//在提交的主框架期间发生错误时调用
- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error
{
    HXINFOLOG(@"error1 == %@", error.localizedDescription);
    if (error.code == -999 )
    [self loadInfogoView];
}
//当开始加载数据时发生错误时调用
-(void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error
{
    HXINFOLOG(@"error2 == %@", error.localizedDescription);//The operation couldn’t be completed.
    if (error.code != -999)
    [self loadInfogoView];
}
//  页面加载完成之后调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
//    HXINFOLOG(@"5-------页面加载完成之后调用");
}
#pragma mark webview导航动作事件处理
// 处理报文
/* 
  @abstract决定是否允许或取消导航。
  @param webView调用委托方法的Web视图。
  @param navigationAction关于操作的描述性信息
  触发导航请求。
  @param decisionHandler调用允许或取消的决策处理程序
  导航。 参数是枚举类型WKNavigationActionPolicy的常量之一。
  @discussion如果不实现此方法，Web视图将加载请求，或者如果适当，将其转发到另一个应用程序。
*/
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    NSURL *URL = navigationAction.request.URL;
    NSString *scheme = [URL scheme];
    NSString *absoluteStr = [URL absoluteString];
    NSString *urlString = [absoluteStr stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    if (urlString.length < 1) {
        unsigned long gbk_encode = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
        urlString = [absoluteStr stringByReplacingPercentEscapesUsingEncoding:gbk_encode];
    }

    NSArray *array = self.mainWebView.subviews;

    for (NSView *subView in array) {
        if ([subView isKindOfClass:[NSScrollView class]]) {
            // 不显示竖直的滚动条
            NSScrollView *sView = (NSScrollView *)subView;
            sView.hasHorizontalScroller = NO;
        }
    }


//    HXINFOLOG(@"%@", urlString);
    NSArray *urlComps = [urlString componentsSeparatedByString:@":|@|"];
    if ([scheme isEqualToString:@"iosnative"]) {
        if (activityIndicator){
//            [self webViewDidFinishLoad];
        }
//        save_local_Log(@"iosnative", urlString);
//        HXINFOLOG(@"iosnative字段 取消加载URL = %@", urlComps[1]);
        decisionHandler(WKNavigationActionPolicyCancel);
        if([urlComps count] && [[urlComps objectAtIndex:0] isEqualToString:@"iosnative"])
        {
            //有参数的
            if([[urlComps objectAtIndex:1] isEqualToString:@"getSystemInfo"])
            {
                NSString * SERIAL = [self cutOffString:urlString];//截取SERIAL
                NSString * allString = [self comperStr:urlComps[2]];// 上报信息的字符串
                [self webviewJSReport:SERIAL andString:allString];
                [self socketOfAppStart];
                
            }else if([[urlComps objectAtIndex:1] isEqualToString:@"getConfig"]) {
#pragma mark 获取本地配置
                NSString * comps = [urlComps objectAtIndex:2];
                NSRange rang = [comps rangeOfString:@"</CallOneFuncMode>"];
                NSUInteger num = rang.length + rang.location;
                NSMutableString * changeString = [NSMutableString stringWithFormat:@"%@", comps];
                [changeString insertString:@"\n	<Result>Yes</Result>" atIndex:num];
                BOOL isAuto = [readFile(@"Automatic") isEqualToString:@"1"];// 设置页面自动认证参数
                NSString *newString = [NSString stringWithFormat:@"%@[<REPLY>]{\"autoauth\":%d}[</REPLY>]", changeString, isAuto];
                NSString * SERIAL = [self cutOffString:urlString];//截取SERIAL
                NSString * xmlString = [NSString stringWithFormat:@"var script = document.createElement('script');"
                                        "script.type = 'text/javascript';"
                                        "script.text = \"function myFunction(result,serial,type,encode) { "
                                        "onRecvMsg(result,serial,type,encode);"
                                        "}\";"
                                        "document.getElementsByTagName('head')[0].appendChild(script);"];
                [self.mainWebView evaluateJavaScript:xmlString completionHandler:^(id id, NSError * error) {}];
                [self webviewJSReport:SERIAL andString:newString];

            }else if([[urlComps objectAtIndex:1] isEqualToString:@"refreshNet"]) {
                [self refreshNet];            //刷新界面
            }else if([[urlComps objectAtIndex:1] isEqualToString:@"StartVpn"]) {
#pragma mark  vpn连接
            }else if([[urlComps objectAtIndex:1] isEqualToString:@"openSetting"]) {
#pragma mark  打开设置
                [self presentViewControllerAsSheet:[[SetViewController alloc] init]];
    
            }else if([[urlComps objectAtIndex:1] isEqualToString:@"getWEBConfig"]){
#pragma mark  上报软件硬件信息
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
                    [self savegetWEBConfigInfo:urlString];//  获取DeviceID
                    [WebJSInteractive webJSgetWEBConfig:urlString];
                });
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5*NSEC_PER_SEC)),dispatch_get_main_queue(), ^{
                    [YGTool appleScriptClearArpTable];
                });
            }else if([[urlComps objectAtIndex:1] isEqualToString:@"MACCheckSoftInstallStat"]){
#pragma mark 必须安装APP检查
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    NSString * SERIAL = [self cutOffString:urlString];//截取SERIAL
                    NSString *allString = [YGMessageSplicing CheckSoftInstallStat:urlComps[2] withWeb:YES];
                    [self webviewJSReport:SERIAL andString:allString];
                });

            }else if ([urlString rangeOfString:@"MACCheckSoftForbidInstallStat"].location != NSNotFound){
#pragma mark 禁止安装app检查
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    NSString * SERIAL = [self cutOffString:urlString];//截取SERIAL
                    NSString *allString = [YGMessageSplicing CheckSoftForbidInstallStat:urlComps[2] withWeb:YES];
                    [self webviewJSReport:SERIAL andString:allString];
                });
            }else if ([[urlComps objectAtIndex:1] isEqualToString:@"MACCheckProcessMustRun"]){
#pragma mark 必须运行进程检查
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    NSString * SERIAL = [self cutOffString:urlString];// 截取SERIAL
                    NSString *allString = [YGMessageSplicing CheckProcessMustRun:urlComps[2] withWeb:YES];
                    [self webviewJSReport:SERIAL andString:allString];
                });
            }else if ([[urlComps objectAtIndex:1] isEqualToString:@"MACCheckSystemProcess"]){
#pragma mark 禁止运行进程检查
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    NSString * SERIAL = [self cutOffString:urlString];// 截取SERIAL
                    NSString *allString = [YGMessageSplicing CheckSystemProcess:urlComps[2] withWeb:YES];
                    [self webviewJSReport:SERIAL andString:allString];
                });
            }
#pragma mark 未实现的安检项 直接上报为合规的
            // 1. 杀毒软件检查
            else if ([[urlComps objectAtIndex:1] isEqualToString:@"CheckAntiVirusSoft"]){
                NSString * SERIAL = [self cutOffString:urlString];// 截取SERIAL
                NSString * allString = [YGMessageSplicing CheckSecureDesktop:urlComps[2] withWeb:YES];
                [self webviewJSReport:SERIAL andString:allString];
            }
            // 2. 安全桌面
            else if ([[urlComps objectAtIndex:1] isEqualToString:@"CheckSecureDesktop"]){
                NSString * SERIAL = [self cutOffString:urlString];// 截取SERIAL
                NSString * allString = [YGMessageSplicing CheckSecureDesktop:urlComps[2] withWeb:YES];
                [self webviewJSReport:SERIAL andString:allString];
            }else if ([[urlComps objectAtIndex:1] isEqualToString:@"test"]){
                //            NSString *headerStr = @"document.getElementsByTagName('score')[0].innerText = '测试文字';";
                [webView evaluateJavaScript:[NSString stringWithFormat:@"pp('clearCache')"] completionHandler:^(id id, NSError * _Nullable error) {
                    HXINFOLOG(@"error js = %@", error);
                }];
            }else if ([urlComps[1] isEqualToString:@"setAutoCertification"]) {
                //  自动认证传入账号密码
                if (XInclusionRelationshipExists(urlComps[2], @"#infogo#")) {
                    NSArray *u_pArray = [urlComps[2] componentsSeparatedByString:@"#infogo#"];
                    if (u_pArray.count == 2) {
                        YGNetAuthModel *model = [[YGNetAuthModel model] qunueSelectFromNetAuthModel];
                        if (model == nil) {
                            model = [YGNetAuthModel model];
                        }
                        model.username = u_pArray[0];
                        model.password = u_pArray[1];
                        [model qunueUpdateNetAuthTable];
                    }
                }
            }else if ([urlComps[1] isEqualToString:@"writeAutoAuthTime"]) {
                // web认证通过后通知客户端，客户端记录当前时间更新本地NetAuthTable表的最近一次认证时间节点
            }else if ([urlComps[1] isEqualToString:@"imonitor"]) {
#pragma mark 必须安装app检查 ----- 修复按钮回执
                YGDownloadRequestObject *dRObj = [YGDownloadRequestObject shareInstance];
                NSArray *dArr = [urlComps[2] componentsSeparatedByString:@"#infogo#"];
                if (dArr.count == 2) {
                    [dRObj downloadForTaskSoftName:dArr[1] SoftURL:dArr[0]];
                }else{
                    [dRObj downloadForTaskSoftName:nil SoftURL:urlComps[2]];
                }
            }else if ([urlComps[1] isEqualToString:@"setUnInstallKey"]) {
#pragma mark 万能卸载码
//                writeFile(unInstallKey, @"UnInstallKey");// 保存万能卸载码
                if (urlComps.count >= 2) {
                    writeFile(urlComps[2], @"UnInstallKey");
                }else{
                    writeFile(@"", @"UnInstallKey");
                }
            }
            

        }

    }else {
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}
#pragma mark web页面的弹窗控制
//completionHandler 必须实现不然报错
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler{
    HXINFOLOG(@"1=%@", message);
    completionHandler();
}
- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL))completionHandler{
    HXINFOLOG(@"2=%@", message);
    
}
- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * _Nullable))completionHandler{
    
    HXINFOLOG(@"3=%@ \n%@", prompt, defaultText);
}
- (BOOL)webView:(WKWebView *)webView shouldPreviewElement:(WKPreviewElementInfo *)elementInfo {
    return YES;
}

/*！
  @abstract决定在导航之后是否允许或取消导航
  响应是已知的。
  @param webView调用委托方法的Web视图。
  @param navigationResponse有关导航的描述性信息
  响应。
  @param decisionHandler调用允许或取消的决策处理程序
  导航。 参数是枚举类型WKNavigationResponsePolicy的常量之一。
  @discussion如果您不实现此方法，Web视图将允许响应，如果Web视图可以显示它。
  */
//- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler
//{
//    NSLog(@"decidePolicyForNavigationResponse    %@", [webView.URL absoluteString]);
//
//    decisionHandler(WKNavigationResponsePolicyAllow);
//}
/**重新加载数据*/
- (void)refreshNet
{
//    [self webViewDidStartLoad];
    self.ipAddress = readFile(kServerAddress);
    if (self.ipAddress.length < 1) {
        // 没有ip地址  则 先读取本地默认
        if(![self getAddress]){
            // 读取本地默认ip失败
            //加载404
            [self loadInfogoView];
            return;
        }
    }
    if (self.mainWebView.loading) {
        [self.mainWebView stopLoading];
    }
    NSURL *url;
    if ([readFile(@"debug") isEqualToString:@"debug"]) {
        //debug模式
        url = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@/a/mobile/wel.html?isIphone=true&log=1", self.ipAddress]];
    }else{
        url = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@/a/mobile/wel.html?isIphone=true", self.ipAddress]];
    }
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.mainWebView loadRequest:request];
}

/**加载本地404页面*/
- (void)loadInfogoView
{
//    [self webViewDidFinishLoad];
    NSString * path = [[NSBundle mainBundle] pathForResource:@"404" ofType:@"html"];
//    NSString *path = [[NSBundle mainBundle] pathForResource:@"index" ofType:@"html"];
    NSURL *url = [NSURL fileURLWithPath:path];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.mainWebView stopLoading];
    [self.mainWebView loadRequest:request];
}

/*
 第一次进入程序是没有ip的 设置为在本地读
 */
- (BOOL)getAddress {
    NSString * ipDefault = ReadFileDefault();
    if (ipDefault.length > 0) {
        writeFile(ipDefault, kServerAddress);
        self.ipAddress = ipDefault;
        return YES;// 还有默认ip
    }
    return NO;
}
#pragma mark  加载socket
- (void)createSocket{
    if ([NSThread isMainThread]){
        __weak typeof(self)weakSelf = self;
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            HXINFOLOG(@"createSocket at mainThread, we change ");
            __strong typeof(weakSelf)strongSelf = weakSelf;
            [strongSelf createSocket];
        });
    }else{
        HXINFOLOG(@"createSocket at thread is not mainthread ");
        if (self.ygSingleton == nil){
            self.ygSingleton = [Singleton shareInstancetype];
        }else{
            CloseSocket();
            self.ygSingleton = nil;
        }
        [self.ygSingleton initNetwork:readFile(kServerAddress) andPort:37527];
    }
    [self createUsbManagerControl];

}

/** 在设置页面修改了服务器地址*/
- (void)ipAddressChanged:(NSNotification *)notification {
    NSString * nowServerIp = readFile(kServerAddress);
    NSString * ipAddress = self.ipAddress.length>0 ? self.ipAddress:nowServerIp;
    if (![nowServerIp isEqualToString:ipAddress] && ipAddress) {
        HXINFOLOG(@"\ndefaultsip = %@\nserverip = %@", self.ipAddress, nowServerIp);
        [self releasePolicyTimer:nil];
        [self refreshNet];
        [self createSocket];
    }
}
//监听是否锁屏了
// [[NSDistributedNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNotification:) name:@"com.apple.screenIsLocked" object:nil];




//  
- (void)aNotificationHandler:(NSNotification *)noti
{
    int num = [readFile(@"BedgeLabel") intValue];
    num++;
    writeFile([NSString stringWithFormat:@"%d", num], @"BedgeLabel");
    [[[NSApplication sharedApplication] dockTile] setBadgeLabel:[NSString stringWithFormat:@"%d", num]];

    NSUserNotification *notification = [[NSUserNotification alloc] init];
//    notification.title = [noti object];
    if([[noti object] isKindOfClass:[NSString class]]){
        notification.informativeText = [noti object];
    }
//    if ([notification.informativeText rangeOfString:@"程序"].location != NSNotFound) {
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            NSLog(@"策略锁屏LockScreen");
//            LockScreen();
//        });
//    }
//    NSUserNotificationAlertStyle
//    notification.informativeText = [noti object];
//    NSImage * anImage = [NSImage imageNamed:@"imc.png"];
//    [notification setValue:anImage forKey:@"_identityImage"];// 虽然是显示在左边 但是不符合需求
//    notification.contentImage = [NSImage imageNamed:@"imc.png"];//  这里设置的图片显示在通知的右边
    
    /*
     //设置通知提交的时间
     notification.deliveryDate = [NSDate dateWithTimeIntervalSinceNow:5];
     //设置通知的循环(必须大于1分钟，估计是防止软件刷屏)
     NSDateComponents *dateComponents = [[NSDateComponents alloc] init];
     [dateComponents setSecond:70];
     notification.deliveryRepeatInterval = dateComponents;
     */
    
    //只有当用户设置为提示模式时，才会显示按钮

    if (XInclusionRelationshipExists([noti object], @"错误")||XInclusionRelationshipExists([noti object], @"失败")){
        notification.hasActionButton = NO;
    }else{
        notification.hasActionButton = YES;
    }
    notification.actionButtonTitle = @"OK";
//    notification.otherButtonTitle = @"Cancel";
    notification.soundName = NSUserNotificationDefaultSoundName;
    NSUserNotificationCenter *userNotificationCenter = [NSUserNotificationCenter defaultUserNotificationCenter];

    //设置通知的代理
    userNotificationCenter.delegate = self;
    //递交通知
    [userNotificationCenter deliverNotification:notification];
    
    //删除已经显示过的通知(已经存在用户的通知列表中的)
//    [[NSUserNotificationCenter defaultUserNotificationCenter] removeAllDeliveredNotifications];

//    //删除已经在执行的通知(比如那些循环递交的通知)
//    for (NSUserNotification *notify in [[NSUserNotificationCenter defaultUserNotificationCenter] scheduledNotifications])
//    {
//        [[NSUserNotificationCenter defaultUserNotificationCenter] removeScheduledNotification:notify];
//    }
}

- (void)userNotificationCenter:(NSUserNotificationCenter *)center didDeliverNotification:(NSUserNotification *)notification {
    if ([notification.informativeText rangeOfString:@"警告"].location == NSNotFound)
    {
        writeFile(@"1", @"SendMsg");
    }
    HXINFOLOG(@"通知已经递交！");
}

- (void)userNotificationCenter:(NSUserNotificationCenter *)center didActivateNotification:(NSUserNotification *)notification {
    HXINFOLOG(@"用户点击了OK！");
    NSApplication * application = [NSApplication sharedApplication];
    NSInteger num = application.dockTile.badgeLabel.integerValue;
    if (num > 0) {
        num--;
        [[application dockTile] setBadgeLabel:num==0?@"":[NSString stringWithFormat:@"%ld", num]];
        writeFile(@"0", @"BedgeLabel");
    }
}

- (BOOL)userNotificationCenter:(NSUserNotificationCenter *)center shouldPresentNotification:(NSUserNotification *)notification {
    //用户中心决定不显示该条通知(如果显示条数超过限制或重复通知等)，returen YES;强制显示
    return YES;
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    // Update the view, if already loaded.
}

#pragma mark ----字符串操作----
// 截取SERIAL
- (NSString *)cutOffString:(NSString *)urlString
{
    NSRange range = [urlString rangeOfString:@"SERIAL"];
    range.location += 7;
    range.length = 10;
    NSString * serial = [urlString substringWithRange:range];
    return serial;
}

- (NSString *)comperStr:(NSString *)request
{
    NSRange rang = [request rangeOfString:@"</CallOneFuncMode>"];
    NSUInteger num = rang.length + rang.location;
    NSMutableString * changeString = [NSMutableString stringWithFormat:@"%@", request];
    NSString * ipAddress = getIPAddress();
    NSString * macStr = getMacStr();
    NSString * uuid = GetUUID();
    NSString * cpu = GetCPU();
    NSString * mark = GetMarkForMainThread();
    NSString * disk = TotalDiskSpace();
    int numOfSizeToRAM = [GetRAM() intValue] * 1024;
    [changeString insertString:@"\n	<Result>Yes</Result>" atIndex:num];
    NSString * str = [NSString stringWithFormat:@"[<REPLY>]<?xml version=\"1.0\" encoding=\"gbk\"?><MSAC><DeviceName>%@</DeviceName><OS>%@</OS><Ip>%@</Ip><Mac>%@</Mac><IeVersion>Safari</IeVersion><DiskSize>%@</DiskSize><GateWay></GateWay><DiskId>%@</DiskId><CPU>%@</CPU><Mark>%@</Mark><Memory>%dMB</Memory></MSAC>[</REPLY>]",
                      readFile(@"computerName"),// appledeiMac
                      readFile(@"SystemVersion"),
                      ipAddress,
                      macStr,
                      disk,
                      uuid,
                      cpu,//Intel(R) Core(TM) i5-4260U CPU @ 1.40GHz
                      mark,//255.255.248.0
                      numOfSizeToRAM];
    
    return [NSString stringWithFormat:@"%@%@", changeString, str];
}


- (void)webviewJSReport:(NSString *)SERIAL andString:(NSString*)allString{
    dispatch_async(dispatch_get_main_queue(), ^{
        
        NSString * base64 = [CommonFunc base64StringFromText:allString];//  base64加密
        [self.mainWebView evaluateJavaScript:[NSString stringWithFormat:@"myFunction('%@','%@','%@','%@')", base64, SERIAL, @"end", @"base64"] completionHandler:^(id id, NSError * error)
         {
             if (error)
                 HXINFOLOG(@"CheckSoftForbidInstallStat  error  %@", error);
         }];
    });
}


#pragma mark -清除webView缓存
- (BOOL)clearCache
{
    NSString *libraryDir = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES)[0];
    NSString *bundleId  =  [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleIdentifier"];
    NSString *webkitFolderInLib = [NSString stringWithFormat:@"%@/WebKit",libraryDir];
    NSString *webKitFolderInCaches = [NSString
                                      stringWithFormat:@"%@/Caches/%@/WebKit",libraryDir,bundleId];
    NSString *webKitFolderInCachesfs = [NSString
                                        stringWithFormat:@"%@/Caches/%@/fsCachedData",libraryDir,bundleId];
    
    NSError *error;
    NSFileManager *fm = [NSFileManager defaultManager];
    /* iOS8.0 WebView Cache的存放路径 */
    if ([fm fileExistsAtPath:webKitFolderInCaches])
    return [fm removeItemAtPath:webKitFolderInCaches error:&error];
    if ([fm fileExistsAtPath:webkitFolderInLib])
    return [[NSFileManager defaultManager] removeItemAtPath:webkitFolderInLib error:nil];
    
    /* iOS7.0 WebView Cache的存放路径 */
    if ([fm fileExistsAtPath:webKitFolderInCachesfs])
    return [[NSFileManager defaultManager] removeItemAtPath:webKitFolderInCachesfs error:&error];
    return NO;
}

#pragma mark getWEBConfig----获取deviceID
- (void)savegetWEBConfigInfo:(NSString *)urlStr
{
    NSRange range1 = [urlStr rangeOfString:@"[<REQUEST>]"];
    NSRange range2 = [urlStr rangeOfString:@"[</REQUEST>]"];
    NSRange range;
    range.length = range2.location - range1.location - range1.length;
    range.location = range1.length + range1.location;
    NSString * str = [urlStr substringWithRange:range];
    NSData *jsonData = [str dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
    NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:jsonData
                                                             options:NSJSONReadingMutableContainers
                                                               error:&error];
    if (jsonDict.count > 0) {
        NSString *deviecID = jsonDict[@"DeviceID"];
        if (deviecID.length > 0) {
            writeFile(jsonDict[@"DeviceID"], kAgentID);
        }
        NSString *autoAuth = jsonDict[@"AndroidAutoAuth"];
        YGNetAuthModel *model = [[YGNetAuthModel model] qunueSelectFromNetAuthModel];
        if (autoAuth.length > 0) {
            model.IsNetAuth = 1;
            model.autoAuthTime = [autoAuth doubleValue];
            model.InsertTime = current_Time_Stamp();
        }else {
            model.IsNetAuth = 0;
            model.autoAuthTime = 0;
            model.InsertTime = 0;
        }
        [model qunueUpdateNetAuthTable];
        NSString *unInstallKey = jsonDict[@"UnInstallKey"];
//        if (unInstallKey.length > 0) {
            writeFile(unInstallKey, @"UnInstallKey");// 保存万能卸载码
//        }
    }
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSDirectoryEnumerator<NSString *> * myDirectoryEnumerator;
    NSString *strPath = kCachesDirictory;
    NSString *path;
    myDirectoryEnumerator=  [fileManager enumeratorAtPath:strPath];
    while (path = [myDirectoryEnumerator nextObject]) {
        for (NSString * namePath in path.pathComponents) {
            if ([[namePath pathExtension] isEqualToString:@"dmg"] || [[namePath pathExtension] isEqualToString:@"pkg"]) {
                if ([fileManager fileExistsAtPath:[strPath stringByAppendingPathComponent: namePath]]) {
                    if ([fileManager removeItemAtPath:[strPath stringByAppendingPathComponent: namePath] error:nil]) {

                    }
                }
            }
//            NSLog(@"-----AAA-----%@", namePath  );
        }

    }
}

#pragma mark---- 小菊花
-(void)webViewDidStartLoad
{
    self.mainWebView.hidden = YES;
    HXINFOLOG(@"start");
    if (backView || activityIndicator) {
        HXINFOLOG(@"start___________fail");
        return;
    }
    NSRect cgrect = self.mainWebView.frame;
    //创建UIActivityIndicatorView背底半透明View
    
    backView = [[NSView alloc] initWithFrame:cgrect];
    [backView setWantsLayer:YES];
    backView.layer.backgroundColor = [NSColor grayColor].CGColor;
    backView.alphaValue = 0.3;
    [self.view addSubview:backView];
    activityIndicator = [[NSProgressIndicator alloc] initWithFrame:CGRectMake(cgrect.size.width / 2 - 16, cgrect.size.height / 2 - 16, 32.0f ,32.0f)];
//    [activityIndicator setCenter:view.layer.contentsCenter.origin];
    activityIndicator.style = NSProgressIndicatorSpinningStyle;
    [backView addSubview:activityIndicator];
    [activityIndicator startAnimation:nil];
}

-(void)webViewDidFinishLoad
{
    self.mainWebView.hidden = NO;
    if (activityIndicator) {
        [activityIndicator stopAnimation:nil];
        [activityIndicator removeFromSuperview];
        activityIndicator = nil;
        HXINFOLOG(@"stop");
    }
    if (backView){
        [backView removeFromSuperview];
        backView = nil;
    }
}

/*
// 心跳计时器 同一个计时器要放在同一个线程内(目前全放在主线程)
 */
- (void)createNSTimerForHeart
{
    HXINFOLOG(@"self.SocketTimer.valid:%d", self.SocketTimer.valid);
    if (!self.SocketTimer.valid) {
        [self.SocketTimer invalidate];
        self.SocketTimer = nil;
        self.SocketTimer = [NSTimer scheduledTimerWithTimeInterval:30.0 target:self selector:@selector(timerFired:) userInfo:nil repeats:YES];// 心跳计时器
        [self.SocketTimer fire];// 立即执行计时器
    }
}

#pragma mark 策略
- (void)CheckViolationHandling:(NSNotification *)noti
{
    NSLog(@"策略通知");
    YGPolicyItem *policyItem = noti.object;
//    NSData *dataForLocal = readFile(POLICY);
//    YGPolicyItem *localPolicyItem = [NSKeyedUnarchiver unarchiveObjectWithData:dataForLocal];
    
    if ([readFile(Offline) intValue] != 0 && !policyItem.OffLineEffect) {
        // 离线且离线不生效则返回
        return;
    }
    if (!policyItem.wifiRecordModel.ItemList.count &&
        !policyItem.appRecordModel.ItemList.count &&
        !policyItem.fileRecordModel.ItemList.count &&
        !policyItem.internetBehaviorRecordModel.ItemList.count &&
        policyItem.usbPlugAuditModel.Body.count < 1 && // 新增usb管控
        policyItem.usbDeviceCtrlModel.Body.count < 1 &&
        policyItem.SPolicyUsbClassCtrlModel.Body.count < 1) // 新增usb管控
    {
        //  下发策略都没配 就释放掉计时器
        [self releasePolicyTimer:nil];
        return;
    }
//    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:policyItem];
//    writeFile(data, POLICY);
    dispatch_async(dispatch_get_main_queue(), ^{
        BOOL isPolicyChange =  [policyItem isEqualToYGPolicyItem:hYGPolicyItem];// 策略变动
        if (!isPolicyChange || !self.policyTimer.valid){// 策略变动或者计时器无效时
        // 回到主线程创建计时器 (不在主线创建的计时器不一定能执行计时函数)
            if (self.policyTimer){
                [self.policyTimer invalidate];
                self.policyTimer = nil;
            }
            YGPolicyItem *localPlC = [YGPolicyItem GetYGPolicyItem];
            if (![policyItem.appRecordModel isEqualToYGAppRecordModel:localPlC.appRecordModel]) {
                // 本地存储的黑白程序名单清空
                NSData *dataForApp = [NSKeyedArchiver archivedDataWithRootObject:[NSDictionary dictionary]];
                writeFile(dataForApp, Programlist);
            }

            NSTimeInterval time = policyItem.UpdateTimeMin * 60;//  需要得到的是秒数
            if (time != 0) {
                hYGPolicyItem = policyItem;// 全局变量存策略
                self.policyTimer = [NSTimer scheduledTimerWithTimeInterval:time target:self selector:@selector(policyTimerAction:) userInfo:nil repeats:YES];
                HXINFOLOG(@"CheckViolationHandling   because the policy is change");
                [self.policyTimer fire];
                if (policyItem.wifiRecordModel && policyItem.wifiRecordModel.ItemList.count > 0) {
                    // 注册监听wifi
                    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), //center
                                                    (void *)myObserver, // observer
                                                    onNotifyCallback, // callback
                                                    NotificationNetwork_Change, // event name
                                                    NULL, // object
                                                    CFNotificationSuspensionBehaviorDeliverImmediately);

                }
                if (policyItem.usbDeviceCtrlModel || policyItem.usbPlugAuditModel) {
                    [self createUsbManagerControl];
                }
            }

        }

//        if (self.policyTimer.valid){
//            NSLog(@"restart [policyTimer fire]");
//            [self.policyTimer fire];// 如果计时器有效 每次接到通知就立即执行一次
//        }
    });
}
#pragma mark 按照下发周期进行周期检查
- (void)policyTimerAction:(NSTimer *)sender{
    if (sender == nil) return;
//    if ([sender userInfo] == nil) return;// 下发策略为空 或者被释放
    NSLog(@"周期检查");
    if ([readFile(Offline) intValue] != 0 && !hYGPolicyItem.OffLineEffect) {
        // 离线且策略中离线不生效
        return;
    }
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        MobilePolicy_Application(hYGPolicyItem.appRecordModel);// 应用策略检查
        MobilePolicy_WiFi(hYGPolicyItem.wifiRecordModel);// WiFi策略检查
//        //  文档监控没有变动就只开启一次
//        BOOL result1 = [hYGFileRecordModel isEqualToYGFileRecordModel:hYGPolicyItem.fileRecordModel];
//        if (!result1){
//            hYGFileRecordModel = hYGPolicyItem.fileRecordModel;
//            dispatch_async(dispatch_get_main_queue(), ^{
//                [self MobilePolicy_File:hYGFileRecordModel];
//            });
//        }
//        // 上网行为管控的检测周期与其他策略项不同
//        if (![hYGInternetBehaviorRecordModel isEqualYGInternetBehaviorRecordModel:hYGPolicyItem.internetBehaviorRecordModel]){
//            // 如果上网行为管控策略项没有变动就只开启一次
//            hYGInternetBehaviorRecordModel = hYGPolicyItem.internetBehaviorRecordModel;
//            if (hYGInternetBehaviorRecordModel.ItemList.count == 0 && self.InterTimer.valid) {
//                [self.InterTimer invalidate];
//                self.InterTimer = nil;
//            }
//            dispatch_async(dispatch_get_main_queue(), ^{
//                self.InterTimer = [NSTimer scheduledTimerWithTimeInterval:15 target:self selector:@selector(internetBehaviorRecordModelTimer:) userInfo:nil repeats:YES];
//                [self.InterTimer fire];
//            });
//        }
        HXINFOLOG(@"周期检查完成");
        [self.ygSingleton GetAgentPolicyList];
        [self.ygSingleton recvGetDeviceProperty];
    });
}
// 文档审计
- (void)MobilePolicy_File:(YGFileRecordModel *)recordModel{
    if (recordModel.ItemList.count == 0){
        // 下发新的的策略监控文件路径为空   还要加东西
        if (_yListener) {
            _yListener = nil;
        }
        return;
    }
    NSMutableArray * filePathArr = [NSMutableArray array];
    for (YGFileItemList * list in recordModel.ItemList) {
        if (list.FilePath.length < 1) {
            continue;
        }
        [filePathArr addObject:list.FilePath];
    }
    if (_yListener && filePathArr.count < 1){
        _yListener = nil;
    }
    // 开启监听
     _yListener = [[FSEventsListener alloc] initWithFilePath:filePathArr withFileRecordModel:recordModel];
}

/** 释放掉上个策略的计时器*/
- (void)releasePolicyTimer:(NSNotification *)noti{
    __weak typeof(self)weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf)strongSelf = weakSelf;
        // 将全部策略信息清空
        [YGPolicyItem SaveYGPolicyItem:[YGPolicyItem Item]];
        writeFile(@"", @"PolicyTime");
        writeFile(@"", @"sysPolicyTime");
        CFNotificationCenterRemoveObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                           (void *)myObserver,
                                           NotificationNetwork_Change,
                                           NULL);
        hYGPolicyItem = nil;
        [strongSelf cancelAlert];
        // 目前的没有必要去释放掉前一个计时器  只需要去改掉下发的策略信息
        if (strongSelf.policyTimer){
            [strongSelf.policyTimer invalidate];// 从线程池中取出计时器
            strongSelf.policyTimer = nil;
        }
        if (strongSelf.InterTimer){
            [strongSelf.InterTimer invalidate];
            strongSelf.InterTimer = nil;
        }
        if (strongSelf.yListener) {
            strongSelf.yListener = nil;
        }
        
    });
}
#pragma mark 监听wifi  是否符合wifi策略
// 先在viewdidload中注册
static void onNotifyCallback(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo)
{
    NSString* notifyName = (__bridge NSString *)name;
    NSLog(@"notification is [%@]", notifyName);
    if ([notifyName isEqualToString:@"com.apple.system.config.network_change"]) {
        // use the Captive Network API to get more information at this point
        //  http://stackoverflow.com/a/4714842/119114
        NSString *onLine = readFile(Offline);
        if (onLine.intValue > 0 && !hYGPolicyItem.OffLineEffect) {
            // 离线且离线不生效时
            return;
        }
        if (hYGPolicyItem.wifiRecordModel && WiFiSSID().length > 0) {
            long long date = (long long)[[NSDate date] timeIntervalSince1970];
            if (dateForWiFi + 1 < date){
                HXINFOLOG(@"wifi is change【%@】\nobject = [%@]\nuserInfo=[%@]", notifyName, object, userInfo);
                HXINFOLOG(@"timestr :%lld ",date);
                dateForWiFi = date;
                MobilePolicy_WiFi(hYGPolicyItem.wifiRecordModel);
            }
        }
    } else {
        NSLog(@"intercepted %@", notifyName);
    }
}
/**
    上网行为管控
 */
- (void)internetBehaviorRecordModelTimer:(NSTimer *)timer{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        MobilePolicy_InternetBehavior(hYGInternetBehaviorRecordModel);
    });
}

#pragma mark  alert弹出框显示TableView
- (void)initTableView{
    if (_tableContainerView) {
        _tableContainerView = nil;
    }
    // create a table view and a scroll view
    _tableContainerView = [[NSScrollView alloc] initWithFrame:NSMakeRect(10, 50, 600, 200)];
    NSTableView * tableView = [[NSTableView alloc] initWithFrame:NSMakeRect(0, 0, 564, 200)];
    // create columns for our table
    NSTableColumn * column1 = [[NSTableColumn alloc] initWithIdentifier:@"Col1"];
    NSTableColumn * column2 = [[NSTableColumn alloc] initWithIdentifier:@"Col2"];
    [column1 setWidth:198];
    [column2 setWidth:402];
    NSString *lang = getPreferredLanguage();
    if([lang rangeOfString:@"zh-Hant"].location != NSNotFound || [lang rangeOfString:@"zh-Hans"].location != NSNotFound){
        // 当系统语言是中文或繁体中文时
        [column1 setTitle:@"应用名称"];
        [column2 setTitle:@"路径"];
    }else{
        //其它语言的情况下
        [column1 setTitle:@"Application Name"];
        [column2 setTitle:@"path"];
    }
    // generally you want to add at least one column to the table view.
    [tableView addTableColumn:column1];
    [tableView addTableColumn:column2];
    [tableView setDelegate:self];
    [tableView setDataSource:self];
    [tableView reloadData];
    // embed the table view in the scroll view, and add the scroll view to our window.
    [_tableContainerView setDocumentView:tableView];
    
    [_tableContainerView setHasVerticalScroller:YES];
}

#pragma mark tableView代理
-(NSInteger)numberOfRowsInTableView:(NSTableView *)tableView{
    HXINFOLOG(@"cell num  = %ld", self->_dataSourceArray.count);
    return self->_dataSourceArray.count;
}

-(id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    return nil;
}
- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row{
    return 58;
}
- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    NSString *strIdt=[tableColumn identifier];
    NSTableCellView *aView = [tableView makeViewWithIdentifier:strIdt owner:self];
    if (!aView)
        aView = [[NSTableCellView alloc]initWithFrame:CGRectMake(0, 0, tableColumn.width, 58)];
    else
        for (NSView *view in aView.subviews)[view removeFromSuperview];
    
    ApplicationInfo *app = _dataSourceArray[row];
    if ([strIdt isEqualToString:@"Col1"]) {
        NSTextField *textField = [[NSTextField alloc] initWithFrame:CGRectMake(15, 20, 300, 17)];
        textField.stringValue = [NSString stringWithFormat:@"%@",app.ApplicationName];
        textField.font = [NSFont systemFontOfSize:12.0f];
        textField.editable = NO;
        textField.textColor = [NSColor blackColor];
        textField.drawsBackground = NO;
        textField.bordered = NO;
        textField.focusRingType = NSFocusRingTypeNone;
        textField.translatesAutoresizingMaskIntoConstraints = YES;
        [aView addSubview:textField];
    }else{
        NSTextView *textView = [[NSTextView alloc] initWithFrame:CGRectMake(0, 20, 402, 17)];
        textView.string = [NSString stringWithFormat:@"%@", app.ApplicationPath];
        textView.font = [NSFont systemFontOfSize:10.0f];
        [textView setAutoresizingMask:NSViewWidthSizable];
        textView.editable = YES;
        [aView addSubview:textView];
    }
    return aView;
}


- (void)createAlert{
    if (self.alert){
        [self cancelAlert];
    }
    [self initTableView];
    NSString *messageTitle = @"IMC";
    NSString *defaultButtonTitle = @"cancel";
    NSString *lang = getPreferredLanguage();
    if([lang rangeOfString:@"zh-Hant"].location != NSNotFound || [lang rangeOfString:@"zh-Hans"].location != NSNotFound){
        // 当系统语言是中文或繁体中文时
        defaultButtonTitle = @"关闭";
    }else{
        //其它语言的情况下
        defaultButtonTitle = @"cancel";
    }
    self.alert = [NSAlert alertWithMessageText:messageTitle
                                     defaultButton:defaultButtonTitle
                                   alternateButton:nil
                                       otherButton:nil
                         informativeTextWithFormat:@""];
    
    [self.alert setAlertStyle:NSAlertStyleWarning];
    //    NSImage *icon = [NSImage imageNamed:@"icon.png"];
    //    [alert setIcon:icon];
    
    [self.alert layout];
    NSPanel *panel = (NSPanel *)[self.alert window];
    
    NSView* contentView = [panel contentView];
    // Get original sizes
    NSRect rect2 = NSMakeRect(0, 0, _tableContainerView.frame.size.width+50, _tableContainerView.frame.size.height+200);
    [panel setFrame:rect2 display:YES];
    NSTableView *accessoryView = [[NSTableView alloc] init];
    // accessoryView为要添加的NSTableView
    [accessoryView setFrame:rect2];
    NSWindow *win = [NSApp mainWindow];
    [contentView addSubview:_tableContainerView];
    [self.alert beginSheetModalForWindow:win
                      modalDelegate:self
                     didEndSelector:@selector(addNewItemAlertDidEnd:returnCode:contextInfo:)
                        contextInfo:nil];
}

- (void)cancelAlert{
    if (self.alert) {
        [NSApp stopModal];
        [NSApp endSheet:[self.alert window] returnCode:0];
        [[self.alert window] orderOut:nil];
        self.alert = nil;
        dicForAlertInfo = nil;
    }
}

// alert的弹窗点击事件
- (void)addNewItemAlertDidEnd:(NSAlert *)alert returnCode:(NSInteger)returnCode contextInfo:(NSString *)info{
    if (returnCode == 1){
        YGPolicyItem *policy = [YGPolicyItem GetYGPolicyItem];
        if ([readFile(Offline) intValue] >= 2 && !policy.OffLineEffect) {
            // 离线且配置了离线不生效
            return;
        }
        if (policy.appRecordModel.isLock) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(policy.appRecordModel.lockTime * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                NSData *dataProgramlist = readFile(Programlist);
                NSDictionary *dic = [NSKeyedUnarchiver unarchiveObjectWithData:dataProgramlist];
                NSDictionary *softDic = [SoftwareList allAppList];
                int num = 0;
                
                self->_dataSourceArray = nil;
                self->_dataSourceArray = [NSMutableArray array];
                for (NSString *path in dic) {
                    [self->_dataSourceArray addObject:dic[path]];
                    if (![[softDic allKeys] containsObject:path]) {
                        // 本地没有违规软件的路径（没有该违规软件）
                        num++;
                    }
                }
                if ([readFile(Offline) intValue] >= 2 && !policy.OffLineEffect) {
                    [self cancelAlert];
                    // 离线且配置了离线不生效
                    return;
                }
                if (num == dic.count) {
                    [self cancelAlert];
                    return ;
                }
                NSNotification * notification = [NSNotification notificationWithName:@"lockForAlert" object:dic];
                [self lockForAlert:notification];
            });
        }
    }
}


-(void)lockForAlert:(NSNotification *)noti{
     dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
         NSDictionary *dic = noti.object;
        if (dic.count > 0) {
            BOOL doSomeThing = NO;
//            NSData *data = readFile(Programlist);
//            NSDictionary *localDic = [NSKeyedUnarchiver unarchiveObjectWithData:data];
//            NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:localDic];
            if (dic.count != self->dicForAlertInfo.count) {
                doSomeThing = YES;
            }
            for (NSString *path in [dic allKeys]) {
                if ([[self->dicForAlertInfo allKeys] containsObject:path]){
                    [self->dicForAlertInfo removeObjectForKey:path];
                }
            }
            if (self->dicForAlertInfo.count == 0 && !doSomeThing) {
                self->dicForAlertInfo = [NSMutableDictionary dictionaryWithDictionary:dic];
                return;
            }
            self->_dataSourceArray = nil;
            self->_dataSourceArray = [NSMutableArray array];
            for (NSString *path in dic) {
                [self->_dataSourceArray addObject:dic[path]];
            }
        }
        if ([NSThread isMainThread]) {
            [self createAlert];
        }else{
            dispatch_sync(dispatch_get_main_queue(), ^{
                [self createAlert];
            });
        }
     });
}





#pragma mark 睡眠监听
static NSString *sleepMethod_notification_time = @"sleepMethod_notification_time";
static NSString *isSleepNetAuth = @"isSleepNetAuth";
- (void)sleepMethod:(NSNotification *)notication {
    YGNetAuthModel *pModel = [[YGNetAuthModel model] qunueSelectFromNetAuthModel];
    if (pModel.IsNetAuth) {
        BOOL isAuth = YES;
        [YGNetAuthModel NetAuthCheck:&isAuth];
    }
    NSInteger time = (NSInteger)current_Time_Stamp();
    NSInteger l_time = [readFile(sleepMethod_notification_time) integerValue];
    save_local_Log(@"sleepMethod", [NSString stringWithFormat:@"sleepMethod--[%@]", notication.name]);
    if (l_time-time > 20 || time - l_time > 20) {
        writeFile(@"0", isSleepNetAuth);
        save_local_Log(@"sleepMethod", @"唤醒第一次尝试认证");
        YGNetAuthModel *pModel = [[YGNetAuthModel model] qunueSelectFromNetAuthModel];
        if (pModel.IsNetAuth) {
            BOOL isAuth = YES;
            [YGNetAuthModel NetAuthCheck:&isAuth];
        }
        writeFile([NSString stringWithFormat:@"%ld", time], sleepMethod_notification_time);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5*NSEC_PER_SEC)),dispatch_get_main_queue(), ^{
            BOOL IsSleepAuth = [readFile(isSleepNetAuth) boolValue];
            if (!IsSleepAuth) {
                YGNetAuthModel *pModel = [[YGNetAuthModel model] qunueSelectFromNetAuthModel];
                if (pModel.IsNetAuth) {
                    BOOL isAuth = YES;
                    [YGNetAuthModel NetAuthCheck:&isAuth];
                }
                save_local_Log(@"sleepMethod", @"第二次尝试");
                writeFile([NSString stringWithFormat:@"%ld", time], sleepMethod_notification_time);
            }
        });
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(15*NSEC_PER_SEC)),dispatch_get_main_queue(), ^{
            BOOL IsSleepAuth = [readFile(isSleepNetAuth) boolValue];
            if (!IsSleepAuth) {
                YGNetAuthModel *pModel = [[YGNetAuthModel model] qunueSelectFromNetAuthModel];
                if (pModel.IsNetAuth) {
                    BOOL isAuth = YES;
                    [YGNetAuthModel NetAuthCheck:&isAuth];
                }
                save_local_Log(@"sleepMethod", @"第三次尝试");
                writeFile([NSString stringWithFormat:@"%ld", time], sleepMethod_notification_time);
            }
        });
    }
}

#pragma mark USB管控
- (void)createUsbDeviceRegistration:(NSNotification *)notifiacation {
    USBRegisteredWindowController* usbWindowController = [[USBRegisteredWindowController alloc] initWithWindowNibName:@"USBRegisteredWindowController"];
    usbWindowController.model = notifiacation.object;
    [self.WindowControllerCollection presentWindowController:usbWindowController animatedFromBottom:YES];
}

#pragma mark 弹出USBInfo窗口
- (void)createUSBInfoWindowControllerWithModel:(NSNotification *)noti {
    __block USBModel *model = noti.object;
    RecvGetUsbInfo(model.locationID);
    __weak typeof(self) weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        __strong typeof (weakSelf)strongSelf = weakSelf;
        if (strongSelf.usbInfoWindowController) {
            [strongSelf.usbInfoWindowController.window close];
            strongSelf.usbInfoWindowController = nil;
        }
        USBModel *now_model = [model qunueSelectFromUsbTableWithModel:model];
        strongSelf.usbInfoWindowController = [[USBInfoWindowController alloc] initWithWindowNibName:@"USBInfoWindowController"];
        if (now_model) {
            strongSelf.usbInfoWindowController.usbModel = now_model;
            if (model.registered == 2) {
                now_model.registered = model.registered;
            }
        }
        [strongSelf.WindowControllerCollection presentWindowController:strongSelf.usbInfoWindowController animatedFromBottomRight:YES];
    });
}

- (void)openUSBRegistedWaitWindowController:(NSNotification *)notification {
    if (self.rwController) {
        [self.rwController.window close];
        self.rwController = nil;
    }
    self.rwController = [[USBRegistedWaitWindowController alloc] initWithWindowNibName:@"USBRegistedWaitWindowController"];
    self.rwController.usbModel = notification.object;
    [self.WindowControllerCollection presentWindowController:self.rwController animatedFromBottomRight:YES];
}

- (HXWindowControllerCollection *)WindowControllerCollection{
    if (!_WindowControllerCollection) {
        _WindowControllerCollection = [[HXWindowControllerCollection alloc] init];
    }
    return _WindowControllerCollection;
}
// USB管控
- (void)createUsbManagerControl {
    if (!self.usbManager) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.3f * NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            NSArray *array = [[USBModel model] qunueSelectFromUsbModel];
            if (array.count > 0) {
                for (USBModel *model in array) {
                    if (model.bsd_name.length > 0)
                    RecvGetUsbInfo(model.locationID);
                }
            }
        });
        __weak typeof(self) weakSelf = self;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0f * NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            __strong typeof(weakSelf) strongSelf = weakSelf;
            strongSelf.usbManager = [USBManager shareInstance];
//            [strongSelf.usbManager registerMatching];
        });
    }
}

// USB插拔


@end
