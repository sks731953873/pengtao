//
//  USBRegisteredWindowController.m
//  Mac_1.0
//
//  Created by xin on 2019/2/19.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "USBRegisteredWindowController.h"
#import "YGTool.h"
#import "Singleton.h"
#import "USBInfoWindowController.h"
#import "USBRegistedWaitWindowController.h"
#import "YGPopViewController.h"
@interface USBRegisteredWindowController ()<NSComboBoxDelegate, NSComboBoxDataSource,NSWindowDelegate>

/** 部门ID*/
@property (nonatomic, copy) NSString *DepartID;
@property (nonatomic, strong) NSMutableArray *dataArray;
/** 部门信息窗口*/
@property (nonatomic, strong) ArchitectureWindowController *awController;
/** 设备名称*/
@property (weak) IBOutlet NSTextField *deviceNameText;
/** 厂家名称*/
@property (weak) IBOutlet NSTextField *vendorNameText;
/** 型号*/
@property (weak) IBOutlet NSTextField *buildNumberText;
/** 容量*/
@property (weak) IBOutlet NSTextField *sizeText;
/** 注册人*/
@property (weak) IBOutlet NSTextField *usernameText;
/** 部门*/
@property (weak) IBOutlet NSComboBox *comboBox;
/** 备注*/
@property (unsafe_unretained) IBOutlet NSTextView *messageText;

@property (nonatomic, strong) NSAlert *alert;
@property (nonatomic, strong) NSMenu *theMenu;
@property(nonatomic,strong) NSPopover *detailedPopover;
@property (nonatomic, strong) YGPopViewController *popViewController;
@end

@implementation USBRegisteredWindowController

- (void)windowDidLoad {
    [super windowDidLoad];
    [self regNotification];
    [self initUI];
}
//
//- (void)windowWillLoad {
//    [super windowWillLoad];
//}
- (void)initUI {
    self.window.title = @"USB设备注册";
    //    [[self.view.window standardWindowButton:NSWindowFullScreenButton] setEnabled:NO];
    self.comboBox.editable = NO;
    self.comboBox.usesDataSource = NO;
    self.comboBox.delegate = self;
    self.comboBox.maximumNumberOfLines = -1;
    self.comboBox.hasVerticalScroller = NO;
    [self.comboBox removeAllItems];
    if (self.model) {
        self.sizeText.stringValue = self.model.size.length >0? self.model.size:@"未知";
        self.deviceNameText.stringValue = self.model.USBProductName >0 ? self.model.USBProductName: @"未知";
        self.vendorNameText.stringValue = self.model.USBVendorName.length>0? self.model.USBVendorName:@"未知";
        self.buildNumberText.stringValue = self.model.USBVendorString.length>0? self.model.USBVendorString:@"未知";
    }
}

- (void)regNotification {
    NSNotificationCenter * notifi = [NSNotificationCenter defaultCenter];
    [notifi addObserver:self selector:@selector(recvGetDepart:) name:@"recvGetDepart" object:nil];
    [notifi addObserver:self selector:@selector(ArchitectureWindowControllerWillClose) name:@"ArchitectureWindowControllerWillClose" object:nil];
    NSRect rect = self.comboBox.bounds;
    rect.size.width -= 20;
    [self.comboBox addTrackingArea:[[NSTrackingArea alloc] initWithRect:rect options:NSTrackingMouseEnteredAndExited|NSTrackingActiveWhenFirstResponder|NSTrackingActiveAlways owner:self.comboBox userInfo:nil]];

    [self regCutOffNetTimer];
}

- (void)regCutOffNetTimer {
    [self performSelector:@selector(showAlertForWarningCutOffNet) withObject:nil afterDelay:1.9f];
    RecvGetDepart();
}

// 接受到回执
- (void)recvGetDepart:(NSNotification *)noti {
    if ([noti.object isKindOfClass:[NSDictionary class]]) {
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(showAlertForWarningCutOffNet) object:nil];
        [NSObject cancelPreviousPerformRequestsWithTarget:self];
        NSDictionary *xmlDict = noti.object;
        self.dataArray = (NSMutableArray *)[TreeNode DealwithDictionaryToArray:xmlDict];
        if (self.dataArray.count>0) {
            [self initUI];
            TreeNode *tNode = self.dataArray[0];
            self.comboBox.stringValue = tNode.name;
            self.DepartID = [NSString stringWithFormat:@"%@", @(tNode.DepartID)];
        }
    }
}

//  注册按钮点击事件
- (IBAction)registrationButton:(id)sender {
//由字母、数字、中文以及-_组成且长度不超过50位
//    NSString * regex = @"^[a-zA-Z0-9-_\u4e00-\u9fa5]+$";
//    NSString *regex1 = @"^[A-Za-z\\s\\u0391-\\uFFE5!@#$%&*()_+-\\[\\]{}:|<>?,\\.\\d！，。？%]{0,50}$";
//    NSString *regex2 = @"^[A-Za-z\\s\\u0391-\\uFFE5!@#$%&*()_+-\\[\\]{}:|<>?,\\.\\d！，。？%]{0,500}$";

    NSString *regex1 = @"^[a-zA-Z0-9-_\u4e00-\u9fa5]{0,50}$";
    NSString *regex2 = @"^[a-zA-Z0-9-_\u4e00-\u9fa5]{0,500}$";
    NSPredicate *pred1 = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex1];
    NSPredicate *pred2 = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex2];
    NSString *nameString = [NSString stringWithFormat:@"%@", self.usernameText.stringValue];
    NSString *messageString = [NSString stringWithFormat:@"%@", self.messageText.string];
    BOOL result_1 = [pred1 evaluateWithObject:nameString];
    BOOL result_2 = [pred2 evaluateWithObject:messageString];
    if(result_1 && result_2) {
        RecvUSBRegister(self.model, self.usernameText.stringValue, self.messageText.string, self.DepartID);
        self.model.registered = 2;
        self.model.registeredUser = self.usernameText.stringValue;
        self.model.DepartID = [self.DepartID integerValue];
        NSNotification *notification2 = [NSNotification notificationWithName:@"openUSBRegistedWaitWindowController" object:self.model];
        [[NSNotificationCenter defaultCenter] postNotification:notification2];
        [self.window close];
    }else{
        NSString *messageString = @"注册人信息由字母、数字、中文以及-_组成且长度不超过50位.";
        if (!result_2)
            messageString = @"备注信息由字母、数字、中文以及-_组成且长度不超过500位.";
        // 输入不符合
        NSAlert *alert = [[NSAlert alloc] init];
        alert.messageText = @"输入框提示";
        [alert setInformativeText:messageString];
        [alert addButtonWithTitle:@"确认"];
        [alert setAlertStyle:NSWarningAlertStyle];
        [alert runModal];
    }

}


#pragma mark - NSComboBoxDelegate

- (void)comboBoxSelectionDidChange:(NSNotification *)notification {
    //    NSComboBox *comboBox = notification.object;
    //    NSInteger selectedIndex = comboBox.indexOfSelectedItem;
    //    NSLog(@"comboBoxSelectionDidChange selected item %@",self.dataArray[selectedIndex]);
    //    if ([_comboBox.stringValue isEqualToString:self.dataArray[selectedIndex]]) {
    // 去获取当前来宾姓名
    //        NSLog(@"-----------------------------\n%@\n----------------------------",self.dataArray[selectedIndex]);
    //    }
}

- (void)comboBoxSelectionIsChanging:(NSNotification *)notification {
    //    NSComboBox *comboBox = notification.object;
    //    NSInteger selectedIndex = comboBox.indexOfSelectedItem;
    //    NSLog(@"comboBoxSelectionIsChanging selected item %@",self.dataArray[selectedIndex]);

}

- (void)comboBoxWillDismiss:(NSNotification *)notification {
    //    NSLog(@"%@\n-----------------------------\n%@\n----------------------------", notification, _comboBox.stringValue);
    //  获取关联信息
}

- (void)comboBoxWillPopUp:(NSNotification *)notification {
#pragma mark-弹出部门选择列表
//    if (self.dataArray.count < 1) {
//        return;
//    }
    self.awController = [[ArchitectureWindowController alloc] initWithWindowNibName:@"ArchitectureWindowController"];
    __weak typeof(self) weakSelf = self;
    self.awController.block = ^(TreeNode *node) {
//        __strong typeof(weakSelf) strongSelf = weakSelf;
        weakSelf.DepartID = [NSString stringWithFormat:@"%@", @(node.DepartID)];
        weakSelf.comboBox.stringValue = node.name;
    };
    self.awController.dataSource = self.dataArray;
    HXWindowControllerCollection *windowControllerCollection = [[HXWindowControllerCollection alloc] init];
    [windowControllerCollection presentWindowController:self.awController animatedFromBottom:YES];
    self.comboBox.enabled = NO; 
}

-(void)controlTextDidChange:(NSNotification*)notification {
    id object = [notification object];
    //    NSComboBox * box = (NSComboBox *)object;
    [object setCompletes:YES];
    //    NSLog(@"notification : %@\n[%@]",notification, box.stringValue);
}



#pragma mark
- (void)mouseEntered:(NSEvent *)event {
//    NSLog(@"mouse enter");
    [super mouseEntered:event];
    if (self.comboBox.stringValue.length > 0) {
        self.popViewController.pop_message = self.comboBox.stringValue;
//        NSRect rect = [_popViewController getPop_messageLength];
//        [self.detailedPopover setContentSize:rect.size];
        [self.detailedPopover showRelativeToRect:self.comboBox.bounds ofView:self.comboBox preferredEdge:NSRectEdgeMaxY];
    }
}

- (void)mouseExited:(NSEvent *)event {
    [super mouseExited:event];
    if (_theMenu) {
        [_theMenu removeAllItems];
        _theMenu = nil;
    }
    [self.detailedPopover close];
//    NSLog(@"mouse exited");
}

- (void)ArchitectureWindowControllerWillClose {
    if (self.awController.window) {
        [self.awController.window close];
    }
    self.awController = nil;
    if (self.awController.isWindowLoaded) {

    }
    self.comboBox.enabled = YES;
}


#pragma mark -网络不通时的弹窗提示
- (void)showAlertForWarningCutOffNet {
    self.alert = [[NSAlert alloc] init];
    self.alert.messageText = @"提示：";
    self.alert.informativeText = @"当前网络不通，请重试。";
    [self.alert addButtonWithTitle:@"是"];
    [self.alert addButtonWithTitle:@"否"];
    self.alert.alertStyle = NSWarningAlertStyle;
    [NSApp activateIgnoringOtherApps:YES];
    [self.window makeKeyAndOrderFront:self];
    __block USBRegisteredWindowController *block_vc = self;
    [self.alert beginSheetModalForWindow:self.window completionHandler:^(NSModalResponse returnCode) {
        if (returnCode == 1000) {
            [block_vc regCutOffNetTimer];
        } else if (returnCode == 1001) {
            // 点击的否
            NSNotification *notification = [NSNotification notificationWithName:@"createUSBInfoWindowController" object:block_vc.model];
            [[NSNotificationCenter defaultCenter] postNotification:notification];
            [block_vc.window close];
        }
    }];
}

- (NSPopover *)detailedPopover {
    if(!_detailedPopover)
    {
        _detailedPopover=[[NSPopover alloc]init];
        _detailedPopover.appearance = [NSAppearance appearanceNamed:NSAppearanceNameAqua];
        _detailedPopover.contentViewController = self.popViewController;
        _detailedPopover.behavior = NSPopoverBehaviorTransient;
    }
    return _detailedPopover;
}

- (YGPopViewController *)popViewController {
    if(!_popViewController)
    {
        _popViewController = [[YGPopViewController alloc]init];
    }
    return _popViewController;
}

#pragma mark set / get
-(NSString *)DepartID {
    if (!_DepartID) {
        _DepartID = @"";
    }
    return _DepartID;
}

-(NSMutableArray *)dataArray {
    if (!_dataArray){
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)dealloc {
    if (self.awController.window) {
        [self.awController.window close];
        self.awController = nil;
    }
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
