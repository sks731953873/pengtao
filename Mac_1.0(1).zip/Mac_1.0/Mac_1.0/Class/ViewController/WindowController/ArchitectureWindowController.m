//
//  ArchitectureWindowController.m
//  Mac_1.0
//
//  Created by xin on 2019/2/19.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "ArchitectureWindowController.h"
#import "ArchitectureView.h"
#import "Singleton.h"
@interface ArchitectureWindowController ()<NSTableViewDelegate, NSTableViewDataSource>

@property (nonatomic, strong) NSTableView *tableView;
@property (strong, nonatomic) NSScrollView * tableViewContent;
@property (strong, nonatomic) NSTableColumn * tableColumn;
@property (nonatomic, assign) NSInteger selected;

@property (weak) IBOutlet NSTextField *messageLabel;

@property (weak) IBOutlet NSButton *okButton;

@end

@implementation ArchitectureWindowController

static NSInteger kCellHeight = 30.f;

- (void)windowDidLoad {
    [super windowDidLoad];
    [[self.window standardWindowButton:NSWindowCloseButton] setHidden:YES];
    [[self.window standardWindowButton:NSWindowFullScreenButton] setEnabled:NO];
    [[self.window standardWindowButton:NSWindowMiniaturizeButton] setEnabled:NO];
    [[self.window standardWindowButton:NSWindowZoomButton] setEnabled:NO];
    [[self.window standardWindowButton:NSWindowZoomButton] setHidden:YES];
    [[self.window standardWindowButton:NSWindowFullScreenButton] setHidden:YES];
    [[self.window standardWindowButton:NSWindowMiniaturizeButton] setHidden:YES];
    self.window.title = @"请选择您的部门：";
    self.messageLabel.hidden = YES;
    [self.messageLabel.window setLevel:1];
    [self regNotification];
    RecvGetDepart();
    [self performSelector:@selector(showMessageWarningCutOffNet) withObject:nil afterDelay:3.f];

}

- (void)regNotification {
    NSNotificationCenter * notifi = [NSNotificationCenter defaultCenter];
    [notifi addObserver:self selector:@selector(recvGetDepart:) name:@"recvGetDepart" object:nil];
}

#pragma mark - init
- (void)initUI{
    [self.window.contentView addSubview:self.tableViewContent positioned:NSWindowBelow relativeTo:self.messageLabel];
    //    [self.view addSubview:self.tableView];
    self.tableViewContent.hidden = YES;
    [self.tableView addTableColumn:self.tableColumn];
    self.tableView.headerView.hidden = YES;
    [self.tableViewContent setDocumentView:self.tableView];
    [self.tableViewContent setHasVerticalScroller:YES];
    [self.tableViewContent setHasHorizontalScroller:YES];
    [self.tableView reloadData];
    [self.tableViewContent.documentView scrollPoint:NSMakePoint(0, 0)];
//    NSRect bounds = NSMakeRect(0,
//                               NSMinY(self.tableView.bounds),
//                               NSWidth(self.tableView.bounds),
//                               NSHeight(self.tableView.bounds));
//    [self.tableViewContent setValue:@(bounds) forKey:@"bounds"];
//    self.tableView.bounds = bounds;
//    [self.window makeFirstResponder:self.tableView];
}

#pragma mark - setter
- (NSScrollView *)tableViewContent{
    if (!_tableViewContent) {
        _tableViewContent = [[NSScrollView alloc]initWithFrame:CGRectMake(0, 44, self.window.frame.size.width, self.window.frame.size.height-42)];
        _tableViewContent.backgroundColor = [NSColor whiteColor];
    }
    return _tableViewContent;
}

- (NSTableColumn *)tableColumn{
    if (!_tableColumn) {
        _tableColumn = [[NSTableColumn alloc]initWithIdentifier:@"ArchitectureTableColumnCell"];
        _tableColumn.width = self.window.frame.size.width;
        if (self.dataSource.count > 0) {
            NSString *string = @"";
            for (TreeNode * subNode in self.dataSource) {
                NSString *flagText = !subNode.isLeaf? (subNode.isOpen?@"-":@"+"):@"";
                NSString *content = [NSString stringWithFormat:@"%@ %@ %@", subNode.levelString, flagText, subNode.name];
                if (string.length <= content.length) {
                    string = content;
                }
            }
            NSRect rect = [self getStringLength:string];
            self.tableColumn.width = rect.size.width+50;
        }
//                _tableColumn.title = @"标题";
        //        [_tableColumn setDataCell:[[CustomTableViewCell alloc]init]];
    }
    return _tableColumn;
}

- (NSTableView *)tableView
{
    if(!_tableView){
        CGRect rect = self.window.frame;
//                rect.origin.y += 60;
//                rect.size.height -= 60;
        _tableView = [[NSTableView alloc] initWithFrame:rect];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        // 单点
        [_tableView setAction:@selector(ontablerowclicked:)];

        // 双击
        [_tableView setDoubleAction:@selector(ontableviewrowdoubleClicked:)];
    }
    return _tableView;
}

- (NSMutableArray *)dataSource{
    if (!_dataSource) {
        _dataSource = [[NSMutableArray alloc]init];
    }
    return _dataSource;
}

// 接受到回执
- (void)recvGetDepart:(NSNotification *)noti {
    if ([noti.object isKindOfClass:[NSDictionary class]]) {
        NSDictionary *xmlDict = noti.object;
        self.dataSource = (NSMutableArray *)[TreeNode DealwithDictionaryToArray:xmlDict];
        if (self.dataSource.count < 1) 
            return;

        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(showMessageWarningCutOffNet) object:nil];
        [NSObject cancelPreviousPerformRequestsWithTarget:self];
        [self initUI];
        [self.tableView reloadData];
        self.messageLabel.hidden = YES;
        self.tableViewContent.hidden = NO;
    }
}

- (void)showMessageWarningCutOffNet {
    [self.messageLabel.window setLevel:1];
    self.messageLabel.hidden = NO;
}

#pragma mark - NSTableViewDelegate&&NSTableViewDataSourceDelegate
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView{
    return self.dataSource.count;
}

//返回NSView类型的时候调用
- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    NSString * Id = [tableColumn identifier];
    ArchitectureView *view = [tableView makeViewWithIdentifier:Id owner:self];
    TreeNode *node = self.dataSource[row];
    NSString *flagText = !node.isLeaf? (node.isOpen?@"-":@"+"):@"";
    NSString *content = [NSString stringWithFormat:@"%@ %@ %@", node.levelString, flagText, node.name];
    if (!view) {
        view = [[ArchitectureView alloc]initWithFrame:CGRectMake(0, 0, tableColumn.width+50, kCellHeight)];
    }
    view.content = content;
    return view;
}

- (NSRect)getStringLength:(NSString *)string {
    NSDictionary *attributes = @{NSFontAttributeName:[NSFont systemFontOfSize:10],};
    NSRect textSize =[string boundingRectWithSize:NSMakeSize(MAXFLOAT, 100) options:NSStringDrawingTruncatesLastVisibleLine attributes:attributes context:nil];
    return textSize;
}

// 返回NSCell类型的时候调用
//
//- (NSCell *)tableView:(NSTableView *)tableView dataCellForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
//    NSString * Id = [tableColumn identifier];
//    NSCell *cell;
//    if ([Id isEqualToString:@"cell"]&&!cell) {
//        cell = [[CustomTableViewCell alloc]init];
//    }
//    return cell;
//}

- (id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    return nil;
}

- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row{
    return kCellHeight;
}

// 返回是否选中状态
- (BOOL)tableView:(NSTableView *)tableView shouldSelectRow:(NSInteger)row{
    if((row+10) == self.selected) {
        return NO;
    }
    TreeNode *node = self.dataSource[row];
    if (node.isLeaf) {
        return YES;
    }
    node.isOpen = !node.isOpen;
    NSArray *nodes = [node needsDisplayNodes];
    NSInteger insertIndex = [self.dataSource indexOfObject:node] + 1;
    NSRange range = NSMakeRange(insertIndex, nodes.count);
    //    [tableView beginUpdates];
    if (node.isOpen) {
        [self.dataSource insertObjects:nodes atIndexes:[NSIndexSet indexSetWithIndexesInRange:range]];
        [tableView insertRowsAtIndexes:[NSIndexSet indexSetWithIndexesInRange:range]
                         withAnimation:NSTableViewAnimationSlideUp];

    } else {
        for (TreeNode *subNode in nodes) {
            NSUInteger index = [self.dataSource indexOfObject:subNode];
            if (!index) continue;
            [self.dataSource removeObject:subNode];
            [tableView removeRowsAtIndexes:[NSIndexSet indexSetWithIndex:index] withAnimation:NSTableViewAnimationSlideDown];
        }
    }
    NSString *string = @"";
    for (TreeNode * subNode in self.dataSource) {
        NSString *flagText = !subNode.isLeaf? (subNode.isOpen?@"-":@"+"):@"";
        NSString *content = [NSString stringWithFormat:@"%@ %@ %@", subNode.levelString, flagText, subNode.name];
        if (string.length <= content.length) {
            string = content;
        }
    }
    NSRect rect = [self getStringLength:string];
    self.tableColumn.width = rect.size.width+50;
    [tableView reloadData];
    //    [tableView endUpdates];
    return YES;
}

#pragma mark-单击
- (void)ontablerowclicked:(NSTableView *)tableView {
    NSInteger row = tableView.selectedRow+10;
    if (row < 0) {
        self.selected = 0;
        return;
    }else if (row == self.selected) {
        self.selected = -1;
        [tableView selectRowIndexes:[NSIndexSet indexSetWithIndex:-1] byExtendingSelection:YES];
        [tableView reloadData];
    }else {
        self.selected=row;
    }
}

#pragma mark-双击cell
- (void)ontableviewrowdoubleClicked:(NSTableView *)tableView {

}

#pragma mark action
// 确认
- (IBAction)okAction:(id)sender {
    if (self.dataSource.count <1) {
        [self closeSelfWindow];
        return;
    }
    NSInteger num = self.selected <= 0? 0:self.selected - 10;
    if (num > self.dataSource.count)
        return;
    TreeNode *node = self.dataSource[num];
    if (self.block) {
        self.block(node);
    }
    [self closeSelfWindow];
}

// 取消
- (IBAction)cancelAction:(id)sender {
    [self closeSelfWindow];
}


- (void)closeSelfWindow {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ArchitectureWindowControllerWillClose" object:nil];

}

@end
