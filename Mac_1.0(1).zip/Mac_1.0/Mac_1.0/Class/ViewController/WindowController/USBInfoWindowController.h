//
//  USBInfoWindowController.h
//  Mac_1.0
//
//  Created by xin on 2019/2/11.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "USBModel.h"



@interface USBInfoWindowController : NSWindowController

@property (nonatomic, strong) USBModel *usbModel; 

@end


