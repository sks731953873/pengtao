//
//  USBRegisteredWindowController.h
//  Mac_1.0
//
//  Created by xin on 2019/2/19.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "ArchitectureWindowController.h"
#import "USBManager.h"


@interface USBRegisteredWindowController : NSWindowController
@property (nonatomic, strong) USBModel *model;
//@property (nonatomic, copy) NSString *path;

@end

