//
//  ArchitectureWindowController.h
//  Mac_1.0
//
//  Created by xin on 2019/2/19.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "TreeNode.h"
#import "HXWindowControllerCollection.h"
typedef void (^ArchitectureBlock)(TreeNode *node);


@interface ArchitectureWindowController : NSWindowController

@property (nonatomic, copy) ArchitectureBlock block;
@property (nonatomic, strong) TreeNode *node;
@property (strong, nonatomic) NSMutableArray * dataSource;
@end


