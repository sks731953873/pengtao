//
//  USBRegistedWaitWindowController.h
//  Mac_1.0
//
//  Created by xin on 2019/2/20.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "USBModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface USBRegistedWaitWindowController : NSWindowController
@property (nonatomic, strong) USBModel *usbModel;
@end

NS_ASSUME_NONNULL_END
