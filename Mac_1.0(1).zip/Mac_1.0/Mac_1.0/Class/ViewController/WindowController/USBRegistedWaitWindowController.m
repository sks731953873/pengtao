//
//  USBRegistedWaitWindowController.m
//  Mac_1.0
//
//  Created by xin on 2019/2/20.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "USBRegistedWaitWindowController.h"

@interface USBRegistedWaitWindowController ()

@end

@implementation USBRegistedWaitWindowController

- (void)windowDidLoad {
    [super windowDidLoad];
    
    // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(removeWindowController:)
                                                 name:NSWindowWillCloseNotification
                                               object:self.window];
}

- (void)removeWindowController:(NSNotification *)notification {
    NSWindow *window = (NSWindow *)notification.object;
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NSWindowWillCloseNotification object:window];
    NSNotification *notification1 = [NSNotification notificationWithName:@"createUSBInfoWindowController" object:self.usbModel];
    [[NSNotificationCenter defaultCenter] postNotification:notification1];
}


- (IBAction)okAction:(id)sender {
    [self.window close];
}
@end
