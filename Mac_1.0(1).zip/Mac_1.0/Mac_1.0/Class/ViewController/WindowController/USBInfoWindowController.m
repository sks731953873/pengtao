//
//  USBInfoWindowController.m
//  Mac_1.0
//
//  Created by xin on 2019/2/11.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "USBInfoWindowController.h"
#import "USBRegisteredWindowController.h"
#import "Singleton.h"
#import "TreeNode.h"
#import "NSColor+YGCOLOR.h"
#import "YGTool.h"
#import "YGPopViewController.h"

@interface USBInfoWindowController ()
// 名称
@property (weak) IBOutlet NSTextField *username;
// 部门
@property (weak) IBOutlet NSTextField *group;
// 注册人
@property (weak) IBOutlet NSTextField *rUsername;
// 注册期限
@property (weak) IBOutlet NSTextField *regTime;
// 访问控制
@property (weak) IBOutlet NSTextField *accessControl;
// 注册按钮
@property (weak) IBOutlet NSButton *registered;

@property (nonatomic, strong) NSMutableArray *dataArray;

@property (nonatomic, strong) NSAlert *alert;

@property(nonatomic,strong) NSPopover *detailedPopover;
@property (nonatomic, strong) YGPopViewController *popViewController;

@end

@implementation USBInfoWindowController

- (void)windowDidLoad {
    [super windowDidLoad];
    self.window.title = @"您插入一个存储设备";
    [[self.window standardWindowButton:NSWindowFullScreenButton] setEnabled:NO];
    [[self.window standardWindowButton:NSWindowMiniaturizeButton] setEnabled:NO];
    [[self.window standardWindowButton:NSWindowZoomButton] setEnabled:NO];
    [[self.window standardWindowButton:NSWindowZoomButton] setHidden:YES];
    [[self.window standardWindowButton:NSWindowFullScreenButton] setHidden:YES];
    [[self.window standardWindowButton:NSWindowMiniaturizeButton] setHidden:YES];

    [self regNotification];
    // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    self.username.stringValue = self.usbModel.USBProductName.length>0?self.usbModel.USBProductName:@"";
    [self setAccessControlWithModel];
    [self setRegTimeWithModel];
    [self setRUsernameWithModel];

    [self.group addTrackingArea:[[NSTrackingArea alloc] initWithRect:self.group.bounds options:NSTrackingMouseEnteredAndExited|NSTrackingActiveWhenFirstResponder|NSTrackingActiveAlways owner:self.group userInfo:nil]];
    [self.rUsername addTrackingArea:[[NSTrackingArea alloc] initWithRect:self.rUsername.bounds options:NSTrackingMouseEnteredAndExited|NSTrackingActiveWhenFirstResponder|NSTrackingActiveAlways owner:self.rUsername userInfo:nil]];
}

// 注册按钮点击事件
- (IBAction)registeredClick:(id)sender {
//    NSButton *button = sender;
//    if ([button.stringValue isEqualToString:@"确认"]) {
//        // 移除通知
//        [self removeNotification];
//        [self closeWindow];
//    }
    if (self.usbModel.volumes.count > 0 || self.usbModel.bsd_name.length > 1) {
        NSNotification* noti = [NSNotification notificationWithName:@"UsbDeviceRegistration" object:self.usbModel];
        [[NSNotificationCenter defaultCenter] postNotification:noti];
    }
    // 移除通知
    [self removeNotification];
    [self closeWindow];
}


- (void)regNotification {

    NSNotificationCenter * notifi = [NSNotificationCenter defaultCenter];
    [notifi addObserver:self selector:@selector(recvGetDepartUSBInfo:) name:@"recvGetDepartUSBInfo" object:nil];
//    self.usbModel.registeredUser = @"";
//    self.usbModel.registered = 0;
//    self.usbModel.EndDate = @"";
    int usbinfo_result = RecvGetUsbInfo(self.usbModel.locationID);
//    NSDistributedNotificationCenter *center = [NSDistributedNotificationCenter defaultCenter];
//    [center addObserver:self
//               selector:@selector(recvGetDepartUSBInfo:)
//                   name:@"recvGetDepartUSBInfo"/*@"PiaoYun Notification"*/
//                 object:nil];

    int depart_result = RecvGetDepart();
    if (depart_result != 1 || usbinfo_result != 1) {
        
    }
    [self regCutOffNetTimer];
}

- (void)removeNotification {
    NSDistributedNotificationCenter *center = [NSDistributedNotificationCenter defaultCenter];
    [center removeObserver:self];
}

- (void)regCutOffNetTimer {
    [self performSelector:@selector(showAlertForWarningCutOffNet) withObject:nil afterDelay:2.3f];
    RecvGetDepart();
}

// 接受到回执
- (void)recvGetDepartUSBInfo:(NSNotification *)noti {
        NSDictionary *xmlDict = nil;
        id userInfo = noti.object;
        if ([userInfo isKindOfClass:[NSDictionary class]]) {
            xmlDict = (NSDictionary *)userInfo;
        } else {
            return;
        }
        @try {
            self.dataArray = (NSMutableArray *)[TreeNode DealwithXMLDictionaryToArray:xmlDict];
            if (self.dataArray.count<1)
                return;
            USBModel *new_model = [self.usbModel qunueSelectFromUsbTableWithModel:self.usbModel];
            if (!new_model) {
                return;
            }
            if (new_model.registered != 1 && self.usbModel.registered == 2) {
                new_model.registered = 2;
            }
            self.usbModel = new_model;
            [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(showAlertForWarningCutOffNet) object:nil];
            [NSObject cancelPreviousPerformRequestsWithTarget:self];
            for (TreeNode *node in self.dataArray) {
                if (node.DepartID == self.usbModel.DepartID) {
                    self.username.stringValue = self.usbModel.USBProductName.length>0?self.usbModel.USBProductName:@"";
                    [self setAccessControlWithModel];
                    [self setRegTimeWithModel];
                    [self setRUsernameWithModel];
                    if(self.rUsername.stringValue.length>0){
                        self.group.stringValue = node.name.length>0? node.name: @"";
                        self.group.textColor = [NSColor blackColor];
                    }
                    break;
                }
            }
        } @catch (NSException *exception) {
            HXINFOLOG(@"%@", exception);
        } @finally {

        }
}

- (void)closeWindow {
    [self.window close];

}

- (void)setRegTimeWithModel {
    NSString *time = @"未注册";
    NSString *endDate = self.usbModel.EndDate;
    if (endDate.length > 0) {
        if ([endDate isEqualToString:@"9999-00-00"]) {
            time = @"永久";
        }else if ([endDate isEqualToString:@"0000-00-00"]){
            time = @"待审核";
        }
        else{
            time = endDate;
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            [formatter setDateFormat:@"yyyy-MM-dd"];
            [formatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:8]];//解决8小时时间差问题
            NSDateFormatter *formatter2 = [[NSDateFormatter alloc] init];
            [formatter2 setDateFormat:@"yyyy-MM-dd"];
            NSTimeInterval one_day_time = 24 * 60 * 60; // 一天的秒数
            NSDate *someDay = [formatter dateFromString:endDate];
            NSDate *date = [NSDate date];
            NSTimeZone *zone = [NSTimeZone systemTimeZone];
            NSInteger interval = [zone secondsFromGMTForDate:date];
            NSDate *datenow = [date dateByAddingTimeInterval:interval - one_day_time];
            NSComparisonResult result = [someDay compare:datenow];
            if (result == NSOrderedAscending) {
                //someDay比datenow大
                // 说明超过期限了
                self.accessControl.stringValue = @"禁止访问(使用期限已过期)";
                self.accessControl.textColor = [NSColor redColor];
                __block USBModel *model = self.usbModel;
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    if (model.volumes.count > 0) {
                        for (USBVolumeModel *volumeModel in model.volumes) {
                            if (volumeModel.mount_point.length > 0)
                                [YGTool AppleScriptAtMTLaunchedThroughTheUrlPath:[NSURL fileURLWithPath:volumeModel.mount_point] withPath:volumeModel.mount_point];
                        }
                    }
                });
            }
        }
    }else if (self.usbModel.registered == 2) {
        time = @"待审核";
    }
    self.regTime.stringValue = time.length > 0? time:@"";
}

- (void)setAccessControlWithModel {
    NSString *string = @"未注册";
    NSInteger isReg = self.usbModel.registered;
    if (isReg == 1) {
        string = @"已注册  放行访问";
        // 如果是已注册，那么就隐藏注册按钮
        self.accessControl.textColor = [NSColor colorWithHexString:@"#8B8B00"];
        self.registered.hidden = YES;
        self.registered.stringValue = @"确认";
    }else if (isReg == 2){
        self.registered.hidden = YES;
        string = @"待审核  禁止访问";
        self.registered.hidden = YES;
        self.accessControl.textColor = [NSColor redColor];
        __block USBModel *model = self.usbModel;
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            if (model.volumes.count > 0) {
                for (USBVolumeModel *volumeModel in model.volumes) {
                    if (volumeModel.mount_point.length > 0)
                    [YGTool AppleScriptAtMTLaunchedThroughTheUrlPath:[NSURL fileURLWithPath:volumeModel.mount_point] withPath:volumeModel.mount_point];
                }
            }
        });
    }else{
        self.accessControl.textColor = [NSColor redColor];
        if ([self.usbModel.EndDate isEqualToString:@"0000-00-00"]) {
            string = @"待审核  禁止访问";
            self.registered.hidden = YES;
        }else if (self.usbModel.EndDate.length > 0) {
            string = @"已注册  放行访问";
        }
    }
    self.accessControl.stringValue = string;
}

- (void)setRUsernameWithModel {
    self.rUsername.stringValue = self.usbModel.registeredUser.length>0? self.usbModel.registeredUser : @"";
}


#pragma mark -网络不通时的弹窗提示
- (void)showAlertForWarningCutOffNet {
    if (self.usbModel.EndDate.length > 1) {
        self.group.stringValue = @"暂时未获取到详细信息";
        self.group.textColor = [NSColor redColor];
    }
    self.alert = [[NSAlert alloc] init];
    self.alert.messageText = @"提示：存储设备信息获取异常";
    self.alert.informativeText = @"暂时未获取到详细信息，请重试。";
    [self.alert addButtonWithTitle:@"是"];
    [self.alert addButtonWithTitle:@"否"];
    self.alert.alertStyle = NSWarningAlertStyle;
    [NSApp activateIgnoringOtherApps:YES];
    [self.window makeKeyAndOrderFront:self];
    NSModalResponse response = [self.alert runModal];
    if (response == 1000) {
        [self regCutOffNetTimer];
    } else if (response == 1001) {
        // 点击的否
//        [self.window close];
    }
}


#pragma mark
- (void)mouseEntered:(NSEvent *)event {
    [super mouseEntered:event];
    NSPoint eventLocation = [event locationInWindow];
    NSPoint center = [self.window.contentView convertPoint:eventLocation fromView:nil];
//    NSLog(@"mouse enter[%f][%f]", center.x, center.y);
    if (center.y < 177) {
        // 显示注册人信息
        if (self.rUsername.stringValue.length > 10) {
            self.popViewController.pop_message = self.rUsername.stringValue;
            [self.detailedPopover showRelativeToRect:self.rUsername.bounds ofView:self.rUsername preferredEdge:NSRectEdgeMaxY];
        }
    }else {
        if (self.group.stringValue.length > 10) {
            self.popViewController.pop_message = self.group.stringValue;
            [self.detailedPopover showRelativeToRect:self.group.bounds ofView:self.group preferredEdge:NSRectEdgeMaxY];
        }
    }
}



- (void)mouseExited:(NSEvent *)event {
    [super mouseExited:event];
    if (self.detailedPopover.isShown) {
        [self.detailedPopover close];
    }

    NSPoint eventLocation = [event locationInWindow];
    NSPoint center = [self.window.contentView convertPoint:eventLocation fromView:nil];
        NSLog(@"mouse exited[%f][%f]", center.x, center.y);
}

- (NSPopover *)detailedPopover
{
    if(!_detailedPopover)
    {
        _detailedPopover=[[NSPopover alloc]init];
        _detailedPopover.appearance = [NSAppearance appearanceNamed:NSAppearanceNameAqua];
        _detailedPopover.contentViewController = self.popViewController;
        _detailedPopover.behavior = NSPopoverBehaviorTransient;
    }
    return _detailedPopover;
}

- (YGPopViewController *)popViewController {
    if(!_popViewController)
    {
        _popViewController=[[YGPopViewController alloc]init];
    }
    return _popViewController;
}

- (void)dealloc {
    if (self.alert) {
        [NSApp endSheet:self.alert.window];
        [self.alert.window orderOut:nil];
        self.alert = nil;
    }
}

@end
