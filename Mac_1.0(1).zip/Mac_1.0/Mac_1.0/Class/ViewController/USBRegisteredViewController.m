//
//  USBRegisteredViewController.m
//  Mac_1.0
//
//  Created by xin on 2019/1/22.
//  Copyright © 2019 infogo. All rights reserved.
//

#import "USBRegisteredViewController.h"
#import "ArchitectureViewController.h"
#import "YGTool.h"
#import "USBManager.h"
#import "Singleton.h"
#import "USBInfoWindowController.h"
@interface USBRegisteredViewController ()<NSComboBoxDelegate, NSComboBoxDataSource>

@property (nonatomic, strong) USBModel *model;
/** 部门ID*/
@property (nonatomic, copy) NSString *DepartID;
@property (nonatomic, strong) NSMutableArray *dataArray;

/** 部门*/
@property (weak) IBOutlet NSComboBox *comboBox;
/** 注册人*/
@property (weak) IBOutlet NSTextField *usernameText;
/** 设备名称*/
@property (weak) IBOutlet NSTextField *deviceNameText;
/** 厂家名称*/
@property (weak) IBOutlet NSTextField *vendorNameText;
/** 型号*/
@property (weak) IBOutlet NSTextField *buildNumberText;
/** 容量*/
@property (weak) IBOutlet NSTextField *sizeText;

@property (unsafe_unretained) IBOutlet NSTextView *messageText;

@end

@implementation USBRegisteredViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
    [self regNotification];
    [self initUI];
}

- (void)initUI {
    self.title = @"USB设备注册";
    //    [[self.view.window standardWindowButton:NSWindowFullScreenButton] setEnabled:NO];
    self.comboBox.editable = NO;
    self.comboBox.usesDataSource = NO;
    self.comboBox.delegate = self;
    self.comboBox.maximumNumberOfLines = 0;
    [self.comboBox removeAllItems];
    NSArray *array = [[USBModel model] qunueSelectFromUsbModel];

    for (USBModel *model in array) {
        if (model.paths.count > 0) {
            for (NSString *path in model.paths) {
                if ([path isEqualToString:self.path]) {
                    self.model = model;
                }
            }
        }
    }
    if (self.model) {
        self.sizeText.stringValue = self.model.size.length >0? self.model.size:@"未知";
        self.deviceNameText.stringValue = self.model.USBProductName >0 ? self.model.USBProductName: @"未知";
        self.vendorNameText.stringValue = self.model.USBVendorName.length>0? self.model.USBVendorName:@"未知";
        self.buildNumberText.stringValue = self.model.USBVendorString;
    }
}

- (void)regNotification {
    NSNotificationCenter * notifi = [NSNotificationCenter defaultCenter];
    [notifi addObserver:self selector:@selector(recvGetDepart:) name:@"recvGetDepart" object:nil];
    RecvGetDepart();
}

// 接受到回执
- (void)recvGetDepart:(NSNotification *)noti {
    if ([noti.object isKindOfClass:[NSDictionary class]]) {
        NSDictionary *xmlDict = noti.object;
        self.dataArray = (NSMutableArray *)[TreeNode DealwithDictionaryToArray:xmlDict];
        if (self.dataArray.count>0) {
            TreeNode *tNode = self.dataArray[0];
            self.comboBox.stringValue = tNode.name;
            self.DepartID = [NSString stringWithFormat:@"%@", @(tNode.DepartID)];
        }
    }
}

//  注册按钮点击事件
- (IBAction)registrationButton:(id)sender {

    RecvUSBRegister(self.model, self.usernameText.stringValue, self.messageText.string, self.DepartID);
    NSNotification *notification = [NSNotification notificationWithName:@"createUSBInfoWindowController" object:self.model];
    [[NSNotificationCenter defaultCenter] postNotification:notification];
    [self dismissController:nil];
}
#pragma mark - NSComboBoxDelegate

- (void)comboBoxSelectionDidChange:(NSNotification *)notification {
    //    NSComboBox *comboBox = notification.object;
    //    NSInteger selectedIndex = comboBox.indexOfSelectedItem;
    //    NSLog(@"comboBoxSelectionDidChange selected item %@",self.dataArray[selectedIndex]);
    //    if ([_comboBox.stringValue isEqualToString:self.dataArray[selectedIndex]]) {
    // 去获取当前来宾姓名
    //        NSLog(@"-----------------------------\n%@\n----------------------------",self.dataArray[selectedIndex]);
    //    }
}

- (void)comboBoxSelectionIsChanging:(NSNotification *)notification {
    //    NSComboBox *comboBox = notification.object;
    //    NSInteger selectedIndex = comboBox.indexOfSelectedItem;
    //    NSLog(@"comboBoxSelectionIsChanging selected item %@",self.dataArray[selectedIndex]);

}

- (void)comboBoxWillDismiss:(NSNotification *)notification {
    //    NSLog(@"%@\n-----------------------------\n%@\n----------------------------", notification, _comboBox.stringValue);
    //  获取关联信息

}

- (void)comboBoxWillPopUp:(NSNotification *)notification {
    // 弹出部门选择列表
    ArchitectureViewController *vc = [[ArchitectureViewController alloc] init];
    vc.block = ^(TreeNode *node) {
        self.DepartID = [NSString stringWithFormat:@"%@", @(node.DepartID)];
        self.comboBox.stringValue = node.name;
    };
    vc.dataSource = self.dataArray;
    [self presentViewControllerAsModalWindow:vc];
}

-(void)controlTextDidChange:(NSNotification*)notification {
    id object = [notification object];
    //    NSComboBox * box = (NSComboBox *)object;
    [object setCompletes:YES];
    //    NSLog(@"notification : %@\n[%@]",notification, box.stringValue);
}


#pragma mark set / get
-(NSString *)DepartID {
    if (!_DepartID) {
        _DepartID = @"";
    }
    return _DepartID;
}

-(NSMutableArray *)dataArray {
    if (!_dataArray){
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

@end
