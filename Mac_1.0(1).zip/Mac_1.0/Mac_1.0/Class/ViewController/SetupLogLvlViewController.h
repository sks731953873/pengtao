//
//  SetupLogLvlViewController.h
//  Mac_1.0
//
//  Created by jerrium on 11/14/18.
//  Copyright © 2018 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface SetupLogLvlViewController : NSViewController
@property (weak) IBOutlet NSButton *chkInfoLvl;
@property (weak) IBOutlet NSButton *chkDebugLvl;
@property (weak) IBOutlet NSButton *chkErrLvl;

@end

NS_ASSUME_NONNULL_END
