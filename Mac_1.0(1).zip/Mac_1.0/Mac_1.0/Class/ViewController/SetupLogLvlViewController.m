//
//  SetupLogLvlViewController.m
//  Mac_1.0
//
//  Created by jerrium on 11/14/18.
//  Copyright © 2018 infogo. All rights reserved.
//

#import "SetupLogLvlViewController.h"
#import "YGTool.h"

@interface SetupLogLvlViewController ()

@end

@implementation SetupLogLvlViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
    
    [self initData];
}

-(void)initData
{
    NSString *logLvl = readFile(@"LogLvl");
    
    if ([logLvl isEqualToString:@"debugLog"])
    {
        // 调试级别
        [self.chkDebugLvl setState:NSControlStateValueOn];
        [self.chkErrLvl setState:NSControlStateValueOff];
    }
    else if ([logLvl isEqualToString:@"errLog"])
    {
        // 错误级别
        [self.chkDebugLvl setState:NSControlStateValueOn];
        [self.chkErrLvl setState:NSControlStateValueOn];
    }
}

- (IBAction)saveAction:(id)sender {
    [self saveData];
    [self dismissViewController:self];
}

-(void)saveData
{
    if (self.chkErrLvl.state)
        writeFile(@"errLog", @"LogLvl");
    else if (self.chkDebugLvl.state)
        writeFile(@"debugLog", @"LogLvl");
    else
        writeFile(@"infoLog", @"LogLvl");
}

- (IBAction)checkChangeLvlAction:(NSButton*)sender
{
    // debug
    if (sender.tag == 1)
    {
        if (!sender.state)
            [self.chkErrLvl setState:sender.state];
    }
    // error
    else
    {
        if (sender.state)
            [self.chkDebugLvl setState:sender.state];
    }
}

@end
