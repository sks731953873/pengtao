//
//  ViewController.h
//  Mac_1.0
//
//  Created by apple on 2016/11/7.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController

@end

