//
//  SetViewController.h
//  Mac_1.0
//
//  Created by huhood on 16/12/12.
//  Copyright (c) 2016年 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface SetViewController : NSViewController

@end
