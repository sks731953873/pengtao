//
//  USBRegisteredViewController.h
//  Mac_1.0
//
//  Created by xin on 2019/1/22.
//  Copyright © 2019 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface USBRegisteredViewController : NSViewController
@property (nonatomic, copy) NSString *path;
@end

NS_ASSUME_NONNULL_END
