//
//  ProgramViewController.h
//  Mac_1.0
//
//  Created by apple on 2017/4/13.
//  Copyright © 2017年 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ProgramViewController : NSViewController

@end
