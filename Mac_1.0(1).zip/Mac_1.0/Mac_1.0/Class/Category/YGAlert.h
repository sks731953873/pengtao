//
//  YGAlert.h
//  Mac_1.0
//
//  Created by xin on 2018/4/18.
//  Copyright © 2018年 infogo. All rights reserved.
//

#import <Cocoa/Cocoa.h>


typedef void(^progressHandler)(NSModalResponse returnCode, NSString *message);

@interface YGAlert : NSAlert
/** 进度条*/
@property (nonatomic, strong) NSProgressIndicator *progressIndicator;

@property (nonatomic, strong) progressHandler handler;

@property (nonatomic, strong) NSTextField *textField;

/** 初始化YGAlert弹窗*/
+ (instancetype)alertWithStyle:(NSAlertStyle)alertStyle
                       message:(NSString *)message
                   informative:(NSString *)infomative
                       handler:(progressHandler)handler;
/** 关闭弹窗*/
- (void)endAlertSheet;

@end
