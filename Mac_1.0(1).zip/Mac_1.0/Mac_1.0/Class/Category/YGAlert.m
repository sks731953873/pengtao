//
//  YGAlert.m
//  Mac_1.0
//
//  Created by xin on 2018/4/18.
//  Copyright © 2018年 infogo. All rights reserved.
//

#import "YGAlert.h"

@implementation YGAlert

+ (instancetype)alertWithStyle:(NSAlertStyle)alertStyle
                       message:(NSString *)message
                   informative:(NSString *)infomative
                       handler:(progressHandler)handler {
    YGAlert *alert = [super new];
    if (message.length > 1)
    [alert setMessageText:message];
    if (infomative.length > 1)
    [alert setInformativeText:infomative];
    [alert setAlertStyle:alertStyle];
    [alert createProgressIndicator];
    [alert createTextField];
//    [alert addButtonWithTitle:@""];
    NSWindow *window = [NSApp keyWindow];
    if (!window) {
        window = [NSApp mainWindow];
        if (!window) {
            [NSApp activateIgnoringOtherApps:YES];

            NSArray *windows = [NSApp windows];
            window = windows[0];
            if ([window isVisible]) {
                    [window orderOut:self];
            } else {
                    [NSApp activateIgnoringOtherApps:YES];
                    [window makeKeyAndOrderFront:self];
                }
//            window = windows[0];
        }
    }
    
    [alert beginSheetModalForWindow:window completionHandler:^(NSModalResponse returnCode) {
        handler(returnCode, alert.messageText);
    }];

    return alert;
}

//- (NSProgressIndicator *)progressIndicator {
//    if (!_progressIndicator) {
//        _progressIndicator = [[NSProgressIndicator alloc] initWithFrame:NSMakeRect(110, 50, 100, 20)];
//    }
//    return _progressIndicator;
//}

/** 创建进度条*/
- (void)createProgressIndicator {
    NSProgressIndicator * progressIndicator = [[NSProgressIndicator alloc] initWithFrame:NSMakeRect(110, 50, self.window.frame.size.width -150, 20)];
    progressIndicator.wantsLayer = YES;
//    progressIndicator.layer.backgroundColor = [NSColor cyanColor].CGColor;
    progressIndicator.controlSize = NSControlSizeRegular;
    [progressIndicator sizeToFit];
    [progressIndicator setDoubleValue:0];
    [progressIndicator setIndeterminate: NO];
    [progressIndicator setMinValue:0];
    [progressIndicator setMaxValue:100];
    self.progressIndicator = progressIndicator;
    [[[self window] contentView] addSubview:self.progressIndicator];
}
//
- (void)createTextField {
    NSTextField *textField = [[NSTextField alloc] initWithFrame:NSMakeRect(200, 25, 80, 20)];
    textField.stringValue = @"0%";
    textField.backgroundColor = [NSColor clearColor];
    //设置是否可以编辑
    [textField setEditable:NO];
    //设置是否绘制背景
    textField.drawsBackground = NO;
    //设置文字颜色
    textField.textColor = [NSColor blackColor];
    //设置是否显示边框
    textField.bordered = NO;
    //设置是否绘制贝塞尔风格的边框
    textField.bezeled = NO;
    //设置文本框是否可以选中
    textField.selectable = NO;
    //设置贝塞尔风格
    textField.bezelStyle = NSTextFieldSquareBezel;
    //设置倾向布局宽度
//    _textField.preferredMaxLayoutWidth = 100;
    //设置最大行数
//    _textField.maximumNumberOfLines = 5;
    //设置断行模式
//    [[_textField cell] setLineBreakMode:NSLineBreakByCharWrapping];
    //设置是否启用单行模式
    [[textField cell]setUsesSingleLineMode:YES];
    //设置超出行数是否隐藏
    [[textField cell] setTruncatesLastVisibleLine:YES];
    self.textField = textField;
    [[[self window] contentView] addSubview:textField];
}
/** 关闭弹窗*/
- (void)endAlertSheet {
    //  想做成提示3s后关闭弹窗
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            [[NSApp keyWindow] endSheet:[self window]];
//            [NSApp endSheet:[self window] returnCode:NSAlertDefaultReturn];
//            NSWindow *window = [NSApp keyWindow];
//            if (!window) {
//                window = [NSApp mainWindow];
//                if (!window) {
//                    [NSApp activateIgnoringOtherApps:YES];
//                    NSArray *windows = [NSApp windows];
//                    if (windows.count > 0) {
//                        window = windows[0];
//                        if ([window isVisible]) {
//                            [window orderOut:self];
//                        } else {
//                            [NSApp activateIgnoringOtherApps:YES];
//                            [window makeKeyAndOrderFront:self];
//                        }
//                    }
//                }
//            }
    // 这里不能使用NSWindow 的 endSheet方法   因为不是模拟点击事件  不会直接释放self 当创建处 的NSAlert=nil了也不会释放；但是使用了下面方法就可以释放
        [NSApp endSheet:[self window] returnCode:NSAlertDefaultReturn];

//            [[self window] orderOut:nil];// 只能做到隐藏，但是可能别的事件会触发导致又显示出来
//    NSWindow *window = [NSApp mainWindow];
//    [[window attachedSheet] close];
//    });
}



- (void)dealloc {
    NSNotification *notification = [NSNotification notificationWithName:@"progressCancelAlert" object:nil];
    [[NSNotificationCenter defaultCenter] postNotification:notification];
    HXINFOLOG(@"%s", __func__);
}
@end
