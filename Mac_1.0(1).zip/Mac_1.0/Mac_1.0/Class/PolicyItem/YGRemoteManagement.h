//
//  YGSecurityPolicy.h
//  Mac_1.0
//
//  Created by apple on 2016/12/21.
//  Copyright © 2016年 infogo. All rights reserved.
//
// 远程管理
#import <Foundation/Foundation.h>

@interface YGRemoteManagement : NSObject

/**
 ***** 上报正在运行软件信息报文
 */
void RecvReportProcessInfo(int nSerial);
/**
 ***** 发送本地通知执行情况报文
 */
void RecvReportSendMsg(NSString * receiveString, int nSerial);

/**
 ***** 发送锁屏情况报文
 */
void RecvReportLockScreen(int nSerial);
/**
 ***** 发送客户端时间报文
 */
void RecvReportGetAgentTime(int nSerial);

/**
 ****** 修改本地时间并发送执行情况报文
 */
void RecvReportModifyAgentTime(NSString *agentTime, int nSerial);
/**
 ***** 发送终止进程情况报文
 */
void RecvReportTerminateProcess(NSString *TerminateProcess, int nSerial);
@end
