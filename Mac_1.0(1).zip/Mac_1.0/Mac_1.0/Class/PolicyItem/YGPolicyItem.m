//
//  YGPolicyItem.m
//  Mac_1.0
//
//  Created by apple on 2016/12/21.
//  Copyright © 2016年 infogo. All rights reserved.
// 获取策略项

#import "YGPolicyItem.h"
#import "XMLDictionary.h"

#import "ApplicationInfo.h"
#import "Singleton.h"
#import "YGPolicyItemModel.h"
#import "YGTool.h"
#import "SoftwareList.h"
#import <Cocoa/Cocoa.h>
#import "YGAppItemList.h"
#import "YGWifiItemList.h"
#import "YGFileItemList.h"
#import "YGInternetBehaviorItemList.h"
#import <CoreWLAN/CoreWLAN.h>// wifi信息


@implementation YGPolicyItem
static FSEventsListener *yListener = nil;
@synthesize wifiRecordModel;
@synthesize fileRecordModel;
@synthesize appRecordModel;
@synthesize UpdateTimeMin;
@synthesize OffLineEffect;
@synthesize LegalWifiPolicy;
@synthesize ygPolicyNum;
@synthesize internetBehaviorRecordModel;


- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.wifiRecordModel forKey:@"wifiRecordModel"];
    [encoder encodeObject:self.appRecordModel forKey:@"appRecordModel"];
    [encoder encodeObject:self.usbDeviceCtrlModel forKey:@"usbDeviceCtrlModel"];
    [encoder encodeObject:self.usbPlugAuditModel forKey:@"usbPlugAuditModel"];
    [encoder encodeObject:self.SPolicyUsbClassCtrlModel forKey:@"SPolicyUsbClassCtrlModel"];
    [encoder encodeObject:[NSNumber numberWithInt:self.UpdateTimeMin] forKey:@"UpdateTimeMin"];
    [encoder encodeObject:[NSNumber numberWithBool:self.OffLineEffect] forKey:@"OffLineEffect"];
    [encoder encodeObject:[NSNumber numberWithInt:self.ygPolicyNum] forKey:@"ygPolicyNum"];
    [encoder encodeObject:self.internetBehaviorRecordModel forKey:@"internetBehaviorRecordModel"];
    [encoder encodeObject:self.fileRecordModel forKey:@"fileRecordModel"];
    [encoder encodeObject:[NSNumber numberWithBool:self.LegalWifiPolicy] forKey:@"LegalWifiPolicy"];
}

- (nullable instancetype)initWithCoder:(NSCoder *)decoder{
    self = [super init];
    if (self) {
        self.wifiRecordModel = [decoder decodeObjectForKey:@"wifiRecordModel"];
        self.appRecordModel = [decoder decodeObjectForKey:@"appRecordModel"];
        self.usbDeviceCtrlModel = [decoder decodeObjectForKey:@"usbDeviceCtrlModel"];
        self.usbPlugAuditModel = [decoder decodeObjectForKey:@"usbPlugAuditModel"];
        self.SPolicyUsbClassCtrlModel = [decoder decodeObjectForKey:@"SPolicyUsbClassCtrlModel"];
        self.UpdateTimeMin = [[decoder decodeObjectForKey:@"UpdateTimeMin"] intValue];
        self.OffLineEffect = [[decoder decodeObjectForKey:@"OffLineEffect"] boolValue];
        self.ygPolicyNum = [[decoder decodeObjectForKey:@"ygPolicyNum"] intValue];
        self.LegalWifiPolicy = [[decoder decodeObjectForKey:@"LegalWifiPolicy"] boolValue];
        self.internetBehaviorRecordModel = [decoder decodeObjectForKey:@"internetBehaviorRecordModel"];
        self.fileRecordModel = [decoder decodeObjectForKey:@"fileRecordModel"];
    }
    return self;
}

+(YGPolicyItem *)Item
{
    return [[YGPolicyItem alloc] init];
}


+ (void)SaveYGPolicyItem:(YGPolicyItem *)item {
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:item];
    writeFile(data, kInfogoPOLICY);
}

+ (YGPolicyItem *)GetYGPolicyItem {
    NSData *dataPOLICY = readFile(kInfogoPOLICY);
    YGPolicyItem *policy = [NSKeyedUnarchiver unarchiveObjectWithData:dataPOLICY];
    return policy;
}

- (BOOL)isEqualToYGPolicyItem:(YGPolicyItem *)policyItem
{
    if (!self && !policyItem ) {
        return YES;
    }
    // 如果是完全相同的对象，就省去后面的判断
    if (self == policyItem) return YES;
    
    // 如果object的类型不对，就不需要比较
    if (![policyItem isKindOfClass:self.class]) return NO;
    
    // 基本数据类型
    BOOL result = (self.OffLineEffect == policyItem.OffLineEffect && self.ygPolicyNum == policyItem.ygPolicyNum && self.UpdateTimeMin == policyItem.UpdateTimeMin && self.LegalWifiPolicy == policyItem.LegalWifiPolicy);
    if (!result) return result;
    
    BOOL wResult = [self.wifiRecordModel isEqualToYGWifiRecordModel:policyItem.wifiRecordModel];
    if (!wResult && (self.wifiRecordModel || policyItem.wifiRecordModel)) return wResult;
    BOOL aResult = [self.appRecordModel isEqualToYGAppRecordModel:policyItem.appRecordModel];
    if (!aResult && (self.appRecordModel || policyItem.appRecordModel)) return aResult;
    BOOL fResult = [self.fileRecordModel isEqualToYGFileRecordModel:policyItem.fileRecordModel];
    if (!fResult && (self.fileRecordModel || policyItem.fileRecordModel)) return  fResult;
    return YES;
}

//  重写hash
- (NSUInteger)hash
{
    return self.UpdateTimeMin + self.OffLineEffect + self.LegalWifiPolicy + self.ygPolicyNum + self.appRecordModel.hash + self.wifiRecordModel.hash + self.fileRecordModel.hash;
}

- (BOOL)isEqual:(YGPolicyItem *)object
{
    return [self isEqualToYGPolicyItem:object];
}



#pragma mark 策略报文处理
/*
 *****  处理socket报文，并转换YGPolicyItemModel类 
 *****  再使用 GetPolicy 去socket请求单个策略项的内容
 *****  返回策略项的个数
 */
YGPolicyItem *DealwithPolicyItemStr(NSDictionary *xmlDictionary, YGPolicyItem *policyItem){
    if (!policyItem) {
        policyItem = [YGPolicyItem Item];
    }
    NSMutableArray * _policyItems = [NSMutableArray array];
    NSDictionary * PolicyItems = xmlDictionary[@"PolicyItems"];
    id object = PolicyItems[@"Item"];
    if ([object isKindOfClass:[NSDictionary class]]) {
        NSDictionary *item = (NSDictionary *)object;
        YGPolicyItemModel * ygPolicyItem = [YGPolicyItemModel modelWithDictionary:item];
        if (ygPolicyItem) {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                [[Singleton shareInstancetype] GetPolicy:ygPolicyItem.itemId];
            });
            [_policyItems addObject:ygPolicyItem];
        }
    }else if ([object isKindOfClass:[NSArray class]]) {
        NSArray *items = PolicyItems[@"Item"];
        for (NSDictionary *item in items) {
            YGPolicyItemModel * ygPolicyItem = [YGPolicyItemModel modelWithDictionary:item];
            if (ygPolicyItem) {
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    [[Singleton shareInstancetype] GetPolicy:ygPolicyItem.itemId];
                });
                [_policyItems addObject:ygPolicyItem];
            }
        }
    }
    //  获取服务器USB注册配置信息
    policyItem.ygPolicyNum = YGPolicyItemGetSPolicy_UsbClassCtrl(xmlDictionary[@"SystemPolicyItems"])? 1: 0;
    NSDictionary * advOption = PolicyItems[@"AdvOption"];
    policyItem.OffLineEffect = [advOption[@"OffLineEffect"] boolValue];
    policyItem.LegalWifiPolicy = [advOption[@"LegalWifiPolicy"] boolValue];
    policyItem.UpdateTimeMin = [advOption[@"UpdateTimeMin"] intValue];
    policyItem.ygPolicyNum += (int)_policyItems.count;
    return policyItem;
}


/*
 ***** 在socket内调用  
 ***** socketString 是下发的单个策略项报文
 ***** 判断是哪种策略项并执行
 */
YGPolicyItem *GetPolicyItem(NSArray * policy, YGPolicyItem *policyItem){
    for (NSString *socketString in policy) {
        NSString * itemName = CutOffStringBetweenBoth(socketString, @"<ItemName>", @"</ItemName>");
        if ([itemName isEqualToString:YGMP_Application]) {
            YGAppRecordModel *recordModel = GetAppPolicyItemList(socketString);//  将下发报文整理成对象
            policyItem.appRecordModel     = recordModel;
        } else if ([itemName isEqualToString:YGMP_WiFi]) {
            YGWifiRecordModel *recordModel = GetWifiPolicyItemList(socketString);// 生成wifi对象
            policyItem.wifiRecordModel     = recordModel;
        } else if ([itemName isEqualToString:YGMP_File]) {
            YGFileRecordModel * recordModel = GetFilePolicyItemList(socketString);// 生成文档策略对象
            policyItem.fileRecordModel      = recordModel;
        } else if ([itemName isEqualToString:YGMP_InternetBehavio]) {
            YGInternetBehaviorRecordModel * recordModel = GetInternetBehaviorItemList(socketString);// 生成上网监控对象
            policyItem.internetBehaviorRecordModel      = recordModel;
        } else if ([itemName isEqualToString:YGMP_UsbDeviceCtrl]) { // usb使用策略
            YGPolicyUsbDeviceCtrlModel *recordModel = GetUsbDeviceCtrlPolicyItemList(socketString);
            policyItem.usbDeviceCtrlModel = recordModel;
        } else if ([itemName isEqualToString:YGMP_UsbPlugAudit]) { // usb插拔策略
            YGPolicyUsbPlugAuditModel *recordModel = GetUsbPlugPolicyItemList(socketString);
            policyItem.usbPlugAuditModel = recordModel;
        }
    }
    return policyItem;
}


#pragma mark 策略检查
// 黑名单是不能装某些应用
// 白名单是只能装某些应用
#pragma mark 程序黑白名单
// 获取黑白名单策略项的详细配置
YGAppRecordModel * GetAppPolicyItemList(NSString *string){
    NSString * itemList = CutOffStringBetweenBoth(string, @"<ItemList>", @"</ItemList>");// 获取下发策略全部软件名字段
    NSArray * items = [itemList componentsSeparatedByString:@"<Item>"];
    NSMutableArray * softItems = [NSMutableArray array];
    for (NSString *item in items) {// 将下发的软件名称字段逐个转换成对象 YGAppItemList
        if (item.length < 20) {
            continue;
        }
        YGAppItemList *ygItemList = [YGAppItemList list];
        ygItemList.softName = CutOffStringBetweenBoth(item, @"<SoftName>", @"</SoftName>");
        ygItemList.remark   = CutOffStringBetweenBoth(item, @"<Remark>", @"</Remark>");
        [softItems addObject:ygItemList];
    }
    // 将整体下发字段转换成对象 YGAppRecordModel
    YGAppRecordModel * ygRecordModel = [YGAppRecordModel Model];
    ygRecordModel.ItemList   = [NSArray arrayWithArray:softItems];
    ygRecordModel.policyType = [CutOffStringBetweenBoth(string, @"<PolicyType>", @"</PolicyType>") intValue];
    ygRecordModel.isLock     = [CutOffStringBetweenBoth(string, @"<IsLock>", @"</IsLock>") boolValue];
    ygRecordModel.lockTime   = [CutOffStringBetweenBoth(string, @"<LockTime>", @"</LockTime>") intValue];;
    ygRecordModel.isOutNet   = [CutOffStringBetweenBoth(string, @"<IsOutNet>", @"</IsOutNet>") boolValue];
    ygRecordModel.isRecord   = [CutOffStringBetweenBoth(string, @"<IsRecord>", @"</IsRecord>") boolValue];
    ygRecordModel.ItemTime   = CutOffStringBetweenBoth(string, @"<ItemTime>", @"</ItemTime>");
    return ygRecordModel;
}
/** 
 周期检查：黑白名单策略检查是否合规
 YGAppRecordModel *recordModel 黑白名单策略
 无返回值
 在viewController内开启的计时器中调用
 */
void MobilePolicy_Application(YGAppRecordModel *recordModel){
    if (!recordModel || recordModel.ItemList.count == 0){
      // 下发策略为空
        NSNotification * noti = [NSNotification notificationWithName:@"cancelAlert" object:nil];
        [[NSNotificationCenter defaultCenter] postNotification:noti];
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:[NSDictionary dictionary]];
        writeFile(data, Programlist);
        return;
    }
    
    // 安装的全部应用
    NSDictionary * softwarelist = [SoftwareList allAppList];
    // 黑名单违规软件
    NSMutableDictionary *ViolationSoftDic;
    if (recordModel.policyType == BlackList){
        // 找到黑名单违规软件存进去
        ViolationSoftDic = [NSMutableDictionary dictionary];
    }else if (recordModel.policyType == WhiteList){
        // 找到合法白名单删除
        ViolationSoftDic = [NSMutableDictionary dictionaryWithDictionary:softwarelist];
    }
    for (YGAppItemList *list in recordModel.ItemList) {
        // 便利本地的软件
        for (NSString *path in softwarelist) {
            ApplicationInfo *appInfo = softwarelist[path];
            NSString *name = appInfo.ApplicationName;

            if (recordModel.policyType == BlackList) {
                if ([name isEqualToString:@"IMC"]||[name isEqualToString:@"ASM"]||[name isEqualToString:@"NAC client"]||[name isEqualToString:@"NAC agent"]){
                    continue;
                }
                // 黑名单绝对匹配
                if ([name isEqualToString:list.softName]) {
                    // 如果违规软件数组中无该软件就存进去
                    if (![[ViolationSoftDic allKeys] containsObject:path]){
                        appInfo.createTime = CurrentTime(YGCURRENTTIMETYPEONE);
                        [ViolationSoftDic setObject:appInfo forKey:path];
                    }
                }
            }else if (recordModel.policyType == WhiteList) {
                // 白名单
                if ([name isEqualToString:@"IMC"]||[name isEqualToString:@"ASM"]||[name isEqualToString:@"NAC client"]||[name isEqualToString:@"NAC agent"]){
                    [ViolationSoftDic removeObjectForKey:path];
                }
                // 模糊匹配：如果本地软件名称中包含了下发策略中的软件名称则为合规；如果不包含则为违规软件
                if ([name rangeOfString:list.softName].location != NSNotFound){
                    // 如果违规软件数组中无该软件就存进去
                    if ([[ViolationSoftDic allKeys] containsObject:path]) {
                        [ViolationSoftDic removeObjectForKey:path];
                    }
                }
            }
        }
    }
    
    NSData *readData = readFile(Programlist);
    NSMutableDictionary *localViolationSoft;
    if (readData.bytes) {
        localViolationSoft = [NSMutableDictionary dictionaryWithDictionary:[NSKeyedUnarchiver unarchiveObjectWithData:readData]];
    }else{
        localViolationSoft = [NSMutableDictionary dictionary];
    }
    NSMutableDictionary *pDic = [NSMutableDictionary dictionary];
    if (recordModel.policyType == BlackList) {
        // 黑名单
        for (NSString *localSavesPath in localViolationSoft) {
            ApplicationInfo *localAppInfo = localViolationSoft[localSavesPath];
            if (![[softwarelist allKeys] containsObject:localSavesPath]) {
                localAppInfo.removeTime = CurrentTime(YGCURRENTTIMETYPEONE);
                [pDic setObject:localAppInfo forKey:localSavesPath];
            }
        }
        for (NSString *path in pDic) {
            // 将要上报的软件从本地记录中删除
            [localViolationSoft removeObjectForKey:path];
        }
        for (NSString *path in ViolationSoftDic) {
            // 如果有不同的软件违规了存进去（这里修改是为了存新的违规软件）
            if (![[localViolationSoft allKeys] containsObject:path]) {
                [localViolationSoft setObject:ViolationSoftDic[path] forKey:path];
            }
        }
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:localViolationSoft];
        writeFile(data, Programlist);
        BlackListDealWith(recordModel, pDic, ViolationSoftDic);
    } else if (recordModel.policyType == WhiteList) {
        // 白名单
        for (NSString *localSavesPath in localViolationSoft) {
            // 从本地NSUserDefault取
            ApplicationInfo *localAppInfo = localViolationSoft[localSavesPath];
            // 从获取的全部软件中对比是否有当前路径的
            if (![[softwarelist allKeys] containsObject:localSavesPath]) {
                localAppInfo.removeTime = CurrentTime(YGCURRENTTIMETYPEONE);
                [pDic setObject:localAppInfo forKey:localSavesPath];
            }
        }
        for (NSString *path in pDic) {
            // 把上报的软件从本地中删除
            [localViolationSoft removeObjectForKey:path];
        }
        for (NSString *path in ViolationSoftDic) {
            if (![[localViolationSoft allKeys] containsObject:path]) {
                ApplicationInfo *app = ViolationSoftDic[path];
                app.createTime = CurrentTime(YGCURRENTTIMETYPEONE);
                [localViolationSoft setObject:app forKey:path];
            }
        }
#warning 下发新的策略时 是不是要删除本地保存的违规软件
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:ViolationSoftDic];
        writeFile(data, Programlist);
        WhiteListDealWith(recordModel, pDic, ViolationSoftDic);
    }

}
// 两种名单违规处理方式是一致的 那么是否要写作一个函数?
/** 程序黑名单违规处理*/
void BlackListDealWith(YGAppRecordModel *recordModel, NSDictionary * forbid, NSDictionary *ViolationSoftDic){
    if (ViolationSoftDic.count == 0 || !recordModel.isLock) {
        // 没有违规，则发送注销alert的通知
        NSNotification * noti = [NSNotification notificationWithName:@"cancelAlert" object:nil];
        [[NSNotificationCenter defaultCenter] postNotification:noti];
    }
    
    if (recordModel.isRecord && forbid.count > 0) {
        // 有需要上报的记录
        for (NSString *appPath in forbid) {
            [[Singleton shareInstancetype] RecvMobilePolicy_Application:forbid[appPath]];
//            RecvMobilePolicy_Application(forbid[appPath]);// 违规上报
        }
        // 本地记录日志
        NSMutableString * forbidAppName = [NSMutableString string];
        for (NSString *path in forbid) {
            ApplicationInfo *app = forbid[path];
            [forbidAppName appendString:[NSString stringWithFormat:@" %@ ", app.ApplicationName]];
        }
        NSString * log = [NSString stringWithFormat:@"软件黑名单违规\nlogTime = [%@]\n", CurrentTime(YGCURRENTTIMETYPEONE)];
        [forbidAppName insertString:log atIndex:0];
        CreateApplicationLog(forbidAppName);
    }
    if (ViolationSoftDic.count > 0) {
        NSString *msg = @"警告:程序黑白名单策略不合规!!!";
        if (recordModel.isLock) {
            dispatch_async(dispatch_get_main_queue(), ^{
                // 弹窗锁屏
                NSNotification * notification1 = [NSNotification notificationWithName:@"lockForAlert" object:ViolationSoftDic];
                [[NSNotificationCenter defaultCenter] postNotification:notification1];

            });
            
            msg = @"警告:程序黑白名单策略不合规,10秒后锁屏。";
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                // 违规10秒后锁屏
                BOOL isLock = LockScreen();// 违规处理锁屏
                HXINFOLOG(@"%@", isLock?@"锁屏成功":@"锁屏失败");
            });
        }
        HXINFOLOG(@"程序黑名单违规");
        NSNotification * notification = [NSNotification notificationWithName:@"RecvReportSendMsg" object:msg];
        [[NSNotificationCenter defaultCenter] postNotification:notification];
        if (recordModel.isOutNet) {
            CutOffNet(@"程序黑白名单策略违规断网");
        }
    }
}
/** 程序白名单违规处理*/
void WhiteListDealWith(YGAppRecordModel *recordModel, NSDictionary * forbid, NSDictionary *ViolationSoftDic){

    if (ViolationSoftDic.count == 0 || !recordModel.isLock) {
        NSNotification * noti = [NSNotification notificationWithName:@"cancelAlert" object:nil];
        [[NSNotificationCenter defaultCenter] postNotification:noti];
    }
    // 记录日志
    if (recordModel.isRecord && forbid.count > 0) {
        NSMutableString * forbidAppName = [NSMutableString string];
        for (NSString *path in forbid) {
            ApplicationInfo *app = forbid[path];
            // 违规上报
            [[Singleton shareInstancetype] RecvMobilePolicy_Application:app];
//            RecvMobilePolicy_Application(app);
            [forbidAppName appendString:[NSString stringWithFormat:@" %@ ", app.ApplicationName]];
        }
        NSString * log = [NSString stringWithFormat:@"软件白名单违规\nlogTime = [%@]\n", CurrentTime(YGCURRENTTIMETYPEONE)];
        [forbidAppName insertString:log atIndex:0];
        CreateApplicationLog(forbidAppName);
    }
    NSString *msg = @"警告:程序黑白名单策略不合规!!!";
    if (ViolationSoftDic.count > 0) {
        HXINFOLOG(@"白名单违规");
        if (recordModel.isLock) {
            dispatch_async(dispatch_get_main_queue(), ^{
                // 发送锁屏命令
                NSNotification * notification1 = [NSNotification notificationWithName:@"lockForAlert" object:ViolationSoftDic];
                [[NSNotificationCenter defaultCenter] postNotification:notification1];
            });
            
            msg = @"警告:程序黑白名单策略不合规,10秒后锁屏。";
            // 锁屏
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                // 违规10秒后锁屏
                LockScreen();// 违规处理锁屏
            });
        }
        // 发送通知消息
        NSNotification * notification = [NSNotification notificationWithName:@"RecvReportSendMsg" object:msg];
        [[NSNotificationCenter defaultCenter] postNotification:notification];
        if (recordModel.isOutNet) {
            CutOffNet(@"程序黑白名单策略违规断网");
        }
    }
}


//   NSString *urlString = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>MReportViolationLog</TradeCode><AgentID>%@</AgentID><ItemList><Item><ViolationStartTime></ViolationStartTime><ViolationEndTime></ViolationEndTime><ViolationItem>MobilePolicy_Application</ViolationItem><Remark></Remark></Item></ItemList></ASM>", readFile(@"AgentID")];

#pragma mark 文档审计策略
/** */
YGFileRecordModel * GetFilePolicyItemList(NSString *string){
    NSString * itemList = CutOffStringBetweenBoth(string, @"<ItemList>", @"</ItemList>");// 获取下发策略全部软件名字段
    NSArray * items = [itemList componentsSeparatedByString:@"<Item>"];
    NSMutableArray * fileList = [NSMutableArray array];
    for (NSString *item in items) {
        if (item.length < 30) {
            continue;
        }
        YGFileItemList * fileItemList= [YGFileItemList List];
        fileItemList.SDCardType = [CutOffStringBetweenBoth(item, @"<SDCardType>", @"</SDCardType>") intValue];
        fileItemList.FilePath   = CutOffStringBetweenBoth(item, @"<FilePath>", @"</FilePath>");
        fileItemList.Remark     = CutOffStringBetweenBoth(item, @"<Remark>", @"</Remark>");
        [fileList addObject:fileItemList];
    }
    YGFileRecordModel * fileRecordModel = [YGFileRecordModel Model];
    fileRecordModel.AgentID      = CutOffStringBetweenBoth(string, @"<AgentID>", @"</AgentID>");
    fileRecordModel.ItemID       = CutOffStringBetweenBoth(string, @"<ItemID>", @"</ItemID>");
    fileRecordModel.ItemTime     = CutOffStringBetweenBoth(string, @"<ItemTime>", @"</ItemTime>");
    fileRecordModel.Result       = CutOffStringBetweenBoth(string, @"<Result>", @"</Result>");
    fileRecordModel.IsAdd        = [CutOffStringBetweenBoth(string, @"<IsAdd>", @"</IsAdd>") boolValue];
    fileRecordModel.IsDelete     = [CutOffStringBetweenBoth(string, @"<IsDelete>", @"</IsDelete>") boolValue];
    fileRecordModel.IsUpdate     = [CutOffStringBetweenBoth(string, @"<IsUpdate>", @"</IsUpdate>") boolValue];
    fileRecordModel.SubDirectory = [CutOffStringBetweenBoth(string, @"<SubDirectory>", @"</SubDirectory>") boolValue];
    fileRecordModel.IsEnable     = [CutOffStringBetweenBoth(string, @"<IsEnable>", @"</IsEnable>") boolValue];
    fileRecordModel.ItemList     = fileList;
    return fileRecordModel;
}



#pragma mark WIFI策略
YGWifiRecordModel * GetWifiPolicyItemList(NSString *string){
    NSString * itemList = CutOffStringBetweenBoth(string, @"<ItemList>", @"</ItemList>");// 获取下发策略全部软件名字段
    NSArray * items = [itemList componentsSeparatedByString:@"<Item>"];
    NSMutableArray * wifiList = [NSMutableArray array];
    for (NSString *item in items) {
        if (item.length < 25) {
            continue;
        }
        YGWifiItemList * wifiItemList = [YGWifiItemList List];
        wifiItemList.SSID   = CutOffStringBetweenBoth(item, @"<SSID>", @"</SSID>");
        wifiItemList.APMac  = CutOffStringBetweenBoth(item, @"<APMac>", @"</APMac>");
        wifiItemList.Remark = CutOffStringBetweenBoth(item, @"<Remark>", @"</Remark>");
        [wifiList addObject:wifiItemList];
    }
    YGWifiRecordModel * model = [YGWifiRecordModel Model];
    model.agentID   = CutOffStringBetweenBoth(string, @"<AgentID>", @"</AgentID>");
    model.ItemID    = CutOffStringBetweenBoth(string, @"<ItemID>", @"</ItemID>");
    model.ItemTime  = CutOffStringBetweenBoth(string, @"<ItemTime>", @"</ItemTime>");
    model.ItemList  = wifiList;
    
    return model;
}
/** 判断wifi策略是否合规*/
void MobilePolicy_WiFi(YGWifiRecordModel *recordModel){
    if (!recordModel || recordModel.ItemList.count == 0) {
        return;
    }
    NSString * currentWiFiName = WiFiSSID();
    int i = 0;//
    for (YGWifiItemList *itemList in recordModel.ItemList) {
        if (itemList.SSID.length < 1) {
            return;
        }
        if ([itemList.SSID isEqualToString:currentWiFiName]){
            if (itemList.APMac.length > 0) {
                //  wifi的bssid不区分大小写
                if (![itemList.APMac.lowercaseString isEqualToString:WiFiBSSID().lowercaseString]){
                    continue;
                }
            }
            i++;
            break;
        }
    }
    
    if (i == 0 && currentWiFiName.length > 0) {//  不合规        
        HXINFOLOG(@"currentWiFiName = [%@][%d]", currentWiFiName, i);
        dispatch_async(dispatch_get_main_queue(), ^{
            NSNotification * notification = [NSNotification notificationWithName:@"RecvReportSendMsg" object:@"警告:WiFi连接不合规，请重新连接。"];
            [[NSNotificationCenter defaultCenter] postNotification:notification];
        });
        
//        closeWifi();
        // 断开当前连接的WiFi
        CWWiFiClient * client = [CWWiFiClient sharedWiFiClient];
        CWInterface *wif = [client interface];
        [wif disassociate];
    }
}

#pragma mark 上网行为管控策略
YGInternetBehaviorRecordModel * GetInternetBehaviorItemList(NSString *string){
    NSString * itemList = CutOffStringBetweenBoth(string, @"<ItemList>", @"</ItemList>");// 获取下发策略全部软件名字段
    NSArray * items = [itemList componentsSeparatedByString:@"<Item>"];
    NSMutableArray * ibList = [NSMutableArray array];
    for (NSString *item in items) {
        if (item.length < 25) {
            continue;
        }
        YGInternetBehaviorItemList * itemList = [YGInternetBehaviorItemList List];
        itemList.DomainName = CutOffStringBetweenBoth(item, @"<DomainName>", @"</DomainName>");
        itemList.Remark     = CutOffStringBetweenBoth(item, @"<Remark>", @"</Remark>");
        [ibList addObject:itemList];
    }
    YGInternetBehaviorRecordModel * recordModel = [YGInternetBehaviorRecordModel Model];
    recordModel.IsEnable    = [CutOffStringBetweenBoth(string, @"<IsEnable>", @"</IsEnable>") boolValue];
    recordModel.IsCloseData = [CutOffStringBetweenBoth(string, @"<IsCloseData>", @"</IsCloseData>") boolValue];
    recordModel.IsRecordLog = [CutOffStringBetweenBoth(string, @"<IsRecordLog>", @"</IsRecordLog>") boolValue];
    recordModel.ItemList = ibList;
    return recordModel;
}

void MobilePolicy_InternetBehavior(YGInternetBehaviorRecordModel *recordModel)
{
    if (!recordModel || recordModel.ItemList.count < 1){// 没有策略
        return;
    }
    // 条件:Safari是运行的
    NSWorkspace *sharedWorkspace = [NSWorkspace sharedWorkspace];
    NSArray * apps = [sharedWorkspace valueForKeyPath:@"launchedApplications.NSApplicationName"];//.NSApplicationName
    BOOL safari = NO;
    for (NSString * appName in apps) {
        if([appName.lowercaseString rangeOfString:@"safari"].location != NSNotFound) {
            safari = YES;
        }
    }
    if (!safari) {
        return;
    }
    // 获取本地自带浏览器当前浏览记录
    NSArray *urlArr;
    if ([NSThread isMainThread]){
        urlArr = GetURLOfEveryWindowFromSafari();
    }else{
        __block NSArray *currentUrlArr;
        dispatch_sync(dispatch_get_main_queue(), ^{
            currentUrlArr = GetURLOfEveryWindowFromSafari();
        });
        urlArr = [NSArray arrayWithArray:currentUrlArr];
    }
    NSMutableArray *forbidUrlArr = [NSMutableArray array];// 存违规的网站
    for (YGInternetBehaviorItemList *list in recordModel.ItemList) {
        for (NSString *url in urlArr) {
            if([url.lowercaseString rangeOfString:list.DomainName.lowercaseString].location != NSNotFound){
                continue;
            }
            YGInternetBehaviorItemList * list = [YGInternetBehaviorItemList List];
            list.DomainName = url;
            list.time = CurrentTime(YGCURRENTTIMETYPEONE);
            [forbidUrlArr addObject:list];
        }
    }
    if (forbidUrlArr.count > 0) {
        RecvMobilePolicy_InternetBehavior(forbidUrlArr);
        // 违规了
        // 违规上报
        // 违规处理
    }
}

- (void)networksetup_listnetworkserviceorder
{
    NSString *script = @"networksetup -listnetworkserviceorder";
    DoShellScript(script);
}



/** 
    通过<CoreWLAN/CoreWLAN.h>调用   api来获取ssid等信息
 */
NSString * WiFiSSID()
{
//    CWInterface *wif = [CWInterface interface];
//    NSLog(@"[%@][%@][%d]",wif.interfaceName, wif.ssid, wif.powerOn);
    CWWiFiClient * client = [CWWiFiClient sharedWiFiClient]; //os x 10.10.0
    CWInterface *wif = [client interface]; //os x 10.10.0
    return wif.ssid;
}

NSString *WiFiBSSID(){
    CWWiFiClient * client = [CWWiFiClient sharedWiFiClient]; //os x 10.10.0
    CWInterface *wif = [client interface]; //os x 10.10.0
    return wif.bssid;
}

void CreateApplicationLog(NSString *string)
{
    NSArray *paths1 =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *documentDirectory = [paths1 objectAtIndex:0];
    
    //定义记录文件全名以及路径的字符串filePath
    NSString *filePath = [documentDirectory stringByAppendingPathComponent:@"/IMC"];
    NSString *filePath1 = [filePath stringByAppendingPathComponent:@"/imc_mac_file.txt"];

    //创建文件管理器
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL fileIsTure = NO;
    //查找文件，如果不存在，就创建一个文件
    if (![fileManager fileExistsAtPath:filePath1]) {
        fileIsTure = [fileManager createFileAtPath:filePath1 contents:nil attributes:nil];
    }
    NSFileHandle *outFile = nil;
    if (fileIsTure) {
        outFile = [NSFileHandle fileHandleForWritingAtPath:filePath1];
    }
    
    if(outFile == nil)
    {
        HXINFOLOG(@"Open of file for writing failed");
    }
    //找到并定位到outFile的末尾位置(在此后追加文件)
    [outFile seekToEndOfFile];
    //读取inFile并且将其内容写到outFile中
    NSString *bs = [NSString stringWithFormat:@"时间:[%@]\n\n[%@]\n\n\n\n", CurrentTime(YGCURRENTTIMETYPEONE), string];
    NSData * buffer = [bs dataUsingEncoding:NSUTF8StringEncoding];
    
    [outFile writeData:buffer];
    //关闭读写文件
    [outFile closeFile];
}
#pragma mark USB管控
YGPolicyUsbPlugAuditModel * GetUsbPlugPolicyItemList(NSString *string){
    NSString *rstring = [string stringByReplacingOccurrencesOfString:@"<?xml version=\"1.0\" encoding=\"gbk\"?>" withString:@""];
    NSDictionary *dict = [NSDictionary dictionaryWithXMLString:rstring];
    YGPolicyUsbPlugAuditModel *model = [[YGPolicyUsbPlugAuditModel alloc] init];
    if (dict.count < 1) {
        return model;
    }
    model.AgentID = [dict[@"AgentID"] integerValue];
    model.ItemID = [dict[@"ItemID"] integerValue];
    model.ItemTime = dict[@"ItemTime"];
    model.ItemName = dict[@"ItemName"];
    NSDictionary *Body = dict[@"Body"];
    NSDictionary *audit = Body[@"Audit"];
    id object = audit[@"Item"];
    if ([object isKindOfClass:[NSDictionary class]]) {
        NSDictionary *itemDict = object;
        YGUsbPlugItem *dItem = [YGUsbPlugItem USBPlugItemWithDict:itemDict];
        [model.Body addObject:dItem];
    }else if ([object isKindOfClass:[NSArray class]]) {
        NSArray *Item = audit[@"Item"];
        for (int i = 0; i < Item.count; i++) {
            NSDictionary *item = Item[i];
            YGUsbPlugItem *pItem = [YGUsbPlugItem USBPlugItemWithDict:item];
            [model.Body addObject:pItem];
        }
    }
    return model;
}

YGPolicyUsbDeviceCtrlModel * GetUsbDeviceCtrlPolicyItemList(NSString *string){
    NSString *rstring = [string stringByReplacingOccurrencesOfString:@"<?xml version=\"1.0\" encoding=\"gbk\"?>" withString:@""];
    NSDictionary *dict = [NSDictionary dictionaryWithXMLString:rstring];
    YGPolicyUsbDeviceCtrlModel *model = [[YGPolicyUsbDeviceCtrlModel alloc] init];
    if (dict.count < 1) {
        return model;
    }
    model.AgentID = [dict[@"AgentID"] integerValue];
    model.ItemID = [dict[@"ItemID"] integerValue];
    model.ItemName = dict[@"ItemName"];
    model.ItemTime = dict[@"ItemTime"];
    model.Result = [dict[@"Result"] integerValue];
    NSDictionary *Body = dict[@"Body"];
    NSDictionary *ctrl = Body[@"Ctrl"];
    id object = ctrl[@"Item"];
    if ([object isKindOfClass:[NSDictionary class]]) {
        NSDictionary *itemDict = object;
        YGUsbDeviceItem *dItem = [YGUsbDeviceItem USBDeviceItemWithDict:itemDict];
        [model.Body addObject:dItem];
    }else if ([object isKindOfClass:[NSArray class]]) {
        NSArray *itemArray = object;
        for (int i = 0; i < itemArray.count; i++) {
            NSDictionary *item = itemArray[i];
            YGUsbDeviceItem *dItem = [YGUsbDeviceItem USBDeviceItemWithDict:item];
            [model.Body addObject:dItem];
        }
    }
    return model;
}


#define YGMP_SPolicy_UsbClassCtrl @"SPolicy_UsbClassCtrl" // USB全局配置
#pragma mark -SystemPolicyItems
NSString *GetSPolicy_UsbClassCtrlTime(NSDictionary *SystemPolicyItems) {
    id Item = SystemPolicyItems[@"Item"];
    if ([Item isKindOfClass:[NSDictionary class]]) {
        NSString *Name = Item[@"Name"];
        if ([Name isEqualToString:YGMP_SPolicy_UsbClassCtrl]) {
            return Item[@"Time"];
        }
    } else if ([Item isKindOfClass:[NSArray class]]) {
        for (NSDictionary *_item in Item) {
            NSString *Name = _item[@"Name"];
            if ([Name isEqualToString:YGMP_SPolicy_UsbClassCtrl]) {
                return _item[@"Time"];
            }
        }
    }
    return nil;
}


BOOL YGPolicyItemGetSPolicy_UsbClassCtrl(NSDictionary *SystemPolicyItems) {
    NSDictionary *Item = SystemPolicyItems[@"Item"];
    if (Item.count < 1) return NO;
    for (NSDictionary *_item in Item) {
        NSString *Name = _item[@"Name"];
        if ([YGMP_SPolicy_UsbClassCtrl isEqualToString:Name]) {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                [[Singleton shareInstancetype] GetPolicy:_item[@"ItemID"]];
            });
            return YES;
        }
    }
    return NO;
}

@end
