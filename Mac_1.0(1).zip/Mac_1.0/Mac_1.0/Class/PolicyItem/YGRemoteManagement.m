//
//  YGSecurityPolicy.m
//  Mac_1.0
//
//  Created by apple on 2016/12/21.
//  Copyright © 2016年 infogo. All rights reserved.
// 远程管理


#import <Cocoa/Cocoa.h>
#import "YGRemoteManagement.h"
#import "YGMessageSplicing.h"
#import "Singleton.h"
#import "YGTool.h"


@implementation YGRemoteManagement

#pragma mark RecvReportProcessInfo 正在运行的应用
void RecvReportProcessInfo(int nSerial)
{
    NSString *request = [YGMessageSplicing ReportProcessInfo:readFile(kAgentID)];
    char *ygBuf = StringToGbk(request);
    
    char *szBuf = (char *)malloc(strlen(ygBuf) + 1024);
    char *pTradeName = "RealTime";
    sprintf(szBuf, "%s", ygBuf);
    BOOL result = [[Singleton shareInstancetype] SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:6 nSNO:nSerial];
    if (result) {
        HXINFOLOG(@"正在运行的应用上报成功");
    }else{
        HXINFOLOG(@"正在运行的应用上报失败");
    }
    if (szBuf)
    free(szBuf);
}


#pragma mark RecvReportSendMsg 服务端向客户端发送消息，客户端弹窗
void RecvReportSendMsg(NSString * receiveString, int nSerial)
{
    [[NSApplication sharedApplication] setApplicationIconImage:nil];
    NSString * msg = CutOffStringBetweenBoth(receiveString, @"<Msg>", @"</Msg>");
    dispatch_async(dispatch_get_main_queue(), ^{
        //更新UI操作
        NSNotification* notification = [NSNotification notificationWithName:@"RecvReportSendMsg" object:msg];
        [[NSNotificationCenter defaultCenter] postNotification:notification];
    });
    
    writeFile(@"0", @"SendMsg");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSString * str;
        // 2秒后异步执行这里的代码...
        if ([readFile(@"SendMsg") isEqualToString:@"1"]) {
            str = @"<Status>1</Status><Msg>成功</Msg>";
//            NSLog(@"SendMsg成功");
        }else{
            str = @"<Status>2</Status><Msg>失败</Msg>";
//            NSLog(@"SendMsg失败");
        }
        char *sendStr = StringToGbk(str);
        
        const char *pFormt = "<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>%s</TradeCode><AgentID>%s</AgentID><RealTimeCode>SendMsg</RealTimeCode><Result>%s</Result></ASM>";
        char szBuf[1024] = {0};
        char *pTradeName = "RealTime";
        sprintf( szBuf, pFormt, pTradeName, [readFile(kAgentID) UTF8String], sendStr);
        BOOL result = [[Singleton shareInstancetype] SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:6 nSNO:nSerial];
        if (result) {
            HXINFOLOG(@"SendMsg客户端回执成功");
        }else{
            HXINFOLOG(@"SendMsg客户端回执失败");
        }
    });
}

#pragma mark RecvReportLockScreen 锁屏
//#include <CoreFoundation/CoreFoundation.h>
//#include <IOKit/IOKitLib.h>
/* Returns 1 on success and 0 on failure. */
void RecvReportLockScreen(int nSerial)
{
    NSString * str;
    BOOL isLock = LockScreen();
    if (isLock){
        str = [NSString stringWithFormat:@"<Status>1</Status><Msg>成功</Msg>"];
    } else {
        str = [NSString stringWithFormat:@"<Status>2</Status><Msg>失败</Msg>"];
    }
    char *sendStr = StringToGbk(str);
    
    const char *pFormt = "<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>%s</TradeCode><AgentID>%s</AgentID><RealTimeCode>LockScreen</RealTimeCode><Result>%s</Result></ASM>";
    char szBuf[1024] = {0};
    
    char *pTradeName = "RealTime";
    sprintf( szBuf, pFormt, pTradeName, [readFile(kAgentID) UTF8String], sendStr);
    BOOL result = [[Singleton shareInstancetype] SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:6 nSNO:nSerial];
    if (result) {
        HXINFOLOG(@"LockScreen客户端send回执成功");
    }else{
        HXINFOLOG(@"LockScreen客户端send回执失败");
    }
}

#pragma mark RecvReportGetAgentTime 上传本地时间
void RecvReportGetAgentTime(int nSerial){
    //获得系统时间当前时间
    NSString * currentDate = CurrentTime(YGCURRENTTIMETYPEONE);
    NSString * timeStr;
    if (currentDate) {
        timeStr = [NSString stringWithFormat:@"<Status>1</Status><Msg>成功</Msg><Time>%@</Time>", currentDate];
    }else{
        timeStr = @"<Status>2</Status><Msg>失败</Msg><Time></Time>";
    }
    char *sendStr = StringToGbk(timeStr);
    
    const char *pFormt = "<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>%s</TradeCode><AgentID>%s</AgentID><RealTimeCode>GetAgentTime</RealTimeCode><Result>%s</Result></ASM>";
    char szBuf[1024] = {0};
    char *pTradeName = "RealTime";
    sprintf( szBuf, pFormt, pTradeName, [readFile(kAgentID) UTF8String], sendStr);
    BOOL result = [[Singleton shareInstancetype] SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:6 nSNO:nSerial];
    if (result) {
        HXINFOLOG(@"上传本地时间成功");
    }else{
        HXINFOLOG(@"上传本地时间失败");
    }
}

#pragma mark RecvReportModifyAgentTime 远程修改客户端时间

void RecvReportModifyAgentTime(NSString *agentTime, int nSerial){
    //    月  日   时  分  年
    //    01  01  13  30  12
    NSString* string = agentTime;
    NSDateFormatter *inputFormatter = [[NSDateFormatter alloc] init];
    [inputFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    NSDate* inputDate = [inputFormatter dateFromString:string];
    NSDateFormatter *ip1 = [[NSDateFormatter alloc] init];
    [ip1 setDateFormat:@"MMddHHmmYYYY.ss"];
    NSString *timeStr = [ip1 stringFromDate:inputDate];
    // NSAppleScript 脚本操作全放到主线程
    BOOL fixBool;
    if ([NSThread isMainThread]) {
        fixBool = FixSystemTime(timeStr);
    }else{
        __block BOOL isFix;
        dispatch_sync(dispatch_get_main_queue(), ^{
            isFix = FixSystemTime(timeStr);
        });
        fixBool = isFix;
    }
    
    NSString * ygString = NULL;
    if (fixBool) {
        ygString = @"<Status>1</Status><Msg>成功</Msg>";
        HXINFOLOG(@"修改本地时间成功");
    }else{
        ygString = @"<Status>2</Status><Msg>失败</Msg>";
        HXINFOLOG(@"修改本地时间失败");
    }
    char * ygBuf = StringToGbk(ygString);
    
    const char *pFormt = "<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>%s</TradeCode><AgentID>%s</AgentID><RealTimeCode>ModifyAgentTime</RealTimeCode><Result>%s</Result></ASM>";
    char szBuf[1024] = {0};
    char *pTradeName = "RealTime";
    sprintf( szBuf, pFormt, pTradeName, [readFile(kAgentID) UTF8String], ygBuf);
    BOOL result = [[Singleton shareInstancetype] SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:6 nSNO:nSerial];

    if (result) {
        HXINFOLOG(@"ModifyAgentTimeSerial客户端send回执成功");
    }else{
        HXINFOLOG(@"ModifyAgentTimeSerial客户端send回执失败");
    }
}

#pragma mark RecvReportTerminateProcess 终止进程
void RecvReportTerminateProcess(NSString *TerminateProcess, int nSerial){
    BOOL isEnd = CloseProcess(TerminateProcess);
    
    NSString * backStr;
    if (isEnd) {
        backStr = @"<Status>1</Status><Msg>成功</Msg>";
    }else{
        backStr = @"<Status>2</Status><Msg>失败</Msg>";
    }
    char *sendBuf = StringToGbk(backStr);
    
    const char *pFormt = "<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>%s</TradeCode><AgentID>%s</AgentID><RealTimeCode>TerminateProcess</RealTimeCode><Result>%s</Result></ASM>";
    char szBuf[1024] = {0};
    char *pTradeName = "RealTime";
    sprintf( szBuf, pFormt, pTradeName, [readFile(kAgentID) UTF8String], sendBuf);
    BOOL result = [[Singleton shareInstancetype] SocketSendUNRecv:pTradeName pTradeContent:szBuf nContentLen:(int)strlen(szBuf) cType:6 nSNO:nSerial];

    if (result) {
        HXINFOLOG(@"上报终止进程报文成功");
    }else{
        HXINFOLOG(@"上报终止进程报文失败");
    }
}

BOOL CloseProcess(NSString *request)
{
    BOOL isEnd = NO;
    NSString * teriminate = CutOffStringBetweenBoth(request, @"<PID>", @"</PID>");
    NSArray *pidArr = [teriminate componentsSeparatedByString:@","];
    for (NSString *pid in pidArr) {
        NSRunningApplication * runningApplication = [NSRunningApplication runningApplicationWithProcessIdentifier:[pid intValue]];
        if (!runningApplication) {
            HXINFOLOG(@"pid错误，进程id错误,服务端传过来的pid是:%@", pid);
            continue;
        }
        [runningApplication terminate]; // 不保存 强制退出forceTerminate
        NSRunningApplication * terminateApp = [NSRunningApplication runningApplicationWithProcessIdentifier:[pid intValue]];
        if (!terminateApp) {
            isEnd = YES;
            HXINFOLOG(@"关闭: %@ 成功", teriminate);
        }else{
            HXINFOLOG(@"关闭: %@ 失败", [terminateApp valueForKey:@"_localizedName"]);
            // 关闭失败  进一步强制关闭
            BOOL res = [runningApplication forceTerminate];
            if (res) {
                isEnd = YES;
                HXINFOLOG(@"terminate失败，调用forceTerminate成功");
            }else{
                HXINFOLOG(@"不知道为什么关闭不了");
            }
        }
    }
    return isEnd;
}
#pragma mark  修改系统时间，但是每次修改都要通过输入密码账号获得权限
BOOL FixSystemTime(NSString * time)
{
    if ([NSThread isMainThread]) {
        return FixTime(time);
    }else{
        __block BOOL isFix;
        dispatch_sync(dispatch_get_main_queue(), ^{
            isFix = FixTime(time);
        });
        return isFix;
    }
}
BOOL FixTime(NSString *time){
    NSDictionary *error = [NSDictionary new];
    NSString *script =  [NSString stringWithFormat:@"do shell script \"sudo date %@\" with administrator privileges", time];
    NSAppleScript *appleScript = [[NSAppleScript alloc] initWithSource:script];
    NSAppleEventDescriptor *des = [appleScript executeAndReturnError:&error];
    NSLog(@"FixSystemTime=%@",error);
    if (error.count != 0 || !des) {
        return NO;
    }
    return YES;
}

@end
