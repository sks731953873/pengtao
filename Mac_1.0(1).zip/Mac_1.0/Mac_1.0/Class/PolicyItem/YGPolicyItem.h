//
//  YGPolicyItem.h
//  Mac_1.0
//
//  Created by apple on 2016/12/21.
//  Copyright © 2016年 infogo. All rights reserved.
// 获取策略项

#import <Foundation/Foundation.h>
#import "YGWifiRecordModel.h"
#import "YGAppRecordModel.h"
#import "YGFileRecordModel.h"
#import "YGInternetBehaviorRecordModel.h"
#import "FSEventsListener.h"
#import "YGPolicyUsbPlugAuditModel.h"
#import "YGPolicyUsbDeviceCtrlModel.h"
#import "YGSPolicyUsbClassCtrlModel.h"
@interface YGPolicyItem : NSObject<NSCoding>
/** wifi策略*/
@property (nonatomic, strong) YGWifiRecordModel *wifiRecordModel;
/** 应用名单策略*/
@property (nonatomic, strong) YGAppRecordModel  *appRecordModel;
/** 文档策略*/
@property (nonatomic, strong) YGFileRecordModel *fileRecordModel;
/** 上网行为策略*/
@property (nonatomic, strong) YGInternetBehaviorRecordModel * internetBehaviorRecordModel;
/** usb插拔*/
@property (nonatomic, strong) YGPolicyUsbPlugAuditModel *usbPlugAuditModel;
/** usb管控*/
@property (nonatomic, strong) YGPolicyUsbDeviceCtrlModel *usbDeviceCtrlModel;

#pragma mark -SystemPolicy
/** 系统设置内的USB参数*/
@property (nonatomic, strong) YGSPolicyUsbClassCtrlModel *SPolicyUsbClassCtrlModel;
/** 策略更新周期(分钟)*/
@property (nonatomic, assign) int                UpdateTimeMin;
/**
 脱机是否生效
 return 1 生效
 */
@property (nonatomic, assign) BOOL               OffLineEffect;
/** 合法wifi策略 */
@property (nonatomic, assign) BOOL               LegalWifiPolicy;
/** 下发策略项总个数*/
@property (nonatomic, assign) int                ygPolicyNum;

//  初始化
+(YGPolicyItem *)Item;
/** 比较两个YGPolicyItem类是否相等*/
- (BOOL)isEqualToYGPolicyItem:(YGPolicyItem *)policyItem;

// 将下发的策略项封装成类
YGPolicyItem *DealwithPolicyItemStr(NSDictionary *xmlDictionary, YGPolicyItem *policyItem);

/**
 ***** 在socket内调用
 ***** socketString 是下发的单个策略项报文
 ***** 判断是哪种策略项并执行
 */
YGPolicyItem *GetPolicyItem(NSArray * policy, YGPolicyItem *policyItem);

/** 黑白名单策略检查*/
void MobilePolicy_Application(YGAppRecordModel *recordModel);

/** wifi策略检查*/
void MobilePolicy_WiFi(YGWifiRecordModel *recordModel);

/** 文档审计策略检查*/
void MobilePolicy_File(YGFileRecordModel *recordModel);

/** 上网行为管控策略检查*/
void MobilePolicy_InternetBehavior(YGInternetBehaviorRecordModel *recordModel);

/** 通过本地ipa获取WiFissid*/
NSString * WiFiSSID(void);
/** 通过本地ipa获取WiFiBSSID*/
NSString *WiFiBSSID(void);
/** 保存当前策略到本地*/
+ (void)SaveYGPolicyItem:(YGPolicyItem *)item;
/** 从本地获取当前策略*/
+ (YGPolicyItem *)GetYGPolicyItem;

#pragma mark -SystemPolicyItems
NSString *GetSPolicy_UsbClassCtrlTime(NSDictionary *SystemPolicyItems);

@end
