//
//  YGMessageSplicing.m
//  Mac_1.0
//
//  Created by apple on 2016/11/24.
//  Copyright © 2016年 infogo. All rights reserved.
// 安检项

#import "YGMessageSplicing.h"
#import "YGTool.h"
#import "SoftwareList.h"
#import "SystemProcessInfo.h"
#import "ApplicationInfo.h"
#import "XMLDictionary.h"
#import "YGPolicyTaskModel.h"
@implementation YGMessageSplicing

#pragma mark CheckProcessMustRun 必须运行的进程检测
+ (NSString *)CheckProcessMustRun:(NSString *)message withWeb:(BOOL)isWeb
{
    NSString *head = @"";
    NSString *foot = @"";
    if (isWeb) {
        head = @"[<REPLY>]";
        foot = @"[</REPLY>]";
    }
    NSMutableString * changeString = [NSMutableString stringWithString:[YGMessageSplicing cutStringAndInsertString:message]];// 在报文头中插入yes
    NSDictionary *dict = [YGMessageSplicing dealWithStringToArray:message];
    NSDictionary *Option = dict[@"Option"];
    NSString *ProcessInfo = Option[@"ProcessInfo"];
    // 获取下发策略的进程名称
    NSMutableArray * nameArr = [NSMutableArray array];
    NSArray *allNameArr = [NSArray arrayWithArray:[ProcessInfo componentsSeparatedByString:@"|"]];
    for (NSString *str in allNameArr) {
        if ([str rangeOfString:@"##ASM##"].location != NSNotFound) {
            NSArray *pArr = [str componentsSeparatedByString:@"##ASM##"];
            if (pArr) {
                [nameArr addObject:pArr[0]];
            }
        }
    }

    if (nameArr.count < 1) {
        HXINFOLOG(@"没有获取到下发策略的必须运行进程名称,请确认下发禁止必须运行进程策略");
        NSString *allString = [NSString stringWithFormat:@"%@%@<?xml version=\"1.0\" encoding=\"gbk\"?><Result><DllVersion></DllVersion><CheckType><InsideName>MACCheckProcessMustRun</InsideName><OutsideName>必须运行进程检查</OutsideName><Desc>检查客户机是否运行了管理员要求必须运行的进程。</Desc><Result>Yes</Result><Message>符合管理员要求</Message></CheckType></Result>%@", changeString, head, foot];
        return allString;
    }
    NSMutableArray *mustRunArr = [NSMutableArray arrayWithArray:nameArr];
    NSArray * processArr = [SoftwareList runningSystemProcessInfo];
    for (NSString * name in nameArr) {// 便利下发的软件策略
        if (name.length < 1) {
            continue;
        }
        for (SystemProcessInfo * system in processArr) {// 便利运行进程
            // 模糊匹配本地名字包含下发的名字则认为有
            if ([system.processName isEqualToString:name] && system.processName.length > 0) {
                HXINFOLOG(@"已经运行了的必须进程是，%@", name);
                [mustRunArr removeObject:name];// 这个进程是禁止的
            }
        }
    }
    if (mustRunArr.count != 0) {
        // 说明有运行必须进程没有运行
        HXINFOLOG(@"说明有运行必须进程没有运行");
        NSMutableString * allRequestString = [NSMutableString string];
        for (int i = 0; i < mustRunArr.count; i++) {
            NSString * system = mustRunArr[i];
            HXINFOLOG(@"没有运行的必须进程名:%@", system);
            [allRequestString insertString:system atIndex:0];
            if (i == (mustRunArr.count - 1)) {
                continue;
            }
            [allRequestString insertString:@", " atIndex:0];
        }
        NSString *allString = [NSString stringWithFormat:@"%@%@<?xml version=\"1.0\" encoding=\"gbk\"?><Result><DllVersion></DllVersion><CheckType><InsideName>MACCheckProcessMustRun</InsideName><OutsideName>必须运行进程检查</OutsideName><Desc>检查客户机是否运行了管理员要求必须运行的进程。</Desc><Result>No</Result><Message>检查未通过，必须启动进程 %@ 请启动以上进程！</Message>%@</CheckType></Result>%@", changeString, head, allRequestString, allRequestString, foot];
        
        return allString;//
    }
    // 拼接上报报文
    // 所有于要运行的进程都运行了
    NSString *allString = [NSString stringWithFormat:@"%@%@<?xml version=\"1.0\" encoding=\"gbk\"?><Result><DllVersion></DllVersion><CheckType><InsideName>MACCheckSoftInstallStat</InsideName><OutsideName>必须运行进程检查</OutsideName><Desc>检查客户机是否运行了管理员要求必须运行的进程。</Desc><Result>Yes</Result><Message>符合管理员要求</Message></CheckType></Result>%@", changeString, head, foot];
    return allString;
}

#pragma mark CheckSystemProcess  禁止运行进程检查
+ (NSString *)CheckSystemProcess:(NSString *)message withWeb:(BOOL)isWeb
{
    NSString *head = @"";
    NSString *foot = @"";
    if (isWeb) {
        head = @"[<REPLY>]";
        foot = @"[</REPLY>]";
    }
    NSMutableString * changeString = [NSMutableString stringWithString:[YGMessageSplicing cutStringAndInsertString:message]];// 在报文头中插入yes
    // 获取下发策略的进程名称
    NSDictionary *dict = [YGMessageSplicing dealWithStringToArray:message];
    NSDictionary *Option = dict[@"Option"];
    NSString *processInfo = Option[@"ProcessInfo"];
    NSMutableArray * nameArr = [NSMutableArray array];

    NSArray *allNameArr = [NSArray arrayWithArray:[processInfo componentsSeparatedByString:@"|"]];
    for (NSString *str in allNameArr) {
        if ([str rangeOfString:@"##ASM####ASM##"].location != NSNotFound) {
            NSArray *pArr = [str componentsSeparatedByString:@"##ASM####ASM##"];
            if (pArr) {
                [nameArr addObject:pArr[0]];
            }
        }
    }
    if (nameArr.count < 1) {
        HXINFOLOG(@"没有获取到下发策略的软件名称,请确认下发禁止软件检查策略");
        NSString *allString = [NSString stringWithFormat:@"%@%@<?xml version=\"1.0\" encoding=\"gbk\"?><Result><DllVersion></DllVersion><CheckType><InsideName>MACCheckSystemProcess</InsideName><OutsideName>禁止运行进程检查</OutsideName><Desc>检查客户机是否安装了管理员要求禁止运行的进程。</Desc><Result>Yes</Result><Message>符合管理员要求</Message></CheckType></Result>%@", changeString, head, foot];
        return allString;
    }
    
    NSMutableArray *forbidArr = [NSMutableArray array];// 安装了的禁止的应用
    NSArray * processArr = [SoftwareList runningSystemProcessInfo];
    for (NSString * name in nameArr) {// 便利下发的软件策略
        if (name.length < 1) {
            continue;
        }
        for (SystemProcessInfo * system in processArr) {
            if ([system.processName isEqualToString:name] && system.processName.length > 0) {
                [forbidArr addObject:system];// 这个进程是禁止的
            }
        }
    }
    if (forbidArr.count < 1) {
        // 说明没有禁止的运行进程
        HXINFOLOG(@"说明没有禁止的运行进程");
        NSString *allString = [NSString stringWithFormat:@"%@%@<?xml version=\"1.0\" encoding=\"gbk\"?><Result><DllVersion></DllVersion><CheckType><InsideName>MACCheckSystemProcess</InsideName><OutsideName>禁止运行进程检查</OutsideName><Desc>检查客户机是否安装了管理员要求禁止运行的进程。</Desc><Result>Yes</Result><Message>符合管理员要求</Message></CheckType></Result>%@", changeString, head, foot];
        
        return allString;//
    }
    // 拼接上报报文
    // 有禁止安装的软件
    NSMutableString * allRequestString = [NSMutableString string];
    for (int i = 0; i < forbidArr.count; i++) {
        SystemProcessInfo * system = forbidArr[i];
        HXINFOLOG(@"禁止运行的进程:%@", system.processName);
        [allRequestString insertString:system.processName atIndex:0];
        if (i == (forbidArr.count - 1)) {
            continue;
        }
        [allRequestString insertString:@", " atIndex:0];
    }
    NSString *allString = [NSString stringWithFormat:@"%@%@<?xml version=\"1.0\" encoding=\"gbk\"?><Result><DllVersion></DllVersion><CheckType><InsideName>MACCheckSystemProcess</InsideName><OutsideName>禁止运行进程检查</OutsideName><Desc>检查客户机是否禁止运行了管理员要求必须禁止运行的进程。</Desc><Result>No</Result><Message>检查未通过，必须停止进程 %@ 请停止以上进程！</Message>%@</CheckType></Result>%@", changeString, head, allRequestString, allRequestString, foot];
    return allString;
}

#pragma mark CheckSoftForbidInstallStat  禁止安装的软件
+ (NSString *)CheckSoftForbidInstallStat:(NSString *)message withWeb:(BOOL)isWeb
{
    NSString *head = @"";
    NSString *foot = @"";
    if (isWeb) {
        head = @"[<REPLY>]";
        foot = @"[</REPLY>]";
    }
    NSMutableString * changeString = [NSMutableString stringWithString:[YGMessageSplicing cutStringAndInsertString:message]];// 在报文头中插入yes

    // 获取下发策略的软件的名称
    NSMutableArray * nameArr = nil;
    NSMutableArray *forbidArr = [NSMutableArray array];
    NSDictionary *dict = [YGMessageSplicing dealWithStringToArray:message];
    NSString *SoftNames = dict[@"Option"][@"SoftName"];
//    SoftNames = [SoftNames stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];

    nameArr = [NSMutableArray arrayWithArray:[SoftNames componentsSeparatedByString:@","]];

    if (nameArr.count < 1) {
        HXINFOLOG(@"没有获取到下发策略的软件名称,请确认下发禁止软件检查策略");
        NSString *allString = [NSString stringWithFormat:@"%@%@<?xml version=\"1.0\" encoding=\"gbk\"?><Result><DllVersion></DllVersion><CheckType><InsideName>MACCheckSoftForbidInstallStat</InsideName><OutsideName>禁止安装APP检查</OutsideName><Desc>检查客户机是否安装了管理员要求禁止安装的APP。</Desc><Result>Yes</Result><Message>符合管理员要求</Message></CheckType></Result>%@", changeString, head, foot];
        return allString;
    }
    NSMutableString * allRequestString = [NSMutableString string];
    NSDictionary *appInfo = [SoftwareList allAppList];// 获取本地软件
    for (NSString * name in nameArr) {// 便利下发的软件策略
        if (name.length < 1) {
            continue;
        }
        for (NSString *path in appInfo) {// 便利本地的软件
            ApplicationInfo *app = appInfo[path];
            if ([app.ApplicationName isEqualToString:@"IMC"]||[app.ApplicationName isEqualToString:@"ASM"]||[app.ApplicationName isEqualToString:@"NAC client"]||[app.ApplicationName isEqualToString:@"NAC agent"]){
                continue;
            }
            // 模糊匹配本地名字包含下发的名字则认为装了
            if ([[app.ApplicationName lowercaseString] rangeOfString:name.lowercaseString].location != NSNotFound && [app.ApplicationName length] > 0) {
                HXINFOLOG(@"禁止本地软件，%@装了", app.ApplicationName);
                int i =0;// 相同名字只存一个
                for (NSString * strName in forbidArr) {
                    if ([strName isEqualToString:app.ApplicationName]) {
                        i++;
                    }
                }
                if(i==0)
                [forbidArr addObject:app.ApplicationName];
            }
        }
    }
    
    if (forbidArr.count < 1) {
        // 说明没有安装禁止安装的软件
        HXINFOLOG(@"说明没有安装禁止安装的软件");
        NSString *allString = [NSString stringWithFormat:@"%@%@<?xml version=\"1.0\" encoding=\"gbk\"?><Result><DllVersion></DllVersion><CheckType><InsideName>MACCheckSoftForbidInstallStat</InsideName><OutsideName>禁止安装APP检查</OutsideName><Desc>检查客户机是否安装了管理员要求禁止安装的APP。</Desc><Result>Yes</Result><Message>符合管理员要求</Message></CheckType></Result>%@", changeString, head, foot];
        
        return allString;//
    }
    
    // 拼接上报报文
    // 有禁止安装的软件
    for (int i = 0; i < forbidArr.count; i++) {
        HXINFOLOG(@"禁止安装但是安装的软件:%@", forbidArr[i]);
    
        [allRequestString insertString:forbidArr[i] atIndex:0];
        if (i == (forbidArr.count - 1)) {
            continue;
        }
        [allRequestString insertString:@", " atIndex:0];
    }
    NSString *allString = [NSString stringWithFormat:@"%@%@<?xml version=\"1.0\" encoding=\"gbk\"?><Result><DllVersion></DllVersion><CheckType><InsideName>MACCheckSoftForbidInstallStat</InsideName><OutsideName>禁止安装APP检查</OutsideName><Desc>检查客户机是否禁止安装了管理员要求必须禁止安装的APP。</Desc><Result>No</Result><Message>检查未通过，必须删除应用 %@ 请删除以上软件！</Message><Info><SoftName>%@</SoftName><SoftInstallPath></SoftInstallPath><SoftUninstall></SoftUninstall><Publisher></Publisher></Info></CheckType></Result>%@", changeString, head, allRequestString, allRequestString, foot];
    return allString;
}

#pragma mark CheckSoftInstallStat  必须安装的软件
/** 必须安装的软件检查*/
+ (NSString *)CheckSoftInstallStat:(NSString *)message withWeb:(BOOL)isWeb
{
    NSString *head = @"";
    NSString *foot = @"";
    if (isWeb) {
        head = @"[<REPLY>]";
        foot = @"[</REPLY>]";
    }
    NSMutableString * changeString = [NSMutableString stringWithString:[YGMessageSplicing cutStringAndInsertString:message]];// 在报文头中插入yes
    // 获取下发策略的软件的名称
    NSMutableArray * modelArr = [NSMutableArray array];
    NSDictionary *dict = [YGMessageSplicing dealWithStringToArray:message];
    if ([dict[@"Option"][@"Item"] isKindOfClass:[NSArray class]]) {
        NSArray *items = dict[@"Option"][@"Item"];
        for (NSDictionary *item in items) {
            YGPolicyTaskModel *model = [YGMessageSplicing dictionaryToModel:item];
            [modelArr addObject:model];
        }
    } else if ([dict[@"Option"][@"Item"] isKindOfClass:[NSDictionary class]]) {
        NSDictionary *items = dict[@"Option"][@"Item"];
        YGPolicyTaskModel *model = [YGMessageSplicing dictionaryToModel:items];
        [modelArr addObject:model];
    }
    if (modelArr.count < 1) {
        HXINFOLOG(@"没有获取到下发策略的软件名称,请确认下发软件检查策略");
        NSString *allString = [NSString stringWithFormat:@"%@%@<?xml version=\"1.0\" encoding=\"gbk\"?><Result><DllVersion></DllVersion><CheckType><InsideName>MACCheckSoftInstallStat</InsideName><OutsideName>必须安装APP检查</OutsideName><Desc>检查客户机是否安装了管理员要求必须安装的APP。</Desc><Result>Yes</Result><Message>符合管理员要求</Message></CheckType></Result>%@", changeString, head, foot];
        return allString;
    }
    NSMutableArray *mustRunArr = [NSMutableArray arrayWithArray:modelArr];// 装必须运行的应用
    NSDictionary * allAppList = [SoftwareList allAppList];// 获取本地软件
    for (YGPolicyTaskModel * model in modelArr) {// 便利下发的软件策略
        if (model.SoftName.length < 1) {
            continue;
        }
        for (NSString *path in allAppList) {// 便利本地的软件
            ApplicationInfo *app = allAppList[path];
            
            // 模糊匹配本地名字包含下发的名字则认为装了
            if ([[app.ApplicationName lowercaseString] rangeOfString:model.SoftName.lowercaseString].location != NSNotFound && [app.ApplicationName length] > 0) {
                HXINFOLOG(@"必须安装的本地软件，[%@]装了", app.ApplicationName);
                [mustRunArr removeObject:model];
            }
        }
    }    // 添加已经检测的信息
    
    if (mustRunArr.count != 0) {
        // 说明安装必须应用不完全
        NSMutableString * nameRequestString = [NSMutableString string];
        NSMutableString *urlRequestString = [NSMutableString string];
        NSMutableString *bRString = [NSMutableString string];
        for (int i = 0; i < mustRunArr.count; i++) {
            YGPolicyTaskModel *model = mustRunArr[i];
            HXINFOLOG(@"必须安装但是没有安装的软件:%@", model);
            [nameRequestString insertString:model.SoftName atIndex:0];
            [urlRequestString insertString:model.SoftUrl atIndex:0];
            [bRString insertString:model.SoftName atIndex:0];
            if (i == (mustRunArr.count - 1)) {
                continue;
            }
            [nameRequestString insertString:@"," atIndex:0];
            [bRString insertString:@"#infogo#" atIndex:0];
            [urlRequestString insertString:@"#infogo#" atIndex:0];
        }
        NSString *allString = [NSString stringWithFormat:@"%@%@<?xml version=\"1.0\" encoding=\"gbk\"?><Result><DllVersion></DllVersion><CheckType><InsideName>MACCheckSoftInstallStat</InsideName><OutsideName>必须安装APP检查</OutsideName><Desc>检查客户机是否安装了管理员要求必须安装的APP。</Desc><Result>No</Result><Message>检查未通过，必须安装应用 %@ 请安装以上应用！</Message><SoftNames>%@</SoftNames><SoftPaths>%@</SoftPaths></CheckType></Result>%@", changeString, head, nameRequestString, bRString, urlRequestString, foot];
        
        return allString;//
    }
    // 拼接上报报文
    // 所有于要运行的进程都运行了
    NSString *allString = [NSString stringWithFormat:@"%@%@<?xml version=\"1.0\" encoding=\"gbk\"?><Result><DllVersion></DllVersion><CheckType><InsideName>MACCheckSoftInstallStat</InsideName><OutsideName>必须安装APP检查</OutsideName><Desc>检查客户机是否安装了管理员要求必须安装的APP。</Desc><Result>Yes</Result><Message>符合管理员要求</Message></CheckType></Result>%@", changeString, head, foot];
    return allString;
}

+ (YGPolicyTaskModel *)dictionaryToModel:(NSDictionary *)dict {
    YGPolicyTaskModel *model = [YGPolicyTaskModel model];
    model.SoftName = dict[@"SoftName"];
    model.SoftUrl = dict[@"Path"];
    return model;
}
//////////  这2个安检项未实现
#pragma mark 安全桌面
+ (NSString *)CheckSecureDesktop:(NSString *)message withWeb:(BOOL)isWeb {
    NSString *head = @"";
    NSString *foot = @"";
    if (isWeb) {
        head = @"[<REPLY>]";
        foot = @"[</REPLY>]";
    }
    NSMutableString * changeString = [NSMutableString stringWithString:[YGMessageSplicing cutStringAndInsertString:message]];// 在报文头中插入yes
    // 该安检项不处理 直接上报成功
    NSString *allString = [NSString stringWithFormat:@"%@%@<?xml version=\"1.0\" encoding=\"gbk\"?><Result><DllVersion></DllVersion><CheckType><InsideName>CheckSecureDesktop</InsideName><OutsideName>安全桌面</OutsideName><Desc>检查客户机是否符合安全桌面安全检查项。</Desc><Result>Yes</Result><Message>符合管理员要求</Message></CheckType></Result>%@", changeString, head, foot];
    return allString;

}

#pragma mark 杀毒软件检查
+ (NSString *)CheckAntiVirusSoft:(NSString *)message withWeb:(BOOL)isWeb {
    NSString *head = @"";
    NSString *foot = @"";
    if (isWeb) {
        head = @"[<REPLY>]";
        foot = @"[</REPLY>]";
    }
    NSMutableString * changeString = [NSMutableString stringWithString:[YGMessageSplicing cutStringAndInsertString:message]];// 在报文头中插入yes
    // 该安检项不处理 直接上报成功
    NSString *allString = [NSString stringWithFormat:@"%@%@<?xml version=\"1.0\" encoding=\"gbk\"?><Result><DllVersion></DllVersion><CheckType><InsideName>CheckAntiVirusSoft</InsideName><OutsideName>杀毒软件检查</OutsideName><Desc>检查客户机是否符合杀毒软件安全检查项。</Desc><Result>Yes</Result><Message>符合管理员要求</Message></CheckType></Result>%@", changeString, head, foot];
    return allString;
    
}
#pragma mark ReportProcessInfo 上报软件信息
+ (NSString *)ReportProcessInfo:(NSString *)agentID { 
    NSArray * localAppInfo = [SoftwareList runningSoftwareList];
    NSMutableString * string = [[NSMutableString alloc] init];
    for (int i = 0; i < localAppInfo.count; i++) {
        ApplicationInfo * app = localAppInfo[i];
        NSString * str = [NSString stringWithFormat:@"<ProcessInfo><PID>%@</PID><ProcessName>%@</ProcessName><ProcessPath>%@</ProcessPath><ProcessSize></ProcessSize><UserName>%@</UserName><CreateTime>%@</CreateTime></ProcessInfo>",
                          app.ApplicationProcessID,
                          app.ApplicationName,
                          app.ApplicationPath,
                          app.userName,
                          app.createDate];
        [string insertString:str atIndex:0];
    }
    NSString * requestString = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>RealTime</TradeCode><AgentID>%@</AgentID><RealTimeCode>ReportProcessInfo</RealTimeCode>%@</ASM>",
                                agentID,
                                string];
    return requestString;
}


#pragma mark tool

// 截取报文表头并在固定位置插入yes
+ (NSString *)cutStringAndInsertString:(NSString *)message
{
    NSString * comps = message;
    NSRange rang = [comps rangeOfString:@"</CallOneFuncMode>"];
    if (rang.location == NSNotFound) {
        return @"";
    }
    NSUInteger num = rang.length + rang.location;
    NSMutableString * changeString = [NSMutableString stringWithFormat:@"%@", comps];
    [changeString insertString:@"\n	<Result>Yes</Result>" atIndex:num];
    return changeString;
}
/** 用#infogo#做关键字切割字符串*/
+ (NSArray *)getCurrentCheckItemID:(NSString *)string {
    return [string componentsSeparatedByString:@"#infogo#"];
}

/** 截取XML报文，并转换成字典返回*/
+ (NSDictionary *)dealWithStringToArray:(NSString *)string {
    NSString *str = nil;
    str = CutOffStringBetweenBoth(string, @"[<REQUEST>]<?xml version=\"1.0\" encoding=\"gbk\"?>", @"[</REQUEST>]");
    if (str.length < 1 && [string rangeOfString:@"<?xml version=\\\"1.0\\\" encoding=\\\"gbk\\\"?>"].location != NSNotFound) {
        str = [string stringByReplacingOccurrencesOfString:@"<?xml version=\\\"1.0\\\" encoding=\\\"gbk\\\"?>" withString:@""];
    }
    if (str.length == 0) {
        HXERRORLOG(@"解析安检项报文错误");
    }
    return [NSDictionary dictionaryWithXMLString:str];
}
@end
