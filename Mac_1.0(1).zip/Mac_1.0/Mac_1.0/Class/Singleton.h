//
//  Singleton.h
//  Mac_1.0
//
//  Created by apple on 2016/11/10.
//  Copyright © 2016年 infogo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YGPolicyItemModel.h"
#import "YGPolicyItem.h"
#import "ApplicationInfo.h"
#import "USBModel.h"
@interface Singleton : NSObject
@property (nonatomic, retain) NSTimer *connectTimer; // 计时器
@property (nonatomic, assign) int client_sockfd;

+ (instancetype)shareInstancetype;
/** 心跳*/
-(void)longConnectToSocket;
/** 第一次上报软件信息*/
- (void)firstUploadSoftInfo;
/** 第一次上报硬件信息*/
- (void)firstUploadHardware;

/** 初始化client_sockfd 并开启接收*/
- (void)initNetwork:(NSString *)addressip andPort:(int) port;
/** 关闭socket*/
int CloseSocket(void);

//
// 向服务器发送交易报文
// pTradeCode:"HeartTest"
// pTradeContent:"<?xml version=\"1.0\" encoding=\"gbk\"?><ASM><TradeCode>HeartTest</TradeCode><AgentID>35</AgentID></ASM>"
// nContentLen:strlen(pTradeContent)
/*
 char *pTradeName         交易名称
 char *pTradeContent      客户端上传的xml
 int nContentLen          pTradeContent的长度
 char *pRecv              服务器发送的报文
 int nRevLen              pRecv的长度
 int cType                报文的类型 1客户端请求报文 2应答给客户端报文 3AsmSvr请报文 4应答给AsmSvr报文 5WEB端请求报文 6应答给WEB端报文
 int nSNO                 nSerial 对应的交易id(流水号)
 发送报文
 true 发送成功(收到了正确的回执)
 */
- (BOOL)IsSendTo:(char *)pTradeName pTradeContent:(char *)pTradeContent nContentLen:(int)nContentLen pRecv:(char *)pRecv nRevLen:(int)nRevLen cType:(int)cType nSNO:(int)nSNO;
// 对issendto封装
- (int)SocketSendUNRecv:(char *)pTradeName pTradeContent:(char *)pTradeContent nContentLen:(int)nContentLen cType:(int)cType nSNO:(int)nSNO;

#pragma mark 策略项
/** 拿到策略项之后，去服务器取策略*/
- (void)GetPolicy:(NSString *)itemID;

/** 获取客户端策略*/
- (void)GetAgentPolicyList;

/** 软件黑白名单回应报文*/
- (void)RecvMobilePolicy_Application:(ApplicationInfo *)app;

/** 文档策略违规上报报文*/
void RecvMobilePolicy_File(NSDictionary * state);
/** 获取设备属性信息*/
- (void)recvGetDeviceProperty;
/** 上网行为管控上传报文*/
void RecvMobilePolicy_InternetBehavior(NSArray *urlArr);
int RecvGetDepart(void);
void RecvUSBRegister(USBModel *model, NSString *user, NSString *message, NSString *departID);
void RecvUSBPlugReport(USBModel *model, NSString *action);
int RecvGetUsbInfo(NSString * locationID);
void RecvUSBUnknownClass(USBModel *model);

@end
