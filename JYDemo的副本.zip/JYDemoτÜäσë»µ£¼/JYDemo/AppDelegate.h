//
//  AppDelegate.h
//  JYDemo
//
//  Created by west on 2019/9/15.
//  Copyright © 2019 west. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

// 强引用窗口控制器
@property (strong) NSWindowController *mainWindowController;
@end

