//
//  WindowController.m
//  JYDemo
//
//  Created by west on 2019/9/15.
//  Copyright © 2019 west. All rights reserved.
//

#import "WindowController.h"

@interface WindowController ()

@end

static NSString *const kStoryboardName = @"Main";
static NSString *const kWindowControllerIdentifier = @"WindowController";

@implementation WindowController




- (void)windowDidLoad {
    [super windowDidLoad];
    // 居中
    [self.window center];
    // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
}

+(instancetype)windowController{
    NSStoryboard *storyboard = [NSStoryboard storyboardWithName:kStoryboardName bundle:[NSBundle mainBundle]];
    WindowController *WC = [storyboard instantiateControllerWithIdentifier:kWindowControllerIdentifier];
    [WC.window setAnimationBehavior:NSWindowAnimationBehaviorDocumentWindow];
    [WC.window makeFirstResponder:nil];
    return WC;
}


@end
