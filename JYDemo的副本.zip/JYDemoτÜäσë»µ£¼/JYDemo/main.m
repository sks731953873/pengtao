//
//  main.m
//  JYDemo
//
//  Created by west on 2019/9/15.
//  Copyright © 2019 west. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
