//
//  LoginWindowController.m
//  JYDemo
//
//  Created by west on 2019/9/15.
//  Copyright © 2019 west. All rights reserved.
//

#import "LoginWindowController.h"
#import "AppDelegate.h"

static NSString *const kStoryboardName = @"Main";
static NSString *const kLoginWindowControllerIdentifier = @"LoginWindowController";

@interface LoginWindowController ()

@end

@implementation LoginWindowController

- (void)windowDidLoad {
    [super windowDidLoad];
    
    // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
}

@end
