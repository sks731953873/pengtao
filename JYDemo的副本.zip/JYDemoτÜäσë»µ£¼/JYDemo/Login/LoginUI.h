//
//  LoginUI.h
//  JYDemo
//
//  Created by west on 2019/9/15.
//  Copyright © 2019 west. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <AppKit/AppKit.h>
#import <Foundation/Foundation.h>
#import <unistd.h>

NS_ASSUME_NONNULL_BEGIN

@protocol LoginUIDelegate <NSObject>

-(void)LoginDelegate:(NSDictionary*)dic;


@end


@interface LoginUI : NSView

+(instancetype)loadLoginUIView;

@property(weak,nonatomic)id<LoginUIDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
