//
//  LoginUI.m
//  JYDemo
//
//  Created by west on 2019/9/15.
//  Copyright © 2019 west. All rights reserved.
//

#import "LoginUI.h"
#import "MBProgressHUD.h"


@interface LoginUI()<MBProgressHUDDelegate>
{
    
    IBOutlet NSTextField *account;
    IBOutlet NSSecureTextField *password;
    MBProgressHUD *HUD;
}

@property(nonatomic,strong)LoginUI* loginUI;

@end

@implementation LoginUI


+(instancetype)loadLoginUIView
{
    NSArray *arr;
    id targetObj = nil;
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:nil topLevelObjects:&arr];
    for (id obj in arr) {
        if ([obj isKindOfClass:[self class]]) {
            targetObj = obj;
            break;
        }
    }
    return targetObj;
}

- (IBAction)LoginBtnAction:(id)sender {
    
    NSDictionary* dic = @{@"account":account.stringValue,
                          @"password":password.stringValue
                          };
    if ([_delegate respondsToSelector:@selector(LoginDelegate:)]) {
//        HUD = [[MBProgressHUD alloc] initWithView:self.window.contentView];
//        [self.window.contentView addSubview:HUD];
//
//        // Regiser for HUD callbacks so we can remove it from the window at the right time
//        HUD.delegate = self;
//
//        // Show the HUD while the provided method executes in a new thread
//        [HUD showWhileExecuting:@selector(myTask) onTarget:self withObject:nil animated:YES];
//
        //[NSThread sleepForTimeInterval:3.0f];
        
        [_delegate LoginDelegate:dic];
    }
}

- (void)myTask {
    // Do something usefull in here instead of sleeping ...
    [NSThread sleepForTimeInterval:3];
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
