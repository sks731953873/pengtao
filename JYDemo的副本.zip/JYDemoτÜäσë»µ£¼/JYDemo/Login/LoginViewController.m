//
//  LoginViewController.m
//  JYDemo
//
//  Created by west on 2019/9/15.
//  Copyright © 2019 west. All rights reserved.
//

#import "LoginViewController.h"
#import "WindowController.h"
#import "AppDelegate.h"
#import "LoginUI.h"
#import "MBProgressHUD.h"
#import <unistd.h>

typedef void (^loginBlock) (BOOL isOver);

@interface LoginViewController ()<LoginUIDelegate, MBProgressHUDDelegate>
{
    
    AppDelegate *appdelegate;
    
    IBOutlet NSBox *left_box;
    
    MBProgressHUD *HUD;
    IBOutlet NSBox *right_box;
    WindowController* UIwinController;
    BOOL    isOver;
}

@property(nonatomic,strong)LoginUI* loginUI;
@property(nonatomic,strong)loginBlock  backBlock;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    isOver = NO;
    
    if (!_loginUI) {
        _loginUI = [LoginUI loadLoginUIView];
        _loginUI.delegate = self;
        _loginUI.frame = NSMakeRect(0, 0, left_box.contentView.frame.size.width, left_box.contentView.frame.size.height);
    }
    
    [left_box addSubview:_loginUI];
    
}

#pragma --mark LoginUIDelegate
-(void)LoginDelegate:(NSDictionary*)dic{
    
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    
    // Regiser for HUD callbacks so we can remove it from the window at the right time
    HUD.delegate = self;
    
    // Show the HUD while the provided method executes in a new thread
    [HUD showWhileExecuting:@selector(myTask) onTarget:self withObject:nil animated:YES];
    
    
    if ([dic[@"account"] isEqualToString:@"123"] && [dic[@"password"] isEqualToString:@"123"]) {
        //1.创建聊天界面窗口控制器
        
        __weak typeof(self) weakSelf = self;
        
        
        weakSelf.backBlock = ^(BOOL isOver){
            
            __strong typeof(weakSelf) strongSelf = weakSelf;
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                
                
                if (isOver) {
                    
                    //2.强应用这个Window,不然这个Window会在跳转之后ide瞬间被销毁
                    strongSelf->appdelegate = (AppDelegate*)[NSApplication sharedApplication].delegate;
                    strongSelf->UIwinController = [WindowController windowController];
                    
                    
                    strongSelf->appdelegate.mainWindowController = strongSelf->UIwinController;
                    
                    //3.设为KeyWindow并前置
                    [strongSelf->UIwinController.window makeKeyAndOrderFront:self];
                    
                    //4.关闭现在的登录窗口
                    [self.view.window orderOut:self];
                }
            });
        };
    }
    else{
        
        return;
    }
}

- (void)myTask {
    // Do something usefull in here instead of sleeping ...
    [NSThread sleepForTimeInterval:3];
    
    //[NSThread sleepForTimeInterval:3.0f];
    isOver = YES;
    
    if (isOver) {
        self.backBlock(isOver);
    }
    else{
        
        return;
    }
    
    
}


@end
