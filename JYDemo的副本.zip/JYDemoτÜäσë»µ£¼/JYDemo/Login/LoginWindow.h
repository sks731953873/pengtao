//
//  LoginWindow.h
//  JYDemo
//
//  Created by west on 2019/9/15.
//  Copyright © 2019 west. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoginWindow : NSWindow

@end

NS_ASSUME_NONNULL_END
