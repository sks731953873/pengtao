//
//  AppDelegate.h
//  iPREditor
//
//  Created by admin on 10/28/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FileTool.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic) BOOL isChanged;
@property (nonatomic) BOOL goToFile;
@property (nonatomic) BOOL fileOpened;
@property (nonatomic, retain) UIStoryboard* storyBoard;
@property (nonatomic, retain) NSURL* fileURL;
@property (nonatomic, retain) NSMutableDictionary* dictionary;
//@property (nonatomic, retain) NSData* rawData;
@property (nonatomic, strong) NSString* temFilePath;

@property (nonatomic, retain) UINavigationController* navi;
@property (nonatomic, retain) NSString* documentDirectory;
@property (nonatomic, retain) NSString* bundlePath;
@property (nonatomic, retain) FileTool* fileTool;

@end

