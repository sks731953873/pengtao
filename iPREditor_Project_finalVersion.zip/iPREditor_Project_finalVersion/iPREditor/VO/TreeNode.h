//
//  TreeNode.h
//  iPREditor
//
//  Created by admin on 11/2/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TreeNode : NSObject <NSCopying,NSMutableCopying>

@property (nonatomic) NSUInteger nodeLevel;
@property (nonatomic) BOOL isExpanded;
@property (nonatomic,strong) NSString* keyLabel;
@property (nonatomic,strong) NSString* keyPath;
@property (nonatomic,strong) NSString* control;
@property (nonatomic,strong) NSMutableArray* childNodes;
@property (nonatomic,strong) NSString* toolTip;
@property (nonatomic,strong) id extra;


@end
