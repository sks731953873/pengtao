//
//  TextViewController.m
//  iPREditor
//
//  Created by admin on 11/10/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "TextViewController.h"
#import "PlistTool.h"
#import "TreeNode.h"
#import "CustomMessTool.h"
#import "AppDelegate.h"

@implementation TextViewController

PlistTool* tool;
NSArray* relationArray;
int sectionCount;
BOOL relationSectionHasShow;
BOOL isDonePressed;
BOOL isEdit;
BOOL isInitEmpty;
BOOL isModified;
int lastRelationSectionRowCount;
//UITextField* field;
UITextView* viewField;
AppDelegate* delegate;

CGSize size;
float everyRowHeight;
float everyRowWidth;
float shouldWidth;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    tool = [PlistTool instance];
    sectionCount = 1;
    relationSectionHasShow = NO;
    isEdit = NO;
    lastRelationSectionRowCount = -1;
    
    UIBarButtonItem* edit = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editClicked:)];
    self.navigationItem.rightBarButtonItem = edit;
    
    size = [self.keyValue sizeWithAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:15.0],NSFontAttributeName, nil]];
    everyRowHeight = size.height;
    everyRowWidth = SCREEN_WIDTH - 10*2;
    isInitEmpty = NO;
    isModified = NO;
    if ([self.keyValue isEqualToString:@""]) {
        isInitEmpty = YES;
    }
    
    if (everyRowWidth >= size.width) {
        
        shouldWidth = 44.0;
    }
    else {
        
        shouldWidth = 44.0 + ((size.width - 20)/everyRowWidth) * everyRowHeight - 20;
    }
    
    delegate = [UIApplication sharedApplication].delegate;

}

- (void)editClicked: (id)sender {
    
    NSIndexPath* path = [NSIndexPath indexPathForRow:0 inSection:0];
    UITableViewCell* name_cell = [self.tableView cellForRowAtIndexPath:path];
    
    viewField = (UITextView*)[name_cell viewWithTag:1];
    
    if ([[sender title] isEqualToString:@"Edit"]) {
        isEdit = YES;
        viewField.userInteractionEnabled = YES;
        name_cell.textLabel.textColor = [UIColor blackColor];
        if ([self.keyValue isEqualToString:@""] == NO) {
         
            if (isInitEmpty == NO) {
                 viewField.textColor = [UIColor blackColor];
            }
        }
        self.navigationItem.rightBarButtonItem.title = @"Done";
    }
    //点击的是Done
    else {
        isDonePressed = YES;
        isEdit = NO;

        if (sectionCount > 1) {
            
            [self showConfirm];
        }
        else {
            
            [self save:NO];
        }
    }
}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    
    everyRowHeight = size.height;
    everyRowWidth = SCREEN_WIDTH - 10*2;
    
    if (everyRowWidth >= size.width) {
        
        shouldWidth = 44.0;
    }
    else {
        
        shouldWidth = 44.0 + ((size.width - 20)/everyRowWidth) * everyRowHeight - 20;
    }
    
    float cellHeight;
    if (everyRowWidth >= size.width) {
        
        cellHeight = 44.0;
    }
    else {
        int x = (size.width - 20)/everyRowWidth;
        cellHeight = 44.0 + (x)*everyRowHeight - 10;
    }
    
    //转为横屏
    if (UIInterfaceOrientationIsLandscape(toInterfaceOrientation)) {
        
        UITableViewCell* cell = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
        
        cell.frame = CGRectMake(cell.frame.origin.x, cell.frame.origin.y, SCREEN_WIDTH, cellHeight);
        
        ((UITextView*)[cell viewWithTag:1]).frame = CGRectMake(0, 0, SCREEN_WIDTH, shouldWidth);
        
    }
    else {
        
        UITableViewCell* cell = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
        
        cell.frame = CGRectMake(cell.frame.origin.x, cell.frame.origin.y, SCREEN_WIDTH, cellHeight);
        
        ((UITextView*)[cell viewWithTag:1]).frame = CGRectMake(0, 0, SCREEN_WIDTH, shouldWidth);
        
    }
}

- (void)showConfirm {
    
    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:@"Related keys exists" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    
    NSMutableParagraphStyle* ps = [[NSMutableParagraphStyle alloc] init];
    [ps setAlignment:NSTextAlignmentCenter];
    NSDictionary* attribs = @{NSParagraphStyleAttributeName:ps};
    
    NSMutableAttributedString *attributedText =[[NSMutableAttributedString alloc] initWithString:@"Yes: Modify current key and related key          \nNo:Just modify current key" attributes:attribs];
    UIAlertAction* yesAction = [UIAlertAction actionWithTitle:@"Yes"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction *action){
                                                          if (isDonePressed) {
                                                              [self save:YES];
                                                          }
                                                      }];
    UIAlertAction* noAction = [UIAlertAction actionWithTitle:@"No"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction *action){
                                                         if (isDonePressed) {
                                                             [self save:NO];
                                                         }
                                                     }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
    
    [alertController addAction:yesAction];
    [alertController addAction:noAction];
    [alertController addAction:cancelAction];
    
    [alertController setValue:attributedText forKey:@"attributedMessage"];
    [self presentViewController:alertController animated:YES completion:nil];
    
}

- (void)save: (BOOL)saveRelation {
    
    NSString* after_trim = [viewField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    [viewField resignFirstResponder];
    viewField.text = after_trim;
    viewField.userInteractionEnabled = NO;
    viewField.textColor = [UIColor grayColor];
    
    //如果点击了Yes,需要全部保存
    if (saveRelation) {
        
        delegate.isChanged = YES;
        
        self.keyValue = after_trim;
        
        if (self.extra) {
            
            //Integer类型
            if ([self.control isEqualToString:INTEGER]) {
                NSNumber* result = [NSNumber numberWithInteger:[after_trim integerValue]];
                [self.extra setObject:result atIndex:[self.index intValue]];
            }
            //String类型
            else {
                
                [self.extra setObject:after_trim atIndex:[self.index intValue]];
            }
        }
        else {
            
            NSArray* keys = [self.keyPath componentsSeparatedByString:@"."];
            id node = self.dictionary;
            id lastNode = node;
            for (int i = 0; i < keys.count - 1; i++) {
                
                node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                
                //如果key不存在，需要创建
                if (!node) {
                    //NSLog(@"%@ not exist",keys[i]);
                    NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                    [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                    node = tem;
                }
                lastNode = node;
            }
            
            if ([self.control isEqualToString:INTEGER]) {
                NSNumber* result = [NSNumber numberWithInteger:[after_trim integerValue]];
                [tool setValue:result forKey:[keys lastObject] inDictionary:node recursion:NO];
            }
            else {
                [tool setValue:after_trim forKey:[keys lastObject] inDictionary:node recursion:NO];
            }
            [self saveRelationArray];
        }
        [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
    }
    //点击了No,不用保存关联key
    else {
        
        if (isModified) {
            
        
        //与初始值不相等
        if ([after_trim isEqualToString:self.keyValue] == NO) {
            
            delegate.isChanged = YES;
            
            //NSLog(@"not eq");
            self.keyValue = after_trim;
            
            if (self.extra) {
                
                //Integer类型
                if ([self.control isEqualToString:INTEGER]) {
                    NSNumber* result = [NSNumber numberWithInteger:[after_trim integerValue]];
                    [self.extra setObject:result atIndex:[self.index intValue]];
                }
                //String类型
                else {
                    
                    [self.extra setObject:after_trim atIndex:[self.index intValue]];
                }
            }
            else {
                NSArray* keys = [self.keyPath componentsSeparatedByString:@"."];
                
                id node = self.dictionary;
                id lastNode = node;
                for (int i = 0; i < keys.count - 1; i++) {
                    
                    node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                    
                    //如果key不存在，需要创建
                    if (!node) {
                        //NSLog(@"%@ not exist",keys[i]);
                        NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                        [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                        node = tem;
                    }
                    lastNode = node;
                }
                
                if ([self.control isEqualToString:INTEGER]) {
                    NSNumber* result = [NSNumber numberWithInteger:[after_trim integerValue]];
                    [tool setValue:result forKey:[keys lastObject] inDictionary:node recursion:NO];
                }
                else {
                    [tool setValue:after_trim forKey:[keys lastObject] inDictionary:node recursion:NO];
                }
            }
            [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
        }
        isModified = NO;
        }
    }
    self.navigationItem.rightBarButtonItem.title = @"Edit";
}


#pragma - UITableView

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* cellId = @"text_view_cell_id";
    
    UITableViewCell* cell = [self.tableView dequeueReusableCellWithIdentifier:cellId];
    
    if (cell == nil) {
        
     cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
        
    }
    else {
  
        for (UIView* view in cell.contentView.subviews) {
            [view removeFromSuperview];
        }
    }
    if (indexPath.section == 0) {

        UITextView* textView = [[UITextView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, shouldWidth)];
        textView.delegate = self;
        if ([self.control isEqualToString:INTEGER]) {
 
            textView.keyboardType = UIKeyboardTypeNumberPad;
        }
        textView.userInteractionEnabled = NO;
        textView.tag = 1;
        
        textView.text = self.keyValue;
        textView.font = [UIFont systemFontOfSize:15.0];
        textView.textContainerInset = UIEdgeInsetsMake(10, 10, 0, 10);
        
        if ([self.keyValue isEqualToString:@""]) {
            textView.text = @"empty";
            textView.font = [UIFont italicSystemFontOfSize:15.0];
        }
        textView.textColor = [UIColor grayColor];
        if (isEdit) {
            textView.textColor = [UIColor blackColor];
            textView.userInteractionEnabled = YES;
        }
        [cell.contentView addSubview:textView];
    }
    else {
        cell.textLabel.adjustsFontSizeToFitWidth = YES;
        cell.textLabel.minimumScaleFactor = 9.0/[UIFont labelFontSize];
        cell.textLabel.text = [[relationArray objectAtIndex:indexPath.row] keyPath];
        //显示current value
        if (indexPath.section == 1) {
            id lastNode = [CustomMessTool gimmeLastNode:[[relationArray objectAtIndex:indexPath.row] keyPath] inDictionary:self.dictionary];
            
            if (lastNode == nil) {
                cell.detailTextLabel.text = NIL_STR;
            }
            else {
                if ([BLN_SET containsObject:NSStringFromClass([lastNode class])]) {
                    cell.detailTextLabel.text = [lastNode boolValue] ? TRUE_STR : FALSE_STR;
                }
                else {
                    cell.detailTextLabel.text = [lastNode description];
                }
            }
            
        }
        //显示expected value
        else {
        
            id value = [[relationArray objectAtIndex:indexPath.row] extra];
        
            if ([BLN_SET containsObject:NSStringFromClass([value class])]) {
            
                cell.detailTextLabel.text = [value boolValue] ? TRUE_STR : FALSE_STR;
            }
            else {
            
                cell.detailTextLabel.text = [[relationArray objectAtIndex:indexPath.row] extra];
            }
        }
        
    }
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return sectionCount;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section == 0) {
        return 1;
    }
    return relationArray.count;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    if (section == 0) {
        return self.keyLabel;
    }
    else if (section == 1) {
        return @"Current Related key value:";
    }
    return @"Expected Related key value:";
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section
{
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    if (section == 0) {
        [header.textLabel setText:self.keyLabel];
    }
    else if (section == 1){
        [header.textLabel setText:@"Current Related key value:"];
    }
    else {
        [header.textLabel setText:@"Expected Related key value:"];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (everyRowWidth >= size.width) {
        
        return 44.0;
    }
    int x = (size.width - 20)/everyRowWidth;
    return 44.0 + (x)*everyRowHeight - 10;
}

#pragma - UITextViewDelegate
- (void)textViewDidBeginEditing:(UITextView *)textView {
    
    //是空的话
    if ([self.keyValue isEqualToString:@""] || isInitEmpty) {
        
        textView.text = @"";
    }
    textView.textColor = [UIColor blackColor];
    textView.font = [UIFont systemFontOfSize:15.0];
}
- (void)textViewDidChange:(UITextView *)textView {
    
    isModified = YES;
    NSString* after_trim = [textView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    id value;
    //如果是Integer
    if ([self.control isEqualToString:INTEGER]) {
        value = [NSNumber numberWithInteger:[after_trim integerValue]];
    }
    //是String
    else {
        value = after_trim;
    }
    [self showRelation:value];
}

#pragma - UITextFieldDidChange
- (void)showRelation:(id)value {
    NSString* product = [CustomMessTool getProduct:@"FactoryDocControl.PRODUCT" inDictionary:self.dictionary];
    
    relationArray = [CustomMessTool getRelation:self.keyPath withValue:value andProduct:product];
    
    if (relationArray.count > 0) {
        //第一次显示出来
        if (relationSectionHasShow == NO) {
            sectionCount = sectionCount + 2;
            NSMutableIndexSet *idxSet = [[NSMutableIndexSet alloc] init];
            [idxSet addIndex:1];
            [idxSet addIndex:2];
            [self.tableView beginUpdates];
            [self.tableView insertSections:idxSet withRowAnimation:UITableViewRowAnimationFade];
            
            for (int i = 0 ; i < relationArray.count; i++) {
                
                NSIndexPath* currentPath = [NSIndexPath indexPathForRow:i inSection:1];
                NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:i inSection:2];

                [self.tableView insertRowsAtIndexPaths:@[currentPath,expectedPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
            [self.tableView endUpdates];
            lastRelationSectionRowCount = (int)relationArray.count;
            relationSectionHasShow = YES;
        }
        //后面的需要改值
        else {
            
            //当前关联数组与上一次的长度一样的话,只需改值
            if (relationArray.count == lastRelationSectionRowCount) {
                for (int i = 0 ; i < relationArray.count; i++) {
                    
                    //修改current
                    NSIndexPath* currentPath = [NSIndexPath indexPathForRow:i inSection:1];
                    UITableViewCell* currentCell = [self.tableView cellForRowAtIndexPath:currentPath];
                    currentCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                    id lastNode = [CustomMessTool gimmeLastNode:[[relationArray objectAtIndex:i] keyPath] inDictionary:self.dictionary];
                    if (lastNode == nil) {
                        currentCell.detailTextLabel.text = NIL_STR;
                    }
                    else {
                        if ([BLN_SET containsObject:NSStringFromClass([lastNode class])]) {
                            currentCell.detailTextLabel.text = [lastNode boolValue] ? TRUE_STR : FALSE_STR;
                        }
                        else {
                            currentCell.detailTextLabel.text = [lastNode description];
                        }
                    }
                    //修改expected
                    NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:i inSection:2];
                    UITableViewCell* expectedCell = [self.tableView cellForRowAtIndexPath:expectedPath];
                    id value = [[relationArray objectAtIndex:i] extra];
                    expectedCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                    if ([BLN_SET containsObject:NSStringFromClass([value class])]) {
                        
                        expectedCell.detailTextLabel.text = [value boolValue] ? TRUE_STR : FALSE_STR;
                    }
                    else {
                        
                        expectedCell.detailTextLabel.text = [[relationArray objectAtIndex:i] extra];
                    }
                }
            }
            //当前关联数组长度 > 上次的话，需要在表格上插入新的行
            else if (relationArray.count > lastRelationSectionRowCount) {
                
                //先修改
                int i = 0;
                for (; i < lastRelationSectionRowCount; i++) {
                    
                    //修改current
                    NSIndexPath* currentPath = [NSIndexPath indexPathForRow:i inSection:1];
                    UITableViewCell* currentCell = [self.tableView cellForRowAtIndexPath:currentPath];
                    currentCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                    id lastNode = [CustomMessTool gimmeLastNode:[[relationArray objectAtIndex:i] keyPath] inDictionary:self.dictionary];
                    if (lastNode == nil) {
                        currentCell.detailTextLabel.text = NIL_STR;
                    }
                    else {
                        if ([BLN_SET containsObject:NSStringFromClass([lastNode class])]) {
                            currentCell.detailTextLabel.text = [lastNode boolValue] ? TRUE_STR : FALSE_STR;
                        }
                        else {
                            currentCell.detailTextLabel.text = [lastNode description];
                        }
                    }
                    
                    //修改expected
                    NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:i inSection:2];
                    UITableViewCell* expectedCell = [self.tableView cellForRowAtIndexPath:expectedPath];
                    id value = [[relationArray objectAtIndex:i] extra];
                    expectedCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                    if ([BLN_SET containsObject:NSStringFromClass([value class])]) {
                        
                        expectedCell.detailTextLabel.text = [value boolValue] ? TRUE_STR : FALSE_STR;
                    }
                    else {
                        
                        expectedCell.detailTextLabel.text = [[relationArray objectAtIndex:i] extra];
                    }
                }
                //后添加行
                for (; i < relationArray.count; i++) {
                    
                    NSIndexPath* currentPath = [NSIndexPath indexPathForRow:i inSection:1];
                     NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:i inSection:1];
                    [self.tableView insertRowsAtIndexPaths:@[currentPath,expectedPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                }
                lastRelationSectionRowCount = (int)relationArray.count;
            }
            //当前关联数组长度 < 上次的话，需要在表格上删除行
            else {
                //先修改
                int i = 0;
                for (; i < relationArray.count; i++) {
                    
                    //修改current
                    NSIndexPath* currentPath = [NSIndexPath indexPathForRow:i inSection:1];
                    UITableViewCell* currentCell = [self.tableView cellForRowAtIndexPath:currentPath];
                    currentCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                    id lastNode = [CustomMessTool gimmeLastNode:[[relationArray objectAtIndex:i] keyPath] inDictionary:self.dictionary];
                    if (lastNode == nil) {
                        currentCell.detailTextLabel.text = NIL_STR;
                    }
                    else {
                        if ([BLN_SET containsObject:NSStringFromClass([lastNode class])]) {
                            currentCell.detailTextLabel.text = [lastNode boolValue] ? TRUE_STR : FALSE_STR;
                        }
                        else {
                            currentCell.detailTextLabel.text = [lastNode description];
                        }
                    }
                    
                    //修改expected
                    NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:i inSection:2];
                    UITableViewCell* expectedCell = [self.tableView cellForRowAtIndexPath:expectedPath];
                    id value = [[relationArray objectAtIndex:i] extra];
                    expectedCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                    if ([BLN_SET containsObject:NSStringFromClass([value class])]) {
                        
                        expectedCell.detailTextLabel.text = [value boolValue] ? TRUE_STR : FALSE_STR;
                    }
                    else {
                        
                        expectedCell.detailTextLabel.text = [[relationArray objectAtIndex:i] extra];
                    }
                }
                //后删除
                //后添加行
                int j = i;
                for (; i < lastRelationSectionRowCount; i++) {
                    
                    NSIndexPath* currentPath = [NSIndexPath indexPathForRow:j inSection:1];
                    NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:j inSection:2];
                    [self.tableView deleteRowsAtIndexPaths:@[currentPath,expectedPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                }
                lastRelationSectionRowCount = (int)relationArray.count;
            }
            
        }
    }
    else {
        if (relationSectionHasShow == YES) {
            sectionCount = sectionCount - 2;
            lastRelationSectionRowCount = -1;
            NSMutableIndexSet *idxSet = [[NSMutableIndexSet alloc] init];
            [idxSet addIndex:1];
            [idxSet addIndex:2];
            [self.tableView beginUpdates];
            [self.tableView deleteSections:idxSet withRowAnimation:UITableViewRowAnimationFade];
            [self.tableView endUpdates];
            relationSectionHasShow = NO;
        }
    }
}

- (void) textFieldDidChange:(id) sender {
    
    UITextField* field = (UITextField *)sender;
    NSString* after_trim = [field.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    id value;
    //如果是Integer
    if ([self.control isEqualToString:INTEGER]) {
        value = [NSNumber numberWithInteger:[after_trim integerValue]];
    }
    //是String
    else {
        value = after_trim;
    }
    [self showRelation:value];
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)saveRelationArray {
    
    if (relationArray.count > 0) {
        
        for (TreeNode* relation in relationArray) {
            
            NSArray* keys = [relation.keyPath componentsSeparatedByString:@"."];
            
            id node = self.dictionary;
            id lastNode = node;
            for (int i = 0; i < keys.count - 1; i++) {
                
                node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                
                //如果key不存在，需要创建
                if (!node) {
                    NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                    [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                    node = tem;
                }
                lastNode = node;
            }
            [tool setValue:relation.extra forKey:[keys lastObject] inDictionary:node recursion:NO];
        }
    }
}


@end
