//
//  PreviewController.m
//  iPREditor
//
//  Created by admin on 11/4/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "PreviewController.h"
#import "PlistTool.h"
#import "MainCellViewControllerTableViewController.h"
#import "MainCellTableViewCell.h"

@interface PreviewController ()

@end

@implementation PreviewController
NSString * documentDirectory;
NSString* bundlePath;
PlistTool* plistTool;
UISearchBar* searchBar;
NSMutableArray* data;
NSMutableDictionary* dic;
NSString* currentKey;
NSUInteger currentIndex;

NSString* result;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.textView=[[UITextView alloc] initWithFrame:CGRectMake(0, 70, 380, 550)] ;
    self.textView.delegate=self;
    [self.view addSubview:self.textView];
    self.view.backgroundColor=[UIColor whiteColor];
    _textView.font = [UIFont systemFontOfSize:16];
    
    
    
    NSArray * paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    documentDirectory = [paths objectAtIndex:0];
    bundlePath = [[NSBundle mainBundle] bundlePath];
    plistTool = [PlistTool instance];
    
    //[searchBar setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    //[searchBar sizeToFit];
    //self.tableView.tableHeaderView = searchBar;
    //data = [[NSMutableArray alloc] init];
    //dic = [[NSMutableDictionary alloc] init];
    //dictionary = [[NSMutableDictionary alloc] initWithContentsOfFile:self.fullPath];
    result=[NSString stringWithFormat:@"%@",self.dictionary];
    
    self.textView.text=result;

    
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:NO];
    self.textView.text = [NSString stringWithFormat:@"%@",self.dictionary];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
