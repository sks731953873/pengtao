//
//  ServerViewController.h
//  iPREditor
//
//  Created by admin on 10/31/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ServerViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextField *server;
- (IBAction)getClicked:(id)sender;

- (IBAction)backTapped:(id)sender;
@end
