//
//  PlistNavigationController.h
//  iPREditor
//
//  Created by jett on 15/11/5.
//  Copyright (c) 2015年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlistNavigationController : UINavigationController

@end
