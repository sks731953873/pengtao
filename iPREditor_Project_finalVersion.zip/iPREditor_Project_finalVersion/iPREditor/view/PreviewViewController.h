//
//  PreviewController.h
//  iPREditor
//
//  Created by admin on 11/4/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PreviewViewController : UIViewController <UISearchBarDelegate,UIScrollViewDelegate, UIBarPositioningDelegate,UITextViewDelegate,UIGestureRecognizerDelegate>

@property (nonatomic, copy) NSString* fullPath;
@property (nonatomic, retain) NSMutableDictionary* dictionary;
@property (nonatomic,strong)UITextView *textView;
@end
