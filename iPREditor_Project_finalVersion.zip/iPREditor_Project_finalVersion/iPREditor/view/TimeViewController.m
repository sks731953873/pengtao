//
//  TimeViewController.m
//  iPREditor
//
//  Created by admin on 11/11/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "TimeViewController.h"
#import "UUDatePicker.h"
#import "PlistTool.h"
#import "AppDelegate.h"


@implementation TimeViewController

PlistTool* tool;
NSString* rawPrefix;
NSString* rawSuffix;
BOOL firstEmpty;
BOOL isModified;
AppDelegate* delegate;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    tool = [PlistTool instance];
    firstEmpty = NO;
    isModified = NO;
    UIBarButtonItem* edit = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editClicked:)];
    self.navigationItem.rightBarButtonItem = edit;
    
    if ([self.keyValue isEqualToString:@""]) {
        firstEmpty = YES;
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat: @"yyyy-MM-dd HH:mm:ss"];
        self.keyValue = [NSString stringWithFormat:@"%@ +0000",[dateFormatter stringFromDate:[NSDate date]]];
    }
    
    delegate = [UIApplication sharedApplication].delegate;
}

- (void)editClicked: (id)sender {
    
    NSIndexPath* pickerPath = [NSIndexPath indexPathForRow:0 inSection:1];
    
    
    if ([[sender title] isEqualToString:@"Edit"]) {
        
        self.navigationItem.rightBarButtonItem.title = @"Done";
        
        [self.tableView cellForRowAtIndexPath:pickerPath].userInteractionEnabled = YES;
    }
    //点击的是Done
    else {
        NSIndexPath* cellPath = [NSIndexPath indexPathForRow:0 inSection:0];
        
        if (isModified == NO) {
            
        }
        else {
            //需要保存
            if ([[self.tableView cellForRowAtIndexPath:cellPath].textLabel.text isEqualToString:[NSString stringWithFormat:@"%@ %@",rawPrefix,rawSuffix]] == NO) {
            
                NSRange target = NSMakeRange(0, [self.tableView cellForRowAtIndexPath:cellPath].textLabel.text.length);
                NSRange range = [[self.tableView cellForRowAtIndexPath:cellPath].textLabel.text rangeOfString:@"+"];
                if (range.location != NSNotFound) {
                
                    target.length = range.location - 1;
                }
                NSString* dateString = [[self.tableView cellForRowAtIndexPath:cellPath].textLabel.text substringWithRange:target];
            
                rawPrefix = dateString;
                rawSuffix = [[self.tableView cellForRowAtIndexPath:cellPath].textLabel.text substringWithRange:NSMakeRange(range.location, 5)];

                NSArray* keys = [self.keyPath componentsSeparatedByString:@"."];
            
                id node = self.dictionary;
                id lastNode = node;
                for (int i = 0; i < keys.count - 1; i++) {
                
                    node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                
                    //如果key不存在，需要创建
                    if (!node) {
                        NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                        [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                        node = tem;
                    }
                    lastNode = node;
                }
                [tool setValue:[self.tableView cellForRowAtIndexPath:cellPath].textLabel.text forKey:[keys lastObject] inDictionary:node recursion:NO];
                delegate.isChanged = YES;
                [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
            }
        }
        self.navigationItem.rightBarButtonItem.title = @"Edit";
        [self.tableView cellForRowAtIndexPath:pickerPath].userInteractionEnabled = NO;
    }
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* cellId = @"setting_time_cellId";
    
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    else {
        return cell;
    }
    if (indexPath.section == 0) {
        
        if (firstEmpty) {
            
             cell.textLabel.text = @"";
        }
        else {
            
            cell.textLabel.text = self.keyValue;
        }

    }
    else {
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];

        NSString* keyValueTem = [self.keyValue mutableCopy];
        
        NSRange target = NSMakeRange(0, keyValueTem.length);
        
        NSRange range = [keyValueTem rangeOfString:@"+"];
        
        if (range.location == NSNotFound) {
            
            [dateFormatter setDateFormat: @"yyyy-MM-dd HH:mm:ss"];
            keyValueTem = [NSString stringWithFormat:@"%@ +0000",[dateFormatter stringFromDate:[NSDate date]]];
            
            range = [keyValueTem rangeOfString:@"+"];
            
             target.length = range.location - 1;
        }
        else {
            
            target.length = range.location - 1;
        }

        
        NSString* dateString = [keyValueTem substringWithRange:target];
        
        rawPrefix = dateString;
        rawSuffix = [keyValueTem substringWithRange:NSMakeRange(range.location, 5)];
        
        [dateFormatter setDateFormat: @"yyyy-MM-dd HH:mm:ss"];

        NSDate *destDate= [dateFormatter dateFromString:dateString];
        UUDatePicker *datePicker
        = [[UUDatePicker alloc]initWithframe:CGRectMake(0, 0, SCREEN_WIDTH, 54)
                                 PickerStyle:0
                                 currentDate:destDate
                                 didSelected:^(NSString *year,
                                               NSString *month,
                                               NSString *day,
                                               NSString *hour,
                                               NSString *minute,
                                               NSString *second,
                                               NSString *weekDay) {
                                     [self picked:[NSString stringWithFormat:@"%@-%@-%@ %@:%@:%@",year,month,day,hour,minute,second]];
                                 }];
        [cell.contentView addSubview:datePicker];
        cell.userInteractionEnabled = NO;

    }
    cell.textLabel.textColor = [UIColor grayColor];
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 1) {
        
        return 220.0;
    }
    return 44;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    if (section == 0) {
        return self.keyLabel;
    }
    return @"Select:";
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section
{
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    if (section == 0) {
        [header.textLabel setText:self.keyLabel];
    }
    else {
        [header.textLabel setText:@"Select:"];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}
- (void)picked: (NSString*)dateString {
    
    NSIndexPath* cellPath = [NSIndexPath indexPathForRow:0 inSection:0];
    [self.tableView cellForRowAtIndexPath:cellPath].textLabel.text = [NSString stringWithFormat:@"%@ %@",dateString,rawSuffix];
    isModified = YES;
}

@end
