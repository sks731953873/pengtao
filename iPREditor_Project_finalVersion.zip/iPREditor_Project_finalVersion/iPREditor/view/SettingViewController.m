
//
//  SettingViewController.m
//  iPREditor
//
//  Created by admin on 11/19/15.
//  Copyright © 2015 admin. All rights reserved.
//

#import "SettingViewController.h"
#import "SettingViewCell.h"
#import "PlistTool.h"
#import "TextViewController.h"
#import "TimeViewController.h"
#import "CheckViewController.h"
#import "PopUpViewController.h"
#import "MultiChoiceViewController.h"
#import "ListViewConroller.h"
#import "ConfigOutListViewController.h"
#import "CustomMessTool.h"
#import "FileTool.h"
#import "AppDelegate.h"

@implementation SettingViewController

UISearchBar* searchBar;

PlistTool* plistTool;
UISearchBar* searchBar;
NSMutableArray* data;
NSMutableArray* searchData;
BOOL isSeach;
BOOL isFirstSearch;
BOOL isFirstIn;
BOOL isConfigChanged;
BOOL isKeyBoardShowed;
NSString* lastProduct;
NSMutableDictionary* dic;
NSString* currentKey;
NSUInteger currentIndex;
NSMutableDictionary* searchCache;
NSMutableDictionary* statuDic;
//NSArray* colorArray;
NSString* temPath;
NSMutableDictionary* temDic;

AppDelegate* delegate;

float currentContentSizeHeight;
float lastContentSizeHeight;
float keyBoardHeight;
float keyBoardOffset;

UIAlertController *alertController;
//BOOL isNeverShowed;
int othersFixCount;
int otherIndex;

- (void)viewDidLoad {
    
    delegate = [UIApplication sharedApplication].delegate;
    
    searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, 44)];
    searchBar.delegate = self;
    searchBar.showsCancelButton = NO;
    searchBar.placeholder = @"Search";
    
    temPath = [NSTemporaryDirectory() stringByAppendingPathComponent:@"Setting.tem"];
    
    //消除searchBar背景色
    for (UIView *view in searchBar.subviews) {
        // for before iOS7.0
        if ([view isKindOfClass:NSClassFromString(@"UISearchBarBackground")]) {
            [view removeFromSuperview];
            break;
        }
        // for later iOS7.0(include)
        if ([view isKindOfClass:NSClassFromString(@"UIView")] && view.subviews.count > 0) {
            [[view.subviews objectAtIndex:0] removeFromSuperview];
            break;
        }
    }
    
    searchBar.layer.borderWidth = 1;
    searchBar.layer.borderColor = [UIColor grayColor].CGColor;
    
    CGFloat tabBarItemHeight = 0;
    for (UIView *view in [self.tabBarController.tabBar subviews]) {
        if ([view isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            tabBarItemHeight = view.frame.size.height;
            break;
        }
    }

    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 108, SCREEN_WIDTH, SCREEN_HEIGHT - 108 - tabBarItemHeight) style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:searchBar];
    [self.view addSubview:self.tableView];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;

    plistTool = [PlistTool instance];
    
    data = [[NSMutableArray alloc] init];
    dic = [[NSMutableDictionary alloc] init];
    isSeach = NO;
    isFirstSearch = YES;
    isFirstIn = YES;
    isConfigChanged = NO;
    isKeyBoardShowed = NO;

    //isNeverShowed = NO;
    
    self.navigationItem.title = [self.fullPath lastPathComponent];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Close" style:UIBarButtonItemStylePlain target:self action:@selector(Close:)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Save" style:UIBarButtonItemStylePlain target:self action:@selector(Save:)];
    self.navigationItem.rightBarButtonItem.enabled = NO;
    
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center addObserver:self selector:@selector(keyboardDidShow:)  name:UIKeyboardDidShowNotification  object:nil];
    [center addObserver:self selector:@selector(keyboardDidHide:)  name:UIKeyboardWillHideNotification object:nil];
    
//    //转为横屏
//    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])) {
//        
//        searchBar.frame = CGRectMake(0, 30, SCREEN_WIDTH, 44);
//        self.tableView.frame = CGRectMake(0, 74, SCREEN_WIDTH, SCREEN_HEIGHT - 74 - tabBarItemHeight);
//        
//    }
//    else {
//        
//        searchBar.frame = CGRectMake(0, 64, SCREEN_WIDTH, 44);
//        self.tableView.frame = CGRectMake(0, 108, SCREEN_WIDTH, SCREEN_HEIGHT - 108 - tabBarItemHeight);
//        
//    }
    //刚开始是0
    currentContentSizeHeight = self.tableView.contentSize.height;
    lastContentSizeHeight = currentContentSizeHeight;
    keyBoardHeight = -1;
    keyBoardOffset = 0;
    
}

//键盘弹出
- (void)keyboardDidShow: (NSNotification *)aNotification
{
    isKeyBoardShowed = YES;
 
    CGFloat tabBarItemHeight = 0;
    for (UIView *view in [self.tabBarController.tabBar subviews]) {
        if ([view isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            tabBarItemHeight = view.frame.size.height;
            break;
        }
    }
    NSDictionary *userInfo = [aNotification userInfo];
    NSValue *aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    float height = keyboardRect.size.height;
    
    //刚开始
    if (keyBoardHeight == -1) {
        
        keyBoardOffset = 0;
    }
    else {
     
        keyBoardOffset = height - keyBoardHeight;
    }
    keyBoardHeight = height;

}
//键盘消失
- (void)keyboardDidHide: (NSNotification *)aNotification
{
    
    isKeyBoardShowed = NO;
    CGFloat tabBarItemHeight = 0;
    for (UIView *view in [self.tabBarController.tabBar subviews]) {
        if ([view isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            tabBarItemHeight = view.frame.size.height;
            break;
        }
    }
    NSDictionary *userInfo = [aNotification userInfo];
    NSValue *aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    float height = keyboardRect.size.height;
    
    CGSize size={SCREEN_WIDTH,self.tableView.contentSize.height - height + tabBarItemHeight};
    self.tableView.contentSize = size;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {

    if (isKeyBoardShowed) {
        
        CGFloat tabBarItemHeight = 0;
        for (UIView *view in [self.tabBarController.tabBar subviews]) {
            if ([view isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
                tabBarItemHeight = view.frame.size.height;
                break;
            }
        }

        if (lastContentSizeHeight != self.tableView.contentSize.height) {
            
            CGSize size={SCREEN_WIDTH,self.tableView.contentSize.height + keyBoardHeight - tabBarItemHeight};
            self.tableView.contentSize = size;
            lastContentSizeHeight = self.tableView.contentSize.height;
        }
        
    }
}

//取消searchbar背景色
- (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size
{
   CGRect rect = CGRectMake(0, 0, size.width, size.height);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

- (void)loadOthers {
    otherIndex = -1;
    
    for (int i = 0; i < [data count]; i++) {
        
        if ([[data objectAtIndex:i] nodeLevel] == 0 && [[[data objectAtIndex:i] keyLabel] isEqualToString:@"Others"]) {
            
            otherIndex = i;
            break;
        }
    }
    
    if (otherIndex != -1) {
        
        if ([[data objectAtIndex:otherIndex] isExpanded] == YES) {
            
            int count = (int)[[[data objectAtIndex:otherIndex] childNodes] count] - othersFixCount;
            for (int i = 1; i <= count; i++) {
                
                [[[data objectAtIndex:otherIndex] childNodes] removeLastObject];
                [data removeObjectAtIndex:otherIndex + othersFixCount + 1];
            }
            
            [self findOthers:temDic parentKey:NULL];
            
            //插入点
            int insertPosition = otherIndex + othersFixCount + 1;
            
            int extraOtherCount = (int)[[[data objectAtIndex:otherIndex] childNodes] count] - othersFixCount;
            
            for (int i = 1; i <= extraOtherCount; i++) {
                
                [data insertObject:[[[data objectAtIndex:otherIndex] childNodes] objectAtIndex:othersFixCount+i-1] atIndex:insertPosition];
                insertPosition++;
            }
        }
        else {
            
            int count = (int)[[[data objectAtIndex:otherIndex] childNodes] count] - othersFixCount;
            
            for (int i = 1; i <= count; i++) {
                
                [[[data objectAtIndex:otherIndex] childNodes] removeLastObject];
            }
            [self findOthers:temDic parentKey:NULL];
        }
    }
}

//tab切换过来的时候，会执行
- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:NO];
    CGFloat tabBarItemHeight = 0;
    for (UIView *view in [self.tabBarController.tabBar subviews]) {
        if ([view isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            tabBarItemHeight = view.frame.size.height;
            break;
        }
    }
    //转为横屏
    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])) {

        //iPad
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
            searchBar.frame = CGRectMake(0, 64, SCREEN_WIDTH, 44);
            self.tableView.frame = CGRectMake(0, 108, SCREEN_WIDTH, SCREEN_HEIGHT - 108 - tabBarItemHeight);
        }
        //iPhone
        else {
            searchBar.frame = CGRectMake(0, 30, SCREEN_WIDTH, 44);
            self.tableView.frame = CGRectMake(0, 74, SCREEN_WIDTH, SCREEN_HEIGHT - 74 - tabBarItemHeight);
        }
        
    }
    else {
        
        searchBar.frame = CGRectMake(0, 64, SCREEN_WIDTH, 44);
        self.tableView.frame = CGRectMake(0, 108, SCREEN_WIDTH, SCREEN_HEIGHT - 108 - tabBarItemHeight);
        
    }
    //data => String => Write to File => Dictionary
    //[[[NSString alloc] initWithData:delegate.rawData encoding:NSUTF8StringEncoding] writeToFile:temPath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    
    temDic = [NSMutableDictionary dictionaryWithContentsOfFile:delegate.temFilePath];
    
    if (delegate.isChanged) {
        
        self.navigationItem.rightBarButtonItem.enabled = YES;
    }
    
    if (!isFirstIn) {
        
        NSString* product = [CustomMessTool getProduct:@"FactoryDocControl.PRODUCT" inDictionary:temDic];
        
        if (product == nil) {
            
            product = @"Default";
        }
        else {
            product = [product stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            //配制文件不存在
            if ([delegate.fileTool isExist:[delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"Config/%@_config.plist",product]]] == NO) {
                
                product = @"Default";
            }
        }
        
        if ([lastProduct isEqualToString:product] == NO) {
            
            isConfigChanged = YES;
            isFirstSearch = YES;
            lastProduct = product;
            [statuDic removeAllObjects];
            [data removeAllObjects];
            [self fillData:[NSString stringWithFormat:@"%@_config.plist",product]];
            
            otherIndex = -1;
            
            for (int i = 0; i < [data count]; i++) {
                
                if ([[data objectAtIndex:i] nodeLevel] == 0 && [[[data objectAtIndex:i] keyLabel] isEqualToString:@"Others"]) {
                    
                    otherIndex = i;
                    break;
                }
            }
            //othersFixCount = (int)[[[data lastObject] childNodes] count];
            othersFixCount = (int)[[[data objectAtIndex:otherIndex] childNodes] count];
            
            [self findOthers:temDic parentKey:NULL];
        }
        else {
            
            //非搜索状态下
            if (isSeach == NO) {
                
                [self loadOthers];
            }
            //搜索状态下
            else {
                
                
            }
            
        }
    }
    else {
        
        isFirstIn = NO;
        
        //获取产品
        NSString* product = [CustomMessTool getProduct:@"FactoryDocControl.PRODUCT" inDictionary:temDic];
        if (product == nil) {
            
            product = @"Default";
        }
        else {
            product = [product stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            //配制文件不存在
            if ([delegate.fileTool isExist:[delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"Config/%@_config.plist",product]]] == NO) {
                
                product = @"Default";
            }
        }
        
        lastProduct = product;
        
        [self fillData:[NSString stringWithFormat:@"%@_config.plist",product]];
        
        otherIndex = -1;
        
        for (int i = 0; i < [data count]; i++) {
            
            if ([[data objectAtIndex:i] nodeLevel] == 0 && [[[data objectAtIndex:i] keyLabel] isEqualToString:@"Others"]) {
                
                otherIndex = i;
                break;
            }
        }
        
        //othersFixCount = (int)[[[data lastObject] childNodes] count];
        othersFixCount = (int)[[[data objectAtIndex:otherIndex] childNodes] count];
        
        [self findOthers:temDic parentKey:NULL];
        
    }
    
    [self.tableView reloadData];

}


- (void)viewDidAppear:(BOOL)animated {
 
    if (temDic == NULL) {
        
        alertController = [UIAlertController alertControllerWithTitle:@"Hint" message:@"This is not a formal plist file.\nEditing is not supported.       " preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction* cancelAlert = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction* action) {
            
            [self dismissViewControllerAnimated:YES completion:nil];
        }];

        [alertController addAction:cancelAlert];
        [self.parentViewController presentViewController:alertController animated:YES completion:^(void) {
            
            NSThread* thread = [[NSThread alloc] initWithTarget:self selector:@selector(showSeconds) object:nil];
            [thread start];
            
        }];
    }
    
}

-(void)showSeconds {
    
    int i = 5;
    while (i > 0) {
        
        [self performSelectorOnMainThread:@selector(updateUI:) withObject:[NSNumber numberWithInteger:i] waitUntilDone:YES];
        
        [NSThread sleepForTimeInterval:1];
        
        i--;
    }
}

-(void)updateUI: (NSNumber*)count {
    
    alertController.message = [NSString stringWithFormat:@"This is not a formal plist file.\nEditing is not supported.\n%d",[count intValue]];
    
    if ([count intValue] == 1) {
        
        [self dismissViewControllerAnimated:YES completion:nil];
        //[self d]
        //alertController.
    }
}



- (void)Close: (UIBarButtonItem*)sender {
    
    //保存
    if (delegate.isChanged) {
        
        UIAlertController* alertController = [UIAlertController alertControllerWithTitle:@"File Changed" message:@"What do you wanna do?" preferredStyle:UIAlertControllerStyleAlert];
      
        UIAlertAction* overWriteAction = [UIAlertAction actionWithTitle:@"OverWrite" style:UIAlertActionStyleDefault handler:^(UIAlertAction*  action) {
            
            [delegate.fileTool write:[NSString stringWithContentsOfFile:delegate.temFilePath encoding:NSUTF8StringEncoding error:nil] at:self.fullPath append:NO];
            delegate.isChanged = NO;
            [delegate.navi popViewControllerAnimated:YES];
        }];
        UIAlertAction* discardAction = [UIAlertAction actionWithTitle:@"Discard change" style:UIAlertActionStyleDefault handler:^(UIAlertAction* action) {
            
            delegate.isChanged = NO;
            [delegate.navi popViewControllerAnimated:YES];
        }];
        UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
        
        [alertController addAction:overWriteAction];
        [alertController addAction:discardAction];
        [alertController addAction:cancelAction];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
    }
    else {
        
        [delegate.navi popViewControllerAnimated:YES];
    }
}

- (void)Save: (UIBarButtonItem*)sender {
    
    //保存
    if (delegate.isChanged) {
    
        [delegate.fileTool write:[NSString stringWithContentsOfFile:delegate.temFilePath encoding:NSUTF8StringEncoding error:nil] at:self.fullPath append:NO];
        delegate.isChanged = NO;
        
        self.navigationItem.rightBarButtonItem.enabled = NO;
    }
}

- (void)fillData: (NSString*)configFile {
    
    NSString* plistPath = [delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"Config/%@",configFile]];
    NSMutableDictionary* dictionary = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    id  nodes = [plistTool valueForKey:@"Nodes" inDictionary:dictionary recursion:NO];
    [self fillArray:nodes];
    
}

- (void)fillArray: (id)nodes {
    
    int nodeLevel = 0;
    for (id node in nodes) {
        TreeNode* tNode = [[TreeNode alloc] init];
        tNode.keyLabel = [plistTool valueForKey:KEYLABEL inDictionary:node recursion:NO];
        tNode.keyPath = [plistTool valueForKey:KEYPATH inDictionary:node recursion:NO];
        tNode.extra = [plistTool valueForKey:CHOICE inDictionary:node recursion:NO];
        tNode.control = [[plistTool valueForKey:CONTROL_T inDictionary:node recursion:NO] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        tNode.nodeLevel = nodeLevel;
        tNode.isExpanded = NO;
        //存在子结点
        if ([tNode.control isEqualToString:PARENTNODE]) {
            [self fillChildArray:[plistTool valueForKey:CHILDNODES inDictionary:node recursion:NO] inThe: tNode level:nodeLevel+1];
        }
        [data addObject:tNode];
        
    }
}

- (void)fillChildArray: (id)nodes inThe: (TreeNode*)tNode level:(int) nodeLevel {
    tNode.childNodes = [[NSMutableArray alloc] init];
    for (id node in nodes) {
        TreeNode* cNode = [[TreeNode alloc] init];
        cNode.keyLabel = [plistTool valueForKey:KEYLABEL inDictionary:node recursion:NO];
        cNode.keyPath = [plistTool valueForKey:KEYPATH inDictionary:node recursion:NO];
        cNode.control = [plistTool valueForKey:CONTROL_T inDictionary:node recursion:NO];
        cNode.extra = [plistTool valueForKey:CHOICE inDictionary:node recursion:NO];
        cNode.nodeLevel = nodeLevel;
        cNode.isExpanded = NO;
        
        [tNode.childNodes addObject:cNode];
        
        if ([tNode.control isEqualToString:PARENTNODE]) {
            
            [self fillChildArray:[plistTool valueForKey:CHILDNODES inDictionary:node recursion:NO] inThe:cNode level:nodeLevel+1];
        }
    }
}

- (void)findOthers: (id)dictionary parentKey: (NSString*)pKey {
    
    for (NSString* key in [dictionary allKeys]) {
        
        id node = [dictionary objectForKey:key];
        
        //node是一个dictionary,表明还可再分
        if ([node respondsToSelector:@selector(objectForKey:)]) {
            
            if (pKey != NULL) {
                
                [self findOthers:node parentKey:[NSString stringWithFormat:@"%@.%@",pKey,key]];
            }
            else {
                
                [self findOthers:node parentKey:key];
            }
        }
        //否则就是算array也不分
        else {
            NSString* keyPath;
            if (pKey != NULL) {
                keyPath = [NSString stringWithFormat:@"%@.%@",pKey,key];
            }
            else {
                keyPath = key;
            }
            
            if ([self keyPathInConfigFile:keyPath dictionary:data] == NO) {
                
                TreeNode* tNode = [[TreeNode alloc] init];
                tNode.nodeLevel = 1;
                tNode.keyLabel = [[keyPath componentsSeparatedByString:@"."] lastObject];
                tNode.keyPath = keyPath;
                
                NSString* type = [[node class] description];
                
                if ([BLN_SET containsObject:type]) {
                    tNode.control = CHECK;
                }
                else if ([STR_SET containsObject:type]) {
                    tNode.control = TEXT;
                }
                else if ([NUM_SET containsObject:type]) {
                    tNode.control = INTEGER;
                }
                else if ([ARR_SET containsObject:type]) {
                    tNode.control = CONFIG_OUT_LIST;
                    tNode.extra = node;
                }
                else if ([DIC_SET containsObject:type]) {
                    tNode.control = DICTIONARY_STR;
                }
                //[[[data lastObject] childNodes] addObject:tNode];
                [[[data objectAtIndex:otherIndex] childNodes] addObject:tNode];
            }
        }
    }
}

- (BOOL)keyPathInConfigFile: (NSString*)keyPath dictionary: (id)dictionary {
    
    for (id node in dictionary) {
        
        if ([[node keyPath] isEqualToString:keyPath] && [[node control] isEqualToString:PARENTNODE] == NO) {
            
            return YES;
        }
        else {
            if ([[node control] isEqualToString:PARENTNODE]) {
                
                BOOL result = [self keyPathInConfigFile:keyPath dictionary:[node childNodes]];
                
                if (result) {
                    return YES;
                }
            }
        }
    }
    return NO;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (isSeach == NO) {
        return data.count;
    }
    return searchData.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* cellId = @"cell_cell";
    
    SettingViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    
    if (cell == nil) {
        cell = [[SettingViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    else {
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.subKeyLabel.text = @"";
        cell.subTypeLabel.text = @"";
        [cell.arrowImage setImage:nil];
    }
    if (isSeach == NO) {
        cell.treeNode = [data objectAtIndex:indexPath.row];
    }
    else {
        cell.treeNode = [searchData objectAtIndex:indexPath.row];
    }
    
    if (isSeach == NO) {
        cell.mainkeyLabel.text = [[data objectAtIndex:indexPath.row] keyLabel];
    }
    else {
        cell.mainkeyLabel.text = [[searchData objectAtIndex:indexPath.row] keyLabel];
    }
    
    cell.backgroundColor = [COLOR_ARRAY objectAtIndex:cell.treeNode.nodeLevel%COLOR_ARRAY.count];//RGBACOLOR(244, 164, 96, 1);
    cell.imageLine.image = [UIImage imageNamed:@"line.png"];
    
    [cell mainkeyLabel].font = FONT_ARRAY[cell.treeNode.nodeLevel];
    [cell subKeyLabel].font = SUB_FONT_ARRAY[cell.treeNode.nodeLevel];
    [cell subTypeLabel].font = SUB_FONT_ARRAY[cell.treeNode.nodeLevel];
    
    if (cell.treeNode.isExpanded == NO) {
        
        [cell.arrowImage setImage:[UIImage imageNamed:@"arrow_right_32px_vectorized.png"]];
        
        if (cell.treeNode.nodeLevel != 0) {
            
            [cell.arrowImage setImage:[UIImage imageNamed:@"keyboard_arrow_right_32px.png"]];
        }
    }
    else {

        [cell.arrowImage setImage:[UIImage imageNamed:@"arrow_down_32px_vectorized.png"]];
        
        if (cell.treeNode.nodeLevel != 0) {
            
            [cell.arrowImage setImage:[UIImage imageNamed:@"keyboard_arrow_down_32px.png"]];
        }
    }
    if ([cell.treeNode.control isEqualToString:PARENTNODE] == NO) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.backgroundColor = [UIColor clearColor];
        cell.bgImage.image = NULL;
        id node = temDic;
        NSString* subValue = @"";
        NSArray* tem = [self getKeyPathValue:cell.treeNode.keyPath control:cell.treeNode.control inDictionary:node];
        subValue = tem[0];
        [cell.arrowImage setImage:nil];
        cell.subKeyLabel.text = subValue;
        cell.subTypeLabel.text = tem[1];
    }
    [cell setIndention];
    //如果当前是横屏
    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])) {
        
        [cell setNeedsDisplay];
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 54;
}

- (void)adjustHeight:(NSIndexPath *)indexPath sourceData: (id)data {
    //1.得到选中行之前的高度
    float top = 44;//64 + self.tableView.tableHeaderView.frame.size.height;
    for (int i = 0; i < indexPath.row; i++) {
        top = top + [self.tableView cellForRowAtIndexPath:indexPath].frame.size.height;
    }
    if (self.tableView.contentOffset.y > 0) {
        
        top = top - 64 - self.tableView.contentOffset.y;
    }
    else {
        
        top = top - (64 + self.tableView.contentOffset.y);
    }
    //NSLog(@"top:%f",top);
    //2.选中行的高度
    float selected = [self.tableView cellForRowAtIndexPath:indexPath].frame.size.height;
    //NSLog(@"selected:%f",selected);
    //3.得到选中行之后的高度
    float bottom = self.tableView.frame.size.height - top - selected - 64 - 53;
    //NSLog(@"bottom:%f",bottom);
    //4.当前的contentSize
    //float currentContentHeight = self.tableView.contentSize.height;
    // NSLog(@"currentContentHeight:%f",currentContentHeight);
    //5.插入子结点行
    currentIndex = indexPath.row + 1;
    int lastCurrentIndex = (int)currentIndex;
    if (isSeach == YES) {
    
        for (id node in data) {
            
            [self insertSearchChildNode:node];
        }
    }
    else {
        for (id node in [[data objectAtIndex:indexPath.row] childNodes]) {
            [self insertChildNode:node forParentNode:data];
        }
    }
    int insertChildNodeSum = (int)currentIndex - lastCurrentIndex - 1;

    //6.得到所有子结点行的高度
    float childHeightSum = insertChildNodeSum * 53;
    
    if (childHeightSum > bottom) {
        
        [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
    }
    
}
- (void)insertSearchChildNode: (id)node {
    
    [searchData insertObject:node atIndex:currentIndex];
    NSIndexPath* nsPath = [NSIndexPath indexPathForRow:currentIndex inSection:0];
    [self.tableView beginUpdates];
    [self.tableView insertRowsAtIndexPaths:@[nsPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    [self.tableView endUpdates];
    currentIndex = currentIndex + 1;
    
    if ([searchCache objectForKey:[node keyLabel]]) {
        
        //需要展开
        if ([node isExpanded]) {
            for (id child in [searchCache objectForKey:[node keyLabel]]) {
                
                [self insertSearchChildNode:child];
            }
            
        }
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    [searchBar resignFirstResponder];
    
    SettingViewCell* cell = (SettingViewCell*)[self.tableView cellForRowAtIndexPath:indexPath];
    
    if (isSeach == YES) {
        
        if (searchCache == nil) {
            searchCache = [[NSMutableDictionary alloc] init];
        }
        
        //如果点击的是ParentNode
        if ([cell.treeNode.control isEqualToString:PARENTNODE]) {
            
            NSMutableArray* child = [searchCache objectForKey:cell.treeNode.keyLabel];
            //当前是展开的，需要收
            if (cell.treeNode.isExpanded) {

                [cell.arrowImage setImage:[UIImage imageNamed:@"arrow_right_32px_vectorized.png"]];
                
                if (cell.treeNode.nodeLevel != 0) {
                    
                    [cell.arrowImage setImage:[UIImage imageNamed:@"keyboard_arrow_right_32px.png"]];
                }
                int searchChildCount = 0;
                for (id node in [searchCache objectForKey:cell.treeNode.keyLabel]) {
                    
                    searchChildCount = searchChildCount + (int)[self childSearchCount:node];
                }
                for (int i = 1; i <= searchChildCount; i++) {
                    [searchData removeObjectAtIndex:indexPath.row + 1];
                    NSIndexPath* nsPath = [NSIndexPath indexPathForRow:indexPath.row + 1 inSection:indexPath.section];
                    [self.tableView beginUpdates];
                    [self.tableView deleteRowsAtIndexPaths:@[nsPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                    [self.tableView endUpdates];
                }
            }
            //当前是收的，需要展开
            else {

                [cell.arrowImage setImage:[UIImage imageNamed:@"arrow_down_32px_vectorized.png"]];
                
                if (cell.treeNode.nodeLevel != 0) {
                    
                    [cell.arrowImage setImage:[UIImage imageNamed:@"keyboard_arrow_down_32px.png"]];
                }
                [self adjustHeight:indexPath sourceData:child];
            }
            cell.treeNode.isExpanded = !cell.treeNode.isExpanded;
        }
        //点击的是非ParentNode
        else {
            
            [self subPage:cell];
        }
        
    }
    //非搜索状态
    else {
        if ([[[data objectAtIndex:indexPath.row] control] isEqualToString:PARENTNODE]) {
            //展开
            if (cell.treeNode.isExpanded == NO) {

                [cell.arrowImage setImage:[UIImage imageNamed:@"arrow_down_32px_vectorized.png"]];
                
                if (cell.treeNode.nodeLevel != 0) {
                    
                    [cell.arrowImage setImage:[UIImage imageNamed:@"keyboard_arrow_down_32px.png"]];
                }
                [self adjustHeight:indexPath sourceData:data];
            }
            //收起来
            else {
                
                [cell.arrowImage setImage:[UIImage imageNamed:@"arrow_right_32px_vectorized.png"]];
                
                if (cell.treeNode.nodeLevel != 0) {
                    
                    [cell.arrowImage setImage:[UIImage imageNamed:@"keyboard_arrow_right_32px.png"]];
                }
                int index = (int)indexPath.row + 1;
                int count = 0;
                NSMutableArray* arr = [dic objectForKey:cell.treeNode.keyLabel];
                if (arr == nil) {
                    arr = [[NSMutableArray alloc] init];
                    [dic setObject:arr forKey:cell.treeNode.keyLabel];
                }
                [[dic objectForKey:cell.treeNode.keyLabel] removeAllObjects];
                currentKey = cell.treeNode.keyLabel;
                
                for (id node in [[data objectAtIndex:indexPath.row] childNodes]) {
                    count = count + (int)[self childCount:node];
                }
                
                for (int i = 1; i <= count; i++) {
                    
                    [data removeObjectAtIndex:index];
                    NSIndexPath* nsPath = [NSIndexPath indexPathForRow:index inSection:indexPath.section];
                    [self.tableView beginUpdates];
                    [self.tableView deleteRowsAtIndexPaths:@[nsPath] withRowAnimation:UITableViewRowAnimationFade];
                    [self.tableView endUpdates];
                }
            }
            //刚开始反转成yes
            cell.treeNode.isExpanded = !cell.treeNode.isExpanded;
        }
        //点击的是非ParentNode
        else {
            [self subPage:cell];
        }
    }
    currentContentSizeHeight = self.tableView.contentSize.height;
}

- (void)subPage: (SettingViewCell*)cell {
    
    UIViewController* view = nil;
    
    if ([cell.treeNode.control isEqualToString:TEXT] || [cell.treeNode.control isEqualToString:INTEGER]){
        
        view = [[TextViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [view setValue:cell.treeNode.keyLabel forKey:@"keyLabel"];
        [view setValue:cell.treeNode.keyPath forKey:@"keyPath"];
        [view setValue:cell.subKeyLabel.text forKey:@"keyValue"];
        [view setValue:cell.treeNode.control forKey:@"control"];
        [view setValue:temDic forKey:@"dictionary"];
       
    }
    //Time类型
    else if ([cell.treeNode.control isEqualToString:TIME]) {
        
        view = [[TimeViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [view setValue:cell.treeNode.keyLabel forKey:@"keyLabel"];
        [view setValue:cell.treeNode.keyPath forKey:@"keyPath"];
        [view setValue:cell.subKeyLabel.text forKey:@"keyValue"];
        [view setValue:temDic forKey:@"dictionary"];

    }
    //Check类型
    else if ([cell.treeNode.control isEqualToString:CHECK]) {
        
        view = [[CheckViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [view setValue:cell.treeNode.keyLabel forKey:@"keyLabel"];
        [view setValue:cell.treeNode.keyPath forKey:@"keyPath"];
        [view setValue:cell.subKeyLabel.text forKey:@"keyValue"];
        [view setValue:temDic forKey:@"dictionary"];
        
    }
    //PopUp类型
    else if ([cell.treeNode.control isEqualToString:POPUP]) {
        
        view = [[PopUpViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [view setValue:cell.treeNode.keyLabel forKey:@"keyLabel"];
        [view setValue:cell.treeNode.keyPath forKey:@"keyPath"];
        [view setValue:cell.subKeyLabel.text forKey:@"keyValue"];
        [view setValue:[cell.treeNode.extra mutableCopy] forKey:@"choice"];
        [view setValue:temDic forKey:@"dictionary"];
    }
    //MultiChoice类型
    else if ([cell.treeNode.control isEqualToString:MULTICHOICE]) {
        
        view = [[MultiChoiceViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [view setValue:cell.treeNode.keyLabel forKey:@"keyLabel"];
        [view setValue:cell.treeNode.keyPath forKey:@"keyPath"];
        [view setValue:cell.subKeyLabel.text forKey:@"keyValue"];
        [view setValue:[cell.treeNode.extra mutableCopy] forKey:@"choice"];
        [view setValue:temDic forKey:@"dictionary"];
    }
    //List类型，重点关注List，因为有的子结点是array，有的子结点是array中又包含array
    else if ([cell.treeNode.control isEqualToString:LIST]) {
        
        view = [[ListViewConroller alloc] initWithStyle:UITableViewStyleGrouped];
        NSArray* valueAndType = [self getKeyPathValue:cell.treeNode.keyPath control:cell.treeNode.control inDictionary:temDic];
        
        [view setValue:cell.treeNode.keyLabel forKey:@"keyLabel"];
        [view setValue:cell.treeNode.keyPath forKey:@"keyPath"];
        [view setValue:cell.subKeyLabel.text forKey:@"keyValue"];
        [view setValue:valueAndType[1] forKey:@"type"];
        [view setValue:temDic forKey:@"dictionary"];
    }
    //Others分组中的Array类型
    else if ([cell.treeNode.control isEqualToString:CONFIG_OUT_LIST]) {
        
        view = [[ConfigOutListViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [view setValue:cell.treeNode.keyLabel forKey:@"keyLabel"];
        [view setValue:cell.treeNode.keyPath forKey:@"keyPath"];
        
        id configTemDic = temDic;
        
        for (NSString* key in [cell.treeNode.keyPath componentsSeparatedByString:@"."]) {
        
            id node = [configTemDic objectForKey:key];
        
            //Node is array
            if ([node respondsToSelector:@selector(objectAtIndex:)]) {
        
                cell.treeNode.extra = node;
                break;
            }
            //Dictionary
            else if ([node respondsToSelector:@selector(objectForKey:)]) {
                
                configTemDic = node;
                
            }
        }
        
        [view setValue:cell.treeNode.extra forKey:@"extra"];
        [view setValue:temDic forKey:@"dictionary"];
       
    }
    if (view != nil) {
        
        [self.navigationController pushViewController:view animated:YES];
    }
    
}

- (NSMutableArray*)findSearchChildArray: (id)node with: (NSString*)keyLabel {
    
    if ([[node control] isEqualToString:PARENTNODE]) {
        
        if ([[node keyLabel] isEqualToString:keyLabel]) {
            
            return [[node childNodes] mutableCopy];
        }
        for (id tem in [node childNodes]) {
            
            NSMutableArray* result =  [self findSearchChildArray:tem with:keyLabel];
            
            if (result != nil) {
                return result;
            }
        }
    }
    return nil;
}

- (void)insertChildNode: (id)node forParentNode: (id)parentNode {
    
    NSIndexPath* path = [NSIndexPath indexPathForRow:currentIndex inSection:0];
    [parentNode insertObject:node atIndex:currentIndex];
    [self.tableView beginUpdates];
    [self.tableView insertRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationFade];
    [self.tableView endUpdates];
    
    currentIndex = currentIndex + 1;
    //是parent且，展开
    if ([[node control] isEqualToString:PARENTNODE] && [node isExpanded] == YES) {
        
        for (id chilNode in [node childNodes]) {
            
            [self insertChildNode:chilNode forParentNode:parentNode];
        }
    }
}

- (NSUInteger)childSearchCount: (id)node {
    
    int sum = 1;
    
    if ([[node control] isEqualToString:PARENTNODE]) {
        
        
        if ([searchCache objectForKey:[node keyLabel]]) {
            
            if ([node isExpanded]) {
                
                for (id child in [searchCache objectForKey:[node keyLabel]]) {
                    
                    sum = sum + (int)[self childSearchCount:child];
                }
            }
        }
    }
    return sum;
}

- (NSUInteger)childCount: (id)node  {
    [[dic objectForKey:currentKey] addObject:node];
    
    int sum = 0;
    if ([[node control] isEqualToString:PARENTNODE]) {
        
        if ([node isExpanded] == YES) {
            for (id childNode in [node childNodes]) {
                sum = sum + (int)[self childCount:childNode];
            }
            return 1 + sum;
        }
        else {
            return 1;
        }
    }
    else {
        return 1;
    }
    return 0;
}

#pragma mark - UISearchBar

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    
    searchBar.showsCancelButton = YES;
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar {
    
    searchBar.showsCancelButton = NO;
}

//文本变化时
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    
    isSeach = YES;
    
    if (searchData == nil) {
        searchData = [[NSMutableArray alloc] init];
    }
    
    if (statuDic == nil) {
        statuDic = [[NSMutableDictionary alloc] init];
    }
    
    [searchData removeAllObjects];
    for (id node in data) {

        if ([[node control] isEqualToString:PARENTNODE] == YES && [node nodeLevel] == 0) {
            [self fillSearchData:node with:searchText];
        }
    }
    isFirstSearch = NO;
    
    if (searchCache == nil) {
        searchCache = [[NSMutableDictionary alloc] init];
    }
    [searchCache removeAllObjects];
    
    NSMutableArray* searchChildArray = [[NSMutableArray alloc] init];
    
    int index = 0;
    
    NSMutableArray* stack = [[NSMutableArray alloc] init];
    int topChildCount = 0;

    while (index < searchData.count) {
        
        //当前结点
        TreeNode* currentNode = [searchData objectAtIndex:index];
        
        //当前结点是ParentNode
        if ([currentNode.control isEqualToString:PARENTNODE]) {
            
            if (stack.count == 0) {
                [searchCache setObject:[[NSMutableArray alloc] init] forKey:currentNode.keyLabel];
                [stack addObject:currentNode];
                index = index + 1;
                continue;
            }
            
            //cache如果已经存在了
            if ([searchCache objectForKey:currentNode.keyLabel]) {
                
                if (currentNode.isExpanded == NO) {
                    
                    [[stack lastObject] addObject:currentNode];
                    index = index + 1;
                }
                else {
                    
                    [[stack lastObject] addObject:currentNode];
                    index = index + (int)[[searchCache objectForKey:currentNode.keyLabel] count] + 1;
                }
            }
            //cache不存在
            else {
                [searchCache setObject:[[NSMutableArray alloc] init] forKey:currentNode.keyLabel];
                //当前结点Level与stack一样
                //结点同级
                if (currentNode.nodeLevel == [[stack lastObject] nodeLevel]) {
                    
                    //如果当前stack中没有子结点,需要自己添加
                    if (topChildCount == 0) {
                        
                        for (id node in data) {
                            if ([[node control] isEqualToString:PARENTNODE]) {
                                searchChildArray = [self findSearchChildArray:node with:[[stack lastObject] keyLabel]];
                                if (searchChildArray != nil) {
                                    break;
                                }
                            }
                        }
                        [searchCache setObject:searchChildArray forKey:[[stack lastObject] keyLabel]];
                        ((TreeNode*)[stack lastObject]).isExpanded = NO;
                        
                    }
                    //否则，改变当前stack顶元素状态
                    else {
                        
                        ((TreeNode*)[stack lastObject]).isExpanded = YES;
                    }
                    
                    [stack removeLastObject];
                    
                    if (stack.count != 0) {
                        
                        [[searchCache objectForKey:[[stack lastObject] keyLabel]] addObject:currentNode];
                    }
                    
                    [stack addObject:currentNode];
                    
                    topChildCount = 0;
                }
                //当前结点Level是上一层
                //当前结点级数高于stack顶元素
                else if (currentNode.nodeLevel + 1 == [[stack lastObject] nodeLevel]) {
                    
                    if (topChildCount == 0) {
                        
                        for (id node in data) {
                            if ([[node control] isEqualToString:PARENTNODE]) {
                                searchChildArray = [self findSearchChildArray:node with:[[stack lastObject] keyLabel]];
                                if (searchChildArray != nil) {
                                    break;
                                }
                            }
                        }
                        [searchCache setObject:searchChildArray forKey:[[stack lastObject] keyLabel]];
                        ((TreeNode*)[stack lastObject]).isExpanded = NO;
            
                    }
                    else {
                        
                        ((TreeNode*)[stack lastObject]).isExpanded = YES;
                    }
                    
                    [stack removeAllObjects];
                    
                    [stack addObject:currentNode];
                    topChildCount = 0;
                    
                }
                //当前结点Level与stack不一样
                //当前结点是stack顶元素的子结点
                else {
                    //加入
                    [[searchCache objectForKey:[[stack lastObject] keyLabel]] addObject:currentNode];
                    ((TreeNode*)[stack lastObject]).isExpanded = YES;
                    [stack addObject:currentNode];
                    topChildCount = 0;
                }
                index = index + 1;
            }
        }
        //当前结点是非ParentNode
        else {
            
            [[searchCache objectForKey:[[stack lastObject] keyLabel]] addObject:currentNode];
            topChildCount = topChildCount + 1;
            ((TreeNode*)[stack lastObject]).isExpanded = YES;
            index = index + 1;
        }
    }
    
    if (searchData.count != 0) {
        
        if (topChildCount == 0) {
            for (id node in data) {
                if ([[node control] isEqualToString:PARENTNODE]) {
                    searchChildArray = [self findSearchChildArray:node with:[[stack lastObject] keyLabel]];
                    if (searchChildArray != nil) {
                        break;
                    }
                }
            }
            [searchCache setObject:searchChildArray forKey:[[stack lastObject] keyLabel]];
            ((TreeNode*)[stack lastObject]).isExpanded = NO;
        }
        else {
            ((TreeNode*)[stack lastObject]).isExpanded = YES;
        }
    }
    [self.tableView reloadData];
    currentContentSizeHeight = self.tableView.contentSize.height;
    
}
- (void)fillSearchData: (id)node with: (NSString*)searchText {
    
    [searchData addObject:node];
    if ([[node control] isEqualToString:PARENTNODE]) {
        
        //保存ParentNode状态
        if (isFirstSearch) {
            [statuDic setValue:[NSString stringWithFormat:@"%@",[node isExpanded] ? @"YES" : @"NO"] forKey:[node keyLabel]];
        }
        
        for (id childNode in [node childNodes]) {
            [self fillSearchData:childNode with:searchText];
        }
    }
    else {
        //得到node的keyPath值
        id tem = temDic;
        NSString* subValue = [self getKeyPathValue:[node keyPath] control:[node control] inDictionary:tem][0];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"keyLabel CONTAINS[c] %@ OR keyPath CONTAINS[c] %@",searchText,searchText];
        if ([predicate evaluateWithObject:node] == NO) {
            predicate = [NSPredicate predicateWithFormat:@"SELF CONTAINS[c] %@",searchText];
            if ([predicate evaluateWithObject:subValue] == NO) {
                [searchData removeLastObject];
            }
        }
        return;
    }
    if (node == [searchData lastObject]) {
        NSPredicate *predicateTemplate = [NSPredicate predicateWithFormat:@"keyLabel CONTAINS[c] %@ OR keyPath  CONTAINS[c] %@",searchText,searchText];
        if ([predicateTemplate evaluateWithObject:node] == NO) {
            [searchData removeLastObject];
        }
    }
}

- (NSArray*)getKeyPathValue: (NSString*)keyPath control: (NSString*)control inDictionary: (id)dictionary {
    
    id node = dictionary;
    
    for (NSString* str in [keyPath componentsSeparatedByString:@"."]) {
    
        node = [plistTool valueForKey:str inDictionary:node recursion:NO];
    }
    NSString* subValue = @"";
    NSString* subType = @"";
    //Check类型
    if ([control isEqualToString:CHECK]) {

        if (node != NULL) {
            if ([node integerValue] == 0) {
                subValue = FALSE_STR;
            } else if ([node integerValue] == 1) {
                subValue = TRUE_STR;
            }
        }
        subType = BOOLEAN_STR;
    }
    //MultiChoice类型
    else if ([control isEqualToString:MULTICHOICE]) {
        
        //是个数组的话
        if ([node respondsToSelector:@selector(objectAtIndex:)]) {
            
            for (id tem in node) {
                
                subValue = [NSString stringWithFormat:@"%@ %@",subValue,tem];
            }
            subValue = [subValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            subType = ARRAY_STR;
        }
        else {
            subValue = [node description];
            subType = STRING_STR;
        }
        
    }
    //List类型
    else if ([control isEqualToString:LIST]) {
        
        //是一个aray
        if ([node respondsToSelector:@selector(objectAtIndex:)]) {
            
            //只判断两层
            for (id tem in node) {
                
                //还是一个数组
                if ([tem respondsToSelector:@selector(objectAtIndex:)]) {
                    
                    for (id child in tem) {
                        subValue = [NSString stringWithFormat:@"%@ %@",subValue,child];
                    }
                }
                else {
                    subValue = [NSString stringWithFormat:@"%@ %@",subValue,tem];
                }
            }
            subValue = [subValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];

            subType = ARRAY_STR;
        }
        else {

            subType = ARRAY_STR;
            if ([node respondsToSelector:@selector(substringFromIndex:)]) {

                subType = STRING_STR;
            }
            subValue = [node description];
        }
    }
    else if ([control isEqualToString:TIME]) {
        
        subValue = [node description];
        subType = TIME;
    }
    else if ([control isEqualToString:INTEGER]) {
        
        subValue = [node description];
        subType = INTEGER;
    }
    else if ([control isEqualToString:CONFIG_OUT_LIST]) {
        
        subType = ARRAY_STR;

    }
    else if ([control isEqualToString:DICTIONARY_STR]) {
        
        subType = DICTIONARY_STR;
    }
    
    //什么都不是的话，有可能是String
    else {
        subValue = [node description];
        subType = STRING_STR;
        
    }
    if (!subValue) {
        subValue = @"";
    }
    return  [NSArray arrayWithObjects:subValue,subType,nil];
}

//点击取消时
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar2 {
    
    for (id node in data) {
        
        if ([[node control] isEqualToString:PARENTNODE] && [node nodeLevel] == 0) {
            
            [self recoverDataState:node];
        }
    }
    if (statuDic != nil) {
        [statuDic removeAllObjects];
    }
    isFirstSearch = YES;
    
    [searchBar resignFirstResponder];

    isSeach = NO;
    
    searchBar.text = @"";
    
    searchBar.showsCancelButton = NO;
    
    [self loadOthers];
    
    [self.tableView reloadData];
    
}
- (void)recoverDataState: (id)node {
    
    if ([[node control] isEqualToString:PARENTNODE]) {
        
        if ([[statuDic allKeys] containsObject:[node keyLabel]]) {
            
            ((TreeNode*)node).isExpanded = [[statuDic valueForKey:[node keyLabel]] isEqualToString:@"YES"] ? YES : NO;
        }
        for (id child in [node childNodes]) {
            
            [self recoverDataState:child];
        }
    }
    
}
//点击虚拟键盘上的search时
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    
}


- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    
    CGFloat tabBarItemHeight = 0;
    for (UIView *view in [self.tabBarController.tabBar subviews]) {
        if ([view isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            tabBarItemHeight = view.frame.size.height;
            break;
        }
    }
    
    //转为横屏
    if (UIInterfaceOrientationIsLandscape(toInterfaceOrientation)) {
    
        //iPad
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
            searchBar.frame = CGRectMake(0, 64, SCREEN_WIDTH, 44);
            self.tableView.frame = CGRectMake(0, 108, SCREEN_WIDTH, SCREEN_HEIGHT - 108 - tabBarItemHeight);
        }
        //iPhone
        else {
            searchBar.frame = CGRectMake(0, 30, SCREEN_WIDTH, 44);
            self.tableView.frame = CGRectMake(0, 74, SCREEN_WIDTH, SCREEN_HEIGHT - 74 - tabBarItemHeight);
        }
        
    }
    else {
        
        searchBar.frame = CGRectMake(0, 64, SCREEN_WIDTH, 44);
        self.tableView.frame = CGRectMake(0, 108, SCREEN_WIDTH, SCREEN_HEIGHT - 108 - tabBarItemHeight);
        
    }
    
}

//BOOL isPad() {
//#ifdef UI_USER_INTERFACE_IDIOM
//    return (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad);
//#else
//    return NO;
//#endif
//}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
