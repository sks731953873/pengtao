//
//  CheckViewController.m
//  iPREditor
//
//  Created by admin on 11/11/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "CheckViewController.h"
#import "PlistTool.h"
#import "TreeNode.h"
#import "CustomMessTool.h"
#import "AppDelegate.h"
#import "CheckViewCell.h"

@implementation CheckViewController

PlistTool* tool;
UIButton* trueButton;
UIButton* falseButton;
UIButton* nilButton;
BOOL isEdit;
BOOL isDonePressed;
NSMutableArray* relationArray;
int sectionCount;
BOOL relationSectionHasShow;
int lastRelationSectionRowCount;
AppDelegate* delegate;

int selectedIndex;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    delegate = [UIApplication sharedApplication].delegate;
    tool = [PlistTool instance];
    isEdit = NO;
    UIBarButtonItem* edit = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editClicked:)];
    self.navigationItem.rightBarButtonItem = edit;
    sectionCount = 1;
    relationSectionHasShow = NO;
    lastRelationSectionRowCount = -1;
    
    if ([self.keyValue isEqualToString:TRUE_STR]) {
        
        selectedIndex = 0;
    }
    else if ([self.keyValue isEqualToString:FALSE_STR]) {
        
        selectedIndex = 1;
    }
    else {
        
        selectedIndex = 2;
    }
    
}

- (void)editClicked: (id)sender {
    
    if ([[sender title] isEqualToString:@"Edit"]) {

        isEdit = YES;
        [self setTextColor:[UIColor blackColor]];
        self.navigationItem.rightBarButtonItem.title = @"Done";
    }
    //点击的是Done
    else {
        isDonePressed = YES;
        if (sectionCount > 1) {
            [self showConfirm];
        }
        else {
            [self save:NO];
            [self setTextColor:[UIColor grayColor]];
        }
    }
}

- (void)showConfirm {
    
    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:@"Related keys exists" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    
    NSMutableParagraphStyle* ps = [[NSMutableParagraphStyle alloc] init];
    [ps setAlignment:NSTextAlignmentCenter];
    NSDictionary* attribs = @{NSParagraphStyleAttributeName:ps};

    NSMutableAttributedString *attributedText =[[NSMutableAttributedString alloc] initWithString:@"Yes: Modify current key and related key          \nNo:Just modify current key" attributes:attribs];
    UIAlertAction* yesAction = [UIAlertAction actionWithTitle:@"Yes"
                                                     style:UIAlertActionStyleDefault
                                                   handler:^(UIAlertAction *action){
                                                       //add code to make something happen once tapped
                                                       if (isDonePressed) {
                                                           [self save:YES];
                                                           [self setTextColor:[UIColor grayColor]];
                                                       }
                                                   }];
    UIAlertAction* noAction = [UIAlertAction actionWithTitle:@"No"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction *action){
                                                          //add code to make something happen once tapped
                                                          [self save:NO];
                                                          [self setTextColor:[UIColor grayColor]];
                                                      }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
    
    [alertController addAction:yesAction];
    [alertController addAction:noAction];
    [alertController addAction:cancelAction];
    
    [alertController setValue:attributedText forKey:@"attributedMessage"];
    
    [self presentViewController:alertController animated:YES completion:nil];

}

- (void)setTextColor: (UIColor*)color {
    
    for (int i =0 ; i < 3; i++) {
        
        NSIndexPath* index = [NSIndexPath indexPathForRow:i inSection:0];

        ((CheckViewCell*)[self.tableView cellForRowAtIndexPath:index]).label.textColor = color;

    }
}

- (void)save: (BOOL)saveRelation {
    
    self.navigationItem.rightBarButtonItem.title = @"Edit";
    
    //result == NULL
    id result = [self getSelectedValue];
    
    //最开始的值是空
    if ([self.keyValue isEqualToString:@""]) {
        
        //选了值,直接设置值即可。
        if (result) {
            
            delegate.isChanged = YES;
            
            NSArray* keys = [self.keyPath componentsSeparatedByString:@"."];
            
            id node = self.dictionary;
            id lastNode = node;
            for (int i = 0; i < keys.count - 1; i++) {
                
                node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                
                //如果key不存在，需要创建
                if (!node) {
                    NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                    [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                    node = tem;
                }
                lastNode = node;
            }
            [tool setValue:result forKey:[keys lastObject] inDictionary:node recursion:NO];
            //保存relatonArray
            if (saveRelation) {
                [self saveRelationArray];
            }
            self.keyValue = [result boolValue] ? TRUE_STR : FALSE_STR;
            [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
        }
    }
    //初始值是true或false
    else {
        
        //选了值
        if (result != NULL) {
            
            //如果点击了Yes,需要把当前值和关联值都保存
            if (saveRelation) {
                
                delegate.isChanged = YES;
                
                NSArray* keys = [self.keyPath componentsSeparatedByString:@"."];
                
                id node = self.dictionary;
                id lastNode = node;
                for (int i = 0; i < keys.count - 1; i++) {
                    
                    node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                    
                    //如果key不存在，需要创建
                    if (!node) {
                        NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                        [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                        node = tem;
                    }
                    lastNode = node;
                }
                if (self.extra) {
                    
                    [self.extra setObject:result atIndex:[self.index intValue]];
                }
                else {
                    [tool setValue:result forKey:[keys lastObject] inDictionary:node recursion:NO];
                    [self saveRelationArray];
                }
                self.keyValue = [result boolValue] ? TRUE_STR : FALSE_STR;
                [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
            }
            //如果点击了No,只需要把当前值保存即可。
            else {
                
                //与前值不一样时才保存
                if ([self.keyValue isEqualToString:[result boolValue] ? TRUE_STR : FALSE_STR] == NO) {
                    
                    delegate.isChanged = YES;
                    
                    NSArray* keys = [self.keyPath componentsSeparatedByString:@"."];
                    
                    id node = self.dictionary;
                    id lastNode = node;
                    for (int i = 0; i < keys.count - 1; i++) {
                        
                        node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                        
                        //如果key不存在，需要创建
                        if (!node) {
                            NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                            [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                            node = tem;
                        }
                        lastNode = node;
                    }
                    if (self.extra) {
                        
                        [self.extra setObject:result atIndex:[self.index intValue]];
                    }
                    else {
                        [tool setValue:result forKey:[keys lastObject] inDictionary:node recursion:NO];
                    }
                    self.keyValue = [result boolValue] ? TRUE_STR : FALSE_STR;
                    [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
                }
            }
        }
        //没选，或选了nil，则删除此key
        else {
            
            delegate.isChanged = YES;
            
            NSArray* keys = [self.keyPath componentsSeparatedByString:@"."];
            
            id node = self.dictionary;
            for (int i = 0; i < keys.count - 1; i++) {
                node = [tool valueForKey:keys[i]  inDictionary:node recursion:NO];
            }
            if (self.extra) {
                
                [self.extra removeObjectAtIndex:[self.index intValue]];
            }
            else {
                [tool removeKey:[keys lastObject] inDictionary:node recursion:NO];
            }
            self.keyValue = @"";
            [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
        }
    }
    trueButton.userInteractionEnabled = NO;
    falseButton.userInteractionEnabled = NO;
    nilButton.userInteractionEnabled = NO;
    
    isEdit = NO;
}



- (void)saveRelationArray {
    
    if (relationArray.count > 0) {
        
        for (TreeNode* relation in relationArray) {
        
            NSArray* keys = [relation.keyPath componentsSeparatedByString:@"."];
        
            id node = self.dictionary;
            id lastNode = node;
            for (int i = 0; i < keys.count - 1; i++) {
            
                node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
            
                //如果key不存在，需要创建
                if (!node) {
                    NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                    [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                    node = tem;
                }
                lastNode = node;
            }
            
            if ([relation.extra respondsToSelector:@selector(isEqualToString:)]) {
                
                if ([relation.extra isEqualToString:@"NULL"]) {
                    
                    [tool removeKey:[keys lastObject] inDictionary:node recursion:NO];
                }
                else {
                     [tool setValue:relation.extra forKey:[keys lastObject] inDictionary:node recursion:NO];
                }
            }
            else {
                [tool setValue:relation.extra forKey:[keys lastObject] inDictionary:node recursion:NO];
            }
        }
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* cellId = @"check_cellId";
    
    CheckViewCell* cell = [self.tableView dequeueReusableCellWithIdentifier:cellId];
    
    if (cell == nil) {
        
        cell = [[CheckViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
        
        [cell.checkBox addTarget:self action:@selector(cellCheckClicked:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    else {
        
        cell.textLabel.text = @"";
        cell.detailTextLabel.text = @"";

    }
    
    if (indexPath.section == 0) {
        
        if (![cell.checkBox superview]) {
            
            [cell recoverCheckBox];
            [cell.checkBox addTarget:self action:@selector(cellCheckClicked:) forControlEvents:UIControlEventTouchUpInside];
        }
        
        switch (indexPath.row) {
            case 0:
                cell.label.text = TRUE_STR;
                cell.checkBox.tag = 0;
                break;
            case 1:
                cell.label.text = FALSE_STR;
                cell.checkBox.tag = 1;
                break;
            case 2:
                cell.label.text = NIL_STR;
                cell.checkBox.tag = 2;
                break;
        }
        
        if (selectedIndex == indexPath.row) {
            
            cell.checkBox.selected = YES;
        }
        else {
            
            cell.checkBox.selected = NO;
        }
        if (isEdit) {
            
            cell.label.textColor = [UIColor blackColor];
            
        }
        else {
            cell.label.textColor = [UIColor grayColor];
        }
        
        //Landscape
       if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])) {
           
           
           [cell setNeedsDisplay];
        }
    }
    else {
        [cell.checkBox removeFromSuperview];
        [cell.label removeFromSuperview];
        cell.textLabel.adjustsFontSizeToFitWidth = YES;
        cell.textLabel.minimumScaleFactor = 9.0/[UIFont labelFontSize];

        cell.textLabel.text = [[relationArray objectAtIndex:indexPath.row] keyPath];
        
        //显示current value
        if (indexPath.section == 1) {
            id lastNode = [CustomMessTool gimmeLastNode:[[relationArray objectAtIndex:indexPath.row] keyPath] inDictionary:self.dictionary];
            
            if (lastNode == nil) {
                cell.detailTextLabel.text = [NIL_STR uppercaseString];
            }
            else {
                if ([BLN_SET containsObject:NSStringFromClass([lastNode class])]) {
                    cell.detailTextLabel.text = [lastNode boolValue] ? TRUE_STR : FALSE_STR;
                }
                else {
                    cell.detailTextLabel.text = [lastNode description];
                }
            }
            
        }
        //显示expected value
        else {
            id value = [[relationArray objectAtIndex:indexPath.row] extra];
            
            if ([BLN_SET containsObject:NSStringFromClass([value class])]) {
                cell.detailTextLabel.text = [value boolValue] ? TRUE_STR : FALSE_STR;
            }
            else {
                cell.detailTextLabel.text = [[relationArray objectAtIndex:indexPath.row] extra];
            }
        }
    }
    
    return cell;
}

- (void)checkBoxClicked:(int)index {
    
    for (int i = 0; i < 3; i++) {
        
        CheckViewCell* cell = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
        
        if (i == index) {
            
            cell.checkBox.selected = !cell.checkBox.selected;
            selectedIndex = cell.checkBox.selected ? i : -1;
        }
        else {
            cell.checkBox.selected = NO;
        }
    }
    [self showRelation];
}

-(void)cellCheckClicked:(UIButton*) button {
    
    if (isEdit) {
        [self checkBoxClicked:(int)button.tag];
    }
}


- (id)getSelectedValue {

    if (selectedIndex == 0) {
        
        return [[NSNumber alloc] initWithBool:YES];
    }
    else if (selectedIndex == 1) {
        
        return [[NSNumber alloc] initWithBool:NO];
    }
    return NULL;
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return sectionCount;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section == 0) {
        return 3;
    }
    return relationArray.count;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    if (section == 0) {
        return self.keyLabel;
    }
    else if (section == 1) {
        return @"Current Related key value:";
    }
    return @"Expected Related key value:";
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section
{
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    if (section == 0) {
        [header.textLabel setText:self.keyLabel];
    }
    else if (section == 1){
        [header.textLabel setText:@"Current Related key value:"];
    }
    else {
        [header.textLabel setText:@"Expected Related key value:"];
    }
    
}

- (void)showRelation {
    
    id select = [self getSelectedValue];
    
    NSString* keyPath= self.keyPath;
    
    NSString* product = [CustomMessTool getProduct:@"FactoryDocControl.PRODUCT" inDictionary:self.dictionary];

    relationArray = [CustomMessTool getRelation:keyPath withValue:select andProduct:product];
    
    //存在关联关系
    if (relationArray.count > 0) {
        //第一次显示出来
        if (relationSectionHasShow == NO) {
            sectionCount = sectionCount + 1;
            
            //显示current value
            NSMutableIndexSet *currentidxSet = [[NSMutableIndexSet alloc] init];
            [currentidxSet addIndex:1];
            [self.tableView beginUpdates];
            [self.tableView insertSections:currentidxSet withRowAnimation:UITableViewRowAnimationFade];
            
            for (int i = 0 ; i < relationArray.count; i++) {
                
                NSIndexPath* path = [NSIndexPath indexPathForRow:i inSection:1];
                
                [self.tableView insertRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
            [self.tableView endUpdates];

            sectionCount = sectionCount + 1;
            //显示expected value
            NSMutableIndexSet *idxSet = [[NSMutableIndexSet alloc] init];
            [idxSet addIndex:2];
            [self.tableView beginUpdates];
            [self.tableView insertSections:idxSet withRowAnimation:UITableViewRowAnimationFade];
            
            for (int i = 0 ; i < relationArray.count; i++) {
                
                NSIndexPath* path = [NSIndexPath indexPathForRow:i inSection:2];
                
                [self.tableView insertRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
            [self.tableView endUpdates];
            
            lastRelationSectionRowCount = (int)relationArray.count;
            relationSectionHasShow = YES;
        }
        //后面的需要改值
        else {
            
            //当前关联数组与上一次的长度一样的话,只需改值
            if (relationArray.count == lastRelationSectionRowCount) {
                //NSLog(@"in it");
                for (int i = 0 ; i < relationArray.count; i++) {
                    
                    //修改current
                    NSIndexPath* currentPath = [NSIndexPath indexPathForRow:i inSection:1];
                    UITableViewCell* currentCell = [self.tableView cellForRowAtIndexPath:currentPath];
                    currentCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                    id lastNode = [CustomMessTool gimmeLastNode:[[relationArray objectAtIndex:i] keyPath] inDictionary:self.dictionary];
                    if (lastNode == nil) {
                        currentCell.detailTextLabel.text = NIL_STR;
                    }
                    else {
                        if ([BLN_SET containsObject:NSStringFromClass([lastNode class])]) {
                            currentCell.detailTextLabel.text = [lastNode boolValue] ? TRUE_STR : FALSE_STR;
                        }
                        else {
                            currentCell.detailTextLabel.text = [lastNode description];
                        }
                    }
                    
                   //修改expected
                    NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:i inSection:2];
                    UITableViewCell* expectedCell = [self.tableView cellForRowAtIndexPath:expectedPath];
                    id value = [[relationArray objectAtIndex:i] extra];
                    expectedCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                    if ([BLN_SET containsObject:NSStringFromClass([value class])]) {
                        
                        expectedCell.detailTextLabel.text = [value boolValue] ? TRUE_STR : FALSE_STR;
                    }
                    else {
                        
                        expectedCell.detailTextLabel.text = [[relationArray objectAtIndex:i] extra];
                    }
                }
            }
            //当前关联数组长度 > 上次的话，需要在表格上插入新的行
            else if (relationArray.count > lastRelationSectionRowCount) {
                
                //先修改
                int i = 0;
                for (; i < lastRelationSectionRowCount; i++) {
                    
                    //修改current
                    NSIndexPath* currentPath = [NSIndexPath indexPathForRow:i inSection:1];
                    UITableViewCell* currentCell = [self.tableView cellForRowAtIndexPath:currentPath];
                    currentCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                    id lastNode = [CustomMessTool gimmeLastNode:[[relationArray objectAtIndex:i] keyPath] inDictionary:self.dictionary];
                    if (lastNode == nil) {
                        currentCell.detailTextLabel.text = NIL_STR;
                    }
                    else {
                        if ([BLN_SET containsObject:NSStringFromClass([lastNode class])]) {
                            currentCell.detailTextLabel.text = [lastNode boolValue] ? TRUE_STR : FALSE_STR;
                        }
                        else {
                            currentCell.detailTextLabel.text = [lastNode description];
                        }
                    }
                    
                    //修改expected
                    NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:i inSection:2];
                    UITableViewCell* expectedCell = [self.tableView cellForRowAtIndexPath:expectedPath];
                    id expectedValue = [[relationArray objectAtIndex:i] extra];
                    expectedCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                    if ([BLN_SET containsObject:NSStringFromClass([expectedValue class])]) {
                        
                        expectedCell.detailTextLabel.text = [expectedValue boolValue] ? TRUE_STR : FALSE_STR;
                    }
                    else {
                        
                        expectedCell.detailTextLabel.text = [[relationArray objectAtIndex:i] extra];
                    }
                }
                //后添加行
                for (; i < relationArray.count; i++) {
                    
                    NSIndexPath* currentPath = [NSIndexPath indexPathForRow:i inSection:1];
                    NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:i inSection:2];
                    
                    [self.tableView insertRowsAtIndexPaths:@[currentPath,expectedPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                }
                lastRelationSectionRowCount = (int)relationArray.count;
            }
            //当前关联数组长度 < 上次的话，需要在表格上删除行
            else {
                //先修改
                int i = 0;
                for (; i < relationArray.count; i++) {
                    
                    //修改current
                    NSIndexPath* currentPath = [NSIndexPath indexPathForRow:i inSection:1];
                    UITableViewCell* currentCell = [self.tableView cellForRowAtIndexPath:currentPath];
                    currentCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                    id lastNode = [CustomMessTool gimmeLastNode:[[relationArray objectAtIndex:i] keyPath] inDictionary:self.dictionary];
                    if (lastNode == nil) {
                        currentCell.detailTextLabel.text = NIL_STR;
                    }
                    else {
                        if ([BLN_SET containsObject:NSStringFromClass([lastNode class])]) {
                            currentCell.detailTextLabel.text = [lastNode boolValue] ? TRUE_STR : FALSE_STR;
                        }
                        else {
                            currentCell.detailTextLabel.text = [lastNode description];
                        }
                    }

                    //修改expected
                    NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:i inSection:1];
                    UITableViewCell* expectedCell = [self.tableView cellForRowAtIndexPath:expectedPath];
                    id value = [[relationArray objectAtIndex:i] extra];
                    expectedCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                    if ([BLN_SET containsObject:NSStringFromClass([value class])]) {
                        
                        expectedCell.detailTextLabel.text = [value boolValue] ? TRUE_STR : FALSE_STR;
                    }
                    else {
                        
                        expectedCell.detailTextLabel.text = [[relationArray objectAtIndex:i] extra];
                    }
                }
                //后删除
                //后添加行
                int j = i;
                for (; i < lastRelationSectionRowCount; i++) {
                    
                    NSIndexPath* currentPath = [NSIndexPath indexPathForRow:j inSection:1];
                    NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:j inSection:1];
                    [self.tableView deleteRowsAtIndexPaths:@[currentPath,expectedPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                }
                lastRelationSectionRowCount = (int)relationArray.count;
            }
            
        }
    }
    
    //不存在关联关系
    else {

        if (relationSectionHasShow == YES) {

            sectionCount = sectionCount - 2;
            lastRelationSectionRowCount = -1;
            NSMutableIndexSet *idxSet = [[NSMutableIndexSet alloc] init];
            [idxSet addIndex:1];
            [idxSet addIndex:2];
            [self.tableView beginUpdates];
            [self.tableView deleteSections:idxSet withRowAnimation:UITableViewRowAnimationFade];
            [self.tableView endUpdates];
            
            relationSectionHasShow = NO;
        }
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 0) {
        
        if (isEdit) {
            [self checkBoxClicked:(int)indexPath.row];
            
        }
    }
}


@end