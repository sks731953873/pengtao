//
//  MultiChoiceViewController.m
//  iPREditor
//
//  Created by admin on 11/12/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "MultiChoiceViewController.h"
#import "PlistTool.h"
#import "AppDelegate.h"

@implementation MultiChoiceViewController

PlistTool* tool;
BOOL isEdit;
NSArray* origin;
AppDelegate* delegate;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    delegate = [UIApplication sharedApplication].delegate;
    
    tool = [PlistTool instance];
    
    origin = [self.keyValue componentsSeparatedByString:@" "];
    
    [self fillChoices];
    
    UIBarButtonItem* edit = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editClicked:)];
    self.navigationItem.rightBarButtonItem = edit;
    
}

- (void)fillChoices {
    
    for (NSString* value in origin) {
        if ([value isEqualToString:@""] == NO) {
            if ([self.choice containsObject:value] == NO) {
                [self.choice addObject:value];
            }
        }
    }
}

- (void)editClicked: (id)sender {
    
    if ([[sender title] isEqualToString:@"Edit"]) {
        isEdit = YES;
        
        for (int i = 0; i < self.choice.count; i++) {
            NSIndexPath* path = [NSIndexPath indexPathForRow:i inSection:0];
            [self.tableView cellForRowAtIndexPath:path].textLabel.textColor = [UIColor blackColor];
        }
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addClicked:)];
        self.navigationItem.rightBarButtonItem.title = @"Done";
        
    }
    //点击的是Done
    else {
        isEdit = NO;
        
        NSArray* result = [self getSelectedValue];
        if (!result) {
            
            result = [[NSArray alloc] init];
        }
        //与初始值不等时
        if ([result isEqualToArray:origin] == NO) {
            
            //设置保存标志位
            delegate.isChanged = YES;
         
            NSArray* keys = [self.keyPath componentsSeparatedByString:@"."];
            
            id node = self.dictionary;
            id lastNode = node;
            for (int i = 0; i < keys.count - 1; i++) {
                
                node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                
                //如果key不存在，需要创建
                if (!node) {
                    NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                    [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                    node = tem;
                }
                lastNode = node;
            }
            
            [tool setValue:result forKey:[keys lastObject] inDictionary:node recursion:NO];
            
            origin = result;
            
            [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
            
        }
        for (int i = 0; i < self.choice.count; i++) {
            NSIndexPath* path = [NSIndexPath indexPathForRow:i inSection:0];
            [self.tableView cellForRowAtIndexPath:path].textLabel.textColor = [UIColor grayColor];
        }
        self.navigationItem.leftBarButtonItem = NULL;
        self.navigationItem.rightBarButtonItem.title = @"Edit";
       
    }
}

- (void)addClicked: (id) sender {
    
    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:@"Add new value" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction* okAction = [UIAlertAction actionWithTitle:@"Confirm" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
        UITextField* value = alertController.textFields.firstObject;
        [self.choice insertObject:value.text atIndex:self.choice.count];
        [self.tableView beginUpdates];
        [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:self.choice.count - 1 inSection:0]] withRowAnimation:UITableViewRowAnimationAutomatic];
        [self.tableView endUpdates];
        
        
    }];
    [alertController addAction:cancelAction];
    [alertController addAction:okAction];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField){
        textField.placeholder = @"input new value";
    }];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
    
    
}

- (NSArray*)getSelectedValue {
    
    NSMutableArray* result = nil;
    
    for (int i = 0; i < self.choice.count; i++) {
        
        NSIndexPath* path = [NSIndexPath indexPathForRow:i inSection:0];
        
        if ([self.tableView cellForRowAtIndexPath:path].accessoryType == UITableViewCellAccessoryCheckmark) {
            
            if (result == nil) {
                result = [[NSMutableArray alloc] init];
            }
            [result addObject:self.choice[i]];
        }
    }
    return result;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* cellId = @"setting_multi_cellId";
    
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    else {
        
        NSArray* array = [self getSelectedValue];
        
        for (int i = 0; i < self.choice.count; i++) {
            
            NSIndexPath* path = [NSIndexPath indexPathForRow:i inSection:0];
            
            if ([array containsObject:self.choice[i]]) {
                
                [self.tableView cellForRowAtIndexPath:path].accessoryType =UITableViewCellAccessoryCheckmark;
            }
        }
        
        if (isEdit == NO) {
            
            cell.textLabel.textColor = [UIColor grayColor];
        }
        cell.textLabel.text = self.choice[indexPath.row];
        return cell;
        
    }
    if (isEdit == NO) {
        
        cell.textLabel.textColor = [UIColor grayColor];
    }
    if ([origin containsObject:self.choice[indexPath.row]]) {
        
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    cell.textLabel.text = self.choice[indexPath.row];
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.choice.count;
}


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    return self.keyLabel;
    
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section
{
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    if (section == 0) {
        [header.textLabel setText:self.keyLabel];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 0) {
        
        if (isEdit) {
            UITableViewCell* currentCell = [self.tableView cellForRowAtIndexPath:indexPath];
            if (currentCell.accessoryType == UITableViewCellAccessoryCheckmark) {
                currentCell.accessoryType = UITableViewCellAccessoryNone;
            }
            else {
                currentCell.accessoryType = UITableViewCellAccessoryCheckmark;
            }
        }
    }
    
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}



// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        if (isEdit) {
        
            [self.choice removeObjectAtIndex:indexPath.row];
            [self.tableView beginUpdates];
            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [self.tableView endUpdates];
        }
        
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        
    }
}


@end
