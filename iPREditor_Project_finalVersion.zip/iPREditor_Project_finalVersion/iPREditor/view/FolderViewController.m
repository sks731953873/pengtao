//
//  FolderViewController.m
//  iPREditor
//
//  Created by admin on 10/28/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "FolderViewController.h"
#import "FileTool.h"
#import "FileDetailViewController.h"
#import "FileEditToolBar.h"
#import "PRTabbarController.h"
#import "PreviewViewController.h"
#import "LocalFolderViewCell.h"
#import "AppDelegate.h"
#import "SSZipArchive.h"

@interface FolderViewController ()

@end

@implementation FolderViewController

NSMutableArray* files;
NSString* temDirectory;
FileEditToolBar* editToolBar;
static BOOL toolBarShow;
NSMutableArray* selectedFiles;
AppDelegate* delegate;
NSIndexPath * shareIndexPath;
UIDocumentInteractionController *documentController;
UIMenuController *menu;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    delegate = [UIApplication sharedApplication].delegate;
    
    [self set];
    
    UILongPressGestureRecognizer * longPressGr = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressToDo:)];
    longPressGr.minimumPressDuration = 0.5;
    [self.tableView addGestureRecognizer:longPressGr];
    
    if (delegate.goToFile) {
        
        NSString* fileName = [[delegate.fileURL relativePath] lastPathComponent];
    
        //先删除
        [delegate.fileTool removeFile:[delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",fileName]]];
        
        //后复制
        [delegate.fileTool copyFrom:[delegate.fileURL path] to:[delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",fileName]]];
        
        [delegate.fileTool removeFile:[delegate.documentDirectory stringByAppendingPathComponent:@"Inbox"]];
        
        //打开的是zip，需要解压
        if ([[[fileName pathExtension] lowercaseString] isEqualToString:@"zip"]) {
            
            //先考到document/PrFile目录
            [delegate.fileTool copyFrom:[delegate.fileURL path] to:[delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",fileName]]];
            
            //清空Inbox目录
            [delegate.fileTool removeFile:[delegate.documentDirectory stringByAppendingPathComponent:@"Inbox"]];
            //创建目录
            [delegate.fileTool createDirectory:[delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",[fileName stringByDeletingPathExtension]]]];
            
            //解压
            [SSZipArchive unzipFileAtPath:[delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",fileName]] toDestination:[delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",[fileName stringByDeletingPathExtension]]]];
            
            FolderViewController* view = [self.storyboard instantiateViewControllerWithIdentifier:@"story_folderViewController"];
            if (view == NULL) {
                view = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"story_folderViewController"];
            }
            
            [view setValue:[fileName stringByDeletingPathExtension] forKey:@"headTitle"];
           
            [view setValue:[NSString stringWithFormat:@"PrFile/%@",[fileName stringByDeletingPathExtension]] forKey:@"currentPath"];
            
            delegate.goToFile = NO;
            [self.navigationController pushViewController:view animated:YES];
            
        }
        else {
        
            delegate.goToFile = NO;

            NSString* path = [delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PrFile/%@",fileName]];
            
            PRTabbarController* view = [self.storyboard instantiateViewControllerWithIdentifier:@"story_prTabBar"];

            if (view == NULL) {
                
                view = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"story_prTabBar"];
            }
            
            NSMutableDictionary* dic = [[NSMutableDictionary alloc] initWithContentsOfFile:path];
            delegate.dictionary = dic;
            delegate.temFilePath = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.tem",[path lastPathComponent]]];
            [[NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil] writeToFile:delegate.temFilePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
            
            for (int i = 0; i < [[view viewControllers] count]; i++) {
                [[[[[view viewControllers] objectAtIndex:i] viewControllers] objectAtIndex:0] setValue:path forKey:@"fullPath"];
            }
            [self.navigationController pushViewController:view animated:YES];
        }
    }
    
}


-(void)longPressToDo:(UILongPressGestureRecognizer *)gesture {
    
    if(gesture.state == UIGestureRecognizerStateBegan)
    {
        CGPoint point = [gesture locationInView:self.tableView];
        NSIndexPath * indexPath = [self.tableView indexPathForRowAtPoint:point];
        shareIndexPath = indexPath;
        if(indexPath == nil) return;
        
        LocalFolderViewCell* cell = (LocalFolderViewCell*)[self.tableView cellForRowAtIndexPath:indexPath];
        [cell becomeFirstResponder];

        UIMenuItem *shareItem = [[UIMenuItem alloc] initWithTitle:@"Share" action:@selector(handleShare:)];
        menu = [UIMenuController sharedMenuController];
        [menu setMenuItems:[NSArray arrayWithObjects:shareItem,  nil]];
        [menu setTargetRect:cell.frame inView:self.view];
        [menu setMenuVisible:YES animated:YES];
    }
}

- (void)handleShare:(id)sender{
   
    if(shareIndexPath == nil) return;
    LocalFolderViewCell* cell = (LocalFolderViewCell*)[self.tableView cellForRowAtIndexPath:shareIndexPath];
    
    NSString* targetFullPath = [delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@",self.currentPath,cell.textLabel.text]];
    
    //share是一个文件夹,需要把文件夹压缩
    if ([delegate.fileTool isFile:targetFullPath] == NO) {
        
        NSString* zipFile = [temDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.zip",[targetFullPath lastPathComponent]]];
        
        if ([SSZipArchive createZipFileAtPath:zipFile withContentsOfDirectory: targetFullPath]) {
            
            targetFullPath = zipFile;
        }
        
    }
    
    NSURL* url = [NSURL fileURLWithPath:targetFullPath];
    documentController = [UIDocumentInteractionController interactionControllerWithURL:url];
    documentController.delegate = self;
    
    //ipad
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        
//        NSString *textToShare = @"PR attached.";
//        NSArray *activityItems = @[textToShare, url];
//        UIActivityViewController *activityVC = [[UIActivityViewController alloc]initWithActivityItems:activityItems applicationActivities:nil];
//        UIPopoverController* popUp =  [[UIPopoverController alloc] initWithContentViewController:activityVC];
//        [popUp presentPopoverFromRect:[self.tableView cellForRowAtIndexPath:shareIndexPath].frame inView:self.tableView permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];

        [documentController presentOptionsMenuFromRect:[self.tableView cellForRowAtIndexPath:shareIndexPath].frame inView:self.tableView animated:YES];

    }
    else {
//    [documentController presentOpenInMenuFromRect:[self.tableView frame] inView:self.tableView animated:YES];
//    [documentController presentPreviewAnimated:YES];
    [documentController presentOptionsMenuFromRect:self.tableView.frame inView:self.tableView animated:YES];
    }
}


- (UIViewController *)documentInteractionControllerViewControllerForPreview:(UIDocumentInteractionController *)interactionController
{
    return self;
}


-(UIView *)documentInteractionControllerViewForPreview:(UIDocumentInteractionController *)controller{

    return self.tableView;
}

- (CGRect)documentInteractionControllerRectForPreview:(UIDocumentInteractionController*)controller
{

    return self.tableView.frame;
}

- (void)action: (UIBarButtonItem*)sender {
    
    
    NSArray* paths = [[self.tableView indexPathsForSelectedRows] sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        if ([obj1 row] < [obj2 row]) {
            
            return NSOrderedDescending;
        }
        else if ([obj1 row] > [obj2 row]) {
            return NSOrderedAscending;
        }
        return NSOrderedSame;
    }];

    //Copy
    if ([sender.title isEqualToString:@"Copy"]) {
        
        [selectedFiles removeAllObjects];
        
        for (NSIndexPath* path in paths) {
            
            //UITableViewCell* cell = [self.tableView cellForRowAtIndexPath:path];
                
            NSString* fileName = [files objectAtIndex:path.row];
                
            NSString* relativePath = [NSString stringWithFormat:@"%@/%@",self.currentPath,fileName];
                
            [selectedFiles addObject:relativePath];

        }

        if (selectedFiles.count == 0) {
            
            [[editToolBar.items objectAtIndex:2] setEnabled:NO];
            
        } else {
            
            [[editToolBar.items objectAtIndex:2] setEnabled:YES];
            
        }
        
    }
    //Paste
    else if ([sender.title isEqualToString:@"Paste"]) {
        
        if (selectedFiles.count > 0) {
            
            NSArray* currentPathFiles = [delegate.fileTool listFiles:[delegate.documentDirectory stringByAppendingPathComponent:self.currentPath]];
            
            for (int i = 0; i < selectedFiles.count;) {
            
            //for (NSString* path in selectedFiles) {
                
                NSString* path = selectedFiles[i];
                
                if ([delegate.fileTool isExist:[delegate.documentDirectory stringByAppendingPathComponent:path]]) {
                    
                    i++;
                    //已存在目标文件
                    if ([currentPathFiles containsObject:[path lastPathComponent]]) {
                        
                        NSString* sourceFullPath= [delegate.documentDirectory stringByAppendingPathComponent:path];
                        
                        NSString* targetFileName = [path lastPathComponent];
                        
                        NSString* pathExtension = [targetFileName pathExtension];
                        
                        NSString* targetFullPath;
                        
                        if ([pathExtension isEqualToString:@""]) {
                            
                            targetFullPath = [delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@-copy",self.currentPath,targetFileName]];
                        }
                        else {
                            
                            targetFullPath = [delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@-copy.%@",self.currentPath,[targetFileName stringByDeletingPathExtension],[targetFileName pathExtension]]];
                        }
                        
                        if ([delegate.fileTool isExist:targetFullPath] == NO) {
                            
                            [delegate.fileTool copyFrom:sourceFullPath to:targetFullPath];
                            files = nil;
                            files = [[delegate.fileTool listFiles:[delegate.documentDirectory stringByAppendingPathComponent:self.currentPath]] mutableCopy];
                            
                            int insertPosition = 0;
                            
                            for (int i = 0; i < files.count; i++) {
                                
                                if ([[files objectAtIndex:i] isEqualToString:[targetFullPath lastPathComponent]]) {
                                    
                                    insertPosition = i;
                                    break;
                                }
                            }
                            NSIndexPath* last = [NSIndexPath indexPathForRow:insertPosition inSection:0];
                            [self.tableView insertRowsAtIndexPaths:@[last] withRowAnimation:UITableViewRowAnimationAutomatic];
                            
                        }
                        //从0开始找序号
                        else {
                            
                            int i = 0;
                            while (YES) {
                                
                                if ([pathExtension isEqualToString:@""]) {
                                    
                                    targetFullPath = [delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@-copy-%d",self.currentPath,targetFileName,i]];
                                }
                                else {
                                    
                                    targetFullPath = [delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@-copy-%d.%@",self.currentPath,[targetFileName stringByDeletingPathExtension],i,[targetFileName pathExtension]]];
                                }
                                if ([delegate.fileTool isExist:targetFullPath] == NO) {
                                    break;
                                }
                                i = i + 1;
                            }
                            [delegate.fileTool copyFrom:sourceFullPath to:targetFullPath];
                            files = nil;
                            files = [[delegate.fileTool listFiles:[delegate.documentDirectory stringByAppendingPathComponent:self.currentPath]] mutableCopy];
                            
                            int insertPosition = 0;
                            
                            for (int i = 0; i < files.count; i++) {
                                
                                
                                if ([[files objectAtIndex:i] isEqualToString:[targetFullPath lastPathComponent]]) {
                                    
                                    insertPosition = i;
                                    break;
                                }
                            }
                            NSIndexPath* last = [NSIndexPath indexPathForRow:insertPosition inSection:0];
                            [self.tableView insertRowsAtIndexPaths:@[last] withRowAnimation:UITableViewRowAnimationAutomatic];
                            
                        }
                    }
                    //不存在目标文件
                    else {
                        NSString* sourceFullPath= [delegate.documentDirectory stringByAppendingPathComponent:path];
                        NSString* targetFileName = [path lastPathComponent];
                        
                        [delegate.fileTool copyFrom:sourceFullPath to:[delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@",self.currentPath,targetFileName]]];

                        [files addObject:targetFileName];
                        [files sortUsingSelector:@selector(compare:)];
                        
                        int insertPosition = 0;
                        
                        for (int i = 0; i < files.count; i++) {
                            
                            if ([[files objectAtIndex:i] isEqualToString:targetFileName]) {
                                
                                insertPosition = i;
                                break;
                            }
                        }
                        NSIndexPath* last = [NSIndexPath indexPathForRow:insertPosition inSection:0];
                        [self.tableView insertRowsAtIndexPaths:@[last] withRowAnimation:UITableViewRowAnimationAutomatic];
                    }
                }
                //不存在
                else {
                    
                    [selectedFiles removeObject:path];
                }
            }
            if (selectedFiles.count <= 0) {
                
                sender.enabled = NO;
            }
            
        } else {
            sender.enabled = NO;
        }
        
        
    }
    //Delete
    else {
        
        for (NSIndexPath* path in paths) {

            NSString* fileName = [files objectAtIndex:path.row];
                
            [delegate.fileTool removeFile:[delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@",self.currentPath,fileName]]];
            [files removeObjectAtIndex:path.row];
            [self.tableView deleteRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationFade];
        }
        if (toolBarShow == YES) {
            [editToolBar hideAnimated:YES];
            toolBarShow = NO;
        }
        
    }
}

- (void)set {
    
    
    if (selectedFiles == nil) {
        selectedFiles = [[NSMutableArray alloc] init];
    }
    
    self.navigationItem.title = self.headTitle;

    temDirectory = NSTemporaryDirectory();
    
    files = [[delegate.fileTool listFiles:[delegate.documentDirectory stringByAppendingPathComponent:self.currentPath]] mutableCopy];
    
    UIBarButtonItem* edit = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editClicked:)];
  
    self.navigationItem.rightBarButtonItem = edit;

     UIBarButtonItem* back = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:self action:@selector(backClicked:)];
    
    self.navigationItem.leftBarButtonItem = back;
    
    self.tableView.tableFooterView=[[UIView alloc]init];
    
    toolBarShow = NO;
    
    editToolBar = [[FileEditToolBar alloc] init];
    editToolBar.scrollView = self.tableView;
    UIBarButtonItem *copy = [[UIBarButtonItem alloc] initWithTitle:@"Copy" style:UIBarButtonItemStylePlain target:self action:@selector(action:)];
    
    UIBarButtonItem *button2 = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:0];
    
    UIBarButtonItem *paste = [[UIBarButtonItem alloc] initWithTitle:@"Paste" style:UIBarButtonItemStylePlain target:self action:@selector(action:)];
    if (selectedFiles.count <= 0 ) {
        paste.enabled = NO;
    }
    
    UIBarButtonItem *button4 = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:0];
    
    UIBarButtonItem *delete = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemTrash target:self action:@selector(action:)];
    editToolBar.items = @[copy, button2, paste, button4, delete];

}
- (void)setSelectedFiles:(NSMutableArray *) n {
    
    selectedFiles = n;
}
- (void)deselectAllRows {

    NSArray* paths = [self.tableView indexPathsForSelectedRows];
    
    for (NSIndexPath* path in paths) {
        UITableViewCell* cell = [self.tableView cellForRowAtIndexPath:path];
        cell.selected = NO;
    }
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO];
    [self set];
    [self.tableView reloadData];

}

- (void)editClicked:(id) sender {
    
    if([[sender title] isEqualToString:@"Edit"]) {
        
        self.navigationItem.rightBarButtonItem.title = @"Done";
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addClicked:)];

        [self.tableView setEditing:YES animated:YES];
        
        if (selectedFiles.count > 0) {
            [editToolBar showFromNavigationBar:self.navigationController.navigationBar animated:YES];
            toolBarShow = YES;
        }
        
    } else {
        
        self.navigationItem.rightBarButtonItem.title = @"Edit";
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:self action:@selector(backClicked:)];
       
        if (toolBarShow == YES) {
            [editToolBar hideAnimated:YES];
            toolBarShow = NO;
        }
        [self.tableView setEditing:NO animated:YES];
        
    }
    
}

- (void)backClicked: (id)sender {

    [self.navigationController popViewControllerAnimated:YES];
    
}

- (void)addClicked: (id) sender {
    
    NSString* folderBaseName = @"New Folder";
    NSString* folderName = [folderBaseName copy];
    NSString* folderFullPath = [delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@",self.currentPath,folderName]];
    
    //不存在New Folder
    if ([delegate.fileTool isExist:folderFullPath] == NO) {
        
        [delegate.fileTool createDirectory:folderFullPath];
    }
    //已经存在了New Folder,找到序号
    else {
        int i = 0;
        while (YES) {
            
            folderName = [NSString stringWithFormat:@"%@ %d",folderBaseName,i];
            folderFullPath = [delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@",self.currentPath,folderName]];
            if ([delegate.fileTool isExist:folderFullPath] == NO) {
                [delegate.fileTool createDirectory:folderFullPath];
                break;
            }
            i = i + 1;
        }
        
    }
    
    files = nil;
    
    files = [[delegate.fileTool listFiles:[delegate.documentDirectory stringByAppendingPathComponent:self.currentPath]] mutableCopy];
    
    int insertPosition = 0;
    
    for (int i = 0; i < files.count; i++) {
        
        if ([[files objectAtIndex:i] isEqualToString:folderName]) {
            
            insertPosition = i;
            break;
        }
    }
    NSIndexPath* last = [NSIndexPath indexPathForRow:insertPosition inSection:0];
    [self.tableView insertRowsAtIndexPaths:@[last] withRowAnimation:UITableViewRowAnimationAutomatic];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return files.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString* name = [files objectAtIndex:indexPath.row];
    NSString* cellId = @"local_folder_cell";
    
    if (self.currentPath == NULL) {
        
        self.currentPath = @"";
    }
    
    NSString* fullPath= [delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@",self.currentPath,[files objectAtIndex:indexPath.row]]];

    LocalFolderViewCell* cell = [self.tableView dequeueReusableCellWithIdentifier:cellId];
    
    if (cell == nil) {
        
        cell = [[LocalFolderViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        cell.accessoryType = UITableViewCellAccessoryDetailButton;
    }
    
    cell.imageView.image = [UIImage imageNamed:@"Folder_45px.png"];
    
    if ([delegate.fileTool isFile:fullPath]) {
        
        NSString* tem = [delegate.fileTool fileType:fullPath];
        
        if (tem != NULL) {
            
            if ([[delegate.fileTool fileType:fullPath] isEqualToString:@"zip"] || [[delegate.fileTool fileType:fullPath] isEqualToString:@"7z"] || [[delegate.fileTool fileType:fullPath] isEqualToString:@"rar"]) {
                
                cell.imageView.image = [UIImage imageNamed:@"File_Zip_45px.png"];
                
            }
            else {
                cell.imageView.image = [UIImage imageNamed:@"File_Generic_45px.png"];
            }
        }
        else {
            
            cell.imageView.image = [UIImage imageNamed:@"File_Generic_45px.png"];
        }
    }
    cell.textLabel.text = name;

    //处于Edit状态
    if (self.tableView.editing) {
        
        //恢复选中
        if ([selectedFiles containsObject:[files objectAtIndex:indexPath.row]]) {

           // cell.selected = YES;
            [cell setSelected:YES];
        }
    }
    return cell;
}


// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {

    return YES;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return UITableViewCellEditingStyleDelete;
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {

    
        //1.从nand上删除
        UITableViewCell* selectedCell = [tableView cellForRowAtIndexPath:indexPath];
        UILabel* name = (UILabel*)selectedCell.textLabel;
        NSString* fileName = name.text;
        
        [delegate.fileTool removeFile:[delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@",self.currentPath,fileName]]];
        
        //2.从内存数组中删除
        [files removeObjectAtIndex:indexPath.row];
        
        //3.从UITableView删除
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (self.tableView.editing == YES) {
        
        if (toolBarShow == NO) {
            [editToolBar showFromNavigationBar:self.navigationController.navigationBar animated:YES];
            toolBarShow = YES;
        }
    }
    else {
        
        [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
        UILabel* name = (UILabel*)[[tableView cellForRowAtIndexPath:indexPath] textLabel];
        NSString* path = [delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@",self.currentPath,name.text]];
        
        [menu setMenuVisible:NO animated:NO];
        
        //点击的是文件
        if ([delegate.fileTool isFile:path]) {
            
            
            //点击的是zip文件
            if ([[[name.text pathExtension] lowercaseString] isEqualToString:@"zip"]) {
                
                NSString* unzipFolder = [delegate.documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@",self.currentPath,[name.text stringByDeletingPathExtension]]];
                //创建文件夹
                [delegate.fileTool createDirectory:unzipFolder];
                //解压
                if ([SSZipArchive unzipFileAtPath:path toDestination:unzipFolder]) {
                    //存在同步的文件夹
                    if ([files containsObject:[name.text stringByDeletingPathExtension]]) {
                        //删除原来的
                        for (int i = 0; i < files.count; i++) {
                            
                            if ([[files objectAtIndex:i] isEqualToString:[name.text stringByDeletingPathExtension]]) {
                                [files removeObjectAtIndex:i];
                                NSIndexPath* index = [NSIndexPath indexPathForRow:i inSection:indexPath.section];
                                [self.tableView beginUpdates];
                                [self.tableView deleteRowsAtIndexPaths:@[index] withRowAnimation:UITableViewRowAnimationAutomatic];
                                [self.tableView endUpdates];
                                break;
                            }
                        }
                    }
                    NSIndexPath* last = [NSIndexPath indexPathForRow:files.count inSection:0];
                    [files insertObject:[name.text stringByDeletingPathExtension] atIndex:files.count];
                    [self.tableView beginUpdates];
                    [self.tableView insertRowsAtIndexPaths:@[last] withRowAnimation:UITableViewRowAnimationAutomatic];
                    [self.tableView endUpdates];
                }
            }
            else {
                PRTabbarController* view = [self.storyboard instantiateViewControllerWithIdentifier:@"story_prTabBar"];
                if (view == NULL) {
                    view = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"story_prTabBar"];
                }
                
                delegate.temFilePath = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.tem",[path lastPathComponent]]];
                [[NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil] writeToFile:delegate.temFilePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
                
                for (int i = 0; i < [[view viewControllers] count]; i++) {
                    [[[[[view viewControllers] objectAtIndex:i] viewControllers] objectAtIndex:0] setValue:path forKey:@"fullPath"];
                }
                delegate.navi = self.navigationController;
                [self.navigationController pushViewController:view animated:YES];

            }
            
        }
        //是文件夹
        else {
            FolderViewController* view = [self.storyboard instantiateViewControllerWithIdentifier:@"story_folderViewController"];
            if (view == NULL) {
                view = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"story_folderViewController"];
            }
            [view setValue:name.text forKey:@"headTitle"];
            [view setValue:[NSString stringWithFormat:@"%@/%@",self.currentPath,name.text] forKey:@"currentPath"];
            [view setValue:selectedFiles forKey:@"selectedFiles"];
            [self.navigationController pushViewController:view animated:YES];
        }
    }
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSArray* paths = [self.tableView indexPathsForSelectedRows];
    
    if (paths.count == 0) {
        
        if (selectedFiles.count == 0) {
            [editToolBar hideAnimated:YES];
            toolBarShow = NO;
        }
    }
    
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath {
    
    [menu setMenuVisible:NO animated:NO];
    UILabel* name = (UILabel*)[[tableView cellForRowAtIndexPath:indexPath] textLabel];
    FileDetailViewController* detail = [self.storyboard instantiateViewControllerWithIdentifier:@"story_fileDetailViewController"];
    if (detail == NULL) {
        
        detail = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"story_fileDetailViewController"];
    }
    [detail setValue:name.text forKey:@"currentFile"];
    [detail setValue:[NSString stringWithFormat:@"%@/%@",self.currentPath,name.text] forKey:@"currentPath"];
    [self.navigationController pushViewController:detail animated:YES];
}


@end
