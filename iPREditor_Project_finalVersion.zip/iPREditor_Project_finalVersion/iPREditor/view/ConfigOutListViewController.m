//
//  ConfigOutListViewController.m
//  iPREditor
//
//  Created by admin on 11/30/15.
//  Copyright © 2015 admin. All rights reserved.
//

#import "ConfigOutListViewController.h"
#import "CustomMessTool.h"
#import "AppDelegate.h"
#import "CheckViewController.h"
#import "TextViewController.h"

@implementation ConfigOutListViewController

BOOL isEditPressed;
BOOL isChoosed;
AppDelegate* delegate;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    isEditPressed = NO;
    isChoosed = NO;
    self.tableView.allowsSelectionDuringEditing = YES;
    UIBarButtonItem* edit = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editClicked:)];
    //UIBarButtonItem* back = [[UIBarButtonItem alloc] initWithTitle:@"< Back" style:UIBarButtonItemStylePlain target:self action:@selector(backClicked:)];
    self.navigationItem.rightBarButtonItem = edit;
    //self.navigationItem.leftBarButtonItem = back;
    
}

- (void)editClicked: (id)sender {
 
    if ([[sender title] isEqualToString:@"Edit"]) {
        
        isEditPressed = YES;
        [self.tableView setEditing:YES animated:YES];
        [self insertAtLastPosition];
        [self setCellTextLabelColor:[UIColor blackColor]];
        self.navigationItem.rightBarButtonItem.title = @"Done";
    }
    else {
        
        isEditPressed = NO;
        isChoosed = NO;
        [self.tableView setEditing:NO animated:YES];
        [self deleteLastPosition];
        [self setCellTextLabelColor:[UIColor grayColor]];
        [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
        self.navigationItem.rightBarButtonItem.title = @"Edit";
    }
}

- (void)setCellTextLabelColor: (UIColor*)color {
    
    for(int i = 0; i < [self.extra count]; i++) {
        
        NSIndexPath* index = [NSIndexPath indexPathForRow:i inSection:0];
        
        [self.tableView cellForRowAtIndexPath:index].textLabel.textColor = color;
    }
}

- (void)backClicked: (id)sender {
    
    if (isEditPressed) {
        
        isEditPressed = NO;
        [self.extra removeLastObject];
    }
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* cellId = @"config_out_list_cell_id";
    
    UITableViewCell* cell = [self.tableView dequeueReusableCellWithIdentifier:cellId];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellId];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    else {
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.textLabel.text = @"";
        cell.textLabel.textColor = [UIColor clearColor];
        cell.detailTextLabel.text = @"";
    }
    cell.textLabel.text = [NSString stringWithFormat:@"%@%d",@"Item",(int)indexPath.row];
    cell.textLabel.textColor = [UIColor grayColor];
    if (isEditPressed) {
        cell.textLabel.textColor = [UIColor blackColor];
    }
    cell.detailTextLabel.text = [CustomMessTool gimmeType:[self.extra objectAtIndex:indexPath.row]];
    if (isEditPressed && !isChoosed) {
        if (indexPath.row+1 == [self.extra count]) {
            
            cell.textLabel.text = @"New Node";
            cell.detailTextLabel.text = @"";
        }

    }
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    //处于编辑模式，且点击了最后一个
    if (isEditPressed) {
        
        
        if (indexPath.row == [self.extra count] -1) {
            
            int index = (int)[self.extra count] - 1;
            UIAlertController* alertController = [UIAlertController alertControllerWithTitle:@"New Node" message:@"what do you wanna add?" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* booleanAction = [UIAlertAction actionWithTitle:@"Boolean" style:UIAlertActionStyleDefault handler:^(UIAlertAction*  action) {
                isChoosed = YES;
                delegate.isChanged = YES;
                NSNumber* v = [NSNumber numberWithBool:YES];
                [self.extra insertObject:v atIndex:index];
                //[self.dictionary writeToFile:delegate.temFilePath atomically:YES];
                
                [self.tableView beginUpdates];
                [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForItem:[self.extra count] -2 inSection:0]] withRowAnimation:UITableViewRowAnimationLeft];
                [self.tableView endUpdates];
            }];
            UIAlertAction* stringAction = [UIAlertAction actionWithTitle:@"String" style:UIAlertActionStyleDefault handler:^(UIAlertAction* action) {
                
                isChoosed = YES;
                delegate.isChanged = YES;
                NSString* v = [[NSString alloc] init];
                [self.extra insertObject:v atIndex:index];
                //[self.dictionary writeToFile:delegate.temFilePath atomically:YES];
                
                [self.tableView beginUpdates];
                [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForItem:[self.extra count] -2 inSection:0]] withRowAnimation:UITableViewRowAnimationLeft];
                [self.tableView endUpdates];
            }];
            UIAlertAction* integerAction = [UIAlertAction actionWithTitle:@"Integer" style:UIAlertActionStyleDefault handler:^(UIAlertAction* action) {
                
                isChoosed = YES;
                delegate.isChanged = YES;
                NSNumber* v = [NSNumber numberWithInt:0];
                [self.extra insertObject:v atIndex:index];
                //[self.dictionary writeToFile:delegate.temFilePath atomically:YES];
                
                [self.tableView beginUpdates];
                [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForItem:[self.extra count] -2 inSection:0]] withRowAnimation:UITableViewRowAnimationLeft];
                [self.tableView endUpdates];
            }];
            UIAlertAction* arrayAction = [UIAlertAction actionWithTitle:@"Array" style:UIAlertActionStyleDefault handler:^(UIAlertAction* action) {
                
                isChoosed = YES;
                delegate.isChanged = YES;
                NSMutableArray* v = [[NSMutableArray alloc] init];
                [self.extra insertObject:v atIndex:index];
                //[self.dictionary writeToFile:delegate.temFilePath atomically:YES];
                
                [self.tableView beginUpdates];
                [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForItem:[self.extra count] -2 inSection:0]] withRowAnimation:UITableViewRowAnimationLeft];
                [self.tableView endUpdates];
            }];
            UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
            
            [alertController addAction:booleanAction];
            [alertController addAction:stringAction];
            [alertController addAction:integerAction];
            [alertController addAction:arrayAction];
            [alertController addAction:cancelAction];
            
            [self presentViewController:alertController animated:YES completion:nil];
            
        }
    }
    //正常的点击
    else {
        
        UITableViewCell* cell = [self.tableView cellForRowAtIndexPath:indexPath];
        
        NSString* type = cell.detailTextLabel.text;
        UIViewController* view = nil;
        
        if ([type isEqualToString:BOOLEAN_STR]) {
            
            view = [[CheckViewController alloc] initWithStyle:UITableViewStyleGrouped];
            [view setValue:cell.textLabel.text forKey:@"keyLabel"];
            [view setValue:self.keyPath forKey:@"keyPath"];
            [view setValue:[[self.extra objectAtIndex:indexPath.row] boolValue]== YES ? TRUE_STR : FALSE_STR forKey:@"keyValue"];
            [view setValue:self.extra forKey:@"extra"];
            [view setValue:self.dictionary forKey:@"dictionary"];
            [view setValue:[NSNumber numberWithInt:(int)indexPath.row] forKey:@"index"];
            
        }
        else if ([type isEqualToString:STRING_STR] || [type isEqualToString:INTEGER]) {
            
            view = [[TextViewController alloc] initWithStyle:UITableViewStyleGrouped];
            [view setValue:cell.textLabel.text forKey:@"keyLabel"];
            [view setValue:self.keyPath forKey:@"keyPath"];
            [view setValue:type forKey:@"control"];
            [view setValue:[[self.extra objectAtIndex:indexPath.row] description] forKey:@"keyValue"];
            [view setValue:self.extra forKey:@"extra"];
            [view setValue:self.dictionary forKey:@"dictionary"];
            [view setValue:[NSNumber numberWithInt:(int)indexPath.row] forKey:@"index"];
            
        }
        else if ([type isEqualToString:ARRAY_STR]) {
            
            view = [[ConfigOutListViewController alloc] initWithStyle:UITableViewStyleGrouped];
            [view setValue:cell.textLabel.text forKey:@"keyLabel"];
            [view setValue:self.keyPath forKey:@"keyPath"];
            [view setValue:[self.extra objectAtIndex:indexPath.row] forKey:@"extra"];
            [view setValue:self.dictionary forKey:@"dictionary"];
        }
        if (view != nil) {
            
            [self.navigationController pushViewController:view animated:YES];
        }
    }
}

//tab切换过来的时候，会执行
- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:NO];

    [self.tableView reloadData];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        if (isEditPressed) {
            delegate.isChanged = YES;
            [self.extra removeObjectAtIndex:indexPath.row];
            [self.tableView beginUpdates];
            [self.tableView deleteRowsAtIndexPaths:@[[NSIndexPath indexPathForItem:indexPath.row inSection:0]] withRowAnimation:UITableViewRowAnimationAutomatic];
            [self.tableView endUpdates];
        }
    }
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    if (indexPath.row == [self.extra count] - 1) {
        
        return UITableViewCellEditingStyleInsert;
    }
    return UITableViewCellEditingStyleDelete;
    
}

- (void)insertAtLastPosition {
    
    [self.extra addObject:@""];
    [self.tableView beginUpdates];
    [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForItem:[self.extra count] -1 inSection:0]] withRowAnimation:UITableViewRowAnimationLeft];
    [self.tableView endUpdates];
}
- (void)deleteLastPosition {
    
    [self.extra removeLastObject];
    [self.tableView beginUpdates];
    [self.tableView deleteRowsAtIndexPaths:@[[NSIndexPath indexPathForItem:[self.extra count] inSection:0]] withRowAnimation:UITableViewRowAnimationLeft];
    [self.tableView endUpdates];
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return YES;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section == 0) {
        return [self.extra count];
    }
    return 0;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    if (section == 0) {
        return self.keyLabel;
    }
    return @"Related keys:";
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section
{
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    if (section == 0) {
        [header.textLabel setText:self.keyLabel];
    }
    else {
        [header.textLabel setText:@"Related keys:"];
    }
    
}



@end
