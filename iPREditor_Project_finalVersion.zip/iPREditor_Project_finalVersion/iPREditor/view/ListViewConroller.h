//
//  ListViewConroller.h
//  iPREditor
//
//  Created by admin on 11/12/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListViewConroller : UITableViewController

@property (nonatomic,copy) NSString* keyLabel;
@property (nonatomic,copy) NSString* keyPath;
@property (nonatomic,copy) NSString* keyValue;
@property (nonatomic,strong) NSString* type;
@property (nonatomic,retain) NSMutableDictionary* dictionary;

@end
