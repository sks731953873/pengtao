//
//  PreviewViewController.h
//  iPREditor
//
//  Created by leslie on 15/11/20.
//  Copyright (c) 2015年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PreviewSearchView : UITextView<UIScrollViewDelegate>

#pragma mark - Configuration


@property (strong, nonatomic) UIColor *primaryHighlightColor;


@property (strong, nonatomic) UIColor *secondaryHighlightColor;


@property (nonatomic) CGFloat highlightCornerRadius;


@property (nonatomic) BOOL highlightSearchResults;


@property (nonatomic) NSUInteger maxHighlightedMatches;


@property (nonatomic) NSTimeInterval scrollAutoRefreshDelay;


@property (nonatomic, readonly) NSRange rangeOfFoundString;

@property (retain, nonatomic)NSMutableArray *highlightsForArray;

@property (nonatomic)BOOL isRecover;

#pragma mark - Methods

#pragma mark -- Search --


- (NSString *)foundString;


- (void)resetSearch;


- (BOOL)scrollToMatch:(NSString *)pattern;
- (BOOL)scrollToMatch:(NSString *)pattern searchOptions:(NSRegularExpressionOptions)options;
- (BOOL)scrollToMatch:(NSString *)pattern searchOptions:(NSRegularExpressionOptions)options range:(NSRange)range back:(BOOL)isBack;


- (BOOL)scrollToString:(NSString *)stringToFind;
- (BOOL)scrollToString:(NSString *)stringToFind searchOptions:(NSRegularExpressionOptions)options back:(BOOL)isBack;
- (BOOL)scrollToString:(NSString *)stringToFind searchOptions:(NSRegularExpressionOptions)options range:(NSRange)range back:(BOOL)isBack;





#pragma mark -- Misc --


- (void)scrollRangeToVisible:(NSRange)range consideringInsets:(BOOL)considerInsets;

- (void)scrollRectToVisible:(CGRect)rect animated:(BOOL)animated consideringInsets:(BOOL)considerInsets;

- (NSRange)visibleRangeConsideringInsets:(BOOL)considerInsets;

- (NSRange)visibleRangeConsideringInsets:(BOOL)considerInsets startPosition:(UITextPosition *__autoreleasing *)startPosition endPosition:(UITextPosition *__autoreleasing *)endPosition;

- (CGRect)visibleRectConsideringInsets:(BOOL)considerInsets;

@end

