//
//  PopUpViewController.m
//  iPREditor
//
//  Created by admin on 11/11/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "PopUpViewController.h"
#import "PlistTool.h"
#import "TreeNode.h"
#import "CustomMessTool.h"
#import "AppDelegate.h"

@implementation PopUpViewController


PlistTool* tool;
BOOL isEdit;
int selectedIndex;

//解决重用显示问题而设
NSString* selectedValue;

BOOL isOriginEmpty;
BOOL isDonePressed;

NSArray* relationArray;
int sectionCount;
BOOL relationSectionHasShow;
int lastRelationSectionRowCount;
AppDelegate* delegate;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    delegate = [UIApplication sharedApplication].delegate;
    tool = [PlistTool instance];
    isEdit = NO;
    selectedIndex = -1;
    selectedValue = [self.keyValue mutableCopy];
    
    isOriginEmpty = YES;
    sectionCount = 1;
    relationSectionHasShow = NO;
    lastRelationSectionRowCount = -1;
    
    if ([self.keyValue isEqualToString:@""] == NO) {
        isOriginEmpty = NO;
        if ([self.choice containsObject:self.keyValue] == NO) {
            [self.choice insertObject:self.keyValue atIndex:0];
        }
    }
    
    UIBarButtonItem* edit = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editClicked:)];
    self.navigationItem.rightBarButtonItem = edit;
}

- (void)editClicked: (id)sender {
    
    if ([[sender title] isEqualToString:@"Edit"]) {

        isEdit = YES;
        for (int i = 0; i < self.choice.count; i++) {
            NSIndexPath* path = [NSIndexPath indexPathForRow:i inSection:0];
            [self.tableView cellForRowAtIndexPath:path].textLabel.textColor = [UIColor blackColor];
        }
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addClicked:)];
        self.navigationItem.rightBarButtonItem.title = @"Done";
    }
    //点击的是Done
    else {
        
        isDonePressed = YES;
    
        //有关联关系时，需要弹出确认对话框
        if (sectionCount > 1) {
            
            [self showConfirm];
        }
        else {
            
            [self save:NO];
        }
    }
    
}


- (void)showConfirm {

    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:@"Related keys exists" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    
    NSMutableParagraphStyle* ps = [[NSMutableParagraphStyle alloc] init];
    [ps setAlignment:NSTextAlignmentCenter];
    NSDictionary* attribs = @{NSParagraphStyleAttributeName:ps};
    
    NSMutableAttributedString *attributedText =[[NSMutableAttributedString alloc] initWithString:@"Yes: Modify current key and related key          \nNo:Just modify current key" attributes:attribs];
    UIAlertAction* yesAction = [UIAlertAction actionWithTitle:@"Yes"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction *action){
                                                          //add code to make something happen once tapped
                                                          if (isDonePressed) {
                                                              [self save:YES];
                                                          }
                                                      }];
    UIAlertAction* noAction = [UIAlertAction actionWithTitle:@"No"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction *action){
                                                         //add code to make something happen once tapped
                                                         [self save:NO];
                                                     }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
    
    [alertController addAction:yesAction];
    [alertController addAction:noAction];
    [alertController addAction:cancelAction];
    
    [alertController setValue:attributedText forKey:@"attributedMessage"];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
    
}

- (void)addClicked: (id) sender {
    
    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:@"Add new value" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction* okAction = [UIAlertAction actionWithTitle:@"Confirm" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
        UITextField* value = alertController.textFields.firstObject;
        
        [self.choice insertObject:value.text atIndex:self.choice.count];
        [self.tableView beginUpdates];
        [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:self.choice.count - 1 inSection:0]] withRowAnimation:UITableViewRowAnimationAutomatic];
        [self.tableView endUpdates];
        

    }];
    [alertController addAction:cancelAction];
    [alertController addAction:okAction];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField){
        textField.placeholder = @"input new value";
    }];

    [self presentViewController:alertController animated:YES completion:nil];
    
    
}

- (void)save: (BOOL)saveRelation {
    
    selectedIndex = [self getSelectedIndex];
    
    //初始是空的话,只处理有选择的情况
    if (isOriginEmpty) {
        
        if (selectedIndex != - 1) {
            //需要保存
            if ([self.choice[selectedIndex] isEqualToString:self.keyValue] == NO) {
                
                delegate.isChanged = YES;
                
                NSArray* keys = [self.keyPath componentsSeparatedByString:@"."];
                
                id node = self.dictionary;
                id lastNode = node;
                for (int i = 0; i < keys.count - 1; i++) {
                    
                    node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                    
                    //如果key不存在，需要创建
                    if (!node) {
                        NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                        [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                        node = tem;
                    }
                    lastNode = node;
                }
                
                [tool setValue:self.choice[selectedIndex] forKey:[keys lastObject] inDictionary:node recursion:NO];
                
                if (saveRelation) {
                    //保存relationArray
                    [self saveRelationArray];
                }
                self.keyValue = self.choice[selectedIndex];
                isOriginEmpty = NO;
                [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
            }
        }
    }
    //刚开始不为空。
    else {
        
        NSString* result = @"";
        
        //NSLog(@"%d",selectedIndex);
        //选了值
        if (selectedIndex != -1) {
            
            //点了Yes,需要保存当前值和关联值
            if (saveRelation) {
                
                delegate.isChanged = YES;
                
                result = self.choice[selectedIndex];
                
                NSArray* keys = [self.keyPath componentsSeparatedByString:@"."];
                
                id node = self.dictionary;
                id lastNode = node;
                
                for (int i = 0; i < keys.count - 1; i++) {
                    
                    node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                    
                    //如果key不存在，需要创建
                    if (!node) {
                        NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                        [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                        node = tem;
                    }
                    lastNode = node;
                }
                
                [tool setValue:result forKey:[keys lastObject] inDictionary:node recursion:NO];
                //保存relationArray
                [self saveRelationArray];
                self.keyValue = self.choice[selectedIndex];
                //NSLog(@"save relation");
                [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
                
            }
            //点了No,只需要保存当前值
            else {
                
                //不相等时
                if ([self.choice[selectedIndex] isEqualToString:self.keyValue] == NO) {
                    
                    result = self.choice[selectedIndex];
                    
                    delegate.isChanged = YES;
                    
                    NSArray* keys = [self.keyPath componentsSeparatedByString:@"."];
                    
                    id node = self.dictionary;
                    id lastNode = node;
                    
                    for (int i = 0; i < keys.count - 1; i++) {
                        
                        node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                        
                        //如果key不存在，需要创建
                        if (!node) {
                            NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                            [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                            node = tem;
                        }
                        lastNode = node;
                    }
                    
                    [tool setValue:result forKey:[keys lastObject] inDictionary:node recursion:NO];
                    self.keyValue = self.choice[selectedIndex];
                    //NSLog(@"no save relation");
                    [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
                }
                
            }
        }
        //设选值
        else {
            
            delegate.isChanged = YES;
            
            NSArray* keys = [self.keyPath componentsSeparatedByString:@"."];
            
            id node = self.dictionary;
            id lastNode = node;
            
            for (int i = 0; i < keys.count - 1; i++) {
                
                node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                
                //如果key不存在，需要创建
                if (!node) {
                    NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                    [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                    node = tem;
                }
                lastNode = node;
            }
            
            [tool setValue:result forKey:[keys lastObject] inDictionary:node recursion:NO];
            self.keyValue = @"";
            [self.dictionary writeToFile:delegate.temFilePath atomically:YES];
        }
    }
    isEdit = NO;
    for (int i = 0; i < self.choice.count; i++) {
        NSIndexPath* path = [NSIndexPath indexPathForRow:i inSection:0];
        [self.tableView cellForRowAtIndexPath:path].textLabel.textColor = [UIColor grayColor];
    }
    
    [self.tableView setEditing:NO animated:YES];
    self.navigationItem.leftBarButtonItem = NULL;
    self.navigationItem.rightBarButtonItem.title = @"Edit";
}


#pragma - UITableView
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* cellId = @"pop_up_view_id";
    
    UITableViewCell* cell = [self.tableView dequeueReusableCellWithIdentifier:cellId];
    //UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
    }
    else {
        
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.textLabel.textColor = [UIColor blackColor];
        
    }
    if (indexPath.section == 0) {
        
        selectedValue = (selectedIndex >=0 ? self.choice[selectedIndex] : selectedValue);
        
            if ([selectedValue isEqualToString:[self.choice objectAtIndex:indexPath.row]]) {
                cell.accessoryType = UITableViewCellAccessoryCheckmark;
                selectedIndex = (int)indexPath.row;
                
            }
            if (isEdit == NO) {
                cell.textLabel.textColor = [UIColor grayColor];
            }
            cell.textLabel.adjustsFontSizeToFitWidth = YES;
            cell.textLabel.minimumScaleFactor = 9.0/[UIFont labelFontSize];
        
            cell.textLabel.text = [self.choice objectAtIndex:indexPath.row];
    }
    else {
        
        cell.textLabel.adjustsFontSizeToFitWidth = YES;
        cell.textLabel.minimumScaleFactor = 9.0/[UIFont labelFontSize];
        cell.textLabel.text = [[relationArray objectAtIndex:indexPath.row] keyPath];
        
        //显示current value
        if (indexPath.section == 1) {
            id lastNode = [CustomMessTool gimmeLastNode:[[relationArray objectAtIndex:indexPath.row] keyPath] inDictionary:self.dictionary];
            
            if (lastNode == nil) {
                cell.detailTextLabel.text = NIL_STR;
            }
            else {
                if ([BLN_SET containsObject:NSStringFromClass([lastNode class])]) {
                    cell.detailTextLabel.text = [lastNode boolValue] ? TRUE_STR : FALSE_STR;
                }
                else {
                    cell.detailTextLabel.text = [lastNode description];
                }
            }
            
        }
        //显示expected value
        else {
            id value = [[relationArray objectAtIndex:indexPath.row] extra];
            if ([BLN_SET containsObject:NSStringFromClass([value class])]) {
                cell.detailTextLabel.text = [value boolValue] ? TRUE_STR : FALSE_STR;
            }
            else {
                cell.detailTextLabel.text = [[relationArray objectAtIndex:indexPath.row] extra];
            }
        }
    }
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return sectionCount;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section == 0) {
        return self.choice.count;
    }
    return relationArray.count;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    if (section == 0) {
        return self.keyLabel;
    }
    else if (section == 1) {
        return @"Current Related key value:";
    }
    return @"Expected Related key value:";
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section
{
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    if (section == 0) {
        [header.textLabel setText:self.keyLabel];
    }
    else if (section == 1){
        [header.textLabel setText:@"Current Related key value:"];
    }
    else {
        [header.textLabel setText:@"Expected Related key value:"];
    }
}

- (void)showRelation {
    //显示关联部分
    if (selectedIndex != -1) {
        
        NSString* keyPath= self.keyPath;
        
        NSString* product = [CustomMessTool getProduct:@"FactoryDocControl.PRODUCT" inDictionary:self.dictionary];
        relationArray = [CustomMessTool getRelation:keyPath withValue:self.choice[selectedIndex] andProduct:product];
        
        if (relationArray.count > 0) {
            //第一次显示出来
            if (relationSectionHasShow == NO) {
                
                //显示current
                sectionCount = sectionCount + 2;
                NSMutableIndexSet *idxSet = [[NSMutableIndexSet alloc] init];
                [idxSet addIndex:1];
                [idxSet addIndex:2];
                [self.tableView beginUpdates];
                [self.tableView insertSections:idxSet withRowAnimation:UITableViewRowAnimationFade];
                
                for (int i = 0 ; i < relationArray.count; i++) {
                    
                    NSIndexPath* currentPath = [NSIndexPath indexPathForRow:i inSection:1];
                     NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:i inSection:2];
                    
                    [self.tableView insertRowsAtIndexPaths:@[currentPath,expectedPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                }
                
                lastRelationSectionRowCount = (int)relationArray.count;
                [self.tableView endUpdates];
                relationSectionHasShow = YES;
            }
            //后面的需要改值
            else {
                //当前关联数组与上一次的长度一样的话,只需改值
                if (relationArray.count == lastRelationSectionRowCount) {
                    
                    for (int i = 0 ; i < relationArray.count; i++) {
                        
                        //修改current
                        NSIndexPath* currentPath = [NSIndexPath indexPathForRow:i inSection:1];
                        UITableViewCell* currentCell = [self.tableView cellForRowAtIndexPath:currentPath];
                        currentCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                        id lastNode = [CustomMessTool gimmeLastNode:[[relationArray objectAtIndex:i] keyPath] inDictionary:self.dictionary];
                        if (lastNode == nil) {
                            currentCell.detailTextLabel.text = NIL_STR;
                        }
                        else {
                            if ([BLN_SET containsObject:NSStringFromClass([lastNode class])]) {
                                currentCell.detailTextLabel.text = [lastNode boolValue] ? TRUE_STR : FALSE_STR;
                            }
                            else {
                                currentCell.detailTextLabel.text = [lastNode description];
                            }
                        }
                        
                        //修改expected
                        NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:i inSection:2];
                        UITableViewCell* expectedCell = [self.tableView cellForRowAtIndexPath:expectedPath];
                        id value = [[relationArray objectAtIndex:i] extra];
                        expectedCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                        if ([BLN_SET containsObject:NSStringFromClass([value class])]) {
                            
                            expectedCell.detailTextLabel.text = [value boolValue] ? TRUE_STR : FALSE_STR;
                        }
                        else {
                            
                            expectedCell.detailTextLabel.text = [[relationArray objectAtIndex:i] extra];
                        }
                    }
                }
                //当前关联数组长度 > 上次的话，需要在表格上插入新的行
                else if (relationArray.count > lastRelationSectionRowCount) {
                    
                    //先修改
                    int i = 0;
                    for (; i < lastRelationSectionRowCount; i++) {
                        
                        //修改current
                        NSIndexPath* currentPath = [NSIndexPath indexPathForRow:i inSection:1];
                        UITableViewCell* currentCell = [self.tableView cellForRowAtIndexPath:currentPath];
                        currentCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                        id lastNode = [CustomMessTool gimmeLastNode:[[relationArray objectAtIndex:i] keyPath] inDictionary:self.dictionary];
                        if (lastNode == nil) {
                            currentCell.detailTextLabel.text = NIL_STR;
                        }
                        else {
                            if ([BLN_SET containsObject:NSStringFromClass([lastNode class])]) {
                                currentCell.detailTextLabel.text = [lastNode boolValue] ? TRUE_STR : FALSE_STR;
                            }
                            else {
                                currentCell.detailTextLabel.text = [lastNode description];
                            }
                        }
                        
                        //修改expected
                        NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:i inSection:2];
                        UITableViewCell* expectedCell = [self.tableView cellForRowAtIndexPath:expectedPath];
                        id value = [[relationArray objectAtIndex:i] extra];
                        expectedCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                        if ([BLN_SET containsObject:NSStringFromClass([value class])]) {
                            
                            expectedCell.detailTextLabel.text = [value boolValue] ? TRUE_STR : FALSE_STR;
                        }
                        else {
                            
                            expectedCell.detailTextLabel.text = [[relationArray objectAtIndex:i] extra];
                        }
                    }
                    //后添加行
                    for (; i < relationArray.count; i++) {
                        
                        NSIndexPath* currentPath = [NSIndexPath indexPathForRow:i inSection:1];
                        NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:i inSection:2];
                        [self.tableView insertRowsAtIndexPaths:@[currentPath,expectedPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                    }
                    lastRelationSectionRowCount = (int)relationArray.count;
                }
                //当前关联数组长度 < 上次的话，需要在表格上删除行
                else {
                    //先修改
                    int i = 0;
                    for (; i < relationArray.count; i++) {
                        
                        //修改current
                        NSIndexPath* currentPath = [NSIndexPath indexPathForRow:i inSection:1];
                        UITableViewCell* currentCell = [self.tableView cellForRowAtIndexPath:currentPath];
                        currentCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                        id lastNode = [CustomMessTool gimmeLastNode:[[relationArray objectAtIndex:i] keyPath] inDictionary:self.dictionary];
                        if (lastNode == nil) {
                            currentCell.detailTextLabel.text = NIL_STR;
                        }
                        else {
                            if ([BLN_SET containsObject:NSStringFromClass([lastNode class])]) {
                                currentCell.detailTextLabel.text = [lastNode boolValue] ? TRUE_STR : FALSE_STR;
                            }
                            else {
                                currentCell.detailTextLabel.text = [lastNode description];
                            }
                        }
                        
                        //修改expected
                        NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:i inSection:2];
                        UITableViewCell* expectedCell = [self.tableView cellForRowAtIndexPath:expectedPath];
                        id value = [[relationArray objectAtIndex:i] extra];
                        expectedCell.textLabel.text = [[relationArray objectAtIndex:i] keyPath];
                        if ([BLN_SET containsObject:NSStringFromClass([value class])]) {
                            
                            expectedCell.detailTextLabel.text = [value boolValue] ? TRUE_STR : FALSE_STR;
                        }
                        else {
                            
                            expectedCell.detailTextLabel.text = [[relationArray objectAtIndex:i] extra];
                        }
                    }
                    //后删除
                    //后添加行
                    int j = i;
                    for (; i < lastRelationSectionRowCount; i++) {
                        
                        NSIndexPath* currentPath = [NSIndexPath indexPathForRow:j inSection:1];
                        NSIndexPath* expectedPath = [NSIndexPath indexPathForRow:j inSection:2];
                        [self.tableView deleteRowsAtIndexPaths:@[currentPath,expectedPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                    }
                    lastRelationSectionRowCount = (int)relationArray.count;
                }
                
            }
        }
        else {
            //NSLog(@"in it");
            if (relationSectionHasShow == YES) {
                sectionCount = sectionCount - 2;
                NSMutableIndexSet *idxSet = [[NSMutableIndexSet alloc] init];
                [idxSet addIndex:1];
                [idxSet addIndex:2];
                [self.tableView beginUpdates];
                [self.tableView deleteSections:idxSet withRowAnimation:UITableViewRowAnimationFade];
                [self.tableView endUpdates];
                relationSectionHasShow = NO;
            }
        }
    }
    //selectedIndex = -1 时，需要把section删除
    else {
        
        if (relationSectionHasShow) {
            sectionCount = 1;
            lastRelationSectionRowCount = -1;
            NSMutableIndexSet *idxSet = [[NSMutableIndexSet alloc] init];
            [idxSet addIndex:1];
            [idxSet addIndex:2];
            [self.tableView beginUpdates];
            [self.tableView deleteSections:idxSet withRowAnimation:UITableViewRowAnimationFade];
            [self.tableView endUpdates];
            
            relationSectionHasShow = NO;
        }
        
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 0) {
        
        if (isEdit) {
            
            for (int i = 0; i < self.choice.count; i++) {
                NSIndexPath* path = [NSIndexPath indexPathForRow:i inSection:0];
                if (i != indexPath.row) {
                    [self.tableView cellForRowAtIndexPath:path].accessoryType = UITableViewCellAccessoryNone;
                }
                else {
                    if ([self.tableView cellForRowAtIndexPath:path].accessoryType == UITableViewCellAccessoryCheckmark) {
                        [self.tableView cellForRowAtIndexPath:path].accessoryType = UITableViewCellAccessoryNone;
                        selectedIndex = -1;
                    }
                    else {
                        [self.tableView cellForRowAtIndexPath:path].accessoryType = UITableViewCellAccessoryCheckmark;
                        selectedIndex = (int)indexPath.row;
                    }
                }
            }
            [self showRelation];
            
        }
    }

}

//得到所选值
- (int)getSelectedIndex {
    
    for (int i = 0; i < self.choice.count; i++) {
        
         NSIndexPath* path = [NSIndexPath indexPathForRow:i inSection:0];
        
        if ([self.tableView cellForRowAtIndexPath:path].accessoryType == UITableViewCellAccessoryCheckmark) {
            
            return i;
        }
    }
    
    return -1;
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}

- (void)saveRelationArray {
    
    if (relationArray.count > 0) {
        
        for (TreeNode* relation in relationArray) {
            
            NSArray* keys = [relation.keyPath componentsSeparatedByString:@"."];
            
            id node = self.dictionary;
            id lastNode = node;
            for (int i = 0; i < keys.count - 1; i++) {
                
                node = [tool valueForKey:keys[i]  inDictionary:lastNode recursion:NO];
                
                //如果key不存在，需要创建
                if (!node) {
                    NSMutableDictionary* tem = [[NSMutableDictionary alloc] init];
                    [tool setValue:tem forKey:keys[i] inDictionary:lastNode recursion:NO];
                    node = tem;
                }
                lastNode = node;
            }
            [tool setValue:relation.extra forKey:[keys lastObject] inDictionary:node recursion:NO];
        }
    }
}


/*
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return UITableViewCellEditingStyleDelete | UITableViewCellEditingStyleInsert;
    //return UITableViewCellEditingStyleInsert;
}
 */


// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        if (isEdit) {
            
            [self.choice removeObjectAtIndex:indexPath.row];
            [self.tableView beginUpdates];
            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [self.tableView endUpdates];

        }
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
    }
}

- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath {
    return NO;
}


@end
