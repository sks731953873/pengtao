//
//  CustomMessTool.h
//  iPREditor
//
//  Created by admin on 11/13/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CustomMessTool : NSObject


//获取所有关联的key
+ (NSMutableArray*)getRelation: (NSString*)keyPath withValue: (id)value andProduct: (NSString*)product;

//获取产品
+ (NSString*)getProduct: (NSString*)keyPath inDictionary: (id)dictionary;

//获取最后的结点
+ (id)gimmeLastNode: (NSString*)keyPath inDictionary: (id)dictionary;

//获取类型
+ (NSString*)gimmeType: (id)node;

@end
