//
//  MainCellTableViewCell.h
//  iPREditor
//
//  Created by admin on 11/3/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TreeNode.h"

@interface SettingViewCell : UITableViewCell

@property (retain, nonatomic) UILabel* mainkeyLabel;
@property (retain, nonatomic) UILabel* subKeyLabel;
@property (retain, nonatomic) UILabel* subTypeLabel;
@property (retain, nonatomic) UIImageView* image;
@property (retain, nonatomic) UIImageView* bgImage;
@property (retain, nonatomic) UIImageView* imageLine;
@property (retain, nonatomic) UIButton* button;
@property (retain, nonatomic) UIButton* arrowButton;
@property (retain, nonatomic) UIImageView* arrowImage;

@property (retain, nonatomic) TreeNode* treeNode;

- (void)setIndention;

@end
