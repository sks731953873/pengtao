//
//  FXCheckBox.m
//  text
//
//  Created by jett on 15/11/24.
//  Copyright (c) 2015年 jett. All rights reserved.
//

#import "FXCheckBox.h"
#define ICON_WH 48


@implementation FXCheckBox

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.exclusiveTouch = YES;
        [self setImage:[UIImage imageNamed:@"check_off.png"] forState:UIControlStateNormal];
        [self setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateSelected];
        [self addTarget:self action:@selector(checkBoxCheck) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

-(void)setChecked:(BOOL)checked{
    if (_checked == checked) {
        return;
    }
    
    _checked = checked;
    self.selected = checked;
}

-(void)checkBoxCheck{
    self.selected = !self.selected;
    _checked = self.selected;
    if (_delegate ) {
        [_delegate didSelectCheckBox:self checked:self.checked];
    }
}

-(CGRect)imageRectForContentRect:(CGRect)contentRect{
    return CGRectMake(0, 0, ICON_WH, ICON_WH);
}

-(CGRect)titleRectForContentRect:(CGRect)contentRect{
    return CGRectZero;
}

@end