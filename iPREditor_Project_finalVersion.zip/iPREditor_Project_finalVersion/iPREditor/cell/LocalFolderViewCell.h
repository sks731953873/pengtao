//
//  LocalFolderViewCell.h
//  iPREditor
//
//  Created by admin on 12/2/15.
//  Copyright © 2015 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocalFolderViewCell : UITableViewCell

@end
