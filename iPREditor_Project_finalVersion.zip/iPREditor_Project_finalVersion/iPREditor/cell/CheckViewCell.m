//
//  CheckViewCell.m
//  iPREditor
//
//  Created by admin on 1/28/16.
//  Copyright © 2016 admin. All rights reserved.
//

#import "CheckViewCell.h"

@implementation CheckViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];

    //_checkBox = [[UIButton alloc] initWithFrame:CGRectMake(300, cell.textLabel.frame.origin.y+5, 30, 30)];
    _label = [[UILabel alloc] initWithFrame:CGRectMake(20, 5, 100, 30)];
    
    
    _checkBox = [[UIButton alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 70, 5, 30, 30)];
    [_checkBox setImage:[UIImage imageNamed:@"check_off.png"] forState:UIControlStateNormal];
    [_checkBox setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateSelected];
    
    [self.contentView addSubview:_checkBox];
    [self.contentView addSubview:_label];
    return self;
}

- (void)drawRect:(CGRect)rect {
    
    _checkBox.frame = CGRectMake(SCREEN_WIDTH - 70, 5, 30, 30);
    
}

-(void)recoverCheckBox {
    
    _checkBox = [[UIButton alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 70, 5, 30, 30)];
    [_checkBox setImage:[UIImage imageNamed:@"check_off.png"] forState:UIControlStateNormal];
    [_checkBox setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateSelected];
     _label = [[UILabel alloc] initWithFrame:CGRectMake(20, 5, 100, 30)];
    [self.contentView addSubview:_checkBox];
    [self.contentView addSubview:_label];
}

@end
