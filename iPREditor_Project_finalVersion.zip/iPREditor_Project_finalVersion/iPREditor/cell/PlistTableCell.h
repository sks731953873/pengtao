//
//  PlistTableCell.h
//  test
//
//  Created by jett on 15/11/6.
//  Copyright (c) 2015年 jett. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlistTableCell : UITableViewCell
typedef NS_ENUM(NSUInteger, CELLTYPE){
    cellwithoutsubtitle = 0,
    cellwithsubtitle = 1,
} ;

@property (nonatomic, strong) UILabel *mainkeyLable;
@property (nonatomic, strong) UILabel *subkeyLable;
@property (nonatomic, assign) BOOL isExpand;
@property (nonatomic, assign) BOOL isMainKey;


- (void) cellOfArrayWithItem;
- (void) cellWithoutAccessoryAndSubtitle;
- (void) cellWithAccessoryButWithoutSubtitle;
- (void) cellWithAccessoryAndSubtitle;
- (void) setCellAccessoryType:(UITableViewCellAccessoryType )accessoryType  withSubtitle:(CELLTYPE )type;
@end
