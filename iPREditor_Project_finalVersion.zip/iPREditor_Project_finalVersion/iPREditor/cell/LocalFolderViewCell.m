//
//  LocalFolderViewCell.m
//  iPREditor
//
//  Created by admin on 12/2/15.
//  Copyright © 2015 admin. All rights reserved.
//

#import "LocalFolderViewCell.h"

@implementation LocalFolderViewCell


- (BOOL)canBecomeFirstResponder{
    return YES;
}

@end
