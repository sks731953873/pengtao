//
//  BFColorPickerPopoverView.h
//  BFColorPickerPopover Demo
//
//  Created by Balázs Faludi on 07.08.12.
//  Copyright (c) 2012 Balázs Faludi. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface BFColorPickerPopoverView : NSView

@end


