//
//  main.m
//  NSPopover Message Category
//
//  Created by Michael Robinson on 11/03/12.
//  Copyright (c) 2012 Code of Interest. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
