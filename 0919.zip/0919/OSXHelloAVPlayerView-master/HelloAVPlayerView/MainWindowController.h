//
//  MainWindowController.h
//  HelloAVPlayerView
//
//  Created by Bear on 2014/5/18.
//  Copyright (c) 2014年 TakoBear. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DraggedAVPlayerView.h"

@interface MainWindowController : NSWindowController<DraggedAVPlayerViewDelagate>

@end
