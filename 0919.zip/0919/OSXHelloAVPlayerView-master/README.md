## Instruction

This is a simple video player application  of OS X.

The Tutorial is in TakoBear.tw

## Link

If you have any further problem, try to contact with 

takobearx@gmail.com or

[Shawn & Takobear] (http://www.takobear.tw/index.html)