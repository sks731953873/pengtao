//
//  MFPopoverContentViewController.m
//  StatusItemPopup
//
//  Created by Maxim Pervushin on 11/28/12.
//  Copyright (c) 2012 Maxim Pervushin. All rights reserved.
//

#import "MFPopoverContentViewController.h"

@interface MFPopoverContentViewController ()

@end

@implementation MFPopoverContentViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end
