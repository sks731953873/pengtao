//
//  MFAppDelegate.h
//  StatusItemPopup
//
//  Created by Maxim Pervushin on 11/28/12.
//  Copyright (c) 2012 Maxim Pervushin. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MFAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
