NSPopover-From-Status-Bar-Item
==============================

Sample application showing popover from status bar item.
