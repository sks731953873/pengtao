//
//  ViewController.m
//  setCommandTools
//
//  Created by mac on 2017/9/6.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
//

#import "ViewController.h"
#import "ORSSerialPort.h"
#import "GetTimeDay.h"


typedef void (^fixtureBlock)(NSString * backString);

@interface ViewController()<ORSSerialPortDelegate>
{
    IBOutlet NSButton      *  collectButton;   //按钮
    ORSSerialPort          *  fixtureSerial;   //治具串口
    NSMutableString        *  appendString;
    NSString               *  backStr;
    NSString               * outBackString;
    
    IBOutlet NSTextField *SN_TF;
    IBOutlet NSTextField *CP_TF;
    IBOutlet NSTextField *showFixtureCP_TF;
    IBOutlet NSTextField *upDateFixtureID_TF;
    IBOutlet NSTextField *showFixtureID_TF;
    IBOutlet NSTextField *successLable;
    BOOL  isReceive;
    NSThread * myThrad;
    
    int index ;
}

@property(nonatomic,copy)fixtureBlock  backBlock;

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    appendString = [[NSMutableString alloc]initWithCapacity:10];
    fixtureSerial=[ORSSerialPort serialPortWithPath:@"/dev/cu.usbserial-EW-FIX"];
    fixtureSerial.baudRate=@B115200;
    fixtureSerial.delegate=self;
    isReceive = NO;
    index = 1000;
    
     myThrad = [[NSThread alloc] initWithTarget:self selector:@selector(Working) object:nil];
    [myThrad start];

    

    // Do any additional setup after loading the view.
}



- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}



- (IBAction)openBtnAction:(id)sender {
    
    [fixtureSerial open];
    
    if ([fixtureSerial isOpen]) {
        
       [collectButton setTitle:@"Connect(连接)"];
    }
    else
    {
         [collectButton setTitle:@"DisConnect(断开)"];
    }
    
    
}



- (IBAction)set_ID_action:(id)sender {
    
    
    index = 0;
    
    

}




- (IBAction)update_ID_Action:(id)sender {
    
    
    index = 1;
    
    
}

- (IBAction)set_CP_Action:(id)sender {
    
    
    index = 2;
        
    
}









#pragma mark------------------串口代理方法
-(void)serialPort:(ORSSerialPort *)serialPort didReceiveData:(NSData *)data
{
    
    
    if (serialPort==fixtureSerial)
    {
         NSString* str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        [appendString appendString:str];
        
        if ([appendString containsString:@">>"]) {
            
            appendString =[NSMutableString stringWithString:@""];
        }
        
        if ([appendString containsString:@"Write Done"]) {
            
              isReceive = YES;
               appendString =[NSMutableString stringWithString:@""];
            
           
            
        }
        
        if ([appendString containsString:@"*_*"]) {
            
              isReceive = YES;
            
           }
        
        
    }
}


#pragma mark--------------------ORSSerialPort串口中发送指令
-(void)Fixture:(ORSSerialPort *)serialPort writeCommand:(NSString *)command
{
    NSString * commandString =[NSString stringWithFormat:@"%@\r\n",command];
    NSData    * data =[commandString dataUsingEncoding:NSUTF8StringEncoding];
    [serialPort sendData:data];
}




#pragma  mark----------循环等待，直到数据有返回
-(void)whileLoopTest
{
    
    while (!isReceive) {
        
        sleep(0.001);
        
        if (isReceive) {
            break;
        }
    }
    
    isReceive = NO;
    
}


#pragma  mark----------获取返回的数值
-(NSString *)getValueFromFixture_SendCommand:(NSString *)str
{
    NSString  * value;
    
    [self Fixture:fixtureSerial writeCommand:str];
    isReceive = NO;
    [self whileLoopTest];
    
    
    NSLog(@"打印当前的返回值%@",appendString);
    
    if([appendString containsString:@"\r\n"]){
        
        value = [[appendString componentsSeparatedByString:@"\r\n"] objectAtIndex:1];
        
    }
    appendString =[NSMutableString stringWithString:@""];
    
    return value;
}


-(void)Working
{
    
    
    while ([[NSThread currentThread] isCancelled]==NO) //线程未结束一直处于循环状态
    {
        
        //设置fixtureID的值
        if (index ==0)
        {
            
            if ([fixtureSerial isOpen]) {
                
                NSString  * timeString =[[GetTimeDay shareInstance] getFixtureTime];
                
                NSString   *  commandString = [NSString stringWithFormat:@"setFixtureID %@.%@",timeString,SN_TF.stringValue];

                if ([SN_TF.stringValue length] !=4) {
                    
                    
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        successLable.stringValue =@"SN 输入有误";
                        successLable.backgroundColor = [NSColor redColor];
                        [showFixtureID_TF setStringValue:@""];
                        
                    });
                    
                    
                }
                else
                {
                    //存储在沙盒中
                    [[NSUserDefaults standardUserDefaults] setObject:SN_TF.stringValue forKey:@"SN"];

                    //写入当前的值
                    [self Fixture:fixtureSerial writeCommand:commandString];
                    [self whileLoopTest];
                    //获取当前
                     NSString   * FixtureID_String = [self getValueFromFixture_SendCommand:@"Fixture ID?"];
                     NSLog(@"%@",FixtureID_String);
                
                   //刷新界面
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        [showFixtureID_TF setStringValue:FixtureID_String];
                        
                        index = 1000;
                        
                    });
 
               }
            }
            else
            {
                
                [showFixtureID_TF setStringValue:@"fixture disConnect!!!!!"];
                
            }
            
            

            
        }
        
        //更新fixtureID的值
        if (index ==1)
        {
            if ([fixtureSerial isOpen]) {
                
                NSString  * timeString =[[GetTimeDay shareInstance] getFixtureTime];
                
                //从沙盒中得到SN
                
                NSString  *  SN = [[NSUserDefaults standardUserDefaults] objectForKey:@"SN"];
                
                NSString   *  commandString = [NSString stringWithFormat:@"setFixtureID %@.%@",timeString,SN];
                
                //写入当前的值
                [self Fixture:fixtureSerial writeCommand:commandString];
                [self whileLoopTest];
                //获取当前
                NSString   * FixtureID_String = [self getValueFromFixture_SendCommand:@"Fixture ID?"];
                NSLog(@"%@",FixtureID_String);
                
                //刷新界面
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [upDateFixtureID_TF setStringValue:FixtureID_String];
                    
                     index = 1000;
                });
            }
            else
            {
                
                [showFixtureID_TF setStringValue:@"fixture disConnect!!!!!"];
                
            }
            
            
            
        }
        
        
        //同时更新CP和fixtureID
        if (index ==2)
        {
            
            if ([CP_TF.stringValue length]!=0&&[CP_TF.stringValue length]<=6) {
                
                NSString   *  commandString = [NSString stringWithFormat:@"setFixture_CP %@",CP_TF.stringValue];
                //写入当前的值
                [self Fixture:fixtureSerial writeCommand:commandString];
                
                [self whileLoopTest];
                
                //获取当前的CP值
                NSString   * CP_String = [self getValueFromFixture_SendCommand:@"Fixture_CP?"];
                
                
                NSString  * timeString =[[GetTimeDay shareInstance] getFixtureTime];
                //从沙盒中得到SN
                NSString  *  SN = [[NSUserDefaults standardUserDefaults] objectForKey:@"SN"];
                NSString   *  command = [NSString stringWithFormat:@"setFixtureID %@.%@",timeString,SN];
                //写入当前的值
                [self Fixture:fixtureSerial writeCommand:command];
                sleep(1);
                //获取当前
                NSString   * FixtureID_String = [self getValueFromFixture_SendCommand:@"Fixture ID?"];
                
                
                NSLog(@"%@",FixtureID_String);
                
                //刷新界面
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [upDateFixtureID_TF setStringValue:FixtureID_String];
                    [showFixtureCP_TF setStringValue:CP_String];
                    
                     index = 1000;
                    
                    
                });
                
                
            }
            
            else{//直接提示输入有误
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    successLable.stringValue =@"CP 输入有误";
                    successLable.backgroundColor = [NSColor redColor];
                    
                });
                
            }

            
            
        }
        
        //index = 1000;
        if (index == 1000) {
            
            sleep(0.01);
        };
        
    
    }
   
    
    
}



@end
