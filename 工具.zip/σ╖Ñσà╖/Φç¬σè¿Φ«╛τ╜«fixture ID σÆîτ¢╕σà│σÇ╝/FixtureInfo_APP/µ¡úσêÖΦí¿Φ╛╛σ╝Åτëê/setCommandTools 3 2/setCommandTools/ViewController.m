//
//  ViewController.m
//  setCommandTools
//
//  Created by mac on 2017/9/6.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
//cp:10.520
//id:170907150016.1111

#import "ViewController.h"
#import "ORSSerialPort.h"
#import "GetTimeDay.h"


typedef void (^fixtureBlock)(NSString * backString);

@interface ViewController()<ORSSerialPortDelegate>
{
    IBOutlet NSButton      *  collectButton;   //按钮
    ORSSerialPort          *  fixtureSerial;   //治具串口
    NSMutableString        *  appendString;
    NSString               *  backStr;
    NSString               * outBackString;
    
    IBOutlet NSTextField *SN_TF;
    IBOutlet NSTextField *CP_TF;
    IBOutlet NSTextField *showFixtureCP_TF;
    IBOutlet NSTextField *upDateFixtureID_TF;
    IBOutlet NSTextField *showFixtureID_TF;
    IBOutlet NSTextField *successLable;
    
    int index;
}

@property(nonatomic,copy)fixtureBlock  backBlock;

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    appendString = [[NSMutableString alloc]initWithCapacity:10];
    fixtureSerial=[ORSSerialPort serialPortWithPath:@"/dev/cu.usbserial-EW-FIX"];
    fixtureSerial.baudRate=@B115200;
    fixtureSerial.delegate=self;

    
    index = 0;
    
    
    NSString  * string = @"jdflakjfklaf?1222.222*jdsjajkdsada";
    
    NSArray  * arr = [self parseTxt:string];
    
    NSLog(@"arr:===== %@",arr);
    
    
    
//    NSString* txt = @"seFixture_CP12.347EraseDoneWriteDoneFixture_CP?12.347*_*";
//    
//    NSArray* arr = [self parseTxt:txt];
//    
//    NSLog(@"arr: %@", arr);
    
    // Do any additional setup after loading the view.
}



- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}



- (IBAction)openBtnAction:(id)sender {
    
    [fixtureSerial open];
    
    if ([fixtureSerial isOpen]) {
        
       [collectButton setTitle:@"Connect(连接)"];
    }
    else
    {
         [collectButton setTitle:@"DisConnect(断开)"];
    }
    
    
}



- (IBAction)set_ID_action:(id)sender {
    
    index = 3;
    if ([fixtureSerial isOpen]) {
        
        
        NSString  * timeString =[[GetTimeDay shareInstance] getFixtureTime];
        
        NSString   *  commandString = [NSString stringWithFormat:@"setFixtureID %@.%@",timeString,SN_TF.stringValue];
        
        if ([SN_TF.stringValue length] !=4) {
            
            successLable.stringValue =@"fail";
            successLable.backgroundColor = [NSColor redColor];
            [showFixtureID_TF setStringValue:@""];
            
        }
        else
        {
            //存储在沙盒中
            [[NSUserDefaults standardUserDefaults] setObject:SN_TF.stringValue forKey:@"SN"];
            
            //写入当前的值
            [self Fixture:fixtureSerial writeCommand:commandString];
            
            
            
            sleep(1);
            //读取当前的值
            [self Fixture:fixtureSerial writeCommand:@"Fixture ID?"];
            
            dispatch_queue_t  queue = dispatch_queue_create("test", NULL);
            
            dispatch_async(queue, ^{
                
                sleep(0.01);
                
                [self returnBackStringWithString:@"*_*" withTimeOut:0.6 withRepeatTime:1 andTextField:showFixtureID_TF andRangeLength:17];
                

            });
       }
    }
    else
    {
        
        [showFixtureID_TF setStringValue:@"fixture disConnect!!!!!"];
    }
}




- (IBAction)update_ID_Action:(id)sender {
    
    index = 2;
    
     NSString  * timeString =[[GetTimeDay shareInstance] getFixtureTime];
    
     //从沙盒中得到SN
    
    NSString  *  SN = [[NSUserDefaults standardUserDefaults] objectForKey:@"SN"];

    NSString   *  commandString = [NSString stringWithFormat:@"setFixtureID %@.%@",timeString,SN];

    //写入当前的值
    [self Fixture:fixtureSerial writeCommand:commandString];
    sleep(1);
    
    [self Fixture:fixtureSerial writeCommand:@"Fixture ID?"];
    
    dispatch_queue_t  queue = dispatch_queue_create("test", NULL);

        
        dispatch_async(queue, ^{
            
            sleep(0.3);
            
            [self returnBackStringWithString:@"*_*" withTimeOut:0.6 withRepeatTime:1 andTextField:upDateFixtureID_TF andRangeLength:17];
            
            
        });
    
    
}

- (IBAction)set_CP_Action:(id)sender {
    
    showFixtureCP_TF.stringValue = @"ll";
    index = 1;
    
    
    
    if ([fixtureSerial isOpen]) {
        
        if(![CP_TF.stringValue isEqualToString:@""]){
                // NSString  * timeString =[[GetTimeDay shareInstance] getFixtureTime];
                NSString   *  commandString = [NSString stringWithFormat:@"seFixture_CP %@",CP_TF.stringValue];
                NSLog(@"commandString: %@", commandString);
                //写入当前的值
                [self Fixture:fixtureSerial writeCommand:commandString];
            
            
                sleep(1.0);
                //读取当前的值
                [self Fixture:fixtureSerial writeCommand:@"Fixture_CP?"];
            
                dispatch_queue_t  queue = dispatch_queue_create("test", NULL);
                
                
                dispatch_async(queue, ^{
                
                sleep(1.0);
                
                //CP值请参考fixtureID 后面的值进行设置
                [self returnBackStringWithString:@"*_*" withTimeOut:0.6 withRepeatTime:1 andTextField:showFixtureCP_TF andRangeLength:6];

                
                NSLog(@"showFixtureCP_TF: %@", showFixtureCP_TF.stringValue);
        });
        
        }else{
            [showFixtureCP_TF setStringValue:@"cp is null"];
            
        }
    }
    else
    {
        
            //[showFixtureCP_TF setStringValue:@"fixture disConnect!!!!!"];
        
            [fixtureSerial open];
        
            if([fixtureSerial isOpen]){
            
                NSString*  commandString = [NSString stringWithFormat:@"seFixture_CP %@",CP_TF.stringValue];
                NSLog(@"commandString: %@", commandString);
                //写入当前的值
                [self Fixture:fixtureSerial writeCommand:commandString];
                
                
                sleep(1.0);
                //写入当前的值
                [self Fixture:fixtureSerial writeCommand:@"Fixture_CP?"];
                
                dispatch_queue_t  queue = dispatch_queue_create("test", NULL);
                
                
                dispatch_async(queue, ^{
                    
                    sleep(1.0);
                    
                    //CP值请参考fixtureID 后面的值进行设置
                    [self returnBackStringWithString:@"*_*" withTimeOut:0.6 withRepeatTime:1 andTextField:showFixtureCP_TF andRangeLength:6];
                });
            
            
            }
    }
    
}


#pragma mark------------------串口代理方法
-(void)serialPort:(ORSSerialPort *)serialPort didReceiveData:(NSData *)data
{
    
    //backStr=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    if (serialPort==fixtureSerial)
    {
         NSString* str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"str: %@",str);
        [appendString appendString:str];
        
        if ([appendString containsString:@">>"]) {
            
            appendString =[NSMutableString stringWithString:@""];
        }
        
        if (self.backBlock&&appendString.length>0&&[appendString containsString:@"*_*"]) {
            NSLog(@"tt");
            self.backBlock(appendString);
            appendString =[NSMutableString stringWithString:@""];
            
           }
    }
}


#pragma mark--------------------ORSSerialPort串口中发送指令
-(void)Fixture:(ORSSerialPort *)serialPort writeCommand:(NSString *)command
{
    NSString * commandString =[NSString stringWithFormat:@"%@\r\n",command];
    NSData    * data =[commandString dataUsingEncoding:NSUTF8StringEncoding];
    [serialPort sendData:data];
}



#pragma mark--------------------超时等待
-(NSString  *)returnBackStringWithString:(NSString *)endString withTimeOut:(NSInteger)timeout withRepeatTime:(NSInteger)reTime andTextField:(NSTextField *)textField andRangeLength:(int)length
{
    
        float timeStart = [[GetTimeDay shareInstance] getMillSecond];
    
        NSLog(@"timeStart: %f", timeStart);
    
        float timenum;
        
        for (int i=0; ;i++)
        {
            
            sleep(0.1);
            
            float timeEnd = [[GetTimeDay shareInstance] getMillSecond];
            
            NSLog(@"timeEnd: %f", timeEnd);
            
            timenum = timeEnd - timeStart;
            
            
            NSLog(@"timenum: %f", timenum);
            __weak typeof(self) weakSelf = self;
            
            weakSelf.backBlock = ^(NSString * backString)
            {
                backStr = backString;
                
                NSLog(@"%@-------------------%@",backString,backStr);
                
                if ([backStr containsString:endString]) {
                    
                    NSLog(@"============%@",backStr);
                    
                    
                    if (index == 1) {
                        
                        backStr=[backStr stringByReplacingOccurrencesOfString:@"\r\n" withString:@""];
                        NSLog(@"backStr1: %@", backStr);
                        NSArray* arr = [self parseTxt:backStr];
                        NSLog(@"arr: %@", arr);
                        backStr = [NSString stringWithFormat:@"%@", [arr objectAtIndex:0]];
                        NSLog(@"backStr2: %@", backStr);
                        
                    }
                    else if((index == 2)||(index == 3)){
                    
                        //替代字符串
                        backStr=[backStr stringByReplacingOccurrencesOfString:@"\r\n" withString:@""];
                        
                        NSRange range = [backStr rangeOfString:@"?"];
                        backStr = [backStr substringWithRange:NSMakeRange(range.location+1, length)];
                        NSLog(@"backStr3: %@", backStr);
                    
                    }


                    dispatch_async(dispatch_get_main_queue(), ^{
                        [textField setStringValue:backStr];
                        NSLog(@"textField1: %@", textField.stringValue);
                        if ([backStr containsString:SN_TF.stringValue]) {
                            successLable.stringValue =@"success";
                            successLable.backgroundColor = [NSColor greenColor];
                        }
                        
                        
                        
                        backStr=@"";
                    });
                    
                    
                   // break;
                    
                }

                
            };
            
            
            if (timenum>=timeout) {
                NSLog(@"12");
                break;
            }
            
        }
    return backStr;


}

-(NSArray*)parseTxt:(NSString*)content{
    
    NSString* txtContent = [NSString stringWithFormat:@"%@", content];
    
    NSString* Pattern = @".*?\\?(.*?)\\*.*?";
    
    NSString *pattern = [NSString stringWithFormat:@"%@", Pattern];
    
    NSRegularExpression *regex = [[NSRegularExpression alloc] initWithPattern:pattern options:NSRegularExpressionCaseInsensitive error:nil];
    
    NSArray *results = [regex matchesInString:txtContent options:0 range:NSMakeRange(0, txtContent.length)];
    
    NSMutableArray* stringArray = [[NSMutableArray alloc] init];
    
    if (results.count != 0) {
        for (NSTextCheckingResult* result in results) {
            for (int i=1; i<[result numberOfRanges]; i++)
            {
                [stringArray addObject:[txtContent substringWithRange:[result rangeAtIndex:i]]];
            }
        }
    }
    
    return stringArray;
}




@end
