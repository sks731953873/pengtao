//
//  AppDelegate.h
//  SetRefTool
//
//  Created by h on 17/10/25.
//  Copyright © 2017年 h. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

