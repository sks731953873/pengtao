
//
//  ViewController.m
//  SetRefTools
//
//  Created by mac on 2017/9/23.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
//

#import "ViewController.h"
#import "SerialPortList.h"
#import "ORSSerialPort.h"
#import "Agilent3458A.h"
#import "Agilent34461A.h"
#include <fcntl.h> // for open
#include <unistd.h> // for close

@interface ViewController()<ORSSerialPortDelegate>
{
    
    __weak IBOutlet NSComboBox *comboBox;
    
    
    __weak IBOutlet NSComboBox *agilentCombox;
    
    ORSSerialPort  * ORSSerialPortFixture;
    
    __weak IBOutlet NSButton *connect_button;
    
    
    __weak IBOutlet NSButton *agilent3458A_connect_bn;
    
    __weak IBOutlet NSButton *agilent34461A_connect_bn;
    
    
    
    Agilent3458A  * agilent3458A;
    
    Agilent34461A* agilent34461A;
    
    NSMutableString * appendString;
    
    NSMutableString * backStr;
    
    BOOL  isReceive;
    BOOL isOpen_agilent3458A;
    BOOL isOpen_agilent34461A;
    
    __weak IBOutlet NSTextField *showValueView;
    
    
    float SetSpeed; //定义设定值
    float ActualSpeed; //定义实际值
    float err; //定义偏差值
    float err_next; //定义上一个偏差值
    float err_last; //定义最上前的偏差值
    float Kp,Ki,Kd; //定义比例、积分、微分系数
    float voltage; 			//定义电压值（控制执行器的变量）
    float integral;		    //定义积分值
}
@end


@implementation ViewController

- (void)viewDidLoad {
    
    
    [super viewDidLoad];
    
    
    
    SetSpeed=0.0;
    ActualSpeed=0.0;
    err=0.0;
    err_last=0.0;
    

    err_next=0.0;
    /*
     1st:
     Kp=0.07;
     Ki=0.81;
     Kd=-0.03;
     
     2rd:
     Kp=0.07;
     Ki=0.7;
     Kd=-0.032;
     */
    
    
//    Kp=0.07;
//    Ki=0.7;
//    Kd=-0.04;
    
    
    Kp=0.07;
    Ki=0.70;
    Kd=-0.03;
    
    NSArray  * uartArray = [[NSArray alloc]init];
    uartArray = [[SerialPortList Instance].portArray copy];
    appendString = [[NSMutableString alloc]initWithCapacity:10];
    [comboBox addItemsWithObjectValues:uartArray];
    
    
    
    agilent3458A = [[Agilent3458A alloc]init];
    
    agilent34461A = [[Agilent34461A alloc]init];

    isOpen_agilent3458A = NO;
    isOpen_agilent34461A = NO;
    
    NSLog(@"打印当前的值%@",uartArray);
    
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    
    // Update the view, if already loaded.
}




- (IBAction)connect_button:(id)sender {
    
    if([connect_button.title isEqualToString:@"断开"])
    {
        [ORSSerialPortFixture close];
        [connect_button setTitle:@"连接"];
        
    }
    if ([connect_button.title isEqualToString:@"连接"])
    {
        
        //初始化对象
        ORSSerialPortFixture = [ORSSerialPort serialPortWithPath:[comboBox stringValue]];
        ORSSerialPortFixture.baudRate = @B115200;
        ORSSerialPortFixture.delegate = self;        
        [ORSSerialPortFixture open];
        [connect_button setTitle:@"断开"];
    }
    
}


- (IBAction)agilent34461A_connect:(id)sender {
    
    while (YES) {
        
        if ([agilent34461A_connect_bn.title containsString:@"Open"]) {
            
            isOpen_agilent34461A = [agilent34461A Find:nil andCommunicateType:Agilent34461A_MODE_USB_Type]&[agilent34461A OpenDevice:nil andCommunicateType:Agilent34461A_MODE_USB_Type];
            
            if (isOpen_agilent34461A) {
                
                NSLog(@"Agilent 已经打开");
                [agilent34461A_connect_bn setTitle:@"Disconnect"];
                break;
            }
            
        }
        else{
            
            [agilent34461A CloseDevice];
            isOpen_agilent34461A = NO;
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [agilent34461A_connect_bn setTitle:@"Open"];
                NSLog(@"3458A 已经断开");
            });
            break;
            
        }
        
        
        //sleep(0.5);
    }

    
}


- (IBAction)agilent3458A_connect:(id)sender {
    
    
        while (YES) {
            
            if ([agilent3458A_connect_bn.title containsString:@"Open"]) {
                
                isOpen_agilent3458A =  [agilent3458A FindAndOpen:nil];
                
                if (isOpen_agilent3458A) {
                    
                    NSLog(@"Agilent 已经打开");
                    [agilent3458A_connect_bn setTitle:@"Disconnect"];
                    break;
                }
                
            }
            else{
                
                [agilent3458A CloseDevice];
                isOpen_agilent3458A = NO;
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [agilent3458A_connect_bn setTitle:@"Open"];
                    NSLog(@"3458A 已经断开");
                });
                break;
                
            }
            
            
            //sleep(0.5);
        }
    
}


- (IBAction)set_ref1_button:(id)sender {
    
    /*
     *4900 < volt_Num < 5100
     *Kp=0.07;
     *Ki=0.70;
     *Kd=-0.03;
     *
     */
    
    int volt_Num =5020;
    
    while (YES) {
        
        [self Fixture:ORSSerialPortFixture writeCommand:[NSString stringWithFormat:@"set ref1 %d",volt_Num]];
        [self LoopTestWhenIsReceiveIsNotBackString];
        [self Fixture:ORSSerialPortFixture writeCommand:@"U_SF_1a"];
        [self LoopTestWhenIsReceiveIsNotBackString];
        
        
        //从万用表中读取电压
        
        NSString  * agilentString;
        
        if (isOpen_agilent3458A) {
            
            
            [agilent3458A WriteLine:@"END"];
            //
            sleep(0.2);
            
            agilentString = [agilent3458A ReadData:16];
            
        }else{
            
            [agilent34461A WriteLine:@"Read?" andCommunicateType:Agilent34461A_MODE_USB_Type];
            
            sleep(0.2);
            
            agilentString = [agilent34461A ReadData:16 andCommunicateType:Agilent34461A_MODE_USB_Type];
            
        }
        
        
        //读取完后进行转化
        float num = [agilentString floatValue];
        
        NSLog(@"volt_Num: %d---------num: %f", volt_Num, num);
        
        //读出电压进行比较
        if (num<=1.301&&num>=1.299) {
            
            //跳出循环，并显示在界面上
            [showValueView setStringValue:[NSString stringWithFormat:@"%f",num]];
            break;
            
        }
        volt_Num = [self PID_realize:num*(5000/1.3)];
    }
}


-(float) PID_realize:(float) speed{
    
    SetSpeed=speed;
    err=SetSpeed-ActualSpeed;
    float incrementSpeed=Kp*(err-err_next)+Ki*err+Kd*(err-2*err_next+err_last);
    ActualSpeed+=incrementSpeed;
    err_last=err_next;
    err_next=err;
    return ActualSpeed;
}


- (IBAction)testAction:(id)sender {
    
    int count=0;
    while(count<100)
    {
        float speed= [self PID_realize:5008];   //  PID_realize(200.0);
        printf("count:%d--------speed: %f\n",count+1,speed);
        count++;
    }
}


- (IBAction)set_ref2_button:(id)sender {
    
    /*
    Kp=0.07;
    Ki=0.70;
    Kd=-0.03;
    */
    
    //int volt_Num = 4900;
    int volt_Num = 5000;
    while (YES) {
        
        [self Fixture:ORSSerialPortFixture writeCommand:[NSString stringWithFormat:@"set ref2 %d",volt_Num]];
        
        [self LoopTestWhenIsReceiveIsNotBackString];
        
        [self Fixture:ORSSerialPortFixture writeCommand:@"U_SF_1a"];
        
        [self LoopTestWhenIsReceiveIsNotBackString];
        
        //从万用表中读取电压
        
        NSString  * agilentString;
        
        if (isOpen_agilent3458A) {
            
            
            [agilent3458A WriteLine:@"END"];
            //
            sleep(0.2);
            
            agilentString = [agilent3458A ReadData:16];
            
        }else{
            
            [agilent34461A WriteLine:@"Read?" andCommunicateType:Agilent34461A_MODE_USB_Type];
            
            sleep(0.2);
            
            agilentString = [agilent34461A ReadData:16 andCommunicateType:Agilent34461A_MODE_USB_Type];
            
        }
        
        //读取完后进行转化
        float num = [agilentString floatValue];
        
        NSLog(@"volt_Num: %d---------num: %f", volt_Num, num);
        
        //读出电压进行比较
        if (num>=-1.301&&num<=-1.299) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                //跳出循环，并显示在界面上
                [showValueView setStringValue:[NSString stringWithFormat:@"%f",num]];
            });
            
            break;
            
        }
        
        volt_Num = [self PID_realize:(-num*(4900/1.3))];
    }
    
    
}


- (IBAction)set_ref3_button:(id)sender {
    
//    int volt_Num = 5118;
//    
//    while (YES) {
//        
//        [self Fixture:ORSSerialPortFixture writeCommand:[NSString stringWithFormat:@"set ref3 %d",volt_Num]];
//        
//        [self LoopTestWhenIsReceiveIsNotBackString];
//        
//        [self Fixture:ORSSerialPortFixture writeCommand:@"U_SF_1a"];
//        
//        [self LoopTestWhenIsReceiveIsNotBackString];
//        
//        //从万用表中读取电压
//        
//        NSString  * agilentString;
//        
//        if (isOpen_agilent3458A) {
//            
//            
//            [agilent3458A WriteLine:@"END"];
//            //
//            sleep(0.2);
//            
//            agilentString = [agilent3458A ReadData:16];
//            
//        }else{
//            
//            [agilent34461A WriteLine:@"Read?" andCommunicateType:Agilent34461A_MODE_USB_Type];
//            
//            sleep(0.2);
//            
//            agilentString = [agilent34461A ReadData:16 andCommunicateType:Agilent34461A_MODE_USB_Type];
//            
//        }
//
//        
//        //读取完后进行转化
//        float num = [agilentString floatValue];
//        
//        //读出电压进行比较
//        NSLog(@"volt_Num3: %d---------num3: %f", volt_Num, num);
//        
//        //读出电压进行比较
//        if (num<=1.201&&num>=1.199) {
//            
//            dispatch_async(dispatch_get_main_queue(), ^{
//                
//                //跳出循环，并显示在界面上
//                [showValueView setStringValue:[NSString stringWithFormat:@"%f",num]];
//            });
//            
//            break;
//            
//        }
//        
//        volt_Num = [self PID_realize:num*(5008/1.2)];
//
//        
//    }
    
    
    float volt_Num = 5008;
    
    while (YES) {
        
        [self Fixture:ORSSerialPortFixture writeCommand:[NSString stringWithFormat:@"set ref3 %f",volt_Num]];
        
        [self LoopTestWhenIsReceiveIsNotBackString];
        
        [self Fixture:ORSSerialPortFixture writeCommand:@"U_SF_1a"];
        
        [self LoopTestWhenIsReceiveIsNotBackString];
        
        //从万用表中读取电压
        
        NSString  * agilentString;
        
        if (isOpen_agilent3458A) {
            
            
            [agilent3458A WriteLine:@"END"];
            //
            sleep(0.2);
            
            agilentString = [agilent3458A ReadData:16];
            
        }else{
            
            [agilent34461A WriteLine:@"Read?" andCommunicateType:Agilent34461A_MODE_USB_Type];
            
            sleep(0.2);
            
            agilentString = [agilent34461A ReadData:16 andCommunicateType:Agilent34461A_MODE_USB_Type];
            
        }
        
        //读取完后进行转化
        float num = [agilentString floatValue];
        
        //读出电压进行比较
        if (num<=1.201&&num>=1.199) {
            
            //跳出循环，并显示在界面上
            [showValueView setStringValue:[NSString stringWithFormat:@"%f",num]];
            break;
            
        }
        else if (num>1.201)
        {
            volt_Num+=2;
            
        }
        else
        {
            volt_Num-=2;
        }
        
    }
}

- (IBAction)set_ref4_button:(id)sender {
    
    float volt_Num = 5006;
    
    while (YES) {
        
        [self Fixture:ORSSerialPortFixture writeCommand:[NSString stringWithFormat:@"set ref4 %f",volt_Num]];
        
        [self LoopTestWhenIsReceiveIsNotBackString];
        
        [self Fixture:ORSSerialPortFixture writeCommand:@"U_SF_1b"];
        
        [self LoopTestWhenIsReceiveIsNotBackString];
        
        //从万用表中读取电压
        
        NSString  * agilentString;
        
        if (isOpen_agilent3458A) {
            
            
            [agilent3458A WriteLine:@"END"];
            //
            sleep(0.2);
            
            agilentString = [agilent3458A ReadData:16];
            
        }else{
            
            [agilent34461A WriteLine:@"Read?" andCommunicateType:Agilent34461A_MODE_USB_Type];
            
            sleep(0.2);
            
            agilentString = [agilent34461A ReadData:16 andCommunicateType:Agilent34461A_MODE_USB_Type];
            
        }

        
        //读取完后进行转化
        float num = [agilentString floatValue];
        
        //读出电压进行比较
        NSLog(@"volt_Num3: %f---------num3: %f", volt_Num, num);
        
        
        //读出电压进行比较
        if (num>=-1.201&&num<=-1.199) {
            
            //跳出循环，并显示在界面上
            [showValueView setStringValue:[NSString stringWithFormat:@"%f",num]];
            break;
            
        }
        else if (num>-1.199)
        {
            volt_Num+=2;
            
        }
        else
        {
            volt_Num-=2;
        }
        
    }
    
    
}


#pragma mark--------------------ORSSerialPort串口中发送指令
-(void)Fixture:(ORSSerialPort *)serialPort writeCommand:(NSString *)command
{
    NSString * commandString =[NSString stringWithFormat:@"%@\r\n",command];
    NSData    * data =[commandString dataUsingEncoding:NSUTF8StringEncoding];
    [serialPort sendData:data];
}


#pragma mark--------------------代理方法
-(void)serialPort:(ORSSerialPort *)serialPort didReceiveData:(NSData *)data
{
    //返回相关的数值
    
    [appendString appendString:[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]];
    
    if ([appendString containsString:@"*_*"]) {
        backStr =appendString;
        appendString=[[NSMutableString alloc]initWithString:@""];
        isReceive = YES;
    }
    if ([appendString containsString:@"Write Done"]||[appendString containsString:@">>"])
    {
        appendString=[[NSMutableString alloc]initWithString:@""];
        
    }
    
    
    
}




-(void)LoopTestWhenIsReceiveIsNotBackString
{
    int index = 0;
    while (YES) {
        
        if (isReceive) {
            isReceive=NO;
            break;
        }
        
        index++;
        sleep(1.0);
        if (index==2) {
            
            break;
        }
    }
}


-(void)viewDidDisappear
{
    
    [agilent3458A CloseDevice];
    [agilent34461A CloseDevice];
    exit(0);
    
    
}







@end
