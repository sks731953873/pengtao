//
//  main.m
//  SetRefTool
//
//  Created by h on 17/10/25.
//  Copyright © 2017年 h. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
