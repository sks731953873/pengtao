//
//  main.m
//  FTDI_Seriport_Test
//
//  Created by mac on 2017/10/26.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
