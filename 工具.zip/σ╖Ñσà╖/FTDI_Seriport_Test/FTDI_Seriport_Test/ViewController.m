//
//  ViewController.m
//  FTDI_Seriport_Test
//
//  Created by mac on 2017/10/26.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
//

#import "ViewController.h"
#import "FTUART.h"
#import "ConfigureTool.h"
#import "ORSSerialPort.h"

#define DELAY_TIME 1000;

@interface ViewController()
{
    ConfigureTool* configureTool;
    
    __unsafe_unretained IBOutlet NSTextView *cmdLogView;
    
    __weak IBOutlet NSComboBox *txtCmd;
    
    __weak IBOutlet NSButton *connectBn;
    
    
    //ORSSerialPort* fixtureSerial;
    FTUART  *  uart;
    NSString* port;
    NSString* baudrate;
    BOOL isDTR;
    BOOL isRTS;
    NSMutableString* cmdLog;
    BOOL isUartOpen;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    uart = [[FTUART alloc]init];
    
    cmdLog = [NSMutableString string];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(SetConfigure) name:@"SetConfigure_Notification" object:nil];
    
    NSArray* usbArr = [uart findDeviceInfoList];
    
    [[NSUserDefaults standardUserDefaults] setObject:usbArr[0] forKey:@"usb"];
    
    NSLog(@"usbArr: %@", usbArr);
    
    
    
    
//    NSString  * backString = [uart FT_UART_Get];
//    NSLog(@"打印初始化所产生的数据%@",backString);
//    
//    NSString *rx0=[uart FT_UART_SendGet:@"reset\n" Delay:700];
//    NSLog(@"打印返回来的数值%@",rx0);
//
//    
//    //发送help的指令
//    NSString *rx=[uart FT_UART_SendGet:@"help\n" Delay:700];
//    NSLog(@"打印返回来的数值%@",rx);
//
//    
//    //发送U_SF_1a指令
//    NSString *rx1=[uart FT_UART_SendGet:@"U_SF_1a\n" Delay:700];
//    NSLog(@"打印返回来的数值%@",rx1);
//    
//    //发送U_SF_1b指令
//    NSString *rx2=[uart FT_UART_SendGet:@"U_SF_1b\n" Delay:700];
//    NSLog(@"打印返回来的数值%@",rx2);
//    
//    
//    //发送U_SF_2a指令
//    NSString *rx3=[uart FT_UART_SendGet:@"U_SF_2a\n" Delay:700];
//    NSLog(@"打印返回来的数值%@",rx3);
//    
//    //发送Fixture ID?指令
//    NSString *rx4=[uart FT_UART_SendGet:@"Fixture ID?\n" Delay:700];
//    NSLog(@"打印返回来的数值%@",rx4);
//    
//    //发送Fixture?指令
//    NSString *rx5=[uart FT_UART_SendGet:@"ACResistance?\n" Delay:700];
//    NSLog(@"打印返回来的数值%@",rx5);

    // Do any additional setup after loading the view.
}


-(void)SetConfigure{
    NSLog(@"uu");
    port = [[NSUserDefaults standardUserDefaults] objectForKey:@"port"];
    
    baudrate = [[NSUserDefaults standardUserDefaults] objectForKey:@"baudrate"];
    
    isDTR = [[[NSUserDefaults standardUserDefaults] objectForKey:@"isDTR"] boolValue];
    
    isRTS = [[[NSUserDefaults standardUserDefaults] objectForKey:@"isRTS"] boolValue];
    
    NSLog(@"port: %@\n baudrate: %@\n isDTR: %d\n isRTS: %d\n", port, baudrate, isDTR, isRTS);
}

- (IBAction)connectAction:(id)sender {
    
    if ([connectBn.title isEqualToString:@"Connect"]) {
        
        if (port == nil || [baudrate intValue] == 0) {
            
            //cmdLogView.string = [cmdLog stringByAppendingString:@"Please choose the correct port or baudrate in ConfigreTool\n"];
            
            [self addTextLog:@"Please choose the correct port or baudrate in ConfigreTool"];
            
            return;
        }
        
        NSLog(@"port:%@\n [baudrate intValue]: %d",port, [baudrate intValue]);
        
        isUartOpen =[uart FT_UART_Open:port baudRate:[baudrate intValue]];
        
        
        
        if (isUartOpen) {
            
            NSLog(@"找到了治具");
            [self addTextLog:@" Uart has been opened!!!"];
        }
        
        BOOL  isDTRandCTS = [uart FT_UART_SetRTSCTS:isRTS DTR:isDTR];
        
        if (isDTRandCTS) {
            
            NSLog(@"DTR 和 RTS 已经设置好了");
            [self addTextLog:@"DTR 和 RTS 已经设置好了"];
        }

        [connectBn setTitle:@"Disconnect"];
    
    }else{
        
        BOOL isCloseUart = [uart FT_UART_Close];
        isUartOpen = NO;
        if (isCloseUart) {
            NSLog(@"Uart has been closed!!!");
            [self addTextLog:@"Uart has been closed!!!"];
        }
        
        [connectBn setTitle:@"Connect"];
        
    }
}


- (IBAction)selectCmd:(id)sender {
    
    NSString* cmd = [txtCmd stringValue];
    NSLog(@"cmd: %@", cmd);
    
}

- (IBAction)sendCmd:(id)sender {
    
    NSString* retStr;
    
    if (isUartOpen) {
        retStr = [uart FT_UART_SendGet:[NSString stringWithFormat:@"%@\n",[txtCmd stringValue]] Delay:1000];
    }else{
        
        retStr = @"Please connect the fixture!!!";
        NSLog(@"uart is off");
    }
    
    
    NSLog(@"[txtCmd stringValue]: %@", [txtCmd stringValue]);
    
    [self addTextLog:retStr];
    
    //cmdLogView.string = [cmdLog stringByAppendingString:[NSString stringWithFormat:@"%@\n", retStr]];
}

- (IBAction)clearCmdLog:(id)sender {
    
    [[cmdLogView textStorage] replaceCharactersInRange:NSMakeRange(0,[[cmdLogView textStorage] length]) withString:@""];
    
    
}

- (IBAction)addCommand:(id)sender {
    
    
    [txtCmd addItemWithObjectValue:[txtCmd stringValue]];
    
}


-(void)addTextLog:(NSString*)msg
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyy/MM/dd HH:mm:ss.SSS : "];
    NSAttributedString *attributedString;
//    msg = [msg stringByReplacingOccurrencesOfString:@"\r" withString:@""];
//    msg = [msg stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    NSString *str = [NSString stringWithFormat:@"%@ %@\r",[dateFormatter stringFromDate:[NSDate date]],msg];
    attributedString = [[NSAttributedString alloc] initWithString:str];
    
    [[cmdLogView textStorage] appendAttributedString:attributedString];
    
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

@end
