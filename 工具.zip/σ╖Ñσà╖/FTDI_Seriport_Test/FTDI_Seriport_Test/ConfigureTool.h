//
//  ConfigureTool.h
//  FTDI_Seriport_Test
//
//  Created by mini on 17/10/27.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ConfigureTool : NSWindowController

@end
