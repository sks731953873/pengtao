//
//  ConfigureTool.m
//  FTDI_Seriport_Test
//
//  Created by mini on 17/10/27.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
//

#import "ConfigureTool.h"
#import "ORSSerialPort.h"
#import "SerialPortList.h"
#import "FTUART.h"


@interface ConfigureTool (){
    
    __weak IBOutlet NSBox *serialPortOptionBox;
    
    __weak IBOutlet NSComboBox *portComboBox;
    
    __weak IBOutlet NSComboBox *Baudrate;
    
    __weak IBOutlet NSComboBox *parity;
    
    __weak IBOutlet NSComboBox *stop_bits;
    
    ORSSerialPort* ORSSerialPortFixture;

    __weak IBOutlet NSMatrix *DTRStateSelect;
    
    __weak IBOutlet NSMatrix *RTSStateSelect;
    
}

@end

@implementation ConfigureTool
-(id)init{
    
    self = [super initWithWindowNibName:@"ConfigureTool"];
    
    return  self;
}


- (void)windowDidLoad {
    
    [super windowDidLoad];

    serialPortOptionBox.hidden = NO;
    
    NSMutableArray* uartArray = [NSMutableArray array];
    
    uartArray = [[SerialPortList Instance].portArray mutableCopy];
    
    NSLog(@"uartArray: %@", uartArray);
    
    id usb = [[NSUserDefaults standardUserDefaults] objectForKey:@"usb"];
    
    NSLog(@"temp: %@", usb);
    [uartArray addObject:[NSString stringWithFormat:@"%@", usb]];
    
    
    [portComboBox addItemsWithObjectValues:uartArray];
}

- (IBAction)selectPortValueAction:(id)sender {
    
    NSString* port = portComboBox.stringValue;
    NSString* baudrate = Baudrate.stringValue;
    BOOL isDTR = ([DTRStateSelect selectedColumn] == 0)?YES:NO;
    BOOL isRTS = ([RTSStateSelect selectedColumn] == 0)?YES:NO;
    
    NSLog(@"port: %@\n baudrate: %@\n isDTR: %d\n isRTS: %d\n", port, baudrate, isDTR, isRTS);
    
    [[NSUserDefaults standardUserDefaults] setObject:port forKey:@"port"];
    [[NSUserDefaults standardUserDefaults] setObject:baudrate forKey:@"baudrate"];
    [[NSUserDefaults standardUserDefaults] setBool:isDTR forKey:@"isDTR"];
    [[NSUserDefaults standardUserDefaults] setBool:isRTS forKey:@"isRTS"];
//
//    //发送通知, 激活无限循环测试功能
    
    [self.window orderOut:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"SetConfigure_Notification" object:nil];
    
}

- (IBAction)qutiWindow:(id)sender {
    [self.window orderOut:self];
    
}



@end
