//
//  AppDelegate.m
//  FTDI_Seriport_Test
//
//  Created by mac on 2017/10/26.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
//

#import "AppDelegate.h"
#import "ConfigureTool.h"

@interface AppDelegate ()
{
    
    ConfigureTool* configureTool;
    
}

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

- (IBAction)showConfigureTool:(id)sender {
    if (!configureTool) {
        configureTool = [[ConfigureTool alloc] init];
    }
    NSLog(@"tt");
    [configureTool showWindow:self];
    
    
}
@end
