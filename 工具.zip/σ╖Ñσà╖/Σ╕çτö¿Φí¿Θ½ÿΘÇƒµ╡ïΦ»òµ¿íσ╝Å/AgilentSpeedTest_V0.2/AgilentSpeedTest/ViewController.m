//

/*
 
 
 
 
 */


//  ViewController.m
//  AgilentSpeedTest
//
//  Created by mac on 2017/9/18.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
//

#import "ViewController.h"
#import "Agilent3458A.h"
#import "MKTimer.h"
#import "Folder.h"
#import "GetTimeDay.h"
#import "AgilentB2985A.h"
#import "Agilent34461A.h"


@interface ViewController()
{

    __weak IBOutlet NSTextField *NPLC_TF;

    __weak IBOutlet NSTextField *TIME_TF;
    
    
    Agilent3458A      *    agilent;
    
    AgilentB2985A     *    agilentB2985A;
    
    Agilent34461A     *    agilent34461A;
    
    
    
    NSString  * NPLC_String;

    __weak IBOutlet NSComboBox *Mode_BOX;
    
    MKTimer  * timer;
    NSMutableArray  * dataArray;
    NSMutableString * dataString;
    
    BOOL     isTest;
    Folder   * folder;
    NSString * FilePath;
    GetTimeDay * timeDay;
    
    NSThread * myThrad;
    
    __weak IBOutlet NSTextField *dataNum;
    
    __unsafe_unretained IBOutlet NSTextView *data_TV;
    
    
    __unsafe_unretained IBOutlet NSTextView *logInfoView;
    

    __weak IBOutlet NSButton *Button_3458A;
    
    __weak IBOutlet NSButton *Button_2987A;
    
    __weak IBOutlet NSButton *Button_34461A;
    
    
    __weak IBOutlet NSTextField *run_time;
    
    
    __weak IBOutlet NSTextField *high_speed_count;
    
    
    BOOL  isOpen_Agilent3458A;
    BOOL  isOpen_AgilentB2985A;
    BOOL  isOpen_Agilent34461A;
    
    BOOL isHighSpeed_3458A;
    BOOL isHighSpeed_34461A;
}

@end


@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    agilent = [[Agilent3458A alloc]init];
    agilentB2985A = [[AgilentB2985A alloc]init];
    agilent34461A = [[Agilent34461A alloc] init];
    
    timer  = [[MKTimer alloc]init];
    
    FilePath = @"/vault/TestLogfile/";
    folder = [[Folder alloc]init];
    [folder Folder_Creat:FilePath];
    
    timeDay = [GetTimeDay shareInstance];
    
    
    dataArray  = [[NSMutableArray alloc]initWithCapacity:10];
    
    dataString = [[NSMutableString alloc]initWithCapacity:20];
    
    isTest = YES;
    isHighSpeed_3458A = NO;
    isHighSpeed_34461A = NO;
    
//    [self redirectSTD:STDOUT_FILENO];  //冲定向log
//    [self redirectSTD:STDERR_FILENO];
    
    // Do any additional setup after loading the view.
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


//连接E2987A
- (IBAction)open_2987A_Action:(id)sender {
    
    
    while (1) {
        
       
        
        if ([Button_2987A.title containsString:@"Open"]) {
            
            isOpen_AgilentB2985A =[agilentB2985A Find:nil andCommunicateType:AgilentB2985A_USB_Type]&&[agilentB2985A OpenDevice:nil andCommunicateType:AgilentB2985A_USB_Type];
            
            if (isOpen_AgilentB2985A) {
                 //设置模式
                [agilentB2985A SetMessureMode:AgilentB2985A_VOLT andCommunicateType:AgilentB2985A_USB_Type andNPLC:[NPLC_TF.stringValue length]>0?NPLC_TF.stringValue:@"0.001"];
                NSLog(@"E2987A已经连接");
                [Button_2987A setTitle:@"Disconnect"];
                break;
            }
            
        }
        else
        {
            
            [agilentB2985A CloseDevice];
            isOpen_AgilentB2985A = NO;
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [Button_2987A setTitle:@"Open"];
                NSLog(@"2987A 已经断开");
            });
            break;

            
        }
    }
}



- (IBAction)OpenAgilent_34461A_Action:(id)sender {
    
    
    
    while (1) {
        
        if ([Button_34461A.title containsString:@"Open"]) {
            
            isOpen_Agilent34461A = [agilent34461A Find:nil andCommunicateType:Agilent34461A_MODE_USB_Type]&[agilent34461A OpenDevice:nil andCommunicateType:Agilent34461A_MODE_USB_Type];
            
            if (isOpen_Agilent34461A) {
                
                 NSLog(@"3458A 已经连接");
                [Button_34461A setTitle:@"Disconnect"];
                break;
            }
        
        }
        else
        {
            [agilent34461A CloseDevice];
            isOpen_Agilent34461A = NO;
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [Button_34461A setTitle:@"Open"];
                NSLog(@"34461A 已经断开");
            });
            break;
        }
    }
}





- (IBAction)OpenAgilent_Action:(id)sender {
    
    
    while (1) {
        
        if ([Button_3458A.title containsString:@"Open"]) {
            
            isOpen_Agilent3458A =[agilent FindAndOpen:nil];
            
            if (isOpen_Agilent3458A) {
                
                NSLog(@"3458A 已经连接");
                [Button_3458A setTitle:@"Disconnect"];
                break;
            }
            
        }
        else
        {
            
             [agilent CloseDevice];
             isOpen_Agilent3458A = NO;
             dispatch_async(dispatch_get_main_queue(), ^{
                 
                 [Button_3458A setTitle:@"Open"];
                 NSLog(@"3458A 已经断开");
             });
             break;
           
            
        }
        
        
    }
    
}



- (IBAction)start_Action:(id)sender {
    
    isTest = YES;
    [dataArray removeAllObjects];
    dataString = [NSMutableString stringWithString:@""];
    [data_TV setString:@"0"];
    [dataNum setStringValue:@"0"];
    
    [timer setTimer:0.001];
    [timer startTimerWithTextField: TIME_TF];
    
    NSString* time1 = [timeDay getTime];
    
    //测试项线程
     myThrad = [[NSThread alloc] initWithTarget:self selector:@selector(Working) object:nil];
    [myThrad start];
    
}



- (IBAction)Close_Action:(id)sender {
    
    
    [agilent CloseDevice];
    
}



- (IBAction)Set_Mode_Action:(id)sender {
    
    
    NSLog(@"%@",Mode_BOX.stringValue);
    
    if (isOpen_Agilent3458A) {
    
        //万用表发送指令
        if ([Mode_BOX.stringValue isEqualToString:@"DC Volt"])
        {
            
            //直流电压测试
            [agilent SetMessureMode:Agilent3458A_VOLT_DC andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF.stringValue intValue]:(float)0.001];
            NSLog(@"Aglient3458A set VOLT_DC");
            isHighSpeed_3458A = NO;
        }
        else if([Mode_BOX.stringValue isEqualToString:@"AC Volt"])
        {
            [agilent SetMessureMode:Agilent3458A_VOLT_AC andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF.stringValue intValue]:(float)0.001];
            NSLog(@"Aglient3458A set AC_Volt");
            isHighSpeed_3458A = NO;
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"DC Current"])
        {
            [agilent SetMessureMode:Agilent3458A_CURR_DC andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF.stringValue intValue]:(float)0.001];
            NSLog(@"Aglient3458A set DC_Current");
            isHighSpeed_3458A = NO;
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"AC Current"])
        {
            [agilent SetMessureMode:Agilent3458A_CURR_AC andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF.stringValue intValue]:(float)0.001];
            
            NSLog(@"Aglient3458A set AC_Current");
            isHighSpeed_3458A = NO;
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"RES_2W"])
        {
            [agilent SetMessureMode:Agilent3458A_RES_2W andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF.stringValue intValue]:(float)0.001];
            
            NSLog(@"Aglient3458A set RES_2W");
            isHighSpeed_3458A = NO;
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"RES_4W"])
        {
            [agilent SetMessureMode:Agilent3458A_RES_4W andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF.stringValue intValue]:(float)0.001];
            
            NSLog(@"Aglient3458A set RES_4W");
            isHighSpeed_3458A = NO;
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"HighSpeed_3458A_ACV"])
        {
            [agilent SetMessureMode:Agilent3458A_HighSpeed_VOLT_AC andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF.stringValue intValue]:(float)0.001];
            isHighSpeed_3458A=YES;
            
            NSLog(@"Aglient3458A set HighSpeed_VOLT_AC");
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"HighSpeed_3458A_DCV"])
        {
            [agilent SetMessureMode:Agilent3458A_HighSpeed_VOLT_DC andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF.stringValue intValue]:(float)0.001];
            isHighSpeed_3458A=YES;
            
            NSLog(@"Aglient3458A set HighSpeed_3458A_DCV");
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"HighSpeed_3458A_ACI"])
        {
            [agilent SetMessureMode:Agilent3458A_HighSpeed_CURR_AC andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF.stringValue intValue]:(float)0.001];
            isHighSpeed_3458A=YES;
            
            NSLog(@"Aglient3458A set HighSpeed_3458A_ACI");
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"HighSpeed_3458A_DCI"])
        {
            [agilent SetMessureMode:Agilent3458A_HighSpeed_CURR_DC andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF.stringValue intValue]:(float)0.001];
            isHighSpeed_3458A=YES;
            
            NSLog(@"Aglient3458A set HighSpeed_3458A_DCI");
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"HighSpeed_3458A_RES4"])
        {
            [agilent SetMessureMode:Agilent3458A_HighSpeed_RES_4W andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF.stringValue intValue]:(float)0.001];
            isHighSpeed_3458A=YES;
            
            NSLog(@"Aglient3458A set HighSpeed_3458A_RES4");
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"HighSpeed_3458A_RES2 "])
        {
            [agilent SetMessureMode:Agilent3458A_HighSpeed_RES_2W andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF.stringValue intValue]:(float)0.001];
            isHighSpeed_3458A=YES;
            
            NSLog(@"Aglient3458A set HighSpeed_3458A_RES2");
        }
        
        else
        {
            NSLog(@"其它的情形");
            
        }

     }
    
    else if (isOpen_AgilentB2985A) {
        
        //万用表发送指令
        if ([Mode_BOX.stringValue containsString:@"Volt"])
        {
            
            //直流电压测试
              [agilentB2985A SetMessureMode:AgilentB2985A_VOLT andCommunicateType:AgilentB2985A_USB_Type andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF stringValue]:@"0.001"];
            
            NSLog(@"AgilentB2985A set VOLT_DC");
            
        }
        else if ([Mode_BOX.stringValue containsString:@"Current"])
        {
                        
            
            [agilentB2985A SetMessureMode:AgilentB2985A_CURR andCommunicateType:AgilentB2985A_USB_Type andNPLC:[NPLC_TF.stringValue length]>0? [NPLC_TF stringValue]:@"0.001"];
            
            NSLog(@"AgilentB2985A set Current");
        }
        else if ([Mode_BOX.stringValue containsString:@"RES"])
        {
            
            [agilentB2985A SetMessureMode:AgilentB2985A_RES andCommunicateType:AgilentB2985A_USB_Type andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF stringValue]:@"0.001"];
            
            NSLog(@"AgilentB2985A set RES");
        }
        else
        {
            NSLog(@"其它的情形");
        }
    }
    
    else if (isOpen_Agilent34461A) {
        
        //万用表发送指令
        if ([Mode_BOX.stringValue isEqualToString:@"DC Volt"])
        {
            //直流电压测试
            [agilent34461A SetMessureMode:Agilent34461A_MODE_VOLT_DC andCommunicateType:Agilent34461A_MODE_USB_Type andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF stringValue]:@"0.001"];
            NSLog(@"agilent34461A set VOLT_DC");
            
        }
        else if([Mode_BOX.stringValue isEqualToString:@"AC Volt"])
        {
            [agilent34461A SetMessureMode:Agilent34461A_MODE_VOLT_AC andCommunicateType:Agilent34461A_MODE_USB_Type andNPLC:[NPLC_TF.stringValue length]>0?NPLC_TF.stringValue:@"0.001"];
            NSLog(@"agilent34461A set VOLT_AC");
            
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"DC Current"])
        {
            [agilent34461A SetMessureMode:Agilent34461A_MODE_CURR_DC andCommunicateType:Agilent34461A_MODE_USB_Type andNPLC:[NPLC_TF.stringValue length]>0?NPLC_TF.stringValue:@"0.001"];
            NSLog(@"agilent34461A set DC Current");
            
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"AC Current"])
        {
           isHighSpeed_34461A = NO;
            [agilent34461A SetMessureMode:Agilent34461A_MODE_CURR_AC andCommunicateType:Agilent34461A_MODE_USB_Type andNPLC:[NPLC_TF.stringValue length]>0?NPLC_TF.stringValue:@"0.001"];
            NSLog(@"agilent34461A set  AC Current");

            
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"RES_2W"])
        {
            isHighSpeed_34461A = NO;
            [agilent34461A SetMessureMode:Agilent34461A_MODE_RES_2W andCommunicateType:Agilent34461A_MODE_USB_Type andNPLC:[NPLC_TF.stringValue length]>0?NPLC_TF.stringValue:@"0.001"];
            NSLog(@"agilent34461A set  RES_2W");
            
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"RES_4W"])
        {
            isHighSpeed_34461A = NO;
            [agilent34461A SetMessureMode:Agilent34461A_MODE_RES_4W andCommunicateType:Agilent34461A_MODE_USB_Type andNPLC:[NPLC_TF.stringValue length]>0?NPLC_TF.stringValue:@"0.001"];
            NSLog(@"agilent34461A set  RES_4W");
        }
        else if ([Mode_BOX.stringValue isEqualToString:@"HighSpeed_34461A_RES2"])
        {
            isHighSpeed_34461A = YES;
            [agilent34461A SetMessureMode:Agilent34461A_HIGHSPEED_RES_2W andCommunicateType:Agilent34461A_MODE_USB_Type andNPLC:[NPLC_TF.stringValue length]>0?[NPLC_TF stringValue]:@"0.001"];
            NSLog(@"agilent34461A set  RES_4W");
        }
        
        else
        {
            NSLog(@"其它的情形");
        }
    }
    else
    {
        NSLog(@"选择其他的仪器仪表");
    }
    

   }


- (IBAction)Stop_Action:(id)sender {
    
    [self showInView];
}


-(void)Working
{
    
    if (isOpen_Agilent3458A) {
        
        //[agilent WriteLine:@"AZERO OFF"];
        
        if (isHighSpeed_3458A) {
            NSLog(@"in");
            NSArray * agilentStringArr=[agilent queryData:[high_speed_count.stringValue intValue]];
            
            for (int i = 0; i< agilentStringArr.count; i++) {
                [dataArray addObject:agilentStringArr[i]];
                [dataString appendFormat:@"%d\t:\t%@\n", i+1, agilentStringArr[i]];
            }
            NSLog(@"dataArray: %@", dataArray);
            
            if ([agilentStringArr count]) {
                
                [self showInView];
                
            }
        }
        else
        {
            [agilent WriteLine:@"END"];
            
            int count = 0;
            
            NSString* time1 = [timeDay getTime];
            
            NSLog(@"time1: %f", [time1 doubleValue]);
            
        
            while (isTest)
            {
                
                //sleep(0.001);
                
                NSString * agilentString=[agilent ReadData:16];
                
                [dataString appendString:agilentString];
                
                if (agilentString.length>0) {
                    
                    [dataArray addObject:agilentString];
                    
                }
                
                count++;
                
                NSString* time2 = [timeDay getTime];
                
                NSLog(@"time2: %f", [time2 doubleValue]);
                
                int temp = [time2 intValue] - [time1 intValue];
                
                if (temp >= [run_time.stringValue intValue]*1000 || count == 50000000) {
                    
                    [self showInView];
                    break;
                }
                
                
                if (!isTest ) {
                    
                    break;
                }
            }
            
        }
    }
    if (isOpen_AgilentB2985A) {
    
        
        int count = 0;
        
        
        NSString* time1 = [timeDay getTime];
        
        NSLog(@"time1: %f", [time1 doubleValue]);

        
        while (isTest) {
            
            if ([Mode_BOX.stringValue containsString:@"RES"]) {
                
                [agilentB2985A WriteLine:@":MEAS:RES?" andCommunicateType:AgilentB2985A_USB_Type];
                
            }
            else if ([Mode_BOX.stringValue containsString:@"Volt"]){
                
                [agilentB2985A WriteLine:@":MEAS:VOLT?" andCommunicateType:AgilentB2985A_USB_Type];
                
            }else{
                
                [agilentB2985A WriteLine:@":MEAS:CURR?" andCommunicateType:AgilentB2985A_USB_Type];
                
            }
        
            
            //sleep(0.001);
            
            NSString * agilentString=[agilentB2985A ReadData:16 andCommunicateType:AgilentB2985A_USB_Type];
            
            NSLog(@"agilentString: %@", agilentString);\
            
            NSArray  *  array = [agilentString componentsSeparatedByString:@","];
            
            
            [dataString appendFormat:@"%@\n",array[0]];
            
            if (agilentString.length>0) {
                [dataArray addObject:agilentString];
                
            }
            
            count++;
            
            NSString* time2 = [timeDay getTime];
            
            NSLog(@"time2: %f", [time2 doubleValue]);
            
            int temp = [time2 intValue] - [time1 intValue];
            
            if (temp >= [run_time.stringValue intValue]*1000 || count == 50000000) {
                
                [self showInView];
                break;
            }
            
            if (!isTest) {
                
                break;
            }
            
        }
        
    }
    
    if (isOpen_Agilent34461A)
    {
        if (isHighSpeed_34461A)
        {
            [agilent34461A WriteLine:@"*TRG" andCommunicateType:Agilent34461A_MODE_USB_Type];
            sleep(0.1);
            [agilent34461A WriteLine:@"DATA:REM? 3000, WAIT" andCommunicateType:Agilent34461A_MODE_USB_Type];
            
            sleep(0.1);
            
            [agilent34461A WriteLine:@"Read?" andCommunicateType:Agilent34461A_MODE_USB_Type];
            
            sleep(0.1);
            
            NSString * agilentString=[agilent34461A ReadData:2390 andCommunicateType:Agilent34461A_MODE_USB_Type];
            
            NSLog(@"agilentString: %@", agilentString);
            
            NSArray* agilentStringArr = [agilentString componentsSeparatedByString:@","];
            
            for (int i = 0; i< agilentStringArr.count; i++) {
                [dataArray addObject:agilentStringArr[i]];
                [dataString appendFormat:@"%d\t:\t%@\n", i+1, agilentStringArr[i]];
            }
            NSLog(@"dataArray: %@", dataArray);
            
            if ([agilentStringArr count]) {
                
                [self showInView];
                
            }
            
        }
        else
        {
            
            int count = 0;
            
            NSString* time1 = [timeDay getTime];
            
            NSLog(@"time1: %f", [time1 doubleValue]);
            
    
            while (isTest) {
    
                [agilent34461A WriteLine:@"Read?" andCommunicateType:Agilent34461A_MODE_USB_Type];
    
                //[agilent34461A WriteLine:@"FETC?" andCommunicateType:Agilent34461A_MODE_USB_Type];
    
                sleep(0.01);
                NSString * agilentString=[agilent34461A ReadData:16 andCommunicateType:Agilent34461A_MODE_USB_Type];
    
                NSArray  *  array = [agilentString componentsSeparatedByString:@","];
    
    
                [dataString appendFormat:@"%@\n",array[0]];
    
                if (agilentString.length>0) {
                    [dataArray addObject:agilentString];
    
                }
    
                count++;
    
                NSString* time2 = [timeDay getTime];
    
                NSLog(@"time2: %f", [time2 doubleValue]);
    
                int temp = [time2 intValue] - [time1 intValue];
                
                if (temp >= [run_time.stringValue intValue]*1000 || count == 50000000) {
                    
                    [self showInView];
                    break;
                }
    
                if (!isTest) {
                    
                    break;
                }
                
            }

        }
    }
}

/**
 *  必须要清除本地的存储数据,否则可能导致文件创建失败
 */
//界面消失后取消线程
-(void)viewWillDisappear
{
    //=================
    [myThrad cancel];
    myThrad = nil;
    
    //主动释放掉
    [agilent CloseDevice];
    exit(0);
}


//显示在界面上
-(void)showInView
{

    [timer endTimer];
    
    isTest = NO;
    
    NSLog(@"打印当前的界面之%lu",(unsigned long)[dataArray count]);
    
    //测试完，拼接具体时间
    
    [dataString appendFormat:@"测试结束时间:%@",[timeDay getFileTime]];
    
    
    //拼接文件路径
    NSString * path;
    if (isOpen_Agilent3458A) {
        
         path =[FilePath stringByAppendingFormat:@"%@_A3458A_log.txt",[timeDay getFileTime]];
    }
    
    if (isOpen_AgilentB2985A) {
        
        path =[FilePath stringByAppendingFormat:@"%@_2987A_log.txt",[timeDay getFileTime]];
    }
    
    if (isOpen_Agilent34461A) {
        
        path =[FilePath stringByAppendingFormat:@"%@_34461A_log.txt",[timeDay getFileTime]];
    }
    
    //将数据写入TXT文件中
    [dataString writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    
    
    //刷新界面
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if (isOpen_AgilentB2985A) {
            [dataNum setStringValue:[NSString stringWithFormat:@"%lu",(unsigned long)[dataArray count]]];
        }
        if (isOpen_Agilent3458A) {
            
            if (isHighSpeed_3458A) {
                
                [dataNum setStringValue:[NSString stringWithFormat:@"%lu",(unsigned long)[dataArray count]]];
            }else{
                
                [dataNum setStringValue:[NSString stringWithFormat:@"%lu",(unsigned long)[dataArray count]/2]];
            }
        }
        if (isOpen_Agilent34461A) {
            
            [dataNum setStringValue:[NSString stringWithFormat:@"%lu",(unsigned long)[dataArray count]]];
        }
        
        
        [data_TV setString:dataString];
        
    });
    
    [myThrad cancel];
    myThrad = nil;
    
}


//==================== 冲定向log ============================
- (void)redirectNotificationHandle:(NSNotification *)nf{
    NSData *data = [[nf userInfo] objectForKey:NSFileHandleNotificationDataItem];
    NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    if(logInfoView != nil)
    {
        NSRange range;
        range = NSMakeRange ([[logInfoView string] length], 0);
        [logInfoView replaceCharactersInRange: range withString: str];
        [logInfoView scrollRangeToVisible:range];
    }
    [[nf object] readInBackgroundAndNotify];
}

- (void)redirectSTD:(int )fd{
    
    NSPipe * pipe = [NSPipe pipe] ;
    NSFileHandle *pipeReadHandle = [pipe fileHandleForReading] ;
    dup2([[pipe fileHandleForWriting] fileDescriptor], fd) ;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(redirectNotificationHandle:)
                                                 name:NSFileHandleReadCompletionNotification
                                               object:pipeReadHandle] ;
    
    [pipeReadHandle readInBackgroundAndNotify];
}



@end
