//
//  AppDelegate.h
//  AgilentSpeedTest
//
//  Created by mac on 2017/9/18.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

