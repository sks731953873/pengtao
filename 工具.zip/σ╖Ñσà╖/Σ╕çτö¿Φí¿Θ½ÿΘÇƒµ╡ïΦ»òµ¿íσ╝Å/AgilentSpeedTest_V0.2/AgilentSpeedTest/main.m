//
//  main.m
//  AgilentSpeedTest
//
//  Created by mac on 2017/9/18.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
