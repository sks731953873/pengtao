//
//  MainWindowController.h
//  WindowSkip
//
//  Created by gdadmin on 16/11/27.
//  Copyright © 2016年 108. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MainWindowController : NSWindowController
@property (strong) IBOutlet NSView *bgView;
- (IBAction)showNewsWindow:(id)sender;

- (IBAction)nextToConfig:(id)sender;


@end
