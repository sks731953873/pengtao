//
//  ConfigWindowController.h
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016 108. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ConfigWindowController : NSWindowController<NSTableViewDataSource, NSTableViewDelegate>{
    
    NSScrollView* _tableContainerView;
    NSMutableArray* _dataSourceArray;
    
    NSTextField* _scrollTf;
    NSButton* _deleteBtn;
    NSButton* _addBtn;
    
    NSInteger _selectedRowNum;
}

//@property (weak) IBOutlet NSWindow* window;

@property(nonatomic) NSTableView* tableView;

- (IBAction)backToMain:(id)sender;



@end
