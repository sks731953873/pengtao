//
//  FDRSealWindowController.m
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016 108. All rights reserved.
//

#import "FDRSealWindowController.h"
#import "UMWindowController.h"

@interface FDRSealWindowController ()

@property(strong) UMWindowController * UMWindow;

@end

@implementation FDRSealWindowController

- (void)windowDidLoad {
    [super windowDidLoad];
    
    // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
}

- (IBAction)backToUMWindow:(id)sender {
    _UMWindow = [[UMWindowController alloc] initWithWindowNibName:@"UMWindowController"];
    
    [_UMWindow.window orderFront:nil];
    
    [self.window orderOut:nil];
}
@end
