//
//  NewsWindowController.m
//  WindowSkip
//
//  Created by 张鹏伟 on 16/3/7.
//  Copyright © 2016年 108. All rights reserved.
//

#import "UMWindowController.h"
#import "AppDelegate.h"
#import "RadarWindowController.h"
#import "QCRWindowController.h"
#import "FDRSealWindowController.h"

@interface UMWindowController ()

@property(strong) RadarWindowController *RadarWindow;

@property(strong) QCRWindowController *QCRWindow;

@property(strong) FDRSealWindowController *FDRWindow;

@end

@implementation UMWindowController

- (void)windowDidLoad {
    [super windowDidLoad];
    
    _bgView.wantsLayer = YES;
    _bgView.layer.backgroundColor = CGColorCreateGenericRGB(1.0f, 1.0f, 1.0f, 1.0f);
    // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
}

- (IBAction)Back:(id)sender {
    AppDelegate * appDelegate=(AppDelegate*)[[NSApplication sharedApplication]delegate];
    [self.window close];
    //    [appDelegate.mainWindow.window center];
    [[appDelegate.mainWindow window] makeKeyAndOrderFront:nil];
}

- (IBAction)next:(id)sender {
    _RadarWindow = [[RadarWindowController alloc] initWithWindowNibName:@"RadarWindowController"];
    
    [_RadarWindow.window orderFront:nil];
    
    [self.window orderOut:nil];
}

- (IBAction)nextToQCR:(id)sender {
    _QCRWindow = [[QCRWindowController alloc] initWithWindowNibName:@"QCRWindowController"];
    
    [_QCRWindow.window orderFront:nil];
    
    [self.window orderOut:nil];
}

- (IBAction)nextToFDR:(id)sender {
    _FDRWindow = [[FDRSealWindowController alloc] initWithWindowNibName:@"FDRSealWindowController"];
    [_FDRWindow.window orderFront:nil];
    
    [self.window orderOut:nil];
}


@end
