//
//  QCRWindowController.m
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016 108. All rights reserved.
//

#import "QCRWindowController.h"
#import "UMWindowController.h"

@interface QCRWindowController ()

@property(strong) UMWindowController *UMWindow;

@end

@implementation QCRWindowController

- (void)windowDidLoad {
    [super windowDidLoad];
    
    
    _tableContainerView = [[NSScrollView alloc] initWithFrame:CGRectMake(0, 0, 400, 309)];
    _tableView = [[NSTableView alloc] initWithFrame:CGRectMake(0, 0,
                                                               _tableContainerView.frame.size.width,
                                                               _tableContainerView.frame.size.height)];
    [_tableContainerView setDocumentView:_tableView];
    [self.window.contentView addSubview:_tableContainerView];
    
    
}

- (IBAction)backToUMWindow:(id)sender {
    
    _UMWindow = [[UMWindowController alloc] initWithWindowNibName:@"UMWindowController"];
    
    [_UMWindow.window orderFront:nil];
    
    [self.window orderOut:nil];
}


@end
