//
//  ThirdWindowController.m
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016 108. All rights reserved.
//

#import "RadarWindowController.h"
#import "AppDelegate.h"
#import "UMWindowController.h"

@interface RadarWindowController ()

@property(strong) UMWindowController *secondWindow;

@end

@implementation RadarWindowController

- (void)windowDidLoad {
    [super windowDidLoad];
    
    // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
}

- (IBAction)back:(id)sender {
//    AppDelegate *appDelegate = (AppDelegate *)[NSApplication sharedApplication];
//    [self.window close];
//    [[appDelegate.mainWindow window] makeKeyAndOrderFront:nil];
    
    
    _secondWindow = [[UMWindowController alloc] initWithWindowNibName:@"UMWindowController"];
    
    [_secondWindow.window orderFront:nil];
    
    [self.window orderOut:nil];
    
}
@end
