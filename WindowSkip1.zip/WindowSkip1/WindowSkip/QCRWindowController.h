//
//  QCRWindowController.h
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016 108. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface QCRWindowController : NSWindowController
- (IBAction)backToUMWindow:(id)sender;

@property (nonatomic, strong) NSScrollView *tableContainerView;
@property (nonatomic, strong) NSTableView *tableView;


@end
