//
//  ConfigWindowController.m
//  WindowSkip
//
//  Created by gdadmin on 12/3/16.
//  Copyright © 2016 108. All rights reserved.
//

#import "ConfigWindowController.h"
#import "MainWindowController.h"

@interface ConfigWindowController ()

@property (strong) MainWindowController *mainWindow;

@end

@implementation ConfigWindowController




- (void)windowDidLoad {
    [super windowDidLoad];

    NSFileManager *fm = [NSFileManager defaultManager];
    
    NSString *cuDir = [fm currentDirectoryPath];
    
    NSLog(@"10");
    
}

#pragma mark - NSTableViewDataSource
-(void)awakeFromNib{
    
    
    NSLog(@"1");
    _dataSourceArray = [[NSMutableArray alloc] initWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7", nil];
    
    _selectedRowNum = -1;
    
    //删除按钮
    _deleteBtn = [[NSButton alloc] initWithFrame:CGRectMake(360, 170, 70, 25)];
    _deleteBtn.title = @"删除选中行";
    _deleteBtn.wantsLayer = YES;
    _deleteBtn.layer.cornerRadius = 3.0f;
    _deleteBtn.layer.borderColor = [NSColor lightGrayColor].CGColor;
    [_deleteBtn setTarget:self];
    _deleteBtn.action = @selector(deleteTheSelectedRow);
    [self.window.contentView addSubview:_deleteBtn];
    
    //添加按钮
    _addBtn = [[NSButton alloc] initWithFrame:CGRectMake(430, 170, 70, 25)];
    _addBtn.title = @"上面添一行";
    _addBtn.wantsLayer = YES;
    _addBtn.layer.cornerRadius = 3.0f;
    _addBtn.layer.borderColor = [NSColor lightGrayColor].CGColor;
    [_addBtn setTarget:self];
    _addBtn.action = @selector(addRowUnderTheSelectedRow);
    [self.window.contentView addSubview:_addBtn];
    
    _scrollTf = [[NSTextField alloc] initWithFrame:CGRectMake(415, 90, 80, 15)  ];
    _scrollTf.stringValue = @"滚动 0.0";
    _scrollTf.font = [NSFont systemFontOfSize:15.0f];
    _scrollTf.textColor = [NSColor blackColor];
    _scrollTf.drawsBackground = NO;
    _scrollTf.bordered  = NO;
    _scrollTf.focusRingType = NSFocusRingTypeNone;
    _scrollTf.editable = YES;
    [self.window.contentView addSubview:_scrollTf];
    
    //tableView
    _tableContainerView = [[NSScrollView alloc] initWithFrame:CGRectMake(0, 0, 600, 700)];
    _tableView = [[NSTableView alloc] initWithFrame:CGRectMake(0, 20, _tableContainerView.frame.size.width-20, _tableContainerView.frame.size.height)];
    
    [_tableView setBackgroundColor:[NSColor colorWithCalibratedRed:255.0/255 green:255.0/255 blue:255.0/255 alpha:1.0]];
    
    _tableView.focusRingType = NSFocusRingTypeNone;
    _tableView.selectionHighlightStyle = NSTableViewSelectionHighlightStyleRegular;
    _tableView.headerView.frame = NSZeroRect;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    
    //first colunm
    NSTableColumn* column1 = [[NSTableColumn alloc] initWithIdentifier:@"firstColunm"];
    [column1 setWidth:400];
    [_tableView addTableColumn:column1];
    
//    //seconde colunm
//    NSTableColumn* column2 = [[NSTableColumn alloc] initWithIdentifier:@"secondColunm"];
//    [column2 setWidth:200];
//    [_tableView addTableColumn:column2];
    
    [_tableContainerView setDocumentView:_tableView];
    [_tableContainerView setDrawsBackground:NO];
//    [_tableContainerView setHasHorizontalScroller:YES];
    [_tableContainerView setHasVerticalScroller:YES];
    _tableContainerView.autohidesScrollers = YES;
    [self.window.contentView addSubview:_tableContainerView];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(tableViewDidScroll:)
                                                 name:NSViewBoundsDidChangeNotification
                                               object:[[_tableView enclosingScrollView] contentView]];

    
}

#pragma mark - tableview滚动处理
-(void)tableViewDidScroll:(NSNotification*)notification{
    NSLog(@"2");
    NSClipView* contentView = [notification object];
    CGFloat scrollY = contentView.visibleRect.origin.y -20;
    _scrollTf.stringValue = [NSString stringWithFormat:@"gundong: %.1f", scrollY];
    
}

#pragma mark - delete or add a row
-(void)deleteTheSelectedRow{
    
    if(_selectedRowNum == -1){
        NSLog(@"pls choose the deleted row");
        return;
    }
    
    [_tableView beginUpdates];
    [_dataSourceArray removeObjectAtIndex:_selectedRowNum];
    [_tableView removeRowsAtIndexes:[NSIndexSet indexSetWithIndex:_selectedRowNum] withAnimation:NSTableViewAnimationSlideUp];
    [_tableView endUpdates];
    _selectedRowNum = -1;
    
}

-(void)addRowUnderTheSelectedRow{
    
   
    
    if(_selectedRowNum == -1){
        NSLog(@"pls choose which row");
        return;
    }
    NSString* selectedDataObject = [_dataSourceArray objectAtIndex:_selectedRowNum];
    NSString* addObject = [NSString stringWithFormat:@"%@+", selectedDataObject];
    
    [_tableView beginUpdates];
    [_dataSourceArray insertObject:addObject atIndex:_selectedRowNum];
    [_tableView insertRowsAtIndexes:[NSIndexSet indexSetWithIndex:_selectedRowNum] withAnimation:NSTableViewAnimationSlideDown];
    [_tableView endUpdates];
    _selectedRowNum++;
}


#pragma mark - NSTableViewDataSource, NSTableViewDelegate
#pragma mark - required method

-(NSInteger)numberOfRowsInTableView:(NSTableView *)tableView{
    NSLog(@"3");
    
    return _dataSourceArray.count;
}

-(nullable id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    
    NSLog(@"4");
    if([tableColumn.identifier isEqualToString:@"firstColunm"]){
        
        NSString* strIdt = (NSString*)[_dataSourceArray objectAtIndex:row];
        
        return strIdt;
        
        
    }else if([tableColumn.identifier isEqualToString:@"secondColunm"]){
        
        NSString* strIdt = (NSString*)[_dataSourceArray objectAtIndex:row];
        return strIdt;
        
    }
    
    
    return 0;
}

#pragma mark - other methods
- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row{
    NSLog(@"5");
    return 100;
}

-(nullable NSView*)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    
    NSLog(@"6");
    NSString* strId = [tableColumn identifier];
    NSTableCellView *aView = [tableView makeViewWithIdentifier:strId owner:self];
    if(!aView){
        NSLog(@"e");
        aView = [[NSTableCellView alloc] initWithFrame:CGRectMake(0, 0, tableColumn.width, 100)];
    }else{
        NSLog(@"f");
        for (NSView *view in aView.subviews) {
            [view removeFromSuperview];
        }
    }
    
    NSImageView* imageView = [[NSImageView alloc] initWithFrame:CGRectMake(11, 30, 50, 70)];
    imageView.image = [NSImage imageNamed:@"2.png"];
//    imageView.wantsLayer = YES;
//    imageView.layer.cornerRadius = 35.0f;
//    imageView.layer.borderWidth = 2;
//    imageView.layer.borderColor = [NSColor greenColor].CGColor;
//    imageView.layer.masksToBounds = YES;
    
    [aView addSubview:imageView];
    
    NSImageView* imageView2 = [[NSImageView alloc] initWithFrame:CGRectMake(0, 0, 500, 1)];
    imageView2.image = [NSImage imageNamed:@"line.png"];
    //    imageView.wantsLayer = YES;
    //    imageView.layer.cornerRadius = 35.0f;
    //    imageView.layer.borderWidth = 2;
    //    imageView.layer.borderColor = [NSColor greenColor].CGColor;
    //    imageView.layer.masksToBounds = YES;
    [aView addSubview:imageView2];
    
    
    
    NSTextField* textField = [[NSTextField alloc] initWithFrame:CGRectMake(10, 10, 156, 17)];
    textField.stringValue = [NSString stringWithFormat:@"%@-***-%@", tableColumn.identifier,[_dataSourceArray objectAtIndex:row]];
    textField.font = [NSFont systemFontOfSize:15.0f];
    textField.textColor = [NSColor blackColor];
   textField.drawsBackground = NO;
    textField.bordered = NO;
    textField.focusRingType = NSFocusRingTypeNone;
    textField.editable = YES;
    [aView addSubview:textField];

    NSTextField* textField2 = [[NSTextField alloc] initWithFrame:CGRectMake(300, 10, 156, 80)];
    textField2.stringValue = @"FAIL";
    textField2.font = [NSFont systemFontOfSize:40.0f];
    textField2.textColor = [NSColor redColor];
    textField2.drawsBackground = NO;
    textField2.bordered = NO;
    textField2.focusRingType = NSFocusRingTypeNone;
    textField2.editable = YES;
    [aView addSubview:textField2];
    
    
    return aView;
}

-(BOOL)tableView:(NSTableView *)tableView shouldSelectRow:(NSInteger)row{
    NSLog(@"7");
    NSLog(@"===%ld", (long)row);
    _selectedRowNum = row;
    
        [_tableView setBackgroundColor:[NSColor colorWithCalibratedRed:200.0/255 green:200.0/255 blue:200.0/255 alpha:1.0]];
    
    return YES;
}

-(void)tableView:(NSTableView *)tableView didClickTableColumn:(NSTableColumn *)tableColum{
    NSLog(@"8");
    NSLog(@"********%@*********", tableColum.dataCell);
    
}


- (IBAction)backToMain:(id)sender {
    _mainWindow = [[MainWindowController alloc] initWithWindowNibName:@"MainWindowController"];
    
    [_mainWindow.window orderFront:nil];
    
    [self.window orderOut:nil];
    
}
@end
