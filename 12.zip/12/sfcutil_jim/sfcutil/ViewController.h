//
//  ViewController.h
//  sfcutil
//
//  Created by RDSW03 on 11/11/15.
//  Copyright (c) 2015 J. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "sfcDB.h"
#import <string.h>
#import <unistd.h>
#import <stdlib.h>
#import <sys/types.h>
#import <sys/socket.h>
#import <sys/ioctl.h>
#import <net/if.h>
#import <netinet/in.h>
#import <arpa/inet.h>
#import <netdb.h>


@interface ViewController : NSViewController


@property (nonatomic,retain) IBOutlet NSTextField *snLabel;

@property (nonatomic,retain) IBOutlet NSTextField *ProTypeLabel;

@property (nonatomic,retain) IBOutlet NSTextField *SN;

@property (nonatomic,retain) IBOutlet NSTextField *stationLabel;

@property (nonatomic,retain) IBOutlet NSTextField *SelectInfo;

@property (nonatomic,retain) IBOutlet NSPopUpButton *ProType;

@property (nonatomic,retain) IBOutlet NSPopUpButton *Station;

@property (nonatomic,retain) IBOutlet NSTextField *paramLable;

@property (nonatomic,retain) IBOutlet NSPopUpButton *Param;

@property (nonatomic,retain) IBOutlet NSButton *SendButton;

@property (nonatomic,retain) IBOutlet NSScrollView *RecvInfo;

@property (nonatomic,retain) IBOutlet NSButton *LeftBtn;

@property (nonatomic,retain) IBOutlet NSButton *RightBtn;

@property (weak) IBOutlet NSButton *Logo;

- (IBAction)SendClick:(id)sender;

- (IBAction)ParamClick:(id)sender;

- (IBAction)StationClick:(id)sender;

- (IBAction)ProTypeClick:(id)sender;

- (IBAction)LeftClick:(id)sender;

- (IBAction)RightClick:(id)sender;

@end

