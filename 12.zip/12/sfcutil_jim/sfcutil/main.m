//
//  main.m
//  sfcutil
//
//  Created by RDSW03 on 11/11/15.
//  Copyright (c) 2015 J. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    
    @autoreleasepool {
        //NSLog(@"111\n");
    return NSApplicationMain(argc, argv);
 }
}
