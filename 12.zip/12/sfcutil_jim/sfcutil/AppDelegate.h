//
//  AppDelegate.h
//  sfcutil
//
//  Created by RDSW03 on 11/11/15.
//  Copyright (c) 2015 J. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

