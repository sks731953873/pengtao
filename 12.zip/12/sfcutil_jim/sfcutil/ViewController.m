//
//  ViewController.m
//  222
//
//  Created by leslie on 15/11/11.
//  Copyright (c) 2015年 J. All rights reserved.
//

#import "ViewController.h"
@implementation ViewController

#define INDEXSIZE    5
#define SIZE        1024
#define IPHEAD      "192.168"

NSString *TmpProType;
NSString *TmpSN;
NSString *TmpParam;
NSString *TmpStation;
NSTextView *txtView ;
char *TmpRecvInfo;
int paramcount;
int NSindex ;

//- (IBAction)monitorRecvClick:(id)sender {
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    int sd;
    struct ifreq ir;
    char *ip=NULL;
    struct sockaddr_in *srv = (struct sockaddr_in *)(&ir.ifr_addr);
    sd = socket(AF_INET, SOCK_DGRAM, 0);
    strcpy(ir.ifr_name, "en0");
    
    //初始化参数
    NSindex=1;
    paramcount=0;
    TmpProType=@"";
    TmpSN=@"";
    TmpParam=@"";
    TmpStation=@"";
    TmpRecvInfo=NULL;
    
    //初始化文本框
    [self.RecvInfo setBorderType:NSNoBorder];
    [self.RecvInfo  setHasVerticalScroller:YES];
    [self.RecvInfo  setHasHorizontalScroller:NO];
    [self.RecvInfo  setAutoresizingMask:NSViewWidthSizable | NSViewHeightSizable];
    
    txtView =[[NSTextView alloc]initWithFrame:CGRectMake(47, 0, 403, 98)];
    [txtView setMinSize:NSMakeSize(0.0, 98)];
    [txtView setMaxSize:NSMakeSize(FLT_MAX, FLT_MAX)];
    [txtView setVerticallyResizable:YES];
    [txtView setHorizontallyResizable:NO];
    [txtView setAutoresizingMask:NSViewWidthSizable];
    [[txtView textContainer]setContainerSize:NSMakeSize(60000,FLT_MAX)];
    [[txtView textContainer]setWidthTracksTextView:YES];
    [txtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
    [txtView setEditable:YES];
    [self.RecvInfo  setDocumentView:txtView];
    [self.view addSubview:self.RecvInfo ];

    
    //左右按钮设置背景颜色
    [self.LeftBtn setButtonType: NSMomentaryPushInButton];
    [self.LeftBtn setBezelStyle: NSRoundedBezelStyle];
    [self.LeftBtn setBordered: NO];
    [self.LeftBtn setImage: [NSImage imageNamed: @"left_highlighted"]];
    [self.LeftBtn setImagePosition: NSImageOnly];
    [self.LeftBtn setTarget: self];
    
    [self.RightBtn setButtonType: NSMomentaryPushInButton];
    [self.RightBtn setBezelStyle: NSRoundedBezelStyle];
    [self.RightBtn setBordered: NO];
    [self.RightBtn setImage: [NSImage imageNamed: @"right_highlighted"]];
    [self.RightBtn setImagePosition: NSImageOnly];
    [self.RightBtn setTarget: self];
    
    //设置logo
    [self.Logo setButtonType: NSMomentaryPushInButton];
    [self.Logo setBezelStyle: NSRoundedBezelStyle];
    [self.Logo setBordered: NO];
    [self.Logo setImage: [NSImage imageNamed: @"SFCTool"]];
    [self.Logo setImagePosition: NSImageOnly];
    [self.Logo setTarget: self];
    //self.view.window.backgroundColor =[NSColor greenColor];
    //显示第一个界面
    [self FirstView];
    //判断本地ip是否为192.168网段，并进行匹配
    if(ioctl(sd, SIOCGIFADDR, &ir)!=0)
    {
        txtView.string=@"请检查网线是否连接上,并重新打开软件";
        [txtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
        close(sd);
        return ;
    }
    
    ip=inet_ntoa(srv->sin_addr);
    if(strstr(ip,IPHEAD)==NULL)
    {
        txtView.string=@"请换为pdca网线,并重新打开软件";
        [txtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
         close(sd);
         return ;
    }
    
    close(sd);
}
-(void)FirstView
{
    
    //show part
    self.snLabel.hidden=false ;
    self.SN.hidden=false;
    self.ProTypeLabel.hidden=false ;
    self.ProType.hidden=false;
    self.SelectInfo.hidden=false;
    
    //hidden part
    self.Station.hidden=true;
    self.stationLabel.hidden=true;
    self.Param.hidden=true;
    self.paramLable.hidden=true;
    
    self.SelectInfo.textColor=[NSColor blackColor];
    self.SelectInfo.font=[NSFont fontWithName:@"Helvetica" size:16.0];
    self.SelectInfo.stringValue=@"Unit specific info";
}

-(void)SecondView
{
    self.SelectInfo.stringValue=@"Unit configuration info";
    
    //hidden part
    self.Station.hidden=true;
    self.stationLabel.hidden=true;
    
    //add show part
    self.Param.hidden=false;
    self.paramLable.hidden=false;
}

-(void)ThirdView
{
    
    // self.view.window.backgroundColor =[NSColor yellowColor];
    self.SelectInfo.stringValue=@"Station specific info";
    
    //hidden part
    self.Param.hidden=true;
    self.paramLable.hidden=true;
    
    //add show part
    self.Station.hidden=false;
    self.stationLabel.hidden=false;
}

-(void )fourView
{
    self.SelectInfo.stringValue=@"Unit history record";
    
    //hidden part
    self.Param.hidden=true;
    self.paramLable.hidden=true;
    self.Station.hidden=true;
    self.stationLabel.hidden=true;
}

-(void)fiveView
{
    [self ThirdView];
    self.SelectInfo.stringValue=@"Unit process check";
}

#pragma mark -ACTIONS
-(void )changeview
{
    switch (NSindex) {
        case 1:[self FirstView];
            break;
        case 2:[self SecondView];
            break;
        case 3:[self ThirdView];
            break;
        case 4:[self fourView];
            break;
        case 5:[self fiveView];
            break;
        default:
            break;
    }
}
- (IBAction)LeftClick:(id)sender
{
    if(NSindex<=1)
    {
        [self.LeftBtn setImage: [NSImage imageNamed: @"left_normal"]];
        return ;
    }
    [self.LeftBtn setImage: [NSImage imageNamed: @"left_highlighted"]];
    [self.RightBtn setImage: [NSImage imageNamed: @"right_highlighted"]];
    //切换界面时,重新初始化以下参数
    [self.Station setTitle:[self.Station itemTitleAtIndex:0]];
    [self.Param setTitle:[self.Param itemTitleAtIndex:0]];
    paramcount=0;
    TmpParam=@"";
    TmpStation=@"";
    txtView.string=@"";
    
    NSindex--;
    [self changeview];
}

- (IBAction)RightClick:(id)sender
{
    if(NSindex>=INDEXSIZE)
    {
        [self.RightBtn setImage: [NSImage imageNamed: @"right_normal"]];
        return ;
    }
    [self.LeftBtn setImage: [NSImage imageNamed: @"left_highlighted"]];
    [self.RightBtn setImage: [NSImage imageNamed: @"right_highlighted"]];
    
    //切换界面时,重新初始化以下参数
    //[self.Param setTitle:@"--请输入参数--"];
    [self.Station setTitle:[self.Station itemTitleAtIndex:0]];
    [self.Param setTitle:[self.Param itemTitleAtIndex:0]];
    paramcount=0;
    TmpParam=@"";
    TmpStation=@"";
    txtView.string=@"";
    
    NSindex++;
    [self changeview];
}

- (IBAction)SendClick:(id)sender
{
    NSRange range;
    TmpSN=self.SN.stringValue;
    if([TmpSN isEqualToString:@""])
    {
        txtView.string=@"输入机台序列号为空,请重新输入";
        [txtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
        return ;
    }
    else if([TmpProType isEqualToString:@""])
    {
        txtView.string=@"输入产品类型为空,请重新输入";
        [txtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
        return ;
    }
    else if(strlen([TmpSN UTF8String])!=12)
    {
        txtView.string=@"输入机台序列号长度有误,请重新输入";
        [txtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
        return ;
    }
    else
    {
        ;
    }
   // NSLog(@"==>NSindex:%d==>TmpSN:%s==>TmpParam:%s==>TmpProType:%s==>TmpStation:%@\n",NSindex,(const char *)[TmpSN UTF8String],(const char *)[TmpParam UTF8String],(const char *)[TmpProType UTF8String],TmpStation);
    switch (NSindex) {
            case 1:
            TmpRecvInfo=queryProvInfo((const char *)[TmpSN UTF8String],(const char *)[TmpProType UTF8String]);break;
            case 2:
            if([TmpParam isEqualToString:@""])
            {
                txtView.string=@"输入参数为空,请重新输入(另外每次切换页面时,需重新输入参数)";
                [txtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
                return ;
            }
            TmpRecvInfo=queryInfo((const char *)[TmpSN UTF8String],(const char *)[TmpProType UTF8String],(const char *)[TmpParam UTF8String]);break;
            case 3:
            if([TmpStation isEqualToString:@""])
            {
                txtView.string=@"输入工站为空,请重新输入(另外每次切换页面时,需重新选择工站)";
                [txtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
                return ;
            }
            TmpRecvInfo=queryStationInfo((const char *)[TmpSN UTF8String],(const char *)[TmpStation UTF8String],(const char *)[TmpProType UTF8String]);break;
            case 4:
            TmpRecvInfo=queryTestRecord((const char *)[TmpSN UTF8String],(const char *)[TmpProType UTF8String]);break;
        case 5:
            TmpRecvInfo=queryProcessCheck((const char *)[TmpSN UTF8String],(const char *)[TmpStation UTF8String],(const char *)[TmpProType UTF8String]);break;
        default:
            break;
    }
    //C39QJ005GYTM
    //NSLog(@"=====================\n");
    //NSLog(@"TmpRecvInfo:%s",TmpRecvInfo);
    //NSLog(@"=====================\n");
    if(TmpRecvInfo!=NULL)
    {
        range=[[NSString stringWithCString:TmpRecvInfo encoding:NSUTF8StringEncoding] rangeOfString:@"0 SFC_OK"];
        if(range.length<=0)
        {
           [txtView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
        }
        if(strlen(TmpRecvInfo)>10000)
        {
            txtView.string=[NSString stringWithCString:TmpRecvInfo encoding:NSUTF8StringEncoding];
            sleep(1);
        }
        else
        {
            txtView.string=[NSString stringWithCString:TmpRecvInfo encoding:NSUTF8StringEncoding];
        }
    }
        return ;
}

- (IBAction)ParamClick:(id)sender
{
    NSRange range;
    if(![self.Param indexOfSelectedItem])
    {
        return ;
    }
    if(!paramcount)   //the first param  /  paramcount=0
    {
        paramcount++;
        TmpParam=@"p=";
        TmpParam=[TmpParam stringByAppendingString:[self.Param titleOfSelectedItem]];
        return ;
    }
    else            //more than 1 param
    {
        range=[TmpParam rangeOfString:[self.Param titleOfSelectedItem]];     // 检测TmpParam是否包含当前选中的参数
        if(range.length>0)
        {
            //NSLog(@"==>%@==>TmpParam:%@,paramcount:%d",[self.Param titleOfSelectedItem],TmpParam,paramcount);
            return ;
        }
        else
        {
            TmpParam=[TmpParam stringByAppendingString:@"&p="];
            TmpParam=[TmpParam stringByAppendingString:[self.Param titleOfSelectedItem]];
            paramcount++;
            //NSLog(@"ParamClick:%@,paramcount:%d==>[self.Param titleOfSelectedItem]:%@\n",TmpParam,paramcount,[self.Param titleOfSelectedItem]);
            return ;
        }
  }
}
- (IBAction)StationClick:(id)sender
{
    if(![self.Station indexOfSelectedItem])
    {
        return ;
    }
    TmpStation=[self.Station titleOfSelectedItem];
   // NSLog(@"StationClick:%@\n",TmpStation);
}
- (IBAction)ProTypeClick:(id)sender
{
    if(![self.ProType indexOfSelectedItem])
    {
        return ;
    }
    TmpProType=[self.ProType titleOfSelectedItem];
    //NSLog(@"ProTypeClick:%@\n",TmpProType);
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    // Update the view, if already loaded.
}

@end