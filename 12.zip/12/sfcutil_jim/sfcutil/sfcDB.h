#ifndef __SFC_DB__
#define __SFC_DB__

struct MemoryStruct {
        char *memory;
        size_t size;
};

struct MemoryStruct *mem;

char* queryProvInfo( const char* sn, const char* productType ); 

char* queryInfo( const char* sn, const char* productType, const char* param );  

char* queryProcessCheck( const char* sn, const char* station_name, const char* productType );   

char* queryStationInfo( const char* sn, const char* station_name, const char* productType );  

char* queryTestRecord( const char* sn, const char* productType );    

char* findUnitLocation( const char* sn, const char* productType );

char* countOfTest( const char* sn, const char* productType );

#endif
