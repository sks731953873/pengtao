Used the scheme

the PanicCFG file must save as the path: /usr/local/bin/

Process:
marvin > is special? > run next step follow as config file

Fail_Flag,当执行命令失败时，有其他命令的标志位，
PanicTriage，罗列所有特殊的panic信息，每个panic的操作步骤有标志位和命令组成，

function:
get_jebdump(): GetJebdump
get_jebdump_ziponly(): GetJebdumpZiponly
get_mipi(): GetMIPI
get_crstackshot_log():GetCrstackshotLog
get_burnin_log():GetBurninLog
enter_panic():EnterPanic
get_marvin_log():GetMarvinLog, can get all marvin log as default setting
get_reboot_log():GetRebootLog
to_diags_FA(): ToDiagsFA 
to_F1_FA(): ToF1FA
