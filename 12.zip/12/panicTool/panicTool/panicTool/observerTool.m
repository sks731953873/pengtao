//
//  observerTool.m
//  panicTool
//
//  Created by Tony on 17/5/8.
//  Copyright (c) 2017年 Jim. All rights reserved.
//

#import "observerTool.h"
#import "filterStringTool.h"

NSString* const NOTIFICATION_MESSAGE_NAME1 = @"text1";
NSString* const NOTIFICATION_MESSAGE_NAME2 = @"text2";
NSString* const NOTIFICATION_MESSAGE_RADAR = @"radarText";

@interface observerTool()
@end

@implementation observerTool
{
    NSPipe *pipe;
    filterStringTool *filterString;
}
NSTask *task=nil;
static observerTool* observer=nil;

-(instancetype) initWithArgArr:(NSArray*)array{
    self = [super init];
    if(self){
        task = [[NSTask alloc] init];
        filterString=[filterStringTool instance];
        [task setLaunchPath:@"/bin/bash"];
        self.arguments = array;
        
        NSLog(@"self.arguments: %@", self.arguments);
    }
    return self;
}

-(void)observerChange: (NSString *)textSign{
    
    [task setArguments:self.arguments];
    NSLog(@"self.ar:%@",self.arguments);
    pipe = [[NSPipe alloc] init];
    [task setStandardOutput:pipe];
    NSFileHandle *fh = [pipe fileHandleForReading];
    NSNotificationCenter *notification = [NSNotificationCenter defaultCenter];
    [notification removeObserver: self name:NOTIFICATION_MESSAGE_NAME1 object:nil];
    [notification removeObserver: self name:NOTIFICATION_MESSAGE_NAME2 object:nil];
    [notification removeObserver: self name:NOTIFICATION_MESSAGE_RADAR object:nil];
    
    [notification addObserver:self
                     selector:@selector(taskTerminated:)
                         name:NSFileHandleReadCompletionNotification
                       object:task];
    [task launch];
    if([textSign isEqualToString:NOTIFICATION_MESSAGE_NAME1])
    {
        NSLog(@"textSign:%@ NOTIFICATION_MESSAGE_NAME1:%@",textSign,NOTIFICATION_MESSAGE_NAME1);
        [notification addObserver:self
                         selector:@selector(getData1:)
                             name:NSFileHandleReadCompletionNotification
                           object:fh];
    }
    else if([textSign isEqualToString:NOTIFICATION_MESSAGE_NAME2])
    {
         NSLog(@"textSign:%@ NOTIFICATION_MESSAGE_NAME2:%@",textSign,NOTIFICATION_MESSAGE_NAME2);
        [notification addObserver:self
                         selector:@selector(getData2:)
                             name:NSFileHandleReadCompletionNotification
                           object:fh];
    }
    else if([textSign isEqualToString:NOTIFICATION_MESSAGE_RADAR])
    {
        NSLog(@"textSign:%@ NOTIFICATION_MESSAGE_RADAR:%@",textSign,NOTIFICATION_MESSAGE_RADAR);
        [notification addObserver:self
                         selector:@selector(getRadarData:)
                             name:NSFileHandleReadCompletionNotification
                           object:fh];
    }
    
    else
    {
        ;
    }
    [fh readInBackgroundAndNotify];
}

-(void)getData1:(NSNotification *) notification{
    NSString *progress=nil;
    NSData *data= [[notification userInfo] valueForKey:NSFileHandleNotificationDataItem];
    NSLog(@"dataReady:%ld bytes", [data length]);
    if([data length]){
        NSLog(@"+++++++++++");
        NSString * text1= [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"text1:%@",text1);
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        [dic setObject:text1 forKey:@"text1"];
        //Get progress
        progress=[filterString filter_return_progress:text1];
        NSLog(@"progress:%@",progress);
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_MESSAGE_NAME1
                                                            object:progress
                                                        userInfo:dic];
    }
    else{
        NSLog(@"-----------------------");
        NSString *end=@"end";
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_MESSAGE_NAME1
                                                            object:end
                                                          userInfo:nil];
        [self setTaskNil];
        return;
    }
    
    if (task){
        [[pipe fileHandleForReading] readInBackgroundAndNotify];
    }
}

-(void)getData2:(NSNotification *) notification{
    NSData *data= [[notification userInfo] valueForKey:NSFileHandleNotificationDataItem];
    NSLog(@"dataReady:%ld bytes", [data length]);
    if([data length]){
        NSLog(@"+++++++++++");
        NSString * text2 = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"text2:%@",text2);
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        [dic setObject:text2 forKey:@"text2"];
        NSString *progress=[filterString filter_return_progress:text2];
        NSLog(@"progress:%@",progress);
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_MESSAGE_NAME2
                                                            object:progress
                                                          userInfo:dic];
    }
    else{
        NSString *end=@"end";
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_MESSAGE_NAME2
                                                            object:end
                                                          userInfo:nil];

        NSLog(@"-----------------------");
        [self setTaskNil];
        return;
    }
    if (task){
        [[pipe fileHandleForReading] readInBackgroundAndNotify];
    }
    
}

-(void)getRadarData:(NSNotification *) notification{
    NSData *data= [[notification userInfo] valueForKey:NSFileHandleNotificationDataItem];
    NSLog(@"dataReady:%ld bytes", [data length]);
    if([data length]){
        NSLog(@"+++++++++++");
        NSString * radarText = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"radarText:%@",radarText);
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        [dic setObject:radarText forKey:@"radarText"];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_MESSAGE_RADAR
                                                            object:nil
                                                          userInfo:dic];
    }
    else{
        NSString *end=@"end";
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_MESSAGE_RADAR
                                                            object:end
                                                          userInfo:nil];
        NSLog(@"-----------------------");
        [self setTaskNil];
        return;
    }
    if (task){
        [[pipe fileHandleForReading] readInBackgroundAndNotify];
    }
    
}

-(void)setTaskNil{
    NSNotificationCenter *notification = [NSNotificationCenter defaultCenter];
    [notification removeObserver: self];
    [notification addObserver:self
           selector:@selector(taskTerminated:)
               name:NSFileHandleReadCompletionNotification
             object:task];
    task = nil;
}

- (void)taskTerminated:(NSNotification *)notification
{
    task = nil;
}

@end