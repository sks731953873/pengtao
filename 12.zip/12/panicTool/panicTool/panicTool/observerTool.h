//
//  observerTool.h
//  panicTool
//
//  Created by Tony on 17/5/8.
//  Copyright (c) 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern NSString* const NOTIFICATION_MESSAGE_NAME1;
extern NSString* const NOTIFICATION_MESSAGE_NAME2;
extern NSString* const NOTIFICATION_MESSAGE_RADAR;

@interface observerTool : NSViewController
-(instancetype) initWithArgArr:(NSArray*)array;

-(void)observerChange: (NSString *)textSign;
- (void)taskTerminated:(NSNotification *)notification;


@property (nonatomic, strong) NSArray *arguments;

@end
