#ifndef __GETTERMINALINFO__
#define __GETTERMINALINFO__


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#define OUT_SIZE   51200
int KanziCount;
extern char * getCurdate(void);
extern char * getKanziFromTerm(char *comm,char *errInfo);
extern char * getBundleFromTerm(char *comm,char *errInfo) ;
extern char * isFinishCoredump(char *comm,char *errInfo);
#endif  
