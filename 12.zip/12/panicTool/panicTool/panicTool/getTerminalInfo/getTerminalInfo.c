#include "getTerminalInfo.h"

static char *KanziInfo[5]={0};

/////////////////Get Current Time
char *getCurdate(void)
{
	char tm_mon[5]={0};
	char tm_mday[5]={0};
	char tmpdate[128]={0};

	char *curdate=NULL;
	time_t t,ret;
	struct tm *tm;
	ret=time(&t);
	tm=localtime(&t);
 
	sprintf(tm_mon,"%d",tm->tm_mon+1);	
	sprintf(tm_mday,"%d",tm->tm_mday);
	
    
	if((tm->tm_mon+1)<10)
	{strncat(tmpdate,"0",1);	}
	strncat(tmpdate,tm_mon,20);
	strncat(tmpdate,".",1);
	
	if((tm->tm_mday)<10)
	{strncat(tmpdate,"0",1);	}
	
	strncat(tmpdate,tm_mday,20);
	tmpdate[strlen(tmpdate)]=0;

    
	curdate=tmpdate;
	return curdate;
}

////////////////Get Terminal Info
static char * getTerminalInfo(char * comm,char *errInfo)
{
	FILE *read_fp;
	char *buf=NULL;
	char tmpbuf[OUT_SIZE];
	unsigned long chars_read=0;
	
	memset(tmpbuf,0,OUT_SIZE);
	read_fp=popen(comm,"r");
	if(read_fp==NULL)
	{
		errInfo="popen command fail";
		pclose(read_fp);
		return NULL;
	}
	else
	{
		if(KanziCount>1)
		{
			printf("Choose a device:\n");
		}
		printf("comm:%s\n",comm);
		chars_read=fread(tmpbuf,1,OUT_SIZE,read_fp);
		if(chars_read<=0)
		{
			memset(tmpbuf,0,OUT_SIZE);
			errInfo="fread read_fp fail";
			pclose(read_fp);
			return NULL;
		}
        else
        {
            pclose(read_fp);
            if(chars_read>5120)
            {
                return "finally have captured coredump" ;
            }
            buf=tmpbuf ;
        }
	}
	return buf;
}

//////////////If return value isn't null,have finally corefile
char * isFinishCoredump(char *comm,char *errInfo)
{
    return getTerminalInfo(comm,errInfo);
}

//////////////Get Kanzi info thought ls/dev/* comm
char * getKanziFromTerm(char *comm,char *errInfo)
{
	char *ret=NULL;
	char *sub = NULL, *brkt = NULL;
	char *tmpBuf=NULL; 
	char tmp[2];
	char KanziInfoSum[OUT_SIZE]={0};
	char *buf=NULL;
	KanziCount=0;
 
	ret=getTerminalInfo(comm,errInfo);
	if(ret==NULL)
	{
		return NULL;
	}
	else
	{
			
		while( (sub=strtok_r(ret,"\n", &brkt )) != NULL)
		{
				if((tmpBuf=strstr(sub,"KanziSWD-"))!=NULL)
				{	
					sprintf(tmp,"%d",KanziCount);
					strncat(KanziInfoSum,(const char *)tmp,strlen(tmp));
					strncat(KanziInfoSum,")",1);
					KanziInfo[KanziCount++]=tmpBuf;
					strncat(KanziInfoSum,(const char *)tmpBuf,strlen(tmpBuf));
					strncat(KanziInfoSum,",",1);
				}
			ret=NULL;
		}
	}
	buf=KanziInfoSum;	
    if(buf==NULL)
	{
		errInfo="KanziInfoSum is NULL";
	}

    //print all kanzi cable on terminal
    /*
	for(i=0;i<KanziCount;i++)
    {
        printf("%s\n",KanziInfo[i]);
    }
	*/
	return buf;
}

//////////////Get Bundle info from astrisctl isPanic comm
char * getBundleFromTerm(char *comm,char *errInfo)
{
	
	char *ret=NULL;
	char *sub = NULL, *brkt = NULL;
	char *tmpBuf=NULL,*tmpBundleInfo=NULL;
    
	ret=getTerminalInfo(comm,errInfo);
	if(ret==NULL)
	{
		return NULL;
	}
	else
	{
		while( (sub=strtok_r(ret,"\n", &brkt )) != NULL)
		{
			if((tmpBuf=strstr(sub,"OS version"))!=NULL)
			{
				tmpBuf=strstr(tmpBuf,"1");
				tmpBundleInfo=tmpBuf;
			}
			ret=NULL;
		}
	}
    printf("bundleInfo:%s\n",tmpBundleInfo);
	return tmpBundleInfo;
}
