//
//  AppDelegate.m
//  panicTool
//
//  Created by CoreOS_C03-4F_02 on 17/5/4.
//  Copyright (c) 2017年 Jim. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

@end
