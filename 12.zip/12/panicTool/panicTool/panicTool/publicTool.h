//
//  publicTool.h
//  publicTool
//
//  Created by Luke on 10/27/15.
//  Copyright (c) 2015 Luke. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
#import <AppKit/NSView.h>

@interface publicTool : NSView
+ (publicTool*)instance ;
- (NSTextView *)setTextView;
-(void) setScrollView: (NSScrollView *) ScrollView;

-(NSString *) create_radar: (NSString *) production titlePath:(NSString *)titlePath contentPath:(NSString *)contentPath;
-(void)createTable:(NSString*)directory tableName:(NSString*)tableName;

@end
