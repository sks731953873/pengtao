//
//  AppDelegate.h
//  panicTool
//
//  Created by CoreOS_C03-4F_02 on 17/5/4.
//  Copyright (c) 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

