//
//  filterString.m
//  panicTool
//
//  Created by Tony on 17/5/16.
//  Copyright (c) 2017年 Jim. All rights reserved.
//

#import "filterStringTool.h"
#include "FileTool.h"
#define RADAR_TEXT "/radar.txt"
#define TITLE_TEXT "/title.txt"
#define RADAR_CONTENT_TEXT "/radar_content.txt"

static NSArray *radarTextInfo=nil;
static NSArray *logInfo=nil;
static NSString *progress=nil;
static NSString *panicType=nil;
static NSString *radarNumber=nil;
static filterStringTool* tool=nil;
static unsigned int tmpSign=0;
static FileTool *fileTool=nil;
@implementation filterStringTool
{
   
}

+ (filterStringTool*)instance {
    if(tool == nil) {
        tool = [[filterStringTool alloc] init];
        fileTool=[FileTool instance];
    }
    return tool;
}

-(NSArray*)  filter_radar_info:(NSString*)logPath
{
    NSString* txtContent = [NSString stringWithContentsOfFile:logPath encoding:NSUTF8StringEncoding error:NULL];
    NSMutableArray* radarInfoArr = [NSMutableArray array] ;
    if(txtContent){
        
        //        NSString* radarTitle = @"\\n\\[Radar Title\\]\\n(.*)\\n\\s*\\n\\[Radar Description\\]\\n((.*\\n)*)";
        
        NSString* radarTitle = @"\\n\\[Radar Title\\]\\n.*?:(.*?)\\n(.*\\n)*SW\\sBundle:\\s(.*?)\\nConfig:\\s(.*?)\\nSerial:\\s(.*?)_(.*?)\\n";
        
        NSString *pattern_sum = [NSString stringWithFormat:@"%@", radarTitle];
        
        NSRegularExpression *regex = [[NSRegularExpression alloc] initWithPattern:pattern_sum options:NSRegularExpressionCaseInsensitive error:nil];
        
        NSArray *results = [regex matchesInString:txtContent options:0 range:NSMakeRange(0, txtContent.length)];
        //        NSLog(@"results: %@", results);
        
        for (NSTextCheckingResult *result in results){
            
            for(int i = 1; i<[result numberOfRanges]; i++){
                
                NSLog(@"[result numberOfRanges]: %lu", (unsigned long)[result numberOfRanges]);
                
                [radarInfoArr addObject:[txtContent substringWithRange:[result rangeAtIndex:i]]];
            }
        }
    }else{
        NSLog(@"txtContent is nil");
    }
    return radarInfoArr;
}

-(NSArray *)  filter_radar_title_and_content:(NSString *)radarTextPath
{
    radarTextInfo=nil;
    tmpSign=0;
    if(![fileTool isExist:radarTextPath])
    {   return nil;  }
    
    if(![fileTool isExist:[radarTextPath stringByAppendingString:@RADAR_TEXT]])
    {  return  nil;}
    
    if([fileTool isExist:[radarTextPath stringByAppendingString:@TITLE_TEXT]])
    {
        [fileTool removeFile:[radarTextPath stringByAppendingString:@TITLE_TEXT]];
    }
    if([fileTool isExist:[radarTextPath stringByAppendingString:@RADAR_CONTENT_TEXT]])
    {
        [fileTool removeFile:[radarTextPath stringByAppendingString:@RADAR_CONTENT_TEXT]];
    }
    if(![fileTool createFile:[radarTextPath stringByAppendingString:@TITLE_TEXT]])
    {return nil;}
    if(![fileTool createFile:[radarTextPath stringByAppendingString:@RADAR_CONTENT_TEXT]])
    {return nil;}
    
    NSString *content =[fileTool contentsAtPath:[radarTextPath stringByAppendingString:@RADAR_TEXT]];
    
    //filter radar title to radarTextPath/title.txt
    [content enumerateLinesUsingBlock:^(NSString *line, BOOL *stop)
     {
        if(tmpSign>3)
        {
            tmpSign++;
            [fileTool write:line at:[radarTextPath stringByAppendingString:@RADAR_CONTENT_TEXT] append:YES];
            [fileTool write:@"\n" at:[radarTextPath stringByAppendingString:@RADAR_CONTENT_TEXT] append:YES];
        }
        else
        {
            if(tmpSign==2 || tmpSign ==3)
            {
                tmpSign++;
            }
            if(tmpSign==1)
            {
                tmpSign++;
                [fileTool write:line at:[radarTextPath stringByAppendingString:@TITLE_TEXT] append:NO];
                radarTextInfo=[[NSArray alloc] initWithObjects:[radarTextPath stringByAppendingString:@TITLE_TEXT],nil];
            }
            if([line rangeOfString:@"[Radar Title]"].length>0)
            {
                tmpSign++;
            }
        }
         
    }];
    if(radarTextInfo!=nil)
    {
        radarTextInfo =[radarTextInfo arrayByAddingObject:[radarTextPath stringByAppendingString:@RADAR_CONTENT_TEXT]];
    }
    return radarTextInfo;
}



-(NSString *) filter_return_panicType :(NSString *)content
{
    panicType=nil;
    NSString *string=content;
    tmpSign=0;
    [string enumerateLinesUsingBlock:^(NSString *line, BOOL *stop)
     {
         if(tmpSign!=0)
         {
             tmpSign++;
             if(tmpSign==3)
             {
                 panicType =[line substringFromIndex:1];
                 if([panicType rangeOfString:@"MIPIDSI"].length>0)
                 {
                     panicType=@"MIPIDSI";
                 }
                 else if([panicType rangeOfString:@"FED err"].length>0)
                 {
                      panicType=@"FED err";
                 }
                 else if([panicType rangeOfString:@"WDT timeout"].length>0)
                 {
                     panicType=@"WDT timeout";
                 }
                 else if([panicType rangeOfString:@"Userspace"].length>0)
                 {
                     panicType=@"Userspace";
                 }
                 else if([panicType rangeOfString:@"EFI"].length>0)
                 {
                     panicType=@"EFI";
                 }
                 else
                 {
                     ;
                 }
                 tmpSign=0;;
             }
         }
         if([line rangeOfString:@"-Report-"].length>0)
         {
             tmpSign++;
         }
         else
         {
             return ;
         }
     }];
    return  panicType;
}

-(NSString *) filter_return_radarNumber:(NSString *)content
{
    radarNumber=nil;
    NSString *string=content;
    [string enumerateLinesUsingBlock:^(NSString *line, BOOL *stop)
     {
         if([line rangeOfString:@"Radar num is:"].length>0)
         {
             NSArray  *array = [line componentsSeparatedByString:@":"];
             if(array.count>=2)
             {
                 radarNumber=array[1];
             }
         }
         else
         {
             return ;
         }
     }];
    return  radarNumber;
}

-(NSString *) filter_return_progress :(NSString *)content
{
    progress=nil;
    NSString *string=content;
    [string enumerateLinesUsingBlock:^(NSString *line, BOOL *stop)
    {
        
         if([line rangeOfString:@">0"].length>0)
         {
             line=[line stringByReplacingOccurrencesOfString:@">0" withString:@""];
             progress=line;
         }
         else{
             return ;
         }
    }];
    return  progress;
}



-(NSArray *) filter_return_LogSize :(NSString *) content
{
    logInfo=nil;
    NSString *string=content;
    [string enumerateLinesUsingBlock:^(NSString *line, BOOL *stop)
    {
        if([line rangeOfString:@"factory-debug.zip"].length>0)
        {
            NSString *sourcePath=nil;
            sourcePath=[line substringFromIndex:1];
            if([fileTool isExist:sourcePath])
            {
                logInfo=[[NSArray alloc] initWithObjects:sourcePath,nil];
                NSDictionary *dic =[fileTool getAttributes:[line substringFromIndex:1]];
                NSInteger fileSize = [dic[NSFileSize] integerValue];
                NSString *sizeString=nil;
                if(fileSize>0 && fileSize<1000)
                {
                    sizeString=[NSString stringWithFormat:@"%ld",fileSize];
                    sizeString=[sizeString stringByAppendingString:@"B"];
    
                }
                else if((fileSize/1000)>0 && (fileSize/1000)<1000)
                {
                    sizeString=[NSString stringWithFormat:@"%ld",fileSize/1017];
                    sizeString=[sizeString stringByAppendingString:@"KB"];

                }
                else
                {
                    sizeString=[NSString stringWithFormat:@"%ld",fileSize/1000/1000];
                    sizeString=[sizeString stringByAppendingString:@"M"];
                }
                logInfo =[logInfo arrayByAddingObject:sizeString];
            }
            else
            {
                return;
            }
            
        }
    }];
    return logInfo;
}

@end


