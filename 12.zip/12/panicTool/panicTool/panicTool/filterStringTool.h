//
//  filterString.h
//  panicTool
//
//  Created by Tony on 17/5/16.
//  Copyright (c) 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface filterStringTool : NSObject
+ (filterStringTool*)instance ;
-(NSArray*) filter_return_LogSize :(NSString *) content;
-(NSString *) filter_return_progress :(NSString *)content;
-(NSString *) filter_return_panicType :(NSString *)content;
-(NSString *) filter_return_radarNumber:(NSString *)content;
-(NSArray *)  filter_radar_title_and_content:(NSString *)logPath;
-(NSArray*)  filter_radar_info:(NSString*)logPath;


@end

