//
//  panic_config.h
//  pythoncall
//
//  Created by coreos on 5/16/17.
//  Copyright © 2017 Leo Wen. All rights reserved.
//

#ifndef panic_config_h
#define panic_config_h

#include <stdio.h>
#import <Python/Python.h>

#define MODULE_NAME "cfgparser"

extern const char* listPanicTriage();
extern const char* getCMDWithTriage();


//printf("panic triage: %s\n", listPanicTriage());
//printf("=========>MIPIDSI = %s\n", getCMDWithTriage("MIPIDSI"));
//printf("====>halt error = %s\n", getCMDWithTriage("halt error"));


#endif /* panic_config_h */
