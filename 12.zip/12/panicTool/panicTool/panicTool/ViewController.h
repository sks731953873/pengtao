//
//  ViewController.h
//  panicTool
//
//  Created by CoreOS_C03-4F_02 on 17/5/4.
//  Copyright (c) 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "getTerminalInfo.h"


@interface ViewController : NSViewController
{
    NSString *marvinScript;
    NSString *errInfo;
    NSTask *task;
    NSPipe *pipe;
}

@property (strong) IBOutlet NSTextField *config;
@property (strong) IBOutlet NSTextField *sn;
@property (strong) IBOutlet NSButton *kanziLable1;
@property (strong) IBOutlet NSButton *kanziLable2;
@property (strong) IBOutlet NSButton *kanziLable3;
@property (strong) IBOutlet NSButton *kanziLable4;
@property (strong) IBOutlet NSScrollView *output1;
@property (weak) IBOutlet NSScrollView *output2;

@property (strong) IBOutlet NSPopUpButton *screen;
@property (strong) IBOutlet NSPopUpButton *test;
@property (strong) IBOutlet NSPopUpButton *buildPhase;
@property (strong) IBOutlet NSPopUpButton *HWType;
@property (strong) IBOutlet NSPopUpButton *swBundleBranch;
@property (strong) IBOutlet NSTextField *swBundle;

@property (weak) IBOutlet NSButton *selectClick;
@property (weak) IBOutlet NSProgressIndicator *progressIndicator1;
@property (weak) IBOutlet NSProgressIndicator *progressIndicator2;
@property (weak) IBOutlet NSProgressIndicator *progressIndicator3;
@property (weak) IBOutlet NSProgressIndicator *progressIndicator4;
@property (weak) IBOutlet NSTextField *progressLab1;
@property (weak) IBOutlet NSTextField *progressLab2;
@property (weak) IBOutlet NSTextField *progressLab3;
@property (weak) IBOutlet NSTextField *progressLab4;

- (IBAction)runButt:(id)sender;
- (IBAction)clearButt:(id)sender;
- (IBAction)exitButt:(id)sender;
- (IBAction)outputButt:(id)sender;



@end

