//
//  ViewController.m
//  panicTool
//
//  Created by CoreOS_C03-4F_02 on 17/5/4.
//  Copyright (c) 2017年 Jim. All rights reserved.
//

#import "ViewController.h"
#import "FileTool.h"
#import "observerTool.h"
#import "publicTool.h"
#import "panic_config.h"
#import "filterStringTool.h"
#define ISPanic         "/usr/local/bin/astrisctl isPanic"
#define LIST            "/usr/local/bin/astrisctl list"

@interface ViewController ()
@property(strong) observerTool *observerText1;
@property(strong) observerTool *observerText2;
@property(strong) observerTool *observerRadarText;
@end

@implementation ViewController
{
    FileTool *fileTool;
    publicTool *public;
    filterStringTool *filterString;
}

enum {
    AFTER_MARVIN_DONE=1,
    AFTER_COPY_LOGS_DONE,
    AFTER_FILE_RADAR_DONE,
    AFTER_UPLOAD_LOGS_RADAR_DONE,
    AFTER_UPDATE_TABLE_DONE,
}STATUS;

unsigned int curKanzi=0;
NSArray *kanziArr;
NSTextView *outputView1=nil;
NSTextView *outputView2=nil;
NSTimer *timer=nil;
NSString *currentLocalLogPath=nil;

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter ] addObserver:self
                                              selector:@selector(closeWindow)
                                                  name:NSWindowWillCloseNotification
                                                object:[NSApplication sharedApplication]. mainWindow] ;
    
    public=[publicTool instance];
    [public setScrollView:self.output1];
    [public setScrollView:self.output2];
    outputView1=[public setTextView];
    outputView2=[public setTextView];
    
    [self.output1  setDocumentView:outputView1];
    [self.output2  setDocumentView:outputView2];
    [self.view addSubview:self.output1 ];
    [self.view addSubview:self.output2 ];

    [self.progressIndicator1 setIndeterminate:NO];
    [self.progressIndicator2 setIndeterminate:NO];
    [self.progressIndicator3 setIndeterminate:NO];
    [self.progressIndicator4 setIndeterminate:NO];
    
    self.output2.hidden=true;
    self.output1.hidden =false;

    NSLog(@"main:%@",[NSThread currentThread]);
    
    [self handleInit];
    //[self handleKanziCable];
    filterString=[filterStringTool instance];
    fileTool= [FileTool instance];
    timer=[NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(timerAction:) userInfo:nil repeats:YES];  // time 10s
    [timer setFireDate:[NSDate distantFuture]];

}

-(void)timerAction:(id)sender
{
    NSArray *arr=nil;
    NSString *cmd=nil;
    NSLog(@"currentLocalLogPath:%@",currentLocalLogPath);
    NSLog(@"timerAction:");
    switch (STATUS) {
        case AFTER_COPY_LOGS_DONE:
            NSLog(@"filed radar");
            arr=[filterString filter_radar_title_and_content:currentLocalLogPath];
            cmd=[public create_radar:@"D21" titlePath:arr[0] contentPath:arr[1]];
            NSLog(@"==>cmd:%@",cmd);
            NSLog(@"arr[0]:%@,arr[1]:%@",arr[0],arr[1]);
            break;
            
        case AFTER_FILE_RADAR_DONE:
            NSLog(@"upload radar");
            cmd=@"/Users/frankie/Desktop/Logs/0516/panicTool/panicTool/panicTool/radartool bill_chen2:Panic_007 upload 32251314 /Users/frankie/Desktop/Panics/0516/7_KanziSWD-30EE5B_05.16.04.49.58/title.txt";
            break;
        default:
            break;
    }
    
    
    // In here, if you open, will filed a radar.
    /*
    NSArray *arguments = [NSArray arrayWithObjects:@"-c",cmd, nil];
    _observerRadarText= [[observerTool alloc] initWithArgArr:arguments];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFICATION_MESSAGE_RADAR object:nil];
    [_observerRadarText observerChange:NOTIFICATION_MESSAGE_RADAR];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0),^{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(handleRadarTextChange:)
                                                     name:NOTIFICATION_MESSAGE_RADAR
                                                   object:nil];
    
    });*/
}


-(void)handleMarvinTextChange:(NSNotification*) notification
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0),^{
    NSString *progress=notification.object;
    if([progress rangeOfString:@"end"].length>0)
    {
        NSString *content=outputView1.string;
        NSString *panicType=nil;
        STATUS=AFTER_MARVIN_DONE;
        switch (STATUS) {
            case AFTER_MARVIN_DONE:
                if(![self copyLogsStatus:content])
                {    return;  }
            case AFTER_COPY_LOGS_DONE:
                STATUS=AFTER_COPY_LOGS_DONE;
                panicType=[filterString filter_return_panicType:content];
                
                printf("=========>MIPIDSI = %s\n", getCMDWithTriage([panicType cStringUsingEncoding:NSASCIIStringEncoding]));

                [timer setFireDate:[NSDate distantPast]];
                sleep(11);
                NSLog(@"=======AFTER_FILE_RADAR_DONE");
            case AFTER_FILE_RADAR_DONE:
                STATUS=AFTER_FILE_RADAR_DONE;
                [timer setFireDate:[NSDate distantPast]];
                sleep(11);
                NSLog(@"=======AFTER_UPLOAD_LOGS_RADAR_DONE");
                
            case AFTER_UPLOAD_LOGS_RADAR_DONE:
                STATUS=AFTER_UPLOAD_LOGS_RADAR_DONE;
                [public createTable:currentLocalLogPath tableName:@"panic.csv"];
                
            case AFTER_UPDATE_TABLE_DONE:
                NSLog(@"fff");
                currentLocalLogPath=nil;
                
            break;
        }
        return;
    }
    else if (progress!=nil)
    {
        self.progressIndicator1.doubleValue=[progress integerValue];
    }
    else
    {
        ;
    }
    NSLog(@"handleTextChange thread:%@",[NSThread currentThread]);
    NSString *textContent = [[notification userInfo] objectForKey:@"text1"];
    if(textContent==nil)
    {  return ;}
    
    NSTextStorage *ts = [outputView1 textStorage];
    dispatch_async(dispatch_get_main_queue(), ^{
            [ts replaceCharactersInRange:NSMakeRange([ts length], 0) withString:textContent];
    });
    
   });
}



-(void)handleRadarTextChange:(NSNotification*) notification
{
    NSString *obj=notification.object;
    NSString *content=nil;
    NSString *radarNum=nil;
    if([obj rangeOfString:@"end"].length>0)
    {
        content=outputView1.string;
        NSLog(@"handle radar end status:%@",obj);
        switch (STATUS) {
            case AFTER_COPY_LOGS_DONE:
                NSLog(@"filed radar finally");
                radarNum=[filterString filter_return_radarNumber:content];
                if(radarNum==nil)
                {
                    NSLog(@"filed radar failed");
                }
                NSLog(@"filed radar success,radar number:%@",radarNum);
                break;
            case AFTER_FILE_RADAR_DONE:
                NSLog(@"upload finally");
                break;
            default:
                break;
        }
       [timer setFireDate:[NSDate distantFuture]];
       //When filed radar finally, this step is that upload logs to radar.
        return;
    }
    else
    {    }
    NSString *textContent = [[notification userInfo] objectForKey:@"radarText"];
    if(textContent==nil)
    {  return ;}
    
    NSTextStorage *ts = [outputView1 textStorage];
    dispatch_async(dispatch_get_main_queue(), ^{
        [ts replaceCharactersInRange:NSMakeRange([ts length], 0) withString:textContent];
    });
}



-(void)handleInit
{
    self.config.stringValue=@"";
    self.sn.stringValue=@"";
    self.swBundle.stringValue=@"";
    [self.screen setTitle:[self.screen itemTitleAtIndex:0]];
    [self.test setTitle:[self.test itemTitleAtIndex:0]];
    [self.buildPhase setTitle:[self.buildPhase itemTitleAtIndex:0]];
    [self.HWType setTitle:[self.HWType itemTitleAtIndex:0]];
    [self.swBundleBranch setTitle:[self.swBundleBranch itemTitleAtIndex:0]];
}


-(BOOL) handleUiData
{
    if(![self.screen indexOfSelectedItem])
    {return false;}
    if(![self.test indexOfSelectedItem])
    {return false;}
    if(![self.buildPhase indexOfSelectedItem])
    {return false;}
    if(![self.HWType indexOfSelectedItem])
    {return false;}
    if(![self.swBundleBranch indexOfSelectedItem])
    {return false;}
    
    if([[self.screen titleOfSelectedItem] isEqualToString:@""])
    {errInfo=@"screen is NULL"; return false;}
    if([[self.test titleOfSelectedItem] isEqualToString:@""])
    {errInfo=@"test station is NULL";return false; }
    if([[self.buildPhase titleOfSelectedItem] isEqualToString:@""])
    {
        errInfo=@"buildPhase is NULL";
        return false;
    }
    if([[self.HWType titleOfSelectedItem] isEqualToString:@""])
    {  errInfo=@"HWType is NULL"; return false;}
    
    if([[self.swBundleBranch titleOfSelectedItem] isEqualToString:@""])
    {errInfo=@"swBundleBranch is NULL";return false;}
    
    char *ret=getBundleFromTerm(ISPanic,(char *)[errInfo UTF8String]);
    if(ret==NULL)
    {
        errInfo=@"bundle info is NULL, please write sw bundle manaully";
        if([self.swBundle.stringValue isEqualToString:@""])
        {
            return false;
        }
    }
    

    if(ret!=NULL)
    {self.swBundle.stringValue=[[self.swBundleBranch titleOfSelectedItem] stringByAppendingString:[NSString stringWithCString:ret encoding:NSUTF8StringEncoding]];}
    else
    {self.swBundle.stringValue=[[self.swBundleBranch titleOfSelectedItem] stringByAppendingString:self.swBundle.stringValue];}
    
    
    
    if([self.sn.stringValue isEqualToString:@""])
    { errInfo=@"SN is NULL";return false; }
    
    
    if([self.config.stringValue isEqualToString:@""])
    {errInfo=@"config is NULL";return false; }
    NSArray *arr=[self.config.stringValue componentsSeparatedByString:@"_"];
    if(arr.count!=3){
        errInfo=@"Config len is incorrect";
        return false;
    }
    
    
    self.config.stringValue =arr[1];
    self.sn.stringValue =[self.sn.stringValue stringByAppendingString:@"_"];
    self.sn.stringValue =[self.sn.stringValue stringByAppendingString:arr[2]];
    return true;
}



-(void) handleKanziCable
{
    char *ret=getKanziFromTerm(LIST,(char *)[errInfo UTF8String]);
    if(ret==NULL)
    {
        outputView1.string=errInfo;
        return ;
    }
    kanziArr=[[NSString stringWithCString:ret encoding:NSUTF8StringEncoding] componentsSeparatedByString:@","];
    if(kanziArr.count==0)
    { return ;}
    
    for(int i=0;i<(kanziArr.count-1);i++)
    {
        if([[kanziArr objectAtIndex:i] isEqualToString:@""])
        {break;  }
        switch(i)
        {
            case 0:self.kanziLable1.title=[kanziArr objectAtIndex:i];self.progressLab1.stringValue=self.kanziLable1.title;self.progressIndicator1.doubleValue=0;break;
            case 1:self.kanziLable2.title=[kanziArr objectAtIndex:i];self.progressLab2.stringValue=self.kanziLable2.title;self.progressIndicator2.doubleValue=0;break;
            case 2:self.kanziLable3.title=[kanziArr objectAtIndex:i];self.progressLab3.stringValue=self.kanziLable3.title;self.progressIndicator3.doubleValue=0;break;
            case 3:self.kanziLable4.title=[kanziArr objectAtIndex:i];self.progressLab4.stringValue=self.kanziLable4.title;self.progressIndicator4.doubleValue=0;break;
            default: break;
        }
    }
}


-(BOOL)handleCopyLogs: (NSString *)sizeString sourcePath: (NSString *)sourcePath
{
    NSString *string=sizeString;
    if([string containsString:@"M"])
    {
        if([[string stringByReplacingOccurrencesOfString:@"M" withString:@""] intValue]>20)
        {
            // Copy /tmp/marvin/debug/6_KanziSWD-30F59E_05.09.10.19.42/factory-debug.zip to ~/Desktop/Panics/0512
            NSArray *array=[[sourcePath stringByReplacingOccurrencesOfString:@"/factory-debug.zip" withString:@""] componentsSeparatedByString:@"/"];
            NSArray *_array=[sourcePath componentsSeparatedByString:@"_"];
            NSString * time=[[_array[_array.count-1] substringWithRange:NSMakeRange(0, 5)] stringByReplacingOccurrencesOfString:@"." withString:@""];
            NSString *homeDir = NSHomeDirectory();
            NSString *targetPath=[homeDir stringByAppendingString:@"/Desktop/Panics/"];
            targetPath=[targetPath stringByAppendingString:time];
            targetPath=[targetPath stringByAppendingString:@"/"];
            targetPath=[targetPath stringByAppendingString:array[array.count-1]];
            NSLog(@"===>targetPath:%@",targetPath);
            if(![fileTool isExist:targetPath])
            {
                [fileTool createDirectory:targetPath];
            }
            
        
            currentLocalLogPath=targetPath;
            // /tmp/marvin/debug/6_KanziSWD-30F59E_05.09.10.19.42 to ~/Desktop/Panics/0509/6_KanziSWD-30F59E_05.09.10.19.42
            if([fileTool copyFrom:[sourcePath stringByReplacingOccurrencesOfString:@"/factory-debug.zip" withString:@""] to: targetPath])
            {
                return true;
            }
            else
            {
                return  false;
            }
        }
    }
    return  false;
}



-(BOOL)copyLogsStatus: (NSString *) content
{
    static NSString *logSize=nil;
    NSString *textContent =content;
    NSLog(@"textContent:%@",textContent);
    
    
    //1. Get factory-debug.zip size
    NSArray *logInfo=[filterString filter_return_LogSize:textContent];
    if(logInfo==nil)
    {
        NSLog(@"Source path is not exist");
        return false;
    }
    
    
    //2. Logs finally captured, copy logs to special path, but for size<20M,
    textContent=@"\n=================================\n";
    textContent=[textContent stringByAppendingString:logInfo[0]];
    textContent=[textContent stringByAppendingString:@"_"];
    textContent=[textContent stringByAppendingString:logInfo[1]];
    textContent=[textContent stringByAppendingString:@"\n"];
    logSize=logInfo[1];
    if([logInfo[1] rangeOfString:@"M"].length>0)
    {
        if([[logInfo[1] stringByReplacingOccurrencesOfString:@"M" withString:@""] intValue]>20)
        {
            if([self handleCopyLogs:logInfo[1] sourcePath:logInfo[0]])
            {
                NSLog(@"handle Logs ok");
                textContent=[textContent stringByAppendingString:@"处理copylogs成功\n\n\n\n\n\n\n"];
            }
            else
            {
                textContent=[textContent stringByAppendingString:@"处理copylogs失败\n\n\n\n\n\n\n"];
                return false;
            }
            NSTextStorage *ts = [outputView1 textStorage];
            dispatch_async(dispatch_get_main_queue(), ^{
                [ts replaceCharactersInRange:NSMakeRange([ts length], 0) withString:textContent];
            });
        }
    };
    return true;
}

- (IBAction)runButt:(id)sender
{
    if(!(self.kanziLable1.state==1 || self.kanziLable2.state==1 || self.kanziLable3.state==1 || self.kanziLable4.state==1))
    {
        outputView1.string=@"All KanziLable is close, please select kanzi number";
        return ;
    }
    long selectCount=self.kanziLable1.state + self.kanziLable2.state + self.kanziLable3.state +self.kanziLable4.state;
    if(selectCount!=1)
    {
        outputView1.string=@"每次只能选择一个Kanzi";
        return ;
    }
    NSLog(@"%ld",selectCount);
    // just select 1 kanzi cable
    /*
     if(![self handleUiData])
     { outputView.string=errInfo; return ; }
     
     NSLog(@"buildPhase:%@",[self.buildPhase titleOfSelectedItem] );
     NSLog(@"HWType:%@",[self.HWType titleOfSelectedItem] );
     NSLog(@"swBundle:%@",self.swBundle.stringValue);
     NSLog(@"screen:%@",[self.screen titleOfSelectedItem]);
     NSLog(@"test:%@",[self.test titleOfSelectedItem]);
     NSLog(@"SN:%@",self.sn.stringValue);
     NSLog(@"SN:%@",self.config.stringValue);
     
     //D12-PRO2_24R2PS_900247 C39TM01DJ578
     // Run script
     marvinScript=@"/Users/gdlocal/Desktop/coreostriage.sh";
     marvinScript=[marvinScript stringByAppendingString:@" "];
     marvinScript=[marvinScript stringByAppendingString:@"0"];
     marvinScript=[marvinScript stringByAppendingString:@" "];
     marvinScript=[marvinScript stringByAppendingString:[self.buildPhase titleOfSelectedItem]];
     marvinScript=[marvinScript stringByAppendingString:@" "];
     marvinScript=[marvinScript stringByAppendingString:[self.HWType titleOfSelectedItem]];
     marvinScript=[marvinScript stringByAppendingString:@" "];
     marvinScript=[marvinScript stringByAppendingString:self.swBundle.stringValue];
     marvinScript=[marvinScript stringByAppendingString:@" "];
     marvinScript=[marvinScript stringByAppendingString:[self.test titleOfSelectedItem]];
     marvinScript=[marvinScript stringByAppendingString:@" "];
     marvinScript=[marvinScript stringByAppendingString:[self.screen titleOfSelectedItem]];
     marvinScript=[marvinScript stringByAppendingString:@" "];
     marvinScript=[marvinScript stringByAppendingString:self.config.stringValue];
     marvinScript=[marvinScript stringByAppendingString:@" "];
     marvinScript=[marvinScript stringByAppendingString:self.sn.stringValue];
     NSLog(@"pythonScriptInfo:%@",marvinScript);
     outputView.string=marvinScript;
     outputView.string=[outputView.string stringByAppendingString:@"\n"];
     outputView.string=[outputView.string stringByAppendingString:@"################################\n"];
     */
    for(int i=1;i<5;i++)
    {
        switch (i) {
            case 1: if(self.kanziLable1.state==1)
            {
                curKanzi=1;
                outputView1.string=@"";
                self.output2.hidden=true;self.output1.hidden =false;
                [self.selectClick setTitle:self.kanziLable1.title];
                self.progressIndicator1.doubleValue=0;
                
                //If nanocom ok
                //marvin factory
                
                NSArray *arguments1 = [NSArray arrayWithObjects:@"-c",@"cat /tmp/kernel_panic", nil];
                
                NSArray *arguments = [NSArray arrayWithObjects:@"-c",@"cat /tmp/kernel_panic", nil];
                
                _observerText1= [[observerTool alloc] initWithArgArr:arguments];
                [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFICATION_MESSAGE_NAME1 object:nil];
                [_observerText1 observerChange:NOTIFICATION_MESSAGE_NAME1];
                
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0),^{
                    NSLog(@"run1:%@",[NSThread currentThread]);
                    [[NSNotificationCenter defaultCenter] addObserver:self
                                                             selector:@selector(handleMarvinTextChange:)
                                                                 name:NOTIFICATION_MESSAGE_NAME1
                                                               object:nil];
                });
                return;
            }
                break;
            case 2: if(self.kanziLable2.state==1)
            {
                curKanzi=2;
                outputView2.string=@"";
                self.output1.hidden=true;self.output2.hidden =false;
                [self.selectClick setTitle:self.kanziLable2.title];
                self.progressIndicator2.doubleValue=0;
                NSArray *arguments1 = [NSArray arrayWithObjects:@"-c",@"cat /Users/rd/Desktop/Jim2/panicTool/marvinlogs/kernel_panic", nil];
                
                
//                /Users/DemonZhu/Desktop/West/0601/panicTool/marvinlogs/kernel_panic
                
                
                NSArray *arguments = [NSArray arrayWithObjects:@"-c",@"cat /Users/DemonZhu/Desktop/West/0601/panicTool/marvinlogs/kernel_panic", nil];
                
                _observerText2= [[observerTool alloc] initWithArgArr:arguments];
                [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFICATION_MESSAGE_NAME2 object:nil];
                [_observerText2 observerChange:NOTIFICATION_MESSAGE_NAME2];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0),^{
                    NSLog(@"run2:%@",[NSThread currentThread]);
                    [[NSNotificationCenter defaultCenter] addObserver:self
                                                             selector:@selector(handleMarvinTextChange:)
                                                                 name:NOTIFICATION_MESSAGE_NAME2
                                                               object:nil];
                    
                    
                    
                });
                
                return;
            }
                break;
        }
    }
    //NSArray *arguments = [NSArray arrayWithObjects:@"-c",@"/Users/RDSW6/Desktop/Jim3/radar_test/radartool bill_chen2:Panic_007 create_radar Factory\\ Core\\ OS\\ Triage d21 /Users/RDSW6/Desktop/Jim3/radar_test/title.txt /Users/RDSW6/Desktop/Jim3/radar_test/radar_comtent.txt Crash/Hang/Data\\ Loss I\\ Didn\\'t\\ Try", nil];
}

- (IBAction)clearButt:(id)sender
{
    //[public createTable:@"/Users/frankie/Desktop/Panics/0516/7_KanziSWD-30EE5B_05.16.04.49.58" tableName:@"123.csv"];
    [self handleInit];
}

- (IBAction)exitButt:(id)sender
{
    
    [self closeWindow];
    //self.output.hidden=true;
}


- (IBAction)outputButt:(id)sender
{
    if(curKanzi>2)
    { curKanzi = 1;}
    NSLog(@"curKanzi:%d",curKanzi);
    switch (curKanzi) {
        case 1:
            self.output2.hidden=true;self.output1.hidden =false;
             self.kanziLable2.state=0;self.kanziLable1.state=1;
            self.selectClick.title=self.kanziLable1.title;
            break;
        case 2:
            self.output1.hidden=true;self.output2.hidden =false;
            self.kanziLable2.state=1;self.kanziLable1.state=0;
            self.selectClick.title=self.kanziLable2.title;
            
            break;
        default:
            break;
    }
    curKanzi++;
}


-(void) closeWindow
{
    [self handleInit];
    [NSApp terminate:self] ;
    [timer invalidate];
    timer=nil;
}


@end
