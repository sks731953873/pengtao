//
//  publicTool.m
//  publicTool
//
//  Created by Luke on 10/27/15.
//  Copyright (c) 2015 Luke. All rights reserved.
//
#import "publicTool.h"
#import "filterStringTool.h"
#define reproducible  "NoTry"
#define Classification "Crash/Hang/DataLoss"
#define component  "FactoryCoreOSTriage"
#define function  "create_radar"
#define accountPasswd "bill_chen2:Panic_007"
#define radartoolPath "/Users/frankie/Desktop/Logs/0516/panicTool/panicTool/panicTool/radartool"
@implementation publicTool
{

}
static filterStringTool *filterString=nil;
static publicTool* tool=nil;
static NSFileManager* fileManager = nil;
NSString* sandBox;

+ (publicTool*)instance {
    if(tool == nil) {
        tool = [[publicTool alloc] init];
        filterString=[filterStringTool instance];
        fileManager = [NSFileManager defaultManager];
        NSArray* path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        sandBox = [path objectAtIndex:0];
    }
    return tool;
}

- (NSTextView *)setTextView
{
    NSTextView *outputView =[[NSTextView alloc]initWithFrame:CGRectMake(72, 37, 730, 172)];
    [outputView setMinSize:NSMakeSize(0.0, 172)];
    [outputView setMaxSize:NSMakeSize(FLT_MAX, FLT_MAX)];
    [outputView setAutoresizingMask:NSViewWidthSizable];
    [[outputView textContainer]setContainerSize:NSMakeSize(60000,FLT_MAX)];
    [[outputView textContainer]setWidthTracksTextView:YES];
    [outputView setFont:[NSFont fontWithName:@"Helvetica" size:14.0]];
    outputView.editable =NO;
    return outputView;
}

-(void) setScrollView: (NSScrollView *) ScrollView
{
    [ScrollView setHasVerticalScroller:YES];[ScrollView setHasHorizontalScroller:YES];
    [ScrollView setAutoresizingMask:NSViewWidthSizable | NSViewHeightSizable];
}


-(NSString *) create_radar: (NSString *) production titlePath:(NSString *)titlePath contentPath:(NSString *)contentPath
{
    NSString *radarCmd=nil;
    radarCmd=@radartoolPath;
    radarCmd=[radarCmd stringByAppendingString:@" "];
    radarCmd=[radarCmd stringByAppendingString:@accountPasswd];
    radarCmd=[radarCmd stringByAppendingString:@" "];
    radarCmd=[radarCmd stringByAppendingString:@function];
    radarCmd=[radarCmd stringByAppendingString:@" "];
    radarCmd=[radarCmd stringByAppendingString:@component];
    radarCmd=[radarCmd stringByAppendingString:@" "];
    radarCmd=[radarCmd stringByAppendingString:production];
    radarCmd=[radarCmd stringByAppendingString:@" "];
    radarCmd=[radarCmd stringByAppendingString:titlePath];
    radarCmd=[radarCmd stringByAppendingString:@" "];
    radarCmd=[radarCmd stringByAppendingString:contentPath];
    radarCmd=[radarCmd stringByAppendingString:@" "];
    radarCmd=[radarCmd stringByAppendingString:@Classification];
    radarCmd=[radarCmd stringByAppendingString:@" "];
    radarCmd=[radarCmd stringByAppendingString:@reproducible];
    
    return radarCmd;
}



-(void)createTable:(NSString*)directory tableName:(NSString*)tableName{
    
    NSArray * fileArr = [fileManager  contentsOfDirectoryAtPath:directory error:NULL];
    
    NSArray* radarInfo=nil;
    
    if([fileArr containsObject:@"radar.txt"]){
        NSString* radarTxtPath = [directory stringByAppendingPathComponent:@"radar.txt"];
        radarInfo=[filterString filter_radar_info:radarTxtPath];
    }
    for(int i=0;i<radarInfo.count;i++)
    {
        NSLog(@"radarArr:%@",radarInfo[i]);
    }

    //在document中创建csv文件
    NSString* csvPath = [sandBox stringByAppendingPathComponent:tableName];
    NSLog(@"csvPath:%@",csvPath);
    
    //判断是否存在csv文件，若不存在，则创建
    if(![fileManager fileExistsAtPath:csvPath]){
        
        [fileManager createFileAtPath:csvPath contents:nil attributes:nil];
        
        NSOutputStream* output = [[NSOutputStream alloc] initToFileAtPath:csvPath append:YES];
        [output open];
        
        //生成头文件
        NSString* header = @"NO,Location,Station,Config,UNIT#,SrNm,Bundle,OSD Version,Panic info,Umbrella Radar,Radar,Status/Action,Comment/Solution,Date\n";
        const uint8_t *headerString = (const uint8_t *)[header cStringUsingEncoding:NSUTF8StringEncoding];
        NSInteger headerLength = [header lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
        NSInteger result = [output write:headerString maxLength:headerLength];
        if(result<=0){
            NSLog(@"cannot write content");
        }
        [output close];
    }
    
    NSMutableArray* CSVSNArr=[NSMutableArray array];
    //判断是否fdr.csv文件中的SN
    if([[NSFileManager defaultManager] fileExistsAtPath:csvPath]){
        
        NSString *fileContent = [NSString stringWithContentsOfFile:csvPath encoding:NSUTF8StringEncoding error:nil];
        NSLog(@"fileContent: %@", fileContent);
        id  tempStr = [fileContent componentsSeparatedByString:@"\r\n"];
        NSLog(@"tempStr: %@", tempStr);
        
        FILE *fp=fopen([csvPath UTF8String], "r");
        if (fp) {
            char buf[BUFSIZ];
            fgets(buf, BUFSIZ, fp);
            while (!feof(fp)) {
                char buf[BUFSIZ];
                fgets(buf, BUFSIZ, fp);
                
                // 处理文本信息转化成数组文件
                NSString *s=[[NSString alloc]initWithUTF8String:(const char *)buf];
                
                if([s isEqual:[NSNull null]] || s == nil){
                    CSVSNArr = NULL;
                }else{
                    NSString *ss=[s stringByReplacingOccurrencesOfString:@"\r" withString:@""];
                    ss=[ss stringByReplacingOccurrencesOfString:@"\n" withString:@""];
                    NSArray *a=[ss componentsSeparatedByString:@","];
                    [CSVSNArr addObject:a[4]];
                }
            }
            NSLog(@"CSVSNArr: %@", CSVSNArr);
        }
    }
    
    NSOutputStream* output = [[NSOutputStream alloc] initToFileAtPath:csvPath append:YES];
    [output open];
    
    NSString* radarNo = @"rdar://problem/%needToFill";
    
    NSString* row;
    if(CSVSNArr == NULL){
        row = [NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@\n",@"1",@"FXGL",@"Earthbound",radarInfo[3],radarInfo[5],radarInfo[4],radarInfo[2],@"\\",radarInfo[0],@"\\",radarNo,@"Have uploaded the coredump log",@"\\",[NSDate date]];
    }else{
        row = [NSString stringWithFormat:@"%lu,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@,%@\n",CSVSNArr.count,@"FXGL",@"Earthbound",radarInfo[3],radarInfo[5],radarInfo[4],radarInfo[2],@"\\",radarInfo[0],@"\\",radarNo,@"Have uploaded the coredump log",@"\\",[NSDate date]];
        
    }
    const uint8_t *rowString = (const uint8_t *)[row cStringUsingEncoding:NSUTF8StringEncoding];
    NSInteger rowLength = [row lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
    NSInteger result = [output write:rowString maxLength:rowLength];
    if (result<=0) {
        NSLog(@"cannot write content");
    }
    [output close];
}

@end
