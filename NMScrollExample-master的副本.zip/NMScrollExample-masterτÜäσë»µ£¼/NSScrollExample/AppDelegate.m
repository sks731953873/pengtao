//
//  AppDelegate.m
//  NSScrollExample
//
//  Created by wins on 14.10.13.
//  Copyright (c) 2013 wins. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"
#import <QuartzCore/QuartzCore.h>

#define leftPos     @"0"
#define middlePos   @"101"
#define rightPos    @"202"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
    [_scrollView setHasHorizontalRuler:NO];
    [_scrollView setHasVerticalRuler:NO];
    
    _controller = [[ViewController alloc] initWithNibName:@"ViewController"
                                                                  bundle:[NSBundle mainBundle]];
    
    NSView *view = [_controller view];
    
    view.layer = [CAScrollLayer layer];
	view.wantsLayer = YES;
	view.layerContentsRedrawPolicy = NSViewLayerContentsRedrawNever;
    
    [_scrollView setDocumentView:view];
    
    count = 0;
    
    self.timer = [NSTimer scheduledTimerWithTimeInterval:2.f target:self selector:@selector(nextItem) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSDefaultRunLoopMode];
    
   // dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        //[self nextItem];
        
    //});
    
    
    
}

-(void)nextItem{
    
    count++;
    
    NSButton *btn = [[NSButton alloc]init];
    [btn setButtonType:NSButtonTypeMomentaryPushIn];
    
    
    
    if (count%3 ==1) {
        [self scrollToXPosition:leftPos];
        
        NSButton *btn = (NSButton *)[self.window.contentView viewWithTag:1];
        btn.wantsLayer = YES;
        btn.layer.backgroundColor = [NSColor blueColor].CGColor;
        
        NSButton *btn2 = (NSButton *)[self.window.contentView viewWithTag:2];
        btn2.wantsLayer = YES;
        btn2.layer.backgroundColor = [NSColor whiteColor].CGColor;
        
        NSButton *btn3 = (NSButton *)[self.window.contentView viewWithTag:3];
        btn3.wantsLayer = YES;
        btn3.layer.backgroundColor = [NSColor whiteColor].CGColor;
        
    }else if (count%3 ==2){
        [self scrollToXPosition:middlePos];
        //[self performSelector:@selector(scrollToXPosition:) withObject:middlePos afterDelay:1];
        
        NSButton *btn = (NSButton *)[self.window.contentView viewWithTag:1];
        btn.wantsLayer = YES;
        btn.layer.backgroundColor = [NSColor whiteColor].CGColor;
        
        NSButton *btn2 = (NSButton *)[self.window.contentView viewWithTag:2];
        btn2.wantsLayer = YES;
        btn2.layer.backgroundColor = [NSColor blueColor].CGColor;
        
        NSButton *btn3 = (NSButton *)[self.window.contentView viewWithTag:3];
        btn3.wantsLayer = YES;
        btn3.layer.backgroundColor = [NSColor whiteColor].CGColor;
    }
    else{
        //[self performSelector:@selector(scrollToXPosition:) withObject:rightPos afterDelay:1];
        [self scrollToXPosition:rightPos];
        
        NSButton *btn = (NSButton *)[self.window.contentView viewWithTag:1];
        btn.wantsLayer = YES;
        btn.layer.backgroundColor = [NSColor whiteColor].CGColor;
        
        NSButton *btn2 = (NSButton *)[self.window.contentView viewWithTag:2];
        btn2.wantsLayer = YES;
        btn2.layer.backgroundColor = [NSColor whiteColor].CGColor;
        
        NSButton *btn3 = (NSButton *)[self.window.contentView viewWithTag:3];
        btn3.wantsLayer = YES;
        btn3.layer.backgroundColor = [NSColor blueColor].CGColor;
    }
    
}

- (IBAction)test:(id)sender {
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        [self nextItem];
    });
    
    
    
}



- (void)scrollToXPosition:(NSString*)xCoord {
    
    [NSAnimationContext beginGrouping];
    [[NSAnimationContext currentContext] setDuration:0.5];
    NSClipView* clipView = [_scrollView contentView];
    NSPoint newOrigin = [clipView bounds].origin;
    newOrigin.x = [xCoord floatValue];
    [[clipView animator] setBoundsOrigin:newOrigin];
    [_scrollView reflectScrolledClipView: [_scrollView contentView]]; // may not bee necessary
    [NSAnimationContext endGrouping];
}

- (IBAction)showRight:(id)sender {
    
    [self scrollToXPosition:rightPos];
    
    NSButton *btn = (NSButton *)[self.window.contentView viewWithTag:1];
    btn.wantsLayer = YES;
    btn.layer.backgroundColor = [NSColor whiteColor].CGColor;
    
    NSButton *btn2 = (NSButton *)[self.window.contentView viewWithTag:2];
    btn2.wantsLayer = YES;
    btn2.layer.backgroundColor = [NSColor whiteColor].CGColor;
    
    NSButton *btn3 = (NSButton *)[self.window.contentView viewWithTag:3];
    btn3.wantsLayer = YES;
    btn3.layer.backgroundColor = [NSColor blueColor].CGColor;
}

- (IBAction)showMiddle:(id)sender {
    
    [self scrollToXPosition:middlePos];
    
    NSButton *btn = (NSButton *)[self.window.contentView viewWithTag:1];
    btn.wantsLayer = YES;
    btn.layer.backgroundColor = [NSColor whiteColor].CGColor;
    
    NSButton *btn2 = (NSButton *)[self.window.contentView viewWithTag:2];
    btn2.wantsLayer = YES;
    btn2.layer.backgroundColor = [NSColor blueColor].CGColor;
    
    NSButton *btn3 = (NSButton *)[self.window.contentView viewWithTag:3];
    btn3.wantsLayer = YES;
    btn3.layer.backgroundColor = [NSColor whiteColor].CGColor;
}

- (IBAction)showLeft:(id)sender {
    
    [self scrollToXPosition:leftPos];
    
    NSButton *btn = (NSButton *)[self.window.contentView viewWithTag:1];
    btn.wantsLayer = YES;
    btn.layer.backgroundColor = [NSColor blueColor].CGColor;
    
    NSButton *btn2 = (NSButton *)[self.window.contentView viewWithTag:2];
    btn2.wantsLayer = YES;
    btn2.layer.backgroundColor = [NSColor whiteColor].CGColor;
    
    NSButton *btn3 = (NSButton *)[self.window.contentView viewWithTag:3];
    btn3.wantsLayer = YES;
    btn3.layer.backgroundColor = [NSColor whiteColor].CGColor;
}
@end
