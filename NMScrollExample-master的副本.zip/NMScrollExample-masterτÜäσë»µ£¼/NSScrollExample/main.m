//
//  main.m
//  NSScrollExample
//
//  Created by wins on 14.10.13.
//  Copyright (c) 2013 wins. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
