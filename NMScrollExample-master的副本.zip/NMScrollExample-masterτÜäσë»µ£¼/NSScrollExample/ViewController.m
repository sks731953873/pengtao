//
//  ViewController.m
//  NSScrollExample
//
//  Created by wins on 15.10.13.
//  Copyright (c) 2013 wins. All rights reserved.
//

#import "ViewController.h"

static NSArray *leftValues() {
    static NSArray *values = nil;
    if (!values) {
        values = [[NSArray alloc] initWithObjects:
                  @"Great notebook",
                  @"Not a bad notebook",
                  @"Good notebook",
                  @"Other good",
                  nil];
    }
    return values;
}


@interface ViewController ()

@end

@implementation ViewController

-(void)viewDidLoad{
    [super viewDidLoad];
    
//    dispatch_async(dispatch_get_global_queue(0, 0), ^{
//        
//        [self nextItem];
//        
//    });
    
}


//-(void)nextItem{
//
//    for (int i = 1; i < 4000; i++) {
//
//        if (i%3 ==1) {
//
//            [self performSelector:@selector(scrollToXPosition:) withObject:leftPos afterDelay:1];
//
//        }else if (i%3 ==2){
//
//            [self performSelector:@selector(scrollToXPosition:) withObject:middlePos afterDelay:1];
//        }
//        else{
//            [self performSelector:@selector(scrollToXPosition:) withObject:rightPos afterDelay:1];
//
//        }
//        sleep(1);
//
//    }
//
//
//}

#pragma mark - NSTableViewDataSource

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView{

    if ([tableView isEqual:_leftTable])
        return [leftValues() count];
    else
        if([tableView isEqual:_rightTable])
            return 3;
        else
            return 0;
    
}

- (id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    
    if ([tableView isEqual:_leftTable])
        return [leftValues() objectAtIndex:row];
    else
        if([tableView isEqual:_rightTable])
            return [NSString stringWithFormat:@"row %i",(int)(row+1)];
        else
            return 0;
}

#pragma mark - NSTableViewDelegate

@end
