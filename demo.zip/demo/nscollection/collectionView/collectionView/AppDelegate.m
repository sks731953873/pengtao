//
//  AppDelegate.m
//  collectionView
//
//  Created by 仝兴伟 on 2017/5/10.
//  Copyright © 2017年 仝兴伟. All rights reserved.
//

#import "AppDelegate.h"
#import "CollectionViewItem.h"
@interface AppDelegate ()<NSCollectionViewDataSource, NSCollectionViewDelegate, NSCollectionViewDelegateFlowLayout>

@property (weak) IBOutlet NSWindow *window;

@property (nonatomic, strong) NSArray *content;
@property (nonatomic, strong) NSCollectionView *collectionView;
@property (nonatomic, strong) NSScrollView *scrollView;
@property(strong,nonatomic)NSTimer *timer;

@end

#define leftPos     @"0"
#define middlePos   @"101"
#define rightPos    @"202"
#define rightPos3    @"303"
#define rightPos4    @"404"
#define rightPos5    @"505"
#define rightPos6    @"606"


@implementation AppDelegate
{
    int count;
    
}
- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    count = 0;
    [self addCollection];
    
    self.timer = [NSTimer scheduledTimerWithTimeInterval:2.f target:self selector:@selector(nextItem) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSDefaultRunLoopMode];
}

-(void)nextItem{
    
    count++;
    
    NSButton *btn = [[NSButton alloc]init];
    [btn setButtonType:NSButtonTypeMomentaryPushIn];
    
    
    
    if (count%6 ==1) {
        [self scrollToXPosition:leftPos];
        
        NSButton *btn = (NSButton *)[self.window.contentView viewWithTag:1];
        btn.wantsLayer = YES;
        btn.layer.backgroundColor = [NSColor blueColor].CGColor;
        
        NSButton *btn2 = (NSButton *)[self.window.contentView viewWithTag:2];
        btn2.wantsLayer = YES;
        btn2.layer.backgroundColor = [NSColor whiteColor].CGColor;
        
        NSButton *btn3 = (NSButton *)[self.window.contentView viewWithTag:3];
        btn3.wantsLayer = YES;
        btn3.layer.backgroundColor = [NSColor whiteColor].CGColor;
        
    }else if (count%6 ==2){
        [self scrollToXPosition:middlePos];
        //[self performSelector:@selector(scrollToXPosition:) withObject:middlePos afterDelay:1];
        
        NSButton *btn = (NSButton *)[self.window.contentView viewWithTag:1];
        btn.wantsLayer = YES;
        btn.layer.backgroundColor = [NSColor whiteColor].CGColor;
        
        NSButton *btn2 = (NSButton *)[self.window.contentView viewWithTag:2];
        btn2.wantsLayer = YES;
        btn2.layer.backgroundColor = [NSColor blueColor].CGColor;
        
        NSButton *btn3 = (NSButton *)[self.window.contentView viewWithTag:3];
        btn3.wantsLayer = YES;
        btn3.layer.backgroundColor = [NSColor whiteColor].CGColor;
    }
    else if (count%6 ==3){
        [self scrollToXPosition:rightPos];
        
    }
    else if (count%6 ==4){
        [self scrollToXPosition:rightPos3];
        
    }
    else if (count%6 ==5){
        [self scrollToXPosition:rightPos4];
        
    }
//    else if (count%6 ==6){
//        [self scrollToXPosition:rightPos5];
//
//    }
    
    else{
        //[self performSelector:@selector(scrollToXPosition:) withObject:rightPos afterDelay:1];
        [self scrollToXPosition:rightPos5];
        
        NSButton *btn = (NSButton *)[self.window.contentView viewWithTag:1];
        btn.wantsLayer = YES;
        btn.layer.backgroundColor = [NSColor whiteColor].CGColor;
        
        NSButton *btn2 = (NSButton *)[self.window.contentView viewWithTag:2];
        btn2.wantsLayer = YES;
        btn2.layer.backgroundColor = [NSColor whiteColor].CGColor;
        
        NSButton *btn3 = (NSButton *)[self.window.contentView viewWithTag:3];
        btn3.wantsLayer = YES;
        btn3.layer.backgroundColor = [NSColor blueColor].CGColor;
    }
}


- (void)scrollToXPosition:(NSString*)xCoord {
    
    [NSAnimationContext beginGrouping];
    [[NSAnimationContext currentContext] setDuration:0.1];
    NSClipView* clipView = [_scrollView contentView];
    NSPoint newOrigin = [clipView bounds].origin;
    newOrigin.x = [xCoord floatValue];
    [[clipView animator] setBoundsOrigin:newOrigin];
    [_scrollView reflectScrolledClipView: [_scrollView contentView]]; // may not bee necessary
    [NSAnimationContext endGrouping];
}


- (void)dataSource {
    NSImage *computerimage = [NSImage imageNamed:NSImageNameComputer];
    NSImage *folderimage = [NSImage imageNamed:NSImageNameFolder];
    NSImage *homeimage = [NSImage imageNamed:NSImageNameHomeTemplate];
    NSImage *listimage = [NSImage imageNamed:NSImageNameListViewTemplate];
    NSImage *networkimage = [NSImage imageNamed:NSImageNameNetwork];
    NSImage *shareimage = [NSImage imageNamed:NSImageNameShareTemplate];
    
    NSDictionary *item1 =@{
                            @"title":@"computer",
                            @"image":computerimage
                            };
    
    NSDictionary *item2 =@{
                           @"title":@"folder",
                           @"image":folderimage};
    
    NSDictionary *item3 =@{
                            @"title":@"home",
                            @"image":homeimage
                            };
    
    NSDictionary *item4 =@{
                           @"title":@"list",
                           @"image":listimage
                           };
    
    NSDictionary *item5 =@{
                           @"title":@"network",
                           @"image":networkimage
                           };
    
    NSDictionary *item6 =@{
                           @"title":@"share",
                           @"image":shareimage
                           };
    
    self.content = @[
                      item1,
                      item2,
                      item3,
                      item4,
                      item5,
                      item6,
                      ];
    [self.collectionView reloadData];
}


#pragma mark -- addCollection
- (void)addCollection {
    // 创建scrollview
    NSCollectionViewFlowLayout *layout = [[NSCollectionViewFlowLayout alloc]init];
    layout.minimumLineSpacing = 0;
    layout.minimumInteritemSpacing = 0;
    layout.itemSize = NSMakeSize(100, 100);
    layout.scrollDirection = NSCollectionViewScrollDirectionHorizontal;
    layout.sectionInset = NSEdgeInsetsMake(0, 0, 0, 0);
    
//    self.collectionView = [[NSCollectionView alloc]initWithFrame:NSMakeRect(0, 0, 500, 500)];
    
    self.collectionView = [[NSCollectionView alloc]   initWithFrame:NSMakeRect(0, 0, 660, 110)];

    self.collectionView.collectionViewLayout = layout;

    [self.collectionView registerClass:[CollectionViewItem class] forItemWithIdentifier:@"Slide"];
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;

    [self.collectionView setSelectable:YES];
    
//    self.collectionContentView = [[NSScrollView alloc]initWithFrame:NSMakeRect(0, 0, 300, 300)];
    
#pragma mark -- NSScrollView
    //self.scrollView = [[NSScrollView alloc]initWithFrame:[self.window.contentView bounds]];
    
    self.scrollView = [[NSScrollView alloc] initWithFrame:NSMakeRect(200, 200, 100, 100)];
    
    [[_scrollView horizontalScroller] setAlphaValue:0];
    _scrollView.hasVerticalScroller = NO;
    _scrollView.hasHorizontalScroller = NO;
    //_scrollView.scrollerInsets.bottom = -999;
    
    //NSLog(@"_scrollView.scrollerInsets.bottom: %f", _scrollView.scrollerInsets.bottom);
    
#pragma mark -- 给NSScrollView添加自动布局
    
    // 给collectionview添加背景颜色
//    [self.collectionView setWantsLayer:YES];
//    self.collectionView.layer.backgroundColor = [NSColor purpleColor].CGColor;
    
    [self.scrollView setDocumentView:self.collectionView];
    [self.window.contentView addSubview:self.scrollView];
    
    
//    self.scrollView.translatesAutoresizingMaskIntoConstraints = NO;
//
//    [self.scrollView.topAnchor constraintEqualToAnchor:self.window.contentView.topAnchor].active = YES;
//    [self.scrollView.bottomAnchor constraintEqualToAnchor:self.window.contentView.bottomAnchor].active = YES;
//
//    [self.scrollView.leadingAnchor constraintEqualToAnchor:self.window.contentView.leadingAnchor].active = YES;
//
//    [self.scrollView.trailingAnchor constraintEqualToAnchor:self.window.contentView.trailingAnchor].active = YES;

    [self dataSource];
}

#pragma mark -- collectionView delegate
- (NSInteger)numberOfSectionsInCollectionView:(NSCollectionView *)collectionView  {
    return 1;
}


- (NSInteger)collectionView:(NSCollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    if (self.content.count == 0) {
        return 0;
    }
    return self.content.count;
}


//-(NSSize)collectionView:(NSCollectionView *)collectionView layout:(NSCollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
//    return NSMakeSize(50, 50);
//}

- (NSCollectionViewItem *)collectionView:(NSCollectionView *)collectionView itemForRepresentedObjectAtIndexPath:(NSIndexPath *)indexPath {
    CollectionViewItem *item = [collectionView makeItemWithIdentifier:@"Slide" forIndexPath:indexPath];
    item.representedObject = self.content[indexPath.item];
#pragma mark -- item 添加背景颜色
//     [item.view setWantsLayer:YES];
//    [item.view.layer setBackgroundColor:[NSColor redColor].CGColor];
    return item;
}

- (void)collectionView:(NSCollectionView *)collectionView didSelectItemsAtIndexPaths:(NSSet<NSIndexPath *> *)indexPaths {
    NSLog(@"----%lu", (unsigned long)collectionView.selectionIndexes.firstIndex);
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}


- (BOOL)applicationShouldHandleReopen:(NSApplication *)sender hasVisibleWindows:(BOOL)flag{
    [self.window makeKeyAndOrderFront:self];
    return YES;
}


- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender{
    return YES;
}

@end
