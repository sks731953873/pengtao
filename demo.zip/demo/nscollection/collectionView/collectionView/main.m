//
//  main.m
//  collectionView
//
//  Created by 仝兴伟 on 2017/5/10.
//  Copyright © 2017年 仝兴伟. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
