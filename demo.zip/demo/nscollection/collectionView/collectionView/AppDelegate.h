//
//  AppDelegate.h
//  collectionView
//
//  Created by 仝兴伟 on 2017/5/10.
//  Copyright © 2017年 仝兴伟. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

