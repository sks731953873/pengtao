## Introduction ##

Example of using NSScrollView for UI with animation. It created with KISS principle.

also:
[![Build Status](https://travis-ci.org/w-i-n-s/NMScrollExample.png)](https://travis-ci.org/w-i-n-s/NMScrollExample)
because
'The project 'NSScrollExample' does not contain a scheme named "NSScrollExample"'

