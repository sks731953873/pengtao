//
//  WindowController.m
//  SYFlatButton
//
//  Created by Sunnyyoung on 2016/11/18.
//  Copyright © 2016年 Sunnyyoung. All rights reserved.
//

#import "WindowController.h"

@interface WindowController ()

@end

@implementation WindowController

- (void)windowDidLoad {
    [super windowDidLoad];
    self.window.titleVisibility = NSWindowTitleHidden;
    self.window.titlebarAppearsTransparent = YES;
}

@end
