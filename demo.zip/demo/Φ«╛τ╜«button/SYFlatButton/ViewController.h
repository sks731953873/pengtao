//
//  ViewController.h
//  SYFlatButton
//
//  Created by Sunnyyoung on 2016/11/18.
//  Copyright © 2016年 Sunnyyoung. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController

@end
