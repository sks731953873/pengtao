//
//  AppDelegate.h
//  setCommandTools
//
//  Created by mac on 2017/9/6.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property(strong)NSWindowController* mainWindowController;

@end

