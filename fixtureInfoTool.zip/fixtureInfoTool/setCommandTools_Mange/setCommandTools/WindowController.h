//
//  WindowController.h
//  HowToWorks
//
//  Created by h on 17/3/29.
//  Copyright © 2017年 bill. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface WindowController : NSWindowController
//实例化
+(instancetype)windowController;

@end
