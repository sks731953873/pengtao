//
//  ViewController.m
//  setCommandTools
//
//  Created by mac on 2017/9/6.
//  Copyright © 2017年 macjinlongpiaoxu. All rights reserved.
// 11.550

#import "ViewController.h"
#import "ORSSerialPort.h"
#import "GetTimeDay.h"


typedef void (^fixtureBlock)(NSString * backString);

@interface ViewController()<ORSSerialPortDelegate>
{
    IBOutlet NSButton      *  collectButton;   //按钮
    ORSSerialPort          *  fixtureSerial;   //治具串口
    NSMutableString        *  appendString;
    NSString               *  backStr;
    NSString               * outBackString;
    
    IBOutlet NSTextField *SN_TF;
    IBOutlet NSTextField *CP_TF;
    IBOutlet NSTextField *showFixtureCP_TF;
    IBOutlet NSTextField *upDateFixtureID_TF;
    IBOutlet NSTextField *showFixtureID_TF;
    IBOutlet NSTextField *successLable;
}

@property(nonatomic,copy)fixtureBlock  backBlock;

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    appendString = [[NSMutableString alloc]initWithCapacity:10];
    fixtureSerial=[ORSSerialPort serialPortWithPath:@"/dev/cu.usbserial-EW-FIX"];
    fixtureSerial.baudRate=@B115200;
    fixtureSerial.delegate=self;

    // Do any additional setup after loading the view.
}



- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}



- (IBAction)openBtnAction:(id)sender {
    
    [fixtureSerial open];
    
    if ([fixtureSerial isOpen]) {
        
       [collectButton setTitle:@"Connect(连接)"];
    }
    else
    {
         [collectButton setTitle:@"DisConnect(断开)"];
    }
    
    
}



- (IBAction)set_ID_action:(id)sender {
    
    
    if ([fixtureSerial isOpen]) {
        
        
        NSString  * timeString =[[GetTimeDay shareInstance] getFixtureTime];
        
        NSString   *  commandString = [NSString stringWithFormat:@"setFixtureID %@.%@",timeString,SN_TF.stringValue];
        
        if ([SN_TF.stringValue length] !=4) {
            
           
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                successLable.stringValue =@"SN 输入有误";
                successLable.backgroundColor = [NSColor redColor];
                 [showFixtureID_TF setStringValue:@""];
            });
        }
        else
        {
            //存储在沙盒中
            [[NSUserDefaults standardUserDefaults] setObject:SN_TF.stringValue forKey:@"SN"];
            
            //写入当前的值
            [self Fixture:fixtureSerial writeCommand:commandString];
            
            sleep(1);
            //读取当前的值
            [self Fixture:fixtureSerial writeCommand:@"Fixture ID?"];
            
            dispatch_queue_t  queue = dispatch_queue_create("test", NULL);
            
            dispatch_async(queue, ^{
                
                sleep(0.01);
                
                [self returnBackStringWithString:@"*_*" withTimeOut:0.6 withRepeatTime:1 andTextField:showFixtureID_TF andRangeLength:17];
                
            });
       }
    }
    else
    {
        [showFixtureID_TF setStringValue:@"fixture disConnect!!!!!"];
    }
}


/**
 *  <#Description#>
 *
 *  @param sender <#sender description#>
 */

- (IBAction)update_ID_Action:(id)sender {
    
     NSString  * timeString =[[GetTimeDay shareInstance] getFixtureTime];
    
     //从沙盒中得到SN
    
    NSString  *  SN = [[NSUserDefaults standardUserDefaults] objectForKey:@"SN"];

    NSString   *  commandString = [NSString stringWithFormat:@"setFixtureID %@.%@",timeString,SN];

    //写入当前的值
    [self Fixture:fixtureSerial writeCommand:commandString];
    sleep(1);
    
    
    
    [self Fixture:fixtureSerial writeCommand:@"Fixture ID?"];
    
    dispatch_queue_t  queue = dispatch_queue_create("test", NULL);

        
        dispatch_async(queue, ^{
            
            sleep(0.01);
            
            [self returnBackStringWithString:@"*_*" withTimeOut:0.6 withRepeatTime:1 andTextField:upDateFixtureID_TF andRangeLength:17];
            
        });
}



- (IBAction)set_CP_Action:(id)sender {
    
    
    if ([fixtureSerial isOpen]) {
        
        
        if ([CP_TF.stringValue length]!=0&&[CP_TF.stringValue length]<=6) {
            
            NSString   *  commandString = [NSString stringWithFormat:@"setFixture_CP %@",CP_TF.stringValue];
            
            //写入当前的值
            [self Fixture:fixtureSerial writeCommand:commandString];
            sleep(1);
            //写入当前的值
            [self Fixture:fixtureSerial writeCommand:@"Fixture_CP?"];
            
            dispatch_queue_t  queue = dispatch_queue_create("test", NULL);
            
            
            dispatch_async(queue, ^{
                
                sleep(0.01);
                
                //CP值请参考fixtureID 后面的值进行设置
                [self returnBackStringWithString:@"*_*" withTimeOut:0.6 withRepeatTime:1 andTextField:showFixtureCP_TF andRangeLength:6];
            
            });
            
            
        }
        
        else{//直接提示输入有误
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                successLable.stringValue =@"CP 输入有误";
                successLable.backgroundColor = [NSColor redColor];
                
            });
            
        }
    }
    else
    {
        
        [showFixtureCP_TF setStringValue:@"fixture disConnect!!!!!"];
        
    }
}



#pragma mark------------------串口代理方法
-(void)serialPort:(ORSSerialPort *)serialPort didReceiveData:(NSData *)data
{
    
    
    //backStr=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    if (serialPort==fixtureSerial)
    {
         NSString* str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        [appendString appendString:str];
        
        if ([appendString containsString:@">>"]) {
            
            appendString =[NSMutableString stringWithString:@""];
        }
        
        if (self.backBlock&&appendString.length>0&&[appendString containsString:@"*_*"]) {
              self.backBlock(appendString);
              appendString =[NSMutableString stringWithString:@""];
            
           }
        
        
    }
}



#pragma mark--------------------ORSSerialPort串口中发送指令
-(void)Fixture:(ORSSerialPort *)serialPort writeCommand:(NSString *)command
{
    NSString * commandString =[NSString stringWithFormat:@"%@\r\n",command];
    NSData    * data =[commandString dataUsingEncoding:NSUTF8StringEncoding];
    [serialPort sendData:data];
}



#pragma mark--------------------超时等待

/**
 *  <#Description#>
 *
 *  @param endString <#endString description#>
 *  @param timeout   <#timeout description#>
 *  @param reTime    <#reTime description#>
 *  @param textField <#textField description#>
 *  @param length    <#length description#>
 *
 *  @return <#return value description#>
 */

-(NSString  *)returnBackStringWithString:(NSString *)endString withTimeOut:(NSInteger)timeout withRepeatTime:(NSInteger)reTime andTextField:(NSTextField *)textField andRangeLength:(int)length
{
    
        float timeStart = [[GetTimeDay shareInstance] getMillSecond];
        
        float timenum;
        
        for (int i=0; ; i++)
        {
            
            sleep(0.01);
            
            timenum = [[GetTimeDay shareInstance] getMillSecond] - timeStart;
            
            __weak typeof(self) weakSelf = self;
            
            weakSelf.backBlock = ^(NSString * backString)
            {
                backStr = backString;
                
                NSLog(@"%@-------------------%@",backString,backStr);
                
                if ([backStr containsString:endString]) {
                    
                    NSLog(@"返回来的字符串========%@",backStr);
                    //替代字符串
                    backStr=[backStr stringByReplacingOccurrencesOfString:@"\r\n" withString:@""];
                    NSLog(@"打印替代之后的字符串%@",backStr);
                    NSRange range = [backStr rangeOfString:@"?"];
                    backStr = [backStr substringWithRange:NSMakeRange(range.location+1, length)];
                     NSLog(@"打印截取后的值%@",backStr);
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        [textField setStringValue:backStr];
                        
                        if ([backStr containsString:SN_TF.stringValue]||[backStr containsString:CP_TF.stringValue]||[backString containsString:[[NSUserDefaults standardUserDefaults] objectForKey:@"SN"]]) {
                            successLable.stringValue =@"success";
                            successLable.backgroundColor = [NSColor greenColor];
                        }
                        else
                        {
                            successLable.stringValue =@"fail";
                            successLable.backgroundColor = [NSColor redColor];
                        
                        }
                        
                        
                        backStr=@"";
                    });
                    
                    
                   // break;
                    
                }

                
            };
            
            
            if (timenum>=timeout) {
                
                break;
            }
            
        }
    return backStr;


}

@end
